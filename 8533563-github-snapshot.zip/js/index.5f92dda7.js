import { ab as I, Q as J, _ as S, __tla as __tla_0 } from "./index.bb04cb73.js";
import { r as g, w as b, e as D, a9 as V, o as l, J as H, c as m, U as h, V as Q, a as s, L as B, u as v, _ as A, W as d, Y as U, M as k, T as M, ao as E, m as _ } from "./@vue.b00de3e9.js";
import { u as W } from "./vue-i18n.07fcbeea.js";
import { u as Y } from "./vuex.33ea5d58.js";
import "./vue-router.c227d4ba.js";
import "./axios.853f16bf.js";
import "./element-plus.53baa8a9.js";
import "./@element-plus.e21ea623.js";
import "./@ctrl.11979b50.js";
import "./dayjs.9abdbee1.js";
import "./clipboard.aaae98d3.js";
import "./@vueuse.eccd744a.js";
import "./lodash-es.e1022fb5.js";
import "./@popperjs.da591b4f.js";
import "./vant.f7b4805b.js";
import "./@vant.f52f09a9.js";
import "./xe-utils.a532b55a.js";
import "./crypto-js.c184c643.js";
import "./decimal.js.2def1975.js";
import "./nprogress.9fc41f77.js";
import "./vconsole.0cfb1d33.js";
import "./perfect-scrollbar.19f80865.js";
import "./@intlify.928cb664.js";
let yt;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e) {
    }
  })()
]).then(async () => {
  const Z = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAMAAAANIilAAAADAFBMVEVMaXH83dP9ViP/95r/+JBpvKPt6uLquI33us7+9NX/xlH/6tL9SCTI5/359fbfWPuQ0/a53PmhzPX+9dn/76X+7nfc8P/6MBD/wFX9eUr+yGT+3NT9n2ZYvSz62sX9ijj+eUv/7CQjzMrT8P/0NR3oaPfnRfClyv3dR/T91qqVo/X/x1v/5aT/xYP/sYT+Xi7lTfT7sq3++vX86uT/6RYv09n4uojQ6f/+2pSk1Pz9kFj1YFH7PBH+cEHsP+z/6Khcwityf+x+m/X+wyn+ZS//4Jz9d03/1YkW09URxMKH5ej/+4nkb/v//J3++sbkaPuu6+H/+sP97uf+5Rz+y3F/9/q29fdg0M/6zf//zWL6Kgrqn4m52P692/7+hFDcUPeR6V9u1TyV6mb27/dnbOL/0JL+Sx8QsbH5+PD//pf9Rxj+YC/9TSGN21Duc/nzvu5B39vtlfb/4g3/0Apl+v7958iOsvqoyvz8zv/829v/7zilvvv74P/85v+TlOdZvyqX5mGP5mCLqfjmYP/40Jz+81r/9yT/9Vr/hUv8gV0UwsH/1LgW2t7sgfz/053933D+QRb8pxL1Jgr9RhX9thD7PRL/sm/9zBL//eH4Lg36NhD/9Ln/93L8lwv+vw78nhH+xQ7/+oP/+679TBv+4l36kA3/+F/+jVf9bDL9RBv/7YX//Ln6d0D9Zj7+1Rf1TRT/z6z/tXz5rD7/1Zn8YDD+6zn5cFP8sRX8sCn/8qj/+6P8oVz/3aL8hRD9YyD/71HkfPf93R/5tFz/yKT7VhH/0LT/wZL/5sb+rYv/3q7+x2Sn7e/N6Oj/4Lv/+tP/0or+62acwC/2gWf6chn+4Dn4jiH7nS70Zgz/1370RzX+6JH/wnn/6LT+2yv/+8nyxBbfuhvHozr9x0Letqz0mpj8iB/mgd6XrPRxdemtnt/+dyyxe8XPXpPWcx7BzMjY4qLu8bzveJa+mbHvfAfOycLjZYVyqRvUjTaApiVynBvloxeCmiTgTtHqa5/13KL7zTGX4HbDAAAApXRSTlMAH/7+/ggMAwcTFP4O+0f8F0AqNmT8951EJLkqcJ7x/Mz6OLX9Mx/4931S1oz+UOym/Fe66oX5y+pnuf3M7llDG/zw+TrJ4/npavPream9+fuQzNWgqozHznzo69H7+Na84nKS/O1b/HzDRL/C97b29v6cYsqdvLar3L59hPjwwEeY/mXqx5ro4Jz+U7FfPvX///////////////////////////7y4NEcAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFRElEQVR42u3WdVAbWRgA8E2yEEII7u5ubakLFajT0qu7Xd3Pved+M7tsEiRGFJIQAkkILsWheN2Fll69PdeZexuk0zYb0sz0v9s/kkx2f/vt+773vX0Q9HIPGy+q5dh2U6Cvl42FmDq9Jj9vQryFeuf+hGJ6g6elT24Xv6Pd0/KBe8fYWGw9Y2yfzoMzzeyU+Xo/bSHnWR9tJxm/9tlarVj77F/RP77quNvIQEjvrPEZQoPhbGOezxXAVkbCfvDhmuHneS3zdUOuBu+xbcu2J9dHz5plBPscsh95xOWFeEjfaR4p4MvqwMefbBk5FT17thG8OHJz2PDvpCQQ0y40I9sDx1utZm6dOXzq/U+N4bDISIfPBgNQk5aDH1SPdRk4hvz8/I6OgLdvvWUs1WGbHRwWGzQ16L3B6eVlh39Z+fmNBLaOiJhsvAMTh3XSF0SFd4qIcCQ4leiw9Ae8hl9+hU8jm+fLaT1x4wbCHj945Ah9iQsErXWFoPDIpWFPlL3hM4Sx0ZnI0hYdqrvBQ2O+o4LbJ86wORg+dMLe3d19YshEBoMxmXAqp7k9rhuolvJqAsFUC58xIzF8JHAIw92dwdjgRGhpsKSgru6mlCdlJfg+MzSqo5OTk7MVcQ8tExkwT4DWnJv6jbXhPytH8/qPBivhx0sHpAALfr0nD6Thcvx887CrUHl5wOFfYFHN3XsIMpfkPNlcbD1JqMzy/+cUT1Dff/vuOQSRTyetXLVwNT5gu5Sde03i5LOUrixRfjVPcPvWT5pGgIF2dgI5stuP5eRMM7nipJ5VZmVltTcK0LIyJrOahSAINtfQ4fvkrHXTPExhn3lVXQBXBFSjpUwm8+q139UIIg7E52kCea+d6RdPbHcnsJeV9TW4vXLg2rVeNSInewMVONd6lDpN0rYAKxJeyENx3Ctg9d5H5OKAWAhK+XqKr5fJOnW30bu6REKuW56Gyefze6+q/7iPYeIaiQv+3jBpoVRtC52uhLlcuLlAA/DV3/78GwOYfMlt1DeGi6KKTu+kcLlCysXmmjI+P/fKXxiCqfS667XLhq4hnKhp8EV6S9FZLpfC4TTl6cpyc3P5GKbvYKQ/VCiGVuQ3CNJms6iipaUtjs2FRRxOUauKXJaZmdso7+/oOH6849FQ6JUkomktond2FxefB7b8fGUBGdfV4gf9+huApwcbLgoheMXtgZUc7QV2sZbD4VDc8lRkufh0Jqo63qfqa32UvvDw9wuCg8evIlp+KpTlcezi5iIQWCG5rhPLWayAOesX6lX6vh63h4fnf7tr12qCIUfBIpGwnd1c1NQJ7MljJ+QIKydH98sDnUpVUFtbuyR4wYJgop7YUS6CZZLioqamBmAvFZZiwGZnqDX5Ot2dkpKSJSaKTJp3sYIr44LADa31J48VZuaeATY7I+NMqSb/dFCQcLepnqhqE8pkcFtRQ2tewRxg+SgLt0D/jF7vOe9PMrGEzKvS9siElHJg88kngGWiJww2I7SgcsLnUaZ2IcnatgvtXJhCiQNWjEmZpaiA14jTqTf8x401vYFJq9Ky2QoYdpPgloWhwEqr1ef6xry73WW0FZdSxWazuxU9JZcEGF4itVQqPaWZ4D/OfvQdmGuFoh5oSQlIcyMLZDlbfZrt/8pYs/ZueypkbHblpgC8RHiWQ/VjzJRg4aNwZe2gFcTSTJDlU/ox4+xpZm+zo2CZrPYOGcNYvNL6SW++gASdnCqpLQlCMZZ86vpYFxr0QkdyXCWeqYApUS4vvrtdUZl/c463K8miLfGUhH3x1tD/x0s+/gN8ixq4OfwQVwAAAABJRU5ErkJggg==";
  let j, N, O, G, K;
  j = {
    key: 0,
    class: "toast-message-box"
  };
  N = {
    class: "rewardPopup"
  };
  O = {
    class: "rewardBox"
  };
  G = {
    key: 0,
    class: "currencyBox"
  };
  K = {
    key: 1,
    class: "currencyBox activityBox"
  };
  yt = {
    __name: "index",
    setup($) {
      const z = E(() => S(() => import("./wg_activation_icon.ef2d4ca3.js"), ["js/wg_activation_icon.ef2d4ca3.js","js/@vue.b00de3e9.js"]));
      W();
      const f = Y(), c = g(false), x = g(false), e = _({
        message: "",
        amount: "",
        activation: "",
        time: 2e3,
        fun: ""
      }), w = g(1e4 + f.state.zIndex);
      b(() => c, (t) => {
        t || (x.value = true);
      });
      const y = (t = {
        message: "",
        amount: "",
        activation: "",
        time: "",
        fun: ""
      }) => {
        c.value = true, Object.assign(e, t), setTimeout(() => {
          q();
        }, 100);
      };
      D(() => {
        globalVBus.$on("toastReward", y), f.state.zIndex++;
      });
      const L = () => {
        x.value = true;
      }, T = () => {
        setTimeout(() => {
          if (c.value = false, e.fun)
            try {
              e.fun();
            } catch (e2) {
            }
        }, e.time);
      }, q = () => {
        const t = document.querySelector(".toastMsgCanvas"), n = t.getContext("2d"), u = parseFloat(getComputedStyle(document.documentElement).fontSize), R = 4.88 * u, X = 4.88 * u;
        t.width = R, t.height = X;
        function C(o) {
          if (n.clearRect(0, 0, t.width, t.height), !o)
            return;
          const a = (t.width - o.naturalWidth) / 2, i = (t.height - o.naturalHeight) / 2;
          n.drawImage(o, a, i);
        }
        function F(o) {
          const a = [];
          for (let i = 1; i <= o; i++)
            a.push(new Promise((p) => {
              const r = new Image();
              r.src = new URL("/img_wg/toast_message/" + i + ".png", import.meta.url).href, r.onload = () => p(r);
            }));
          return Promise.all(a);
        }
        F(19).then((o) => {
          const a = o.length, p = 1e3 / a;
          let r = 0;
          function P() {
            r < a ? (C(o[r]), r++, setTimeout(P, p)) : n.clearRect(0, 0, t.width, t.height);
          }
          P();
        });
      };
      return (t, n) => {
        const u = V("svg-icon");
        return l(), H(M, {
          to: "body"
        }, [
          c.value ? (l(), m("div", {
            key: 0,
            class: "toast-dialog-wg",
            style: k({
              zIndex: w.value
            })
          }, [
            h(U, {
              name: "zoomIn",
              appear: "",
              onBeforeEnter: L,
              onAfterEnter: T
            }, {
              default: Q(() => [
                c.value ? (l(), m("div", j, [
                  s("div", N, [
                    n[1] || (n[1] = s("img", {
                      src: Z,
                      alt: "",
                      class: ""
                    }, null, -1)),
                    s("div", {
                      class: B([
                        "text",
                        {
                          "text-9": v(f).state.layoutMode === 9
                        }
                      ])
                    }, A(e.message), 3),
                    s("div", O, [
                      e.amount ? (l(), m("div", G, [
                        s("i", null, [
                          h(u, {
                            iconClass: v(I)()
                          }, null, 8, [
                            "iconClass"
                          ])
                        ]),
                        s("span", null, A(v(J)(e.amount)), 1),
                        n[0] || (n[0] = s("canvas", {
                          class: "toastMsgCanvas"
                        }, null, -1))
                      ])) : d("", true),
                      e.activation ? (l(), m("div", K, [
                        s("i", null, [
                          h(v(z), {
                            class: "svg-icon"
                          })
                        ]),
                        s("span", null, A(e.activation), 1)
                      ])) : d("", true)
                    ])
                  ])
                ])) : d("", true)
              ]),
              _: 1
            })
          ], 4)) : d("", true)
        ]);
      };
    }
  };
});
export {
  __tla,
  yt as default
};
