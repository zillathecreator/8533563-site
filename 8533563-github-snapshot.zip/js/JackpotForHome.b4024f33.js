import { k as U, R as k, Q as H, _ as Y, $ as M, av as V, __tla as __tla_0 } from "./index.bb04cb73.js";
import { _ as W, a as q, b as z, c as K, d as Q, e as G, f as X, g as Z, h as tt, i as ot, j as st, k as et, l as at, m as it, n as _t, o as lt, p as nt, q as ct, r as pt, s as rt, t as mt, u as ut } from "./jackpot_home_9.c9bb2337.js";
import { _ as N, p as dt, a as gt, b as kt, c as vt } from "./pool_arrow.22261be2.js";
import { _ as jt } from "./hourglass.f13eb720.js";
import { _ as ht, a as yt, b as bt, c as wt, d as ft } from "./jackpot_home_5.321480ad.js";
import { b as It } from "./vue-router.c227d4ba.js";
import { u as Ot, __tla as __tla_1 } from "./useNumberAnimation.b686b495.js";
import { u as $t } from "./vuex.33ea5d58.js";
import { u as xt } from "./useCountdown.d80d51b6.js";
import { u as Ht } from "./vue-i18n.07fcbeea.js";
import { w as Mt, n as Nt, aa as Et, o as i, c as _, a as t, R as w, ab as At, L as f, _ as s, W as p, a5 as E, u as r, O as Rt, M as St, J as Pt, ao as Tt, r as Bt, l as v } from "./@vue.b00de3e9.js";
import "./axios.853f16bf.js";
import "./element-plus.53baa8a9.js";
import "./@element-plus.e21ea623.js";
import "./@ctrl.11979b50.js";
import "./dayjs.9abdbee1.js";
import "./clipboard.aaae98d3.js";
import "./@vueuse.eccd744a.js";
import "./lodash-es.e1022fb5.js";
import "./@popperjs.da591b4f.js";
import "./vant.f7b4805b.js";
import "./@vant.f52f09a9.js";
import "./xe-utils.a532b55a.js";
import "./crypto-js.c184c643.js";
import "./decimal.js.2def1975.js";
import "./nprogress.9fc41f77.js";
import "./vconsole.0cfb1d33.js";
import "./perfect-scrollbar.19f80865.js";
import "./@intlify.928cb664.js";
let es;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e) {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch (e) {
    }
  })()
]).then(async () => {
  let Ct, Dt, Lt, Jt, Ft, Ut, Yt, Vt, Wt, qt, zt, Kt, Qt, Gt, Xt, Zt, to, oo, so, eo, ao, io, _o, lo, no, co, po, ro, mo, uo, go, ko, vo, jo, ho, yo, bo, wo, fo, Io, Oo, $o, xo;
  Ct = {
    key: 0,
    class: "jackpot-home-modules"
  };
  Dt = {
    key: 0,
    class: "jackpot-info"
  };
  Lt = {
    class: "time-box"
  };
  Jt = {
    class: "time-filter"
  };
  Ft = [
    "onClick"
  ];
  Ut = {
    key: 0,
    class: "join-icon"
  };
  Yt = {
    class: "time-box"
  };
  Vt = {
    class: "pool-time"
  };
  Wt = {
    key: 0
  };
  qt = {
    key: 1
  };
  zt = {
    key: 2
  };
  Kt = {
    class: "jackpot-pool"
  };
  Qt = {
    class: "pool-header"
  };
  Gt = {
    class: "label"
  };
  Xt = {
    class: "value"
  };
  Zt = {
    class: "pool-main"
  };
  to = [
    "src"
  ];
  oo = {
    class: "pool-countdown"
  };
  so = {
    class: "countdown"
  };
  eo = {
    class: "square"
  };
  ao = {
    class: "square"
  };
  io = {
    class: "square"
  };
  _o = {
    class: "participation-data"
  };
  lo = {
    class: "data-item join-num"
  };
  no = {
    class: "value"
  };
  co = {
    class: "label"
  };
  po = {
    class: "data-item bet-min"
  };
  ro = {
    class: "value"
  };
  mo = {
    class: "label"
  };
  uo = {
    class: "data-item bet-rate"
  };
  go = {
    class: "value"
  };
  ko = {
    class: "label"
  };
  vo = {
    class: "data-item my-bet"
  };
  jo = {
    class: "value"
  };
  ho = {
    class: "label"
  };
  yo = {
    class: "action-buttons"
  };
  bo = {
    key: 0,
    class: "jackpot-banner",
    src: ht
  };
  wo = {
    key: 1,
    class: "jackpot-banner",
    src: yt
  };
  fo = {
    key: 2,
    class: "jackpot-banner",
    src: bt
  };
  Io = {
    key: 3,
    class: "jackpot-banner",
    src: wt
  };
  Oo = {
    key: 4,
    class: "jackpot-banner",
    src: ft
  };
  $o = [
    "src"
  ];
  xo = {
    __name: "JackpotForHome",
    props: {
      noNumberBg: {
        type: Boolean,
        default: false
      },
      width: {
        type: String,
        default: "7.1rem"
      }
    },
    setup(I) {
      const A = Tt(() => Y(() => import("./JackpotNum.b61f554a.js").then(async (m) => {
        await m.__tla;
        return m;
      }), ["js/JackpotNum.b61f554a.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/useNumberAnimation.b686b495.js","css/JackpotNum.ef3f7d4f.css"])), R = I, O = It(), d = $t(), { t: j } = Ht(), { animatedValue: S } = Ot(() => {
        var _a;
        return ((_a = d.state.jackpotInfo) == null ? void 0 : _a.totalPrizePoolAmount) || 0;
      }, {
        interval: 20
      }), c = {
        HOUR: 4,
        DAY: 1,
        WEEK: 2,
        MONTH: 3
      }, $ = {
        [c.HOUR]: dt,
        [c.DAY]: gt,
        [c.WEEK]: kt,
        [c.MONTH]: vt
      }, x = {
        [c.HOUR]: j("jackpot.hour"),
        [c.DAY]: j("jackpot.day"),
        [c.WEEK]: j("jackpot.week"),
        [c.MONTH]: j("jackpot.month")
      }, { timeLeft: y, startCountdown: P, stopCountdown: T } = xt(), g = Bt(c.HOUR), a = v(() => d.state.jackpotInfo || {}), b = v(() => {
        var _a;
        return [
          ...((_a = a.value) == null ? void 0 : _a.jackPotCfgList) || []
        ].sort((e, m) => {
          const n = [
            4,
            1,
            2,
            3
          ];
          return n.indexOf(e.cycle) - n.indexOf(m.cycle);
        });
      }), l = v(() => b.value.find((o) => o.cycle === g.value) || {}), u = v(() => b.value.find((o) => o.participated) || {}), B = v(() => {
        var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k;
        const o = ((_a = a.value) == null ? void 0 : _a.showPosition) || 1, e = ((_d = (_c = (_b = a.value) == null ? void 0 : _b.ext) == null ? void 0 : _c.showStyle) == null ? void 0 : _d.style) || 1, m = ((_f = (_e = a.value) == null ? void 0 : _e.ext) == null ? void 0 : _f.initMin) || 0, n = ((_h = (_g = a.value) == null ? void 0 : _g.ext) == null ? void 0 : _h.initMax) || 999999999;
        let h = "";
        return e === 99 ? h = (_k = (_j = (_i = a.value) == null ? void 0 : _i.ext) == null ? void 0 : _j.showStyle) == null ? void 0 : _k.styleImg : h = new URL(Object.assign({
          "../../../assets/img_wg/jackpot/jackpot_home_1.png": W,
          "../../../assets/img_wg/jackpot/jackpot_home_10.png": q,
          "../../../assets/img_wg/jackpot/jackpot_home_11.png": z,
          "../../../assets/img_wg/jackpot/jackpot_home_12.png": K,
          "../../../assets/img_wg/jackpot/jackpot_home_13.png": Q,
          "../../../assets/img_wg/jackpot/jackpot_home_14.png": G,
          "../../../assets/img_wg/jackpot/jackpot_home_15.png": X,
          "../../../assets/img_wg/jackpot/jackpot_home_16.png": Z,
          "../../../assets/img_wg/jackpot/jackpot_home_17.png": tt,
          "../../../assets/img_wg/jackpot/jackpot_home_18.png": ot,
          "../../../assets/img_wg/jackpot/jackpot_home_2.png": st,
          "../../../assets/img_wg/jackpot/jackpot_home_22.png": et,
          "../../../assets/img_wg/jackpot/jackpot_home_3.png": at,
          "../../../assets/img_wg/jackpot/jackpot_home_4-10.png": it,
          "../../../assets/img_wg/jackpot/jackpot_home_4-9.png": _t,
          "../../../assets/img_wg/jackpot/jackpot_home_4.png": lt,
          "../../../assets/img_wg/jackpot/jackpot_home_4_12.png": nt,
          "../../../assets/img_wg/jackpot/jackpot_home_5.png": ct,
          "../../../assets/img_wg/jackpot/jackpot_home_6.png": pt,
          "../../../assets/img_wg/jackpot/jackpot_home_7.png": rt,
          "../../../assets/img_wg/jackpot/jackpot_home_8.png": mt,
          "../../../assets/img_wg/jackpot/jackpot_home_9.png": ut
        })["../../../assets/img_wg/jackpot/jackpot_home_".concat(e, ".png")], self.location).href, {
          showPosition: o,
          styleImg: h,
          minAmount: m,
          maxAmount: n
        };
      });
      Mt(() => l.value.periodEnd, (o) => {
        T(), Nt(() => {
          P(o);
        });
      }, {
        immediate: true
      });
      const C = (o) => $[o] || $[c.HOUR], D = (o) => {
        g.value = o;
      }, L = () => {
        var _a;
        if ((_a = u.value) == null ? void 0 : _a.taskId)
          return;
        const o = {
          optType: 1,
          promotionId: a.value.promotionId,
          taskId: l.value.taskId
        };
        !o.promotionId || !o.taskId || M.post("/user/promotion/jackpotOpt", o).then((e) => {
          d.dispatch("getJackpotInfo");
        });
      }, J = () => {
        var _a;
        if (!((_a = u.value) == null ? void 0 : _a.taskId))
          return;
        const o = {
          optType: 2,
          promotionId: a.value.promotionId,
          taskId: u.value.taskId
        };
        !o.promotionId || !o.taskId || M.post("/user/promotion/jackpotOpt", o).then((e) => {
          d.dispatch("getJackpotInfo");
        });
      }, F = () => {
        var _a, _b;
        if (((_a = a.value) == null ? void 0 : _a.type) === 0)
          O.push("/jackpot");
        else {
          const { redirect: o, redirectUrl: e } = ((_b = a.value) == null ? void 0 : _b.ext) || {};
          if (o) {
            let n = {
              redirect: o,
              redirectUrl: e
            };
            o === 20 && (n = {
              redirect: Number(e)
            }), V(n);
            return;
          }
          const m = d.state.tableList.filter((n) => !!n.vendors.length && ![
            0,
            98,
            99
          ].includes(n.type));
          O.push("/sub-game?typeId=".concat(m[0].type));
        }
      };
      return (o, e) => {
        var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o2, _p, _q, _r, _s, _t2, _u, _v, _w, _x, _y, _z, _A, _B, _C, _D;
        const m = Et("throttle");
        return ((_a = Object.keys(a.value)) == null ? void 0 : _a.length) ? (i(), _("div", Ct, [
          ((_d = (_c = (_b = a.value) == null ? void 0 : _b.ext) == null ? void 0 : _c.showStyle) == null ? void 0 : _d.canOpt) ? (i(), _("div", Dt, [
            t("div", Lt, [
              t("div", Jt, [
                (i(true), _(w, null, At(b.value, (n) => (i(), _("div", {
                  class: f([
                    "filter-btn",
                    {
                      active: g.value === n.cycle
                    }
                  ]),
                  onClick: (h) => D(n.cycle)
                }, [
                  g.value !== n.cycle && n.participated ? (i(), _("div", Ut, s(o.$t("jackpot.joined")), 1)) : p("", true),
                  E(" " + s(x[n.cycle]), 1)
                ], 10, Ft))), 256))
              ]),
              t("div", Yt, [
                e[0] || (e[0] = t("div", {
                  class: "time-line"
                }, null, -1)),
                t("div", Vt, [
                  t("span", null, s(o.$t("jackpot.time")), 1),
                  ((_e = l.value) == null ? void 0 : _e.period) ? (i(), _(w, {
                    key: 0
                  }, [
                    l.value.cycle === c.HOUR ? (i(), _("span", Wt, s(r(k)(l.value.period, "HH:II")) + "-" + s(r(k)(l.value.periodEnd, "HH:II")), 1)) : p("", true),
                    [
                      c.DAY,
                      c.WEEK
                    ].includes(l.value.cycle) ? (i(), _("span", qt, s(r(k)(l.value.period, "DD/MM")) + "-" + s(r(k)(l.value.periodEnd, "DD/MM")), 1)) : p("", true),
                    l.value.cycle === c.MONTH ? (i(), _("span", zt, s(r(k)(l.value.period, "MM/YYYY")), 1)) : p("", true)
                  ], 64)) : p("", true)
                ])
              ])
            ]),
            t("div", Kt, [
              t("div", Qt, [
                t("p", Gt, s(o.$t("jackpot.pool")), 1),
                t("p", Xt, [
                  e[1] || (e[1] = t("img", {
                    class: "arrow arrow-left",
                    src: N,
                    alt: "Arrow Left"
                  }, null, -1)),
                  t("span", null, s(r(H)(l.value.prizePoolAmount)), 1),
                  e[2] || (e[2] = t("img", {
                    class: "arrow arrow-right",
                    src: N,
                    alt: "Arrow Right"
                  }, null, -1))
                ])
              ]),
              t("div", Zt, [
                t("img", {
                  class: "pool-main__box",
                  src: C(g.value),
                  alt: "jackpot pool"
                }, null, 8, to)
              ]),
              t("div", oo, [
                e[5] || (e[5] = t("img", {
                  src: jt,
                  alt: "Timer",
                  class: "timer-icon"
                }, null, -1)),
                t("p", so, [
                  t("span", eo, s(r(y).hours), 1),
                  e[3] || (e[3] = t("span", {
                    class: "split"
                  }, ":", -1)),
                  t("span", ao, s(r(y).minutes), 1),
                  e[4] || (e[4] = t("span", {
                    class: "split"
                  }, ":", -1)),
                  t("span", io, s(r(y).seconds), 1)
                ])
              ])
            ]),
            t("div", _o, [
              t("div", lo, [
                t("p", no, s(l.value.joinNum), 1),
                t("p", co, s(o.$t("jackpot.join_num")), 1)
              ]),
              t("div", po, [
                t("p", ro, s(l.value.singleBetInjectRatioMin), 1),
                t("p", mo, s(o.$t("jackpot.min_bet")), 1)
              ]),
              t("div", uo, [
                t("p", go, s(l.value.singleBetInjectRatio) + "%", 1),
                t("p", ko, s(o.$t("jackpot.inject_ratio")), 1)
              ]),
              t("div", vo, [
                t("p", jo, s(l.value.userInjectAmount), 1),
                t("p", ho, s(o.$t("jackpot.my_inject")), 1)
              ])
            ]),
            t("div", yo, [
              t("div", {
                class: "cancel-btn mobile-1px-all-radius",
                onClick: J
              }, s(o.$t("jackpot.cancel")), 1),
              Rt((i(), _("div", {
                class: f([
                  "join-btn",
                  {
                    disabled: !!u.value.taskId
                  }
                ])
              }, [
                E(s(u.value.taskId ? "".concat(o.$t("jackpot.joined")).concat(x[u.value.cycle]).concat(o.$t("jackpot.pool")) : o.$t("jackpot.join")), 1)
              ], 2)), [
                [
                  m,
                  L
                ]
              ])
            ])
          ])) : (i(), _("div", {
            key: 1,
            class: "no-btn",
            style: St({
              "--jackpot-card-width": R.width
            }),
            onClick: F
          }, [
            ((_f = a.value) == null ? void 0 : _f.type) === 1 ? (i(), Pt(r(A), {
              key: 0,
              itemInfo: B.value,
              noNumberBg: I.noNumberBg
            }, null, 8, [
              "itemInfo",
              "noNumberBg"
            ])) : (i(), _(w, {
              key: 1
            }, [
              t("div", {
                class: f([
                  "pool-num",
                  "style-" + ((_i = (_h = (_g = a.value) == null ? void 0 : _g.ext) == null ? void 0 : _h.showStyle) == null ? void 0 : _i.style)
                ])
              }, s(r(H)(r(S))), 3),
              ((_l = (_k = (_j = a.value) == null ? void 0 : _j.ext) == null ? void 0 : _k.showStyle) == null ? void 0 : _l.style) === 1 ? (i(), _("img", bo)) : p("", true),
              ((_o2 = (_n = (_m = a.value) == null ? void 0 : _m.ext) == null ? void 0 : _n.showStyle) == null ? void 0 : _o2.style) === 2 ? (i(), _("img", wo)) : p("", true),
              ((_r = (_q = (_p = a.value) == null ? void 0 : _p.ext) == null ? void 0 : _q.showStyle) == null ? void 0 : _r.style) === 3 ? (i(), _("img", fo)) : p("", true),
              ((_u = (_t2 = (_s = a.value) == null ? void 0 : _s.ext) == null ? void 0 : _t2.showStyle) == null ? void 0 : _u.style) === 4 ? (i(), _("img", Io)) : p("", true),
              ((_x = (_w = (_v = a.value) == null ? void 0 : _v.ext) == null ? void 0 : _w.showStyle) == null ? void 0 : _x.style) === 5 ? (i(), _("img", Oo)) : p("", true),
              ((_A = (_z = (_y = a.value) == null ? void 0 : _y.ext) == null ? void 0 : _z.showStyle) == null ? void 0 : _A.style) === 99 ? (i(), _("img", {
                key: 5,
                class: "jackpot-banner",
                src: (_D = (_C = (_B = a.value) == null ? void 0 : _B.ext) == null ? void 0 : _C.showStyle) == null ? void 0 : _D.styleImg
              }, null, 8, $o)) : p("", true)
            ], 64))
          ], 4))
        ])) : p("", true);
      };
    }
  };
  es = U(xo, [
    [
      "__scopeId",
      "data-v-a82fc7c4"
    ]
  ]);
});
export {
  __tla,
  es as default
};
