import { i as M, b as lt, g as ut, f as ft, u as $, ah as ht, y as dt, n as pt, d as Ke, m as mt, h as We, p as he, l as L, w as gt, r as vt } from "./@vue.b00de3e9.js";
/*!
* vue-router v4.6.4
* (c) 2025 Eduardo San Martin Morote
* @license MIT
*/
const W = typeof document < "u";
function Qe(e) {
  return typeof e == "object" || "displayName" in e || "props" in e || "__vccOpts" in e;
}
function Rt(e) {
  return e.__esModule || e[Symbol.toStringTag] === "Module" || e.default && Qe(e.default);
}
const O = Object.assign;
function de(e, t) {
  const n = {};
  for (const r in t) {
    const s = t[r];
    n[r] = k(s) ? s.map(e) : e(s);
  }
  return n;
}
const ee = () => {
}, k = Array.isArray;
function Se(e, t) {
  const n = {};
  for (const r in e)
    n[r] = r in t ? t[r] : e[r];
  return n;
}
const ze = /#/g, Et = /&/g, At = /\//g, yt = /=/g, Nt = /\?/g, Ye = /\+/g, Ot = /%5B/g, _t = /%5D/g, Je = /%5E/g, Ct = /%60/g, Xe = /%7B/g, Pt = /%7C/g, Ze = /%7D/g, It = /%20/g;
function ye(e) {
  return e == null ? "" : encodeURI("" + e).replace(Pt, "|").replace(Ot, "[").replace(_t, "]");
}
function wt(e) {
  return ye(e).replace(Xe, "{").replace(Ze, "}").replace(Je, "^");
}
function ve(e) {
  return ye(e).replace(Ye, "%2B").replace(It, "+").replace(ze, "%23").replace(Et, "%26").replace(Ct, "`").replace(Xe, "{").replace(Ze, "}").replace(Je, "^");
}
function St(e) {
  return ve(e).replace(yt, "%3D");
}
function bt(e) {
  return ye(e).replace(ze, "%23").replace(Nt, "%3F");
}
function Tt(e) {
  return bt(e).replace(At, "%2F");
}
function te(e) {
  if (e == null)
    return null;
  try {
    return decodeURIComponent("" + e);
  } catch (e2) {
  }
  return "" + e;
}
const Dt = /\/$/, xt = (e) => e.replace(Dt, "");
function pe(e, t, n = "/") {
  let r, s = {}, f = "", h = "";
  const g = t.indexOf("#");
  let i = t.indexOf("?");
  return i = g >= 0 && i > g ? -1 : i, i >= 0 && (r = t.slice(0, i), f = t.slice(i, g > 0 ? g : t.length), s = e(f.slice(1))), g >= 0 && (r = r || t.slice(0, g), h = t.slice(g, t.length)), r = Lt(r != null ? r : t, n), { fullPath: r + f + h, path: r, query: s, hash: te(h) };
}
function Gt(e, t) {
  const n = t.query ? e(t.query) : "";
  return t.path + (n && "?") + n + (t.hash || "");
}
function be(e, t) {
  return !t || !e.toLowerCase().startsWith(t.toLowerCase()) ? e : e.slice(t.length) || "/";
}
function Bt(e, t, n) {
  const r = t.matched.length - 1, s = n.matched.length - 1;
  return r > -1 && r === s && Q(t.matched[r], n.matched[s]) && $e(t.params, n.params) && e(t.query) === e(n.query) && t.hash === n.hash;
}
function Q(e, t) {
  return (e.aliasOf || e) === (t.aliasOf || t);
}
function $e(e, t) {
  if (Object.keys(e).length !== Object.keys(t).length)
    return false;
  for (var n in e)
    if (!kt(e[n], t[n]))
      return false;
  return true;
}
function kt(e, t) {
  return k(e) ? Te(e, t) : k(t) ? Te(t, e) : (e == null ? void 0 : e.valueOf()) === (t == null ? void 0 : t.valueOf());
}
function Te(e, t) {
  return k(t) ? e.length === t.length && e.every((n, r) => n === t[r]) : e.length === 1 && e[0] === t;
}
function Lt(e, t) {
  if (e.startsWith("/"))
    return e;
  if (!e)
    return t;
  const n = t.split("/"), r = e.split("/"), s = r[r.length - 1];
  (s === ".." || s === ".") && r.push("");
  let f = n.length - 1, h, g;
  for (h = 0; h < r.length; h++)
    if (g = r[h], g !== ".")
      if (g === "..")
        f > 1 && f--;
      else
        break;
  return n.slice(0, f).join("/") + "/" + r.slice(h).join("/");
}
const H = { path: "/", name: void 0, params: {}, query: {}, hash: "", fullPath: "/", matched: [], meta: {}, redirectedFrom: void 0 };
let Re = function(e) {
  return e.pop = "pop", e.push = "push", e;
}({}), me = function(e) {
  return e.back = "back", e.forward = "forward", e.unknown = "", e;
}({});
function Vt(e) {
  if (!e)
    if (W) {
      const t = document.querySelector("base");
      e = t && t.getAttribute("href") || "/", e = e.replace(/^\w+:\/\/[^\/]+/, "");
    } else
      e = "/";
  return e[0] !== "/" && e[0] !== "#" && (e = "/" + e), xt(e);
}
const Mt = /^[^#]+#/;
function Ut(e, t) {
  return e.replace(Mt, "#") + t;
}
function Ht(e, t) {
  const n = document.documentElement.getBoundingClientRect(), r = e.getBoundingClientRect();
  return { behavior: t.behavior, left: r.left - n.left - (t.left || 0), top: r.top - n.top - (t.top || 0) };
}
const se = () => ({ left: window.scrollX, top: window.scrollY });
function jt(e) {
  let t;
  if ("el" in e) {
    const n = e.el, r = typeof n == "string" && n.startsWith("#"), s = typeof n == "string" ? r ? document.getElementById(n.slice(1)) : document.querySelector(n) : n;
    if (!s)
      return;
    t = Ht(s, e);
  } else
    t = e;
  "scrollBehavior" in document.documentElement.style ? window.scrollTo(t) : window.scrollTo(t.left != null ? t.left : window.scrollX, t.top != null ? t.top : window.scrollY);
}
function De(e, t) {
  return (history.state ? history.state.position - t : -1) + e;
}
const Ee = /* @__PURE__ */ new Map();
function qt(e, t) {
  Ee.set(e, t);
}
function Ft(e) {
  const t = Ee.get(e);
  return Ee.delete(e), t;
}
function Kt(e) {
  return typeof e == "string" || e && typeof e == "object";
}
function et(e) {
  return typeof e == "string" || typeof e == "symbol";
}
let w = function(e) {
  return e[e.MATCHER_NOT_FOUND = 1] = "MATCHER_NOT_FOUND", e[e.NAVIGATION_GUARD_REDIRECT = 2] = "NAVIGATION_GUARD_REDIRECT", e[e.NAVIGATION_ABORTED = 4] = "NAVIGATION_ABORTED", e[e.NAVIGATION_CANCELLED = 8] = "NAVIGATION_CANCELLED", e[e.NAVIGATION_DUPLICATED = 16] = "NAVIGATION_DUPLICATED", e;
}({});
const tt = Symbol("");
w.MATCHER_NOT_FOUND + "", w.NAVIGATION_GUARD_REDIRECT + "", w.NAVIGATION_ABORTED + "", w.NAVIGATION_CANCELLED + "", w.NAVIGATION_DUPLICATED + "";
function z(e, t) {
  return O(new Error(), { type: e, [tt]: true }, t);
}
function V(e, t) {
  return e instanceof Error && tt in e && (t == null || !!(e.type & t));
}
const Wt = ["params", "query", "hash"];
function Qt(e) {
  if (typeof e == "string")
    return e;
  if (e.path != null)
    return e.path;
  const t = {};
  for (const n of Wt)
    n in e && (t[n] = e[n]);
  return JSON.stringify(t, null, 2);
}
function zt(e) {
  const t = {};
  if (e === "" || e === "?")
    return t;
  const n = (e[0] === "?" ? e.slice(1) : e).split("&");
  for (let r = 0; r < n.length; ++r) {
    const s = n[r].replace(Ye, " "), f = s.indexOf("="), h = te(f < 0 ? s : s.slice(0, f)), g = f < 0 ? null : te(s.slice(f + 1));
    if (h in t) {
      let i = t[h];
      k(i) || (i = t[h] = [i]), i.push(g);
    } else
      t[h] = g;
  }
  return t;
}
function xe(e) {
  let t = "";
  for (let n in e) {
    const r = e[n];
    if (n = St(n), r == null) {
      r !== void 0 && (t += (t.length ? "&" : "") + n);
      continue;
    }
    (k(r) ? r.map((s) => s && ve(s)) : [r && ve(r)]).forEach((s) => {
      s !== void 0 && (t += (t.length ? "&" : "") + n, s != null && (t += "=" + s));
    });
  }
  return t;
}
function Yt(e) {
  const t = {};
  for (const n in e) {
    const r = e[n];
    r !== void 0 && (t[n] = k(r) ? r.map((s) => s == null ? null : "" + s) : r == null ? r : "" + r);
  }
  return t;
}
const Ne = Symbol(""), Ge = Symbol(""), oe = Symbol(""), Oe = Symbol(""), Ae = Symbol("");
function Z() {
  let e = [];
  function t(r) {
    return e.push(r), () => {
      const s = e.indexOf(r);
      s > -1 && e.splice(s, 1);
    };
  }
  function n() {
    e = [];
  }
  return { add: t, list: () => e.slice(), reset: n };
}
function nt(e, t, n) {
  const r = () => {
    e[t].delete(n);
  };
  lt(r), ut(r), ft(() => {
    e[t].add(n);
  }), e[t].add(n);
}
function On(e) {
  const t = M(Ne, {}).value;
  t && nt(t, "leaveGuards", e);
}
function _n(e) {
  const t = M(Ne, {}).value;
  t && nt(t, "updateGuards", e);
}
function j(e, t, n, r, s, f = (h) => h()) {
  const h = r && (r.enterCallbacks[s] = r.enterCallbacks[s] || []);
  return () => new Promise((g, i) => {
    const u = (c) => {
      c === false ? i(z(w.NAVIGATION_ABORTED, { from: n, to: t })) : c instanceof Error ? i(c) : Kt(c) ? i(z(w.NAVIGATION_GUARD_REDIRECT, { from: t, to: c })) : (h && r.enterCallbacks[s] === h && typeof c == "function" && h.push(c), g());
    }, d = f(() => e.call(r && r.instances[s], t, n, u));
    let a = Promise.resolve(d);
    e.length < 3 && (a = a.then(u)), a.catch((c) => i(c));
  });
}
function ge(e, t, n, r, s = (f) => f()) {
  const f = [];
  for (const h of e)
    for (const g in h.components) {
      let i = h.components[g];
      if (!(t !== "beforeRouteEnter" && !h.instances[g]))
        if (Qe(i)) {
          const u = (i.__vccOpts || i)[t];
          u && f.push(j(u, n, r, h, g, s));
        } else {
          let u = i();
          f.push(() => u.then((d) => {
            if (!d)
              throw new Error("Couldn't resolve component \"".concat(g, '" at "').concat(h.path, '"'));
            const a = Rt(d) ? d.default : d;
            h.mods[g] = d, h.components[g] = a;
            const c = (a.__vccOpts || a)[t];
            return c && j(c, n, r, h, g, s)();
          }));
        }
    }
  return f;
}
function Jt(e, t) {
  const n = [], r = [], s = [], f = Math.max(t.matched.length, e.matched.length);
  for (let h = 0; h < f; h++) {
    const g = t.matched[h];
    g && (e.matched.find((u) => Q(u, g)) ? r.push(g) : n.push(g));
    const i = e.matched[h];
    i && (t.matched.find((u) => Q(u, i)) || s.push(i));
  }
  return [n, r, s];
}
/*!
* vue-router v4.6.4
* (c) 2025 Eduardo San Martin Morote
* @license MIT
*/
let Xt = () => location.protocol + "//" + location.host;
function rt(e, t) {
  const { pathname: n, search: r, hash: s } = t, f = e.indexOf("#");
  if (f > -1) {
    let h = s.includes(e.slice(f)) ? e.slice(f).length : 1, g = s.slice(h);
    return g[0] !== "/" && (g = "/" + g), be(g, "");
  }
  return be(n, e) + r + s;
}
function Zt(e, t, n, r) {
  let s = [], f = [], h = null;
  const g = ({ state: c }) => {
    const l = rt(e, location), N = n.value, _ = t.value;
    let P = 0;
    if (c) {
      if (n.value = l, t.value = c, h && h === N) {
        h = null;
        return;
      }
      P = _ ? c.position - _.position : 0;
    } else
      r(l);
    s.forEach((I) => {
      I(n.value, N, { delta: P, type: Re.pop, direction: P ? P > 0 ? me.forward : me.back : me.unknown });
    });
  };
  function i() {
    h = n.value;
  }
  function u(c) {
    s.push(c);
    const l = () => {
      const N = s.indexOf(c);
      N > -1 && s.splice(N, 1);
    };
    return f.push(l), l;
  }
  function d() {
    if (document.visibilityState === "hidden") {
      const { history: c } = window;
      if (!c.state)
        return;
      c.replaceState(O({}, c.state, { scroll: se() }), "");
    }
  }
  function a() {
    for (const c of f)
      c();
    f = [], window.removeEventListener("popstate", g), window.removeEventListener("pagehide", d), document.removeEventListener("visibilitychange", d);
  }
  return window.addEventListener("popstate", g), window.addEventListener("pagehide", d), document.addEventListener("visibilitychange", d), { pauseListeners: i, listen: u, destroy: a };
}
function Be(e, t, n, r = false, s = false) {
  return { back: e, current: t, forward: n, replaced: r, position: window.history.length, scroll: s ? se() : null };
}
function $t(e) {
  const { history: t, location: n } = window, r = { value: rt(e, n) }, s = { value: t.state };
  s.value || f(r.value, { back: null, current: r.value, forward: null, position: t.length - 1, replaced: true, scroll: null }, true);
  function f(i, u, d) {
    const a = e.indexOf("#"), c = a > -1 ? (n.host && document.querySelector("base") ? e : e.slice(a)) + i : Xt() + e + i;
    try {
      t[d ? "replaceState" : "pushState"](u, "", c), s.value = u;
    } catch (l) {
      console.error(l), n[d ? "replace" : "assign"](c);
    }
  }
  function h(i, u) {
    f(i, O({}, t.state, Be(s.value.back, i, s.value.forward, true), u, { position: s.value.position }), true), r.value = i;
  }
  function g(i, u) {
    const d = O({}, s.value, t.state, { forward: i, scroll: se() });
    f(d.current, d, true), f(i, O({}, Be(r.value, i, null), { position: d.position + 1 }, u), false), r.value = i;
  }
  return { location: r, state: s, push: g, replace: h };
}
function Cn(e) {
  e = Vt(e);
  const t = $t(e), n = Zt(e, t.state, t.location, t.replace);
  function r(f, h = true) {
    h || n.pauseListeners(), history.go(f);
  }
  const s = O({ location: "", base: e, go: r, createHref: Ut.bind(null, e) }, t, n);
  return Object.defineProperty(s, "location", { enumerable: true, get: () => t.location.value }), Object.defineProperty(s, "state", { enumerable: true, get: () => t.state.value }), s;
}
let F = function(e) {
  return e[e.Static = 0] = "Static", e[e.Param = 1] = "Param", e[e.Group = 2] = "Group", e;
}({});
var T = function(e) {
  return e[e.Static = 0] = "Static", e[e.Param = 1] = "Param", e[e.ParamRegExp = 2] = "ParamRegExp", e[e.ParamRegExpEnd = 3] = "ParamRegExpEnd", e[e.EscapeNext = 4] = "EscapeNext", e;
}(T || {});
const en = { type: F.Static, value: "" }, tn = /[a-zA-Z0-9_]/;
function nn(e) {
  if (!e)
    return [[]];
  if (e === "/")
    return [[en]];
  if (!e.startsWith("/"))
    throw new Error('Invalid path "'.concat(e, '"'));
  function t(l) {
    throw new Error("ERR (".concat(n, ')/"').concat(u, '": ').concat(l));
  }
  let n = T.Static, r = n;
  const s = [];
  let f;
  function h() {
    f && s.push(f), f = [];
  }
  let g = 0, i, u = "", d = "";
  function a() {
    u && (n === T.Static ? f.push({ type: F.Static, value: u }) : n === T.Param || n === T.ParamRegExp || n === T.ParamRegExpEnd ? (f.length > 1 && (i === "*" || i === "+") && t("A repeatable param (".concat(u, ") must be alone in its segment. eg: '/:ids+.")), f.push({ type: F.Param, value: u, regexp: d, repeatable: i === "*" || i === "+", optional: i === "*" || i === "?" })) : t("Invalid state to consume buffer"), u = "");
  }
  function c() {
    u += i;
  }
  for (; g < e.length; ) {
    if (i = e[g++], i === "\\" && n !== T.ParamRegExp) {
      r = n, n = T.EscapeNext;
      continue;
    }
    switch (n) {
      case T.Static:
        i === "/" ? (u && a(), h()) : i === ":" ? (a(), n = T.Param) : c();
        break;
      case T.EscapeNext:
        c(), n = r;
        break;
      case T.Param:
        i === "(" ? n = T.ParamRegExp : tn.test(i) ? c() : (a(), n = T.Static, i !== "*" && i !== "?" && i !== "+" && g--);
        break;
      case T.ParamRegExp:
        i === ")" ? d[d.length - 1] == "\\" ? d = d.slice(0, -1) + i : n = T.ParamRegExpEnd : d += i;
        break;
      case T.ParamRegExpEnd:
        a(), n = T.Static, i !== "*" && i !== "?" && i !== "+" && g--, d = "";
        break;
      default:
        t("Unknown state");
        break;
    }
  }
  return n === T.ParamRegExp && t('Unfinished custom RegExp for param "'.concat(u, '"')), a(), h(), s;
}
const ke = "[^/]+?", rn = { sensitive: false, strict: false, start: true, end: true };
var D = function(e) {
  return e[e._multiplier = 10] = "_multiplier", e[e.Root = 90] = "Root", e[e.Segment = 40] = "Segment", e[e.SubSegment = 30] = "SubSegment", e[e.Static = 40] = "Static", e[e.Dynamic = 20] = "Dynamic", e[e.BonusCustomRegExp = 10] = "BonusCustomRegExp", e[e.BonusWildcard = -50] = "BonusWildcard", e[e.BonusRepeatable = -20] = "BonusRepeatable", e[e.BonusOptional = -8] = "BonusOptional", e[e.BonusStrict = 0.7000000000000001] = "BonusStrict", e[e.BonusCaseSensitive = 0.25] = "BonusCaseSensitive", e;
}(D || {});
const sn = /[.+*?^${}()[\]/\\]/g;
function on(e, t) {
  const n = O({}, rn, t), r = [];
  let s = n.start ? "^" : "";
  const f = [];
  for (const u of e) {
    const d = u.length ? [] : [D.Root];
    n.strict && !u.length && (s += "/");
    for (let a = 0; a < u.length; a++) {
      const c = u[a];
      let l = D.Segment + (n.sensitive ? D.BonusCaseSensitive : 0);
      if (c.type === F.Static)
        a || (s += "/"), s += c.value.replace(sn, "\\$&"), l += D.Static;
      else if (c.type === F.Param) {
        const { value: N, repeatable: _, optional: P, regexp: I } = c;
        f.push({ name: N, repeatable: _, optional: P });
        const y = I || ke;
        if (y !== ke) {
          l += D.BonusCustomRegExp;
          try {
            "".concat(y);
          } catch (B) {
            throw new Error('Invalid custom RegExp for param "'.concat(N, '" (').concat(y, "): ") + B.message);
          }
        }
        let C = _ ? "((?:".concat(y, ")(?:/(?:").concat(y, "))*)") : "(".concat(y, ")");
        a || (C = P && u.length < 2 ? "(?:/".concat(C, ")") : "/" + C), P && (C += "?"), s += C, l += D.Dynamic, P && (l += D.BonusOptional), _ && (l += D.BonusRepeatable), y === ".*" && (l += D.BonusWildcard);
      }
      d.push(l);
    }
    r.push(d);
  }
  if (n.strict && n.end) {
    const u = r.length - 1;
    r[u][r[u].length - 1] += D.BonusStrict;
  }
  n.strict || (s += "/?"), n.end ? s += "$" : n.strict && !s.endsWith("/") && (s += "(?:/|$)");
  const h = new RegExp(s, n.sensitive ? "" : "i");
  function g(u) {
    const d = u.match(h), a = {};
    if (!d)
      return null;
    for (let c = 1; c < d.length; c++) {
      const l = d[c] || "", N = f[c - 1];
      a[N.name] = l && N.repeatable ? l.split("/") : l;
    }
    return a;
  }
  function i(u) {
    let d = "", a = false;
    for (const c of e) {
      (!a || !d.endsWith("/")) && (d += "/"), a = false;
      for (const l of c)
        if (l.type === F.Static)
          d += l.value;
        else if (l.type === F.Param) {
          const { value: N, repeatable: _, optional: P } = l, I = N in u ? u[N] : "";
          if (k(I) && !_)
            throw new Error('Provided param "'.concat(N, '" is an array but it is not repeatable (* or + modifiers)'));
          const y = k(I) ? I.join("/") : I;
          if (!y)
            if (P)
              c.length < 2 && (d.endsWith("/") ? d = d.slice(0, -1) : a = true);
            else
              throw new Error('Missing required param "'.concat(N, '"'));
          d += y;
        }
    }
    return d || "/";
  }
  return { re: h, score: r, keys: f, parse: g, stringify: i };
}
function an(e, t) {
  let n = 0;
  for (; n < e.length && n < t.length; ) {
    const r = t[n] - e[n];
    if (r)
      return r;
    n++;
  }
  return e.length < t.length ? e.length === 1 && e[0] === D.Static + D.Segment ? -1 : 1 : e.length > t.length ? t.length === 1 && t[0] === D.Static + D.Segment ? 1 : -1 : 0;
}
function st(e, t) {
  let n = 0;
  const r = e.score, s = t.score;
  for (; n < r.length && n < s.length; ) {
    const f = an(r[n], s[n]);
    if (f)
      return f;
    n++;
  }
  if (Math.abs(s.length - r.length) === 1) {
    if (Le(r))
      return 1;
    if (Le(s))
      return -1;
  }
  return s.length - r.length;
}
function Le(e) {
  const t = e[e.length - 1];
  return e.length > 0 && t[t.length - 1] < 0;
}
const cn = { strict: false, end: true, sensitive: false };
function ln(e, t, n) {
  const r = on(nn(e.path), n), s = O(r, { record: e, parent: t, children: [], alias: [] });
  return t && !s.record.aliasOf == !t.record.aliasOf && t.children.push(s), s;
}
function un(e, t) {
  const n = [], r = /* @__PURE__ */ new Map();
  t = Se(cn, t);
  function s(a) {
    return r.get(a);
  }
  function f(a, c, l) {
    const N = !l, _ = Me(a);
    _.aliasOf = l && l.record;
    const P = Se(t, a), I = [_];
    if ("alias" in a) {
      const B = typeof a.alias == "string" ? [a.alias] : a.alias;
      for (const q of B)
        I.push(Me(O({}, _, { components: l ? l.record.components : _.components, path: q, aliasOf: l ? l.record : _ })));
    }
    let y, C;
    for (const B of I) {
      const { path: q } = B;
      if (c && q[0] !== "/") {
        const U = c.record.path, G = U[U.length - 1] === "/" ? "" : "/";
        B.path = c.record.path + (q && G + q);
      }
      if (y = ln(B, c, P), l ? l.alias.push(y) : (C = C || y, C !== y && C.alias.push(y), N && a.name && !Ue(y) && h(a.name)), ot(y) && i(y), _.children) {
        const U = _.children;
        for (let G = 0; G < U.length; G++)
          f(U[G], y, l && l.children[G]);
      }
      l = l || y;
    }
    return C ? () => {
      h(C);
    } : ee;
  }
  function h(a) {
    if (et(a)) {
      const c = r.get(a);
      c && (r.delete(a), n.splice(n.indexOf(c), 1), c.children.forEach(h), c.alias.forEach(h));
    } else {
      const c = n.indexOf(a);
      c > -1 && (n.splice(c, 1), a.record.name && r.delete(a.record.name), a.children.forEach(h), a.alias.forEach(h));
    }
  }
  function g() {
    return n;
  }
  function i(a) {
    const c = dn(a, n);
    n.splice(c, 0, a), a.record.name && !Ue(a) && r.set(a.record.name, a);
  }
  function u(a, c) {
    let l, N = {}, _, P;
    if ("name" in a && a.name) {
      if (l = r.get(a.name), !l)
        throw z(w.MATCHER_NOT_FOUND, { location: a });
      P = l.record.name, N = O(Ve(c.params, l.keys.filter((C) => !C.optional).concat(l.parent ? l.parent.keys.filter((C) => C.optional) : []).map((C) => C.name)), a.params && Ve(a.params, l.keys.map((C) => C.name))), _ = l.stringify(N);
    } else if (a.path != null)
      _ = a.path, l = n.find((C) => C.re.test(_)), l && (N = l.parse(_), P = l.record.name);
    else {
      if (l = c.name ? r.get(c.name) : n.find((C) => C.re.test(c.path)), !l)
        throw z(w.MATCHER_NOT_FOUND, { location: a, currentLocation: c });
      P = l.record.name, N = O({}, c.params, a.params), _ = l.stringify(N);
    }
    const I = [];
    let y = l;
    for (; y; )
      I.unshift(y.record), y = y.parent;
    return { name: P, path: _, params: N, matched: I, meta: hn(I) };
  }
  e.forEach((a) => f(a));
  function d() {
    n.length = 0, r.clear();
  }
  return { addRoute: f, resolve: u, removeRoute: h, clearRoutes: d, getRoutes: g, getRecordMatcher: s };
}
function Ve(e, t) {
  const n = {};
  for (const r of t)
    r in e && (n[r] = e[r]);
  return n;
}
function Me(e) {
  const t = { path: e.path, redirect: e.redirect, name: e.name, meta: e.meta || {}, aliasOf: e.aliasOf, beforeEnter: e.beforeEnter, props: fn(e), children: e.children || [], instances: {}, leaveGuards: /* @__PURE__ */ new Set(), updateGuards: /* @__PURE__ */ new Set(), enterCallbacks: {}, components: "components" in e ? e.components || null : e.component && { default: e.component } };
  return Object.defineProperty(t, "mods", { value: {} }), t;
}
function fn(e) {
  const t = {}, n = e.props || false;
  if ("component" in e)
    t.default = n;
  else
    for (const r in e.components)
      t[r] = typeof n == "object" ? n[r] : n;
  return t;
}
function Ue(e) {
  for (; e; ) {
    if (e.record.aliasOf)
      return true;
    e = e.parent;
  }
  return false;
}
function hn(e) {
  return e.reduce((t, n) => O(t, n.meta), {});
}
function dn(e, t) {
  let n = 0, r = t.length;
  for (; n !== r; ) {
    const f = n + r >> 1;
    st(e, t[f]) < 0 ? r = f : n = f + 1;
  }
  const s = pn(e);
  return s && (r = t.lastIndexOf(s, r - 1)), r;
}
function pn(e) {
  let t = e;
  for (; t = t.parent; )
    if (ot(t) && st(e, t) === 0)
      return t;
}
function ot({ record: e }) {
  return !!(e.name || e.components && Object.keys(e.components).length || e.redirect);
}
function He(e) {
  const t = M(oe), n = M(Oe), r = L(() => {
    const i = $(e.to);
    return t.resolve(i);
  }), s = L(() => {
    const { matched: i } = r.value, { length: u } = i, d = i[u - 1], a = n.matched;
    if (!d || !a.length)
      return -1;
    const c = a.findIndex(Q.bind(null, d));
    if (c > -1)
      return c;
    const l = je(i[u - 2]);
    return u > 1 && je(d) === l && a[a.length - 1].path !== l ? a.findIndex(Q.bind(null, i[u - 2])) : c;
  }), f = L(() => s.value > -1 && En(n.params, r.value.params)), h = L(() => s.value > -1 && s.value === n.matched.length - 1 && $e(n.params, r.value.params));
  function g(i = {}) {
    if (Rn(i)) {
      const u = t[$(e.replace) ? "replace" : "push"]($(e.to)).catch(ee);
      return e.viewTransition && typeof document < "u" && "startViewTransition" in document && document.startViewTransition(() => u), u;
    }
    return Promise.resolve();
  }
  return { route: r, href: L(() => r.value.href), isActive: f, isExactActive: h, navigate: g };
}
function mn(e) {
  return e.length === 1 ? e[0] : e;
}
const gn = Ke({ name: "RouterLink", compatConfig: { MODE: 3 }, props: { to: { type: [String, Object], required: true }, replace: Boolean, activeClass: String, exactActiveClass: String, custom: Boolean, ariaCurrentValue: { type: String, default: "page" }, viewTransition: Boolean }, useLink: He, setup(e, { slots: t }) {
  const n = mt(He(e)), { options: r } = M(oe), s = L(() => ({ [qe(e.activeClass, r.linkActiveClass, "router-link-active")]: n.isActive, [qe(e.exactActiveClass, r.linkExactActiveClass, "router-link-exact-active")]: n.isExactActive }));
  return () => {
    const f = t.default && mn(t.default(n));
    return e.custom ? f : We("a", { "aria-current": n.isExactActive ? e.ariaCurrentValue : null, href: n.href, onClick: n.navigate, class: s.value }, f);
  };
} }), vn = gn;
function Rn(e) {
  if (!(e.metaKey || e.altKey || e.ctrlKey || e.shiftKey) && !e.defaultPrevented && !(e.button !== void 0 && e.button !== 0)) {
    if (e.currentTarget && e.currentTarget.getAttribute) {
      const t = e.currentTarget.getAttribute("target");
      if (/\b_blank\b/i.test(t))
        return;
    }
    return e.preventDefault && e.preventDefault(), true;
  }
}
function En(e, t) {
  for (const n in t) {
    const r = t[n], s = e[n];
    if (typeof r == "string") {
      if (r !== s)
        return false;
    } else if (!k(s) || s.length !== r.length || r.some((f, h) => f.valueOf() !== s[h].valueOf()))
      return false;
  }
  return true;
}
function je(e) {
  return e ? e.aliasOf ? e.aliasOf.path : e.path : "";
}
const qe = (e, t, n) => {
  var _a;
  return (_a = e != null ? e : t) != null ? _a : n;
}, An = Ke({ name: "RouterView", inheritAttrs: false, props: { name: { type: String, default: "default" }, route: Object }, compatConfig: { MODE: 3 }, setup(e, { attrs: t, slots: n }) {
  const r = M(Ae), s = L(() => e.route || r.value), f = M(Ge, 0), h = L(() => {
    let u = $(f);
    const { matched: d } = s.value;
    let a;
    for (; (a = d[u]) && !a.components; )
      u++;
    return u;
  }), g = L(() => s.value.matched[h.value]);
  he(Ge, L(() => h.value + 1)), he(Ne, g), he(Ae, s);
  const i = vt();
  return gt(() => [i.value, g.value, e.name], ([u, d, a], [c, l, N]) => {
    d && (d.instances[a] = u, l && l !== d && u && u === c && (d.leaveGuards.size || (d.leaveGuards = l.leaveGuards), d.updateGuards.size || (d.updateGuards = l.updateGuards))), u && d && (!l || !Q(d, l) || !c) && (d.enterCallbacks[a] || []).forEach((_) => _(u));
  }, { flush: "post" }), () => {
    const u = s.value, d = e.name, a = g.value, c = a && a.components[d];
    if (!c)
      return Fe(n.default, { Component: c, route: u });
    const l = a.props[d], N = l ? l === true ? u.params : typeof l == "function" ? l(u) : l : null, P = We(c, O({}, N, t, { onVnodeUnmounted: (I) => {
      I.component.isUnmounted && (a.instances[d] = null);
    }, ref: i }));
    return Fe(n.default, { Component: P, route: u }) || P;
  };
} });
function Fe(e, t) {
  if (!e)
    return null;
  const n = e(t);
  return n.length === 1 ? n[0] : n;
}
const yn = An;
function Pn(e) {
  const t = un(e.routes, e), n = e.parseQuery || zt, r = e.stringifyQuery || xe, s = e.history, f = Z(), h = Z(), g = Z(), i = dt(H);
  let u = H;
  W && e.scrollBehavior && "scrollRestoration" in history && (history.scrollRestoration = "manual");
  const d = de.bind(null, (o) => "" + o), a = de.bind(null, Tt), c = de.bind(null, te);
  function l(o, m) {
    let p, v;
    return et(o) ? (p = t.getRecordMatcher(o), v = m) : v = o, t.addRoute(v, p);
  }
  function N(o) {
    const m = t.getRecordMatcher(o);
    m && t.removeRoute(m);
  }
  function _() {
    return t.getRoutes().map((o) => o.record);
  }
  function P(o) {
    return !!t.getRecordMatcher(o);
  }
  function I(o, m) {
    if (m = O({}, m || i.value), typeof o == "string") {
      const R = pe(n, o, m.path), b = t.resolve({ path: R.path }, m), X = s.createHref(R.fullPath);
      return O(R, b, { params: c(b.params), hash: te(R.hash), redirectedFrom: void 0, href: X });
    }
    let p;
    if (o.path != null)
      p = O({}, o, { path: pe(n, o.path, m.path).path });
    else {
      const R = O({}, o.params);
      for (const b in R)
        R[b] == null && delete R[b];
      p = O({}, o, { params: a(R) }), m.params = a(m.params);
    }
    const v = t.resolve(p, m), A = o.hash || "";
    v.params = d(c(v.params));
    const S = Gt(r, O({}, o, { hash: wt(A), path: v.path })), E = s.createHref(S);
    return O({ fullPath: S, hash: A, query: r === xe ? Yt(o.query) : o.query || {} }, v, { redirectedFrom: void 0, href: E });
  }
  function y(o) {
    return typeof o == "string" ? pe(n, o, i.value.path) : O({}, o);
  }
  function C(o, m) {
    if (u !== o)
      return z(w.NAVIGATION_CANCELLED, { from: m, to: o });
  }
  function B(o) {
    return G(o);
  }
  function q(o) {
    return B(O(y(o), { replace: true }));
  }
  function U(o, m) {
    const p = o.matched[o.matched.length - 1];
    if (p && p.redirect) {
      const { redirect: v } = p;
      let A = typeof v == "function" ? v(o, m) : v;
      return typeof A == "string" && (A = A.includes("?") || A.includes("#") ? A = y(A) : { path: A }, A.params = {}), O({ query: o.query, hash: o.hash, params: A.path != null ? {} : o.params }, A);
    }
  }
  function G(o, m) {
    const p = u = I(o), v = i.value, A = o.state, S = o.force, E = o.replace === true, R = U(p, v);
    if (R)
      return G(O(y(R), { state: typeof R == "object" ? O({}, A, R.state) : A, force: S, replace: E }), m || p);
    const b = p;
    b.redirectedFrom = m;
    let X;
    return !S && Bt(r, v, p) && (X = z(w.NAVIGATION_DUPLICATED, { to: b, from: v }), we(v, v, true, false)), (X ? Promise.resolve(X) : _e(b, v)).catch((x) => V(x) ? V(x, w.NAVIGATION_GUARD_REDIRECT) ? x : le(x) : ce(x, b, v)).then((x) => {
      if (x) {
        if (V(x, w.NAVIGATION_GUARD_REDIRECT))
          return G(O({ replace: E }, y(x.to), { state: typeof x.to == "object" ? O({}, A, x.to.state) : A, force: S }), m || b);
      } else
        x = Pe(b, v, true, E, A);
      return Ce(b, v, x), x;
    });
  }
  function it(o, m) {
    const p = C(o, m);
    return p ? Promise.reject(p) : Promise.resolve();
  }
  function ie(o) {
    const m = re.values().next().value;
    return m && typeof m.runWithContext == "function" ? m.runWithContext(o) : o();
  }
  function _e(o, m) {
    let p;
    const [v, A, S] = Jt(o, m);
    p = ge(v.reverse(), "beforeRouteLeave", o, m);
    for (const R of v)
      R.leaveGuards.forEach((b) => {
        p.push(j(b, o, m));
      });
    const E = it.bind(null, o, m);
    return p.push(E), K(p).then(() => {
      p = [];
      for (const R of f.list())
        p.push(j(R, o, m));
      return p.push(E), K(p);
    }).then(() => {
      p = ge(A, "beforeRouteUpdate", o, m);
      for (const R of A)
        R.updateGuards.forEach((b) => {
          p.push(j(b, o, m));
        });
      return p.push(E), K(p);
    }).then(() => {
      p = [];
      for (const R of S)
        if (R.beforeEnter)
          if (k(R.beforeEnter))
            for (const b of R.beforeEnter)
              p.push(j(b, o, m));
          else
            p.push(j(R.beforeEnter, o, m));
      return p.push(E), K(p);
    }).then(() => (o.matched.forEach((R) => R.enterCallbacks = {}), p = ge(S, "beforeRouteEnter", o, m, ie), p.push(E), K(p))).then(() => {
      p = [];
      for (const R of h.list())
        p.push(j(R, o, m));
      return p.push(E), K(p);
    }).catch((R) => V(R, w.NAVIGATION_CANCELLED) ? R : Promise.reject(R));
  }
  function Ce(o, m, p) {
    g.list().forEach((v) => ie(() => v(o, m, p)));
  }
  function Pe(o, m, p, v, A) {
    const S = C(o, m);
    if (S)
      return S;
    const E = m === H, R = W ? history.state : {};
    p && (v || E ? s.replace(o.fullPath, O({ scroll: E && R && R.scroll }, A)) : s.push(o.fullPath, A)), i.value = o, we(o, m, p, E), le();
  }
  let Y;
  function at() {
    Y || (Y = s.listen((o, m, p) => {
      if (!J.listening)
        return;
      const v = I(o), A = U(v, J.currentRoute.value);
      if (A) {
        G(O(A, { replace: true, force: true }), v).catch(ee);
        return;
      }
      u = v;
      const S = i.value;
      W && qt(De(S.fullPath, p.delta), se()), _e(v, S).catch((E) => V(E, w.NAVIGATION_ABORTED | w.NAVIGATION_CANCELLED) ? E : V(E, w.NAVIGATION_GUARD_REDIRECT) ? (G(O(y(E.to), { force: true }), v).then((R) => {
        V(R, w.NAVIGATION_ABORTED | w.NAVIGATION_DUPLICATED) && !p.delta && p.type === Re.pop && s.go(-1, false);
      }).catch(ee), Promise.reject()) : (p.delta && s.go(-p.delta, false), ce(E, v, S))).then((E) => {
        E = E || Pe(v, S, false), E && (p.delta && !V(E, w.NAVIGATION_CANCELLED) ? s.go(-p.delta, false) : p.type === Re.pop && V(E, w.NAVIGATION_ABORTED | w.NAVIGATION_DUPLICATED) && s.go(-1, false)), Ce(v, S, E);
      }).catch(ee);
    }));
  }
  let ae = Z(), Ie = Z(), ne;
  function ce(o, m, p) {
    le(o);
    const v = Ie.list();
    return v.length ? v.forEach((A) => A(o, m, p)) : console.error(o), Promise.reject(o);
  }
  function ct() {
    return ne && i.value !== H ? Promise.resolve() : new Promise((o, m) => {
      ae.add([o, m]);
    });
  }
  function le(o) {
    return ne || (ne = !o, at(), ae.list().forEach(([m, p]) => o ? p(o) : m()), ae.reset()), o;
  }
  function we(o, m, p, v) {
    const { scrollBehavior: A } = e;
    if (!W || !A)
      return Promise.resolve();
    const S = !p && Ft(De(o.fullPath, 0)) || (v || !p) && history.state && history.state.scroll || null;
    return pt().then(() => A(o, m, S)).then((E) => E && jt(E)).catch((E) => ce(E, o, m));
  }
  const ue = (o) => s.go(o);
  let fe;
  const re = /* @__PURE__ */ new Set(), J = { currentRoute: i, listening: true, addRoute: l, removeRoute: N, clearRoutes: t.clearRoutes, hasRoute: P, getRoutes: _, resolve: I, options: e, push: B, replace: q, go: ue, back: () => ue(-1), forward: () => ue(1), beforeEach: f.add, beforeResolve: h.add, afterEach: g.add, onError: Ie.add, isReady: ct, install(o) {
    o.component("RouterLink", vn), o.component("RouterView", yn), o.config.globalProperties.$router = J, Object.defineProperty(o.config.globalProperties, "$route", { enumerable: true, get: () => $(i) }), W && !fe && i.value === H && (fe = true, B(s.location).catch((v) => {
    }));
    const m = {};
    for (const v in H)
      Object.defineProperty(m, v, { get: () => i.value[v], enumerable: true });
    o.provide(oe, J), o.provide(Oe, ht(m)), o.provide(Ae, i);
    const p = o.unmount;
    re.add(o), o.unmount = function() {
      re.delete(o), re.size < 1 && (u = H, Y && Y(), Y = null, i.value = H, fe = false, ne = false), p();
    };
  } };
  function K(o) {
    return o.reduce((m, p) => m.then(() => ie(p)), Promise.resolve());
  }
  return J;
}
function In() {
  return M(oe);
}
function wn(e) {
  return M(Oe);
}
export {
  Cn as a,
  In as b,
  Pn as c,
  On as d,
  _n as o,
  wn as u
};
