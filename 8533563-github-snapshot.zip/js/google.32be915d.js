const o = "/img/im/google.png";
export {
  o as _
};
