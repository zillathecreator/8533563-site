import { _ as f, __tla as __tla_0 } from "./index.bb04cb73.js";
import { _ as g } from "./circular_close.952b11ce.js";
import { u as x } from "./vue-i18n.07fcbeea.js";
import { u as h } from "./vuex.33ea5d58.js";
import { e as b, aa as C, o as s, J as T, V as w, c as a, a as i, O as y, a5 as k, _ as B, W as l, u as D, ao as V, r as c, m as A } from "./@vue.b00de3e9.js";
import "./vue-router.c227d4ba.js";
import "./axios.853f16bf.js";
import "./element-plus.53baa8a9.js";
import "./@element-plus.e21ea623.js";
import "./@ctrl.11979b50.js";
import "./dayjs.9abdbee1.js";
import "./clipboard.aaae98d3.js";
import "./@vueuse.eccd744a.js";
import "./lodash-es.e1022fb5.js";
import "./@popperjs.da591b4f.js";
import "./vant.f7b4805b.js";
import "./@vant.f52f09a9.js";
import "./xe-utils.a532b55a.js";
import "./crypto-js.c184c643.js";
import "./decimal.js.2def1975.js";
import "./nprogress.9fc41f77.js";
import "./vconsole.0cfb1d33.js";
import "./perfect-scrollbar.19f80865.js";
import "./@intlify.928cb664.js";
let no;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e) {
    }
  })()
]).then(async () => {
  let O, E, F, I, L, M;
  O = {
    key: 0,
    class: "alert-dialog alert-dialog-wg"
  };
  E = {
    class: "alert-dialog-box"
  };
  F = {
    class: "alert-dialog-box-content"
  };
  I = {
    class: "scrollContent"
  };
  L = [
    "innerHTML"
  ];
  M = {
    class: "alert-dialog-box-btn"
  };
  no = {
    __name: "index",
    setup(N) {
      const m = V(() => f(() => import("./index.e415b222.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index.e415b222.js","js/@vue.b00de3e9.js","js/vuex.33ea5d58.js","js/index.bb04cb73.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/index.36ac8329.css"])), { t: _ } = x(), r = c(""), e = A({
        btnText: "",
        confirmFun: () => {
        },
        showClose: false
      }), o = c(false);
      h();
      const d = (n = "", t = {
        btnText: _("common.confirm"),
        confirmFun: () => {
        },
        showClose: false
      }) => {
        o.value = true, r.value = n, Object.assign(e, t);
      }, p = async () => {
        try {
          o.value = false, await e.confirmFun();
        } catch (e2) {
        }
      };
      return b(() => {
        globalVBus.$on("handleAlert", d);
      }), (n, t) => {
        const u = C("loadingThrottle");
        return s(), T(D(m), {
          visible: o.value,
          onClose: t[1] || (t[1] = (v) => o.value = false),
          zIndexBase: 9999
        }, {
          default: w(() => [
            o.value ? (s(), a("div", O, [
              i("div", E, [
                i("div", F, [
                  i("div", I, [
                    i("div", {
                      innerHTML: r.value
                    }, null, 8, L)
                  ])
                ]),
                y((s(), a("div", M, [
                  k(B(e.btnText), 1)
                ])), [
                  [
                    u,
                    p
                  ]
                ]),
                e.showClose ? (s(), a("img", {
                  key: 0,
                  src: g,
                  class: "alert-dialog-box-close",
                  onClick: t[0] || (t[0] = (v) => o.value = false)
                })) : l("", true)
              ])
            ])) : l("", true)
          ]),
          _: 1
        }, 8, [
          "visible"
        ]);
      };
    }
  };
});
export {
  __tla,
  no as default
};
