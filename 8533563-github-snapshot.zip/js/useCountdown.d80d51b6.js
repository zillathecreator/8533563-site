import { b as p, r as i } from "./@vue.b00de3e9.js";
function y() {
  const s = i({ days: "0", hours: "00", minutes: "00", seconds: "00" }), t = i(null), e = i(false);
  let a = null, l = false;
  const u = (o) => {
    const c = Date.now(), n = o - c;
    if (n <= 0) {
      s.value = { days: "0", hours: "00", minutes: "00", seconds: "00" }, e.value = true, !l && typeof a == "function" && (l = true, a()), t.value && clearInterval(t.value);
      return;
    }
    e.value = false;
    const d = Math.floor(n / (1e3 * 60 * 60 * 24)), v = Math.floor(n % (1e3 * 60 * 60 * 24) / (1e3 * 60 * 60)), h = Math.floor(n % (1e3 * 60 * 60) / (1e3 * 60)), m = Math.floor(n % (1e3 * 60) / 1e3);
    s.value = { days: d.toString(), hours: v.toString().padStart(2, "0"), minutes: h.toString().padStart(2, "0"), seconds: m.toString().padStart(2, "0") };
  }, f = (o, c) => {
    r(), a = c || null, l = false, u(o), t.value = setInterval(() => {
      u(o);
    }, 1e3);
  }, r = () => {
    t.value && (clearInterval(t.value), t.value = null);
  };
  return p(() => {
    r();
  }), { timeLeft: s, isFinished: e, startCountdown: f, stopCountdown: r, calculateTimeLeft: u };
}
export {
  y as u
};
