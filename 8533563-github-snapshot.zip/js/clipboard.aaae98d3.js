var B = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function J(g) {
  return g && g.__esModule && Object.prototype.hasOwnProperty.call(g, "default") ? g.default : g;
}
function W(g) {
  if (g.__esModule)
    return g;
  var T = g.default;
  if (typeof T == "function") {
    var S = function E() {
      return this instanceof E ? Reflect.construct(T, arguments, this.constructor) : T.apply(this, arguments);
    };
    S.prototype = T.prototype;
  } else
    S = {};
  return Object.defineProperty(S, "__esModule", { value: true }), Object.keys(g).forEach(function(E) {
    var b = Object.getOwnPropertyDescriptor(g, E);
    Object.defineProperty(S, E, b.get ? b : { enumerable: true, get: function() {
      return g[E];
    } });
  }), S;
}
var N = { exports: {} };
/*!
* clipboard.js v2.0.11
* https://clipboardjs.com/
*
* Licensed MIT © Zeno Rocha
*/
(function(g, T) {
  (function(E, b) {
    g.exports = b();
  })(B, function() {
    return function() {
      var S = { 686: function(l, c, t) {
        t.d(c, { default: function() {
          return $;
        } });
        var a = t(279), f = t.n(a), s = t(370), h = t.n(s), y = t(817), m = t.n(y);
        function d(i) {
          try {
            return document.execCommand(i);
          } catch (e) {
            return false;
          }
        }
        var v = function(n) {
          var e = m()(n);
          return d("cut"), e;
        }, p = v;
        function w(i) {
          var n = document.documentElement.getAttribute("dir") === "rtl", e = document.createElement("textarea");
          e.style.fontSize = "12pt", e.style.border = "0", e.style.padding = "0", e.style.margin = "0", e.style.position = "absolute", e.style[n ? "right" : "left"] = "-9999px";
          var r = window.pageYOffset || document.documentElement.scrollTop;
          return e.style.top = "".concat(r, "px"), e.setAttribute("readonly", ""), e.value = i, e;
        }
        var M = function(n, e) {
          var r = w(n);
          e.container.appendChild(r);
          var o = m()(r);
          return d("copy"), r.remove(), o;
        }, k = function(n) {
          var e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : { container: document.body }, r = "";
          return typeof n == "string" ? r = M(n, e) : n instanceof HTMLInputElement && !["text", "search", "url", "tel", "password"].includes(n == null ? void 0 : n.type) ? r = M(n.value, e) : (r = m()(n), d("copy")), r;
        }, P = k;
        function A(i) {
          "@babel/helpers - typeof";
          return typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? A = function(e) {
            return typeof e;
          } : A = function(e) {
            return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
          }, A(i);
        }
        var D = function() {
          var n = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, e = n.action, r = e === void 0 ? "copy" : e, o = n.container, u = n.target, _ = n.text;
          if (r !== "copy" && r !== "cut")
            throw new Error('Invalid "action" value, use either "copy" or "cut"');
          if (u !== void 0)
            if (u && A(u) === "object" && u.nodeType === 1) {
              if (r === "copy" && u.hasAttribute("disabled"))
                throw new Error('Invalid "target" attribute. Please use "readonly" instead of "disabled" attribute');
              if (r === "cut" && (u.hasAttribute("readonly") || u.hasAttribute("disabled")))
                throw new Error('Invalid "target" attribute. You can\'t cut text from elements with "readonly" or "disabled" attributes');
            } else
              throw new Error('Invalid "target" value, use a valid Element');
          if (_)
            return P(_, { container: o });
          if (u)
            return r === "cut" ? p(u) : P(u, { container: o });
        }, F = D;
        function x(i) {
          "@babel/helpers - typeof";
          return typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? x = function(e) {
            return typeof e;
          } : x = function(e) {
            return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
          }, x(i);
        }
        function H(i, n) {
          if (!(i instanceof n))
            throw new TypeError("Cannot call a class as a function");
        }
        function R(i, n) {
          for (var e = 0; e < n.length; e++) {
            var r = n[e];
            r.enumerable = r.enumerable || false, r.configurable = true, "value" in r && (r.writable = true), Object.defineProperty(i, r.key, r);
          }
        }
        function I(i, n, e) {
          return n && R(i.prototype, n), e && R(i, e), i;
        }
        function z(i, n) {
          if (typeof n != "function" && n !== null)
            throw new TypeError("Super expression must either be null or a function");
          i.prototype = Object.create(n && n.prototype, { constructor: { value: i, writable: true, configurable: true } }), n && L(i, n);
        }
        function L(i, n) {
          return L = Object.setPrototypeOf || function(r, o) {
            return r.__proto__ = o, r;
          }, L(i, n);
        }
        function U(i) {
          var n = V();
          return function() {
            var r = O(i), o;
            if (n) {
              var u = O(this).constructor;
              o = Reflect.construct(r, arguments, u);
            } else
              o = r.apply(this, arguments);
            return Y(this, o);
          };
        }
        function Y(i, n) {
          return n && (x(n) === "object" || typeof n == "function") ? n : G(i);
        }
        function G(i) {
          if (i === void 0)
            throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
          return i;
        }
        function V() {
          if (typeof Reflect > "u" || !Reflect.construct || Reflect.construct.sham)
            return false;
          if (typeof Proxy == "function")
            return true;
          try {
            return Date.prototype.toString.call(Reflect.construct(Date, [], function() {
            })), true;
          } catch (e) {
            return false;
          }
        }
        function O(i) {
          return O = Object.setPrototypeOf ? Object.getPrototypeOf : function(e) {
            return e.__proto__ || Object.getPrototypeOf(e);
          }, O(i);
        }
        function j(i, n) {
          var e = "data-clipboard-".concat(i);
          if (n.hasAttribute(e))
            return n.getAttribute(e);
        }
        var X = function(i) {
          z(e, i);
          var n = U(e);
          function e(r, o) {
            var u;
            return H(this, e), u = n.call(this), u.resolveOptions(o), u.listenClick(r), u;
          }
          return I(e, [{ key: "resolveOptions", value: function() {
            var o = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
            this.action = typeof o.action == "function" ? o.action : this.defaultAction, this.target = typeof o.target == "function" ? o.target : this.defaultTarget, this.text = typeof o.text == "function" ? o.text : this.defaultText, this.container = x(o.container) === "object" ? o.container : document.body;
          } }, { key: "listenClick", value: function(o) {
            var u = this;
            this.listener = h()(o, "click", function(_) {
              return u.onClick(_);
            });
          } }, { key: "onClick", value: function(o) {
            var u = o.delegateTarget || o.currentTarget, _ = this.action(u) || "copy", C = F({ action: _, container: this.container, target: this.target(u), text: this.text(u) });
            this.emit(C ? "success" : "error", { action: _, text: C, trigger: u, clearSelection: function() {
              u && u.focus(), window.getSelection().removeAllRanges();
            } });
          } }, { key: "defaultAction", value: function(o) {
            return j("action", o);
          } }, { key: "defaultTarget", value: function(o) {
            var u = j("target", o);
            if (u)
              return document.querySelector(u);
          } }, { key: "defaultText", value: function(o) {
            return j("text", o);
          } }, { key: "destroy", value: function() {
            this.listener.destroy();
          } }], [{ key: "copy", value: function(o) {
            var u = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : { container: document.body };
            return P(o, u);
          } }, { key: "cut", value: function(o) {
            return p(o);
          } }, { key: "isSupported", value: function() {
            var o = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : ["copy", "cut"], u = typeof o == "string" ? [o] : o, _ = !!document.queryCommandSupported;
            return u.forEach(function(C) {
              _ = _ && !!document.queryCommandSupported(C);
            }), _;
          } }]), e;
        }(f()), $ = X;
      }, 828: function(l) {
        var c = 9;
        if (typeof Element < "u" && !Element.prototype.matches) {
          var t = Element.prototype;
          t.matches = t.matchesSelector || t.mozMatchesSelector || t.msMatchesSelector || t.oMatchesSelector || t.webkitMatchesSelector;
        }
        function a(f, s) {
          for (; f && f.nodeType !== c; ) {
            if (typeof f.matches == "function" && f.matches(s))
              return f;
            f = f.parentNode;
          }
        }
        l.exports = a;
      }, 438: function(l, c, t) {
        var a = t(828);
        function f(y, m, d, v, p) {
          var w = h.apply(this, arguments);
          return y.addEventListener(d, w, p), { destroy: function() {
            y.removeEventListener(d, w, p);
          } };
        }
        function s(y, m, d, v, p) {
          return typeof y.addEventListener == "function" ? f.apply(null, arguments) : typeof d == "function" ? f.bind(null, document).apply(null, arguments) : (typeof y == "string" && (y = document.querySelectorAll(y)), Array.prototype.map.call(y, function(w) {
            return f(w, m, d, v, p);
          }));
        }
        function h(y, m, d, v) {
          return function(p) {
            p.delegateTarget = a(p.target, m), p.delegateTarget && v.call(y, p);
          };
        }
        l.exports = s;
      }, 879: function(l, c) {
        c.node = function(t) {
          return t !== void 0 && t instanceof HTMLElement && t.nodeType === 1;
        }, c.nodeList = function(t) {
          var a = Object.prototype.toString.call(t);
          return t !== void 0 && (a === "[object NodeList]" || a === "[object HTMLCollection]") && "length" in t && (t.length === 0 || c.node(t[0]));
        }, c.string = function(t) {
          return typeof t == "string" || t instanceof String;
        }, c.fn = function(t) {
          var a = Object.prototype.toString.call(t);
          return a === "[object Function]";
        };
      }, 370: function(l, c, t) {
        var a = t(879), f = t(438);
        function s(d, v, p) {
          if (!d && !v && !p)
            throw new Error("Missing required arguments");
          if (!a.string(v))
            throw new TypeError("Second argument must be a String");
          if (!a.fn(p))
            throw new TypeError("Third argument must be a Function");
          if (a.node(d))
            return h(d, v, p);
          if (a.nodeList(d))
            return y(d, v, p);
          if (a.string(d))
            return m(d, v, p);
          throw new TypeError("First argument must be a String, HTMLElement, HTMLCollection, or NodeList");
        }
        function h(d, v, p) {
          return d.addEventListener(v, p), { destroy: function() {
            d.removeEventListener(v, p);
          } };
        }
        function y(d, v, p) {
          return Array.prototype.forEach.call(d, function(w) {
            w.addEventListener(v, p);
          }), { destroy: function() {
            Array.prototype.forEach.call(d, function(w) {
              w.removeEventListener(v, p);
            });
          } };
        }
        function m(d, v, p) {
          return f(document.body, d, v, p);
        }
        l.exports = s;
      }, 817: function(l) {
        function c(t) {
          var a;
          if (t.nodeName === "SELECT")
            t.focus(), a = t.value;
          else if (t.nodeName === "INPUT" || t.nodeName === "TEXTAREA") {
            var f = t.hasAttribute("readonly");
            f || t.setAttribute("readonly", ""), t.select(), t.setSelectionRange(0, t.value.length), f || t.removeAttribute("readonly"), a = t.value;
          } else {
            t.hasAttribute("contenteditable") && t.focus();
            var s = window.getSelection(), h = document.createRange();
            h.selectNodeContents(t), s.removeAllRanges(), s.addRange(h), a = s.toString();
          }
          return a;
        }
        l.exports = c;
      }, 279: function(l) {
        function c() {
        }
        c.prototype = { on: function(t, a, f) {
          var s = this.e || (this.e = {});
          return (s[t] || (s[t] = [])).push({ fn: a, ctx: f }), this;
        }, once: function(t, a, f) {
          var s = this;
          function h() {
            s.off(t, h), a.apply(f, arguments);
          }
          return h._ = a, this.on(t, h, f);
        }, emit: function(t) {
          var a = [].slice.call(arguments, 1), f = ((this.e || (this.e = {}))[t] || []).slice(), s = 0, h = f.length;
          for (s; s < h; s++)
            f[s].fn.apply(f[s].ctx, a);
          return this;
        }, off: function(t, a) {
          var f = this.e || (this.e = {}), s = f[t], h = [];
          if (s && a)
            for (var y = 0, m = s.length; y < m; y++)
              s[y].fn !== a && s[y].fn._ !== a && h.push(s[y]);
          return h.length ? f[t] = h : delete f[t], this;
        } }, l.exports = c, l.exports.TinyEmitter = c;
      } }, E = {};
      function b(l) {
        if (E[l])
          return E[l].exports;
        var c = E[l] = { exports: {} };
        return S[l](c, c.exports, b), c.exports;
      }
      return function() {
        b.n = function(l) {
          var c = l && l.__esModule ? function() {
            return l.default;
          } : function() {
            return l;
          };
          return b.d(c, { a: c }), c;
        };
      }(), function() {
        b.d = function(l, c) {
          for (var t in c)
            b.o(c, t) && !b.o(l, t) && Object.defineProperty(l, t, { enumerable: true, get: c[t] });
        };
      }(), function() {
        b.o = function(l, c) {
          return Object.prototype.hasOwnProperty.call(l, c);
        };
      }(), b(686);
    }().default;
  });
})(N);
var K = N.exports;
const Z = J(K);
export {
  Z as C,
  J as a,
  B as c,
  W as g
};
