import { _ as T, __tla as __tla_0 } from "./index.bb04cb73.js";
import { u as E } from "./vuex.33ea5d58.js";
import { u as L } from "./vue-i18n.07fcbeea.js";
import { m as j, e as A, a7 as N, a9 as P, aa as H, u as e, o as i, J as B, V as M, a as t, W as l, _ as h, O as g, c as w, L as O, a5 as D, U as R, ao as y } from "./@vue.b00de3e9.js";
import "./vue-router.c227d4ba.js";
import "./axios.853f16bf.js";
import "./element-plus.53baa8a9.js";
import "./@element-plus.e21ea623.js";
import "./@ctrl.11979b50.js";
import "./dayjs.9abdbee1.js";
import "./clipboard.aaae98d3.js";
import "./@vueuse.eccd744a.js";
import "./lodash-es.e1022fb5.js";
import "./@popperjs.da591b4f.js";
import "./vant.f7b4805b.js";
import "./@vant.f52f09a9.js";
import "./xe-utils.a532b55a.js";
import "./crypto-js.c184c643.js";
import "./decimal.js.2def1975.js";
import "./nprogress.9fc41f77.js";
import "./vconsole.0cfb1d33.js";
import "./perfect-scrollbar.19f80865.js";
import "./@intlify.928cb664.js";
let Co;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e2) {
    }
  })()
]).then(async () => {
  function z() {
    const x = E(), { t: n } = L(), o = j({
      visible: false,
      title: "Tips",
      message: "",
      cancelButtonText: n("common.cancel"),
      confirmButtonText: n("common.confirm"),
      resolve: "",
      reject: "",
      isCancel: false,
      showDialog: true,
      showClose: true,
      showIcon: false
    }), r = async () => {
      o.isCancel = true, await o.reject(), o.isCancel = false, o.showDialog = false;
    }, a = async () => {
      await o.resolve(), o.showDialog = false;
    }, m = async () => {
      o.close ? await o.close() : await o.reject(), o.showDialog = false;
    }, _ = (c = "", f = "Tips", s = {
      confirmText: n("common.confirm"),
      cancelText: n("common.cancel"),
      showIcon: false
    }, d = () => {
    }, u = () => {
    }, p) => {
      o.showDialog = true, o.visible = true, o.title = f, o.message = c, o.cancelButtonText = s.cancelText, o.confirmButtonText = s.confirmText, o.resolve = d, o.reject = u, o.close = p, o.showIcon = s.showIcon, s.showClose !== void 0 && (o.showClose = s.showClose);
    };
    return A(() => {
      globalVBus.$on("handleConfirm", _);
    }), {
      ...N(o),
      store: x,
      cancel: r,
      handleConfirm: a,
      close: m
    };
  }
  let S, $, J, U, W, q, F;
  S = {
    class: "confirm-dialog-box"
  };
  $ = {
    class: "confirm-dialog-box__header"
  };
  J = {
    class: "confirm-dialog-box__content"
  };
  U = [
    "innerHTML"
  ];
  W = {
    class: "confirm-dialog-box__footer"
  };
  q = {
    class: "confirmBtn"
  };
  F = {
    key: 0,
    class: "confirm-dialog-close"
  };
  Co = {
    __name: "confirm",
    setup(x, { expose: n }) {
      const o = y(() => T(() => import("./index.e415b222.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index.e415b222.js","js/@vue.b00de3e9.js","js/vuex.33ea5d58.js","js/index.bb04cb73.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/index.36ac8329.css"])), { showDialog: r, visible: a, title: m, message: _, cancelButtonText: c, confirmButtonText: f, isCancel: s, cancel: d, handleConfirm: u, showClose: p, showIcon: b, close: I } = z(), k = y(() => T(() => import("./download_close.c6269472.js"), ["js/download_close.c6269472.js","js/@vue.b00de3e9.js"]));
      return n({
        open: () => {
        }
      }), (K, C) => {
        const V = P("svg-icon"), v = H("loadingThrottle");
        return e(a) ? (i(), B(e(o), {
          key: 0,
          visible: e(r),
          onClose: C[0] || (C[0] = (Q) => a.value = false),
          zIndexBase: 5e3
        }, {
          default: M(() => [
            t("div", S, [
              t("div", $, [
                e(b) ? (i(), B(V, {
                  key: 0,
                  class: "wg_fail",
                  iconClass: "wg_fail"
                })) : l("", true),
                t("span", null, h(e(m)), 1)
              ]),
              t("div", J, [
                t("div", {
                  class: "message",
                  innerHTML: e(_)
                }, null, 8, U)
              ]),
              t("div", W, [
                e(c) ? g((i(), w("div", {
                  key: 0,
                  class: O([
                    "cancelBtn",
                    {
                      hover: e(s)
                    }
                  ])
                }, [
                  D(h(e(c)), 1)
                ], 2)), [
                  [
                    v,
                    e(d)
                  ]
                ]) : l("", true),
                g((i(), w("div", q, [
                  D(h(e(f)), 1)
                ])), [
                  [
                    v,
                    e(u)
                  ]
                ])
              ])
            ]),
            e(p) ? (i(), w("div", F, [
              t("div", null, [
                g(R(e(k), {
                  class: "svg-icon"
                }, null, 512), [
                  [
                    v,
                    e(I)
                  ]
                ])
              ])
            ])) : l("", true)
          ]),
          _: 1
        }, 8, [
          "visible"
        ])) : l("", true);
      };
    }
  };
});
export {
  __tla,
  Co as default
};
