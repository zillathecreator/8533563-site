import { i as ve, b as he, r as Y, e as me, n as Re, f as ke, g as Me, j as Pe, w as ge, u as $, k as we, l as Ae, m as oe, p as Ce, q as De } from "./@vue.b00de3e9.js";
var D = typeof window < "u";
function ie(t) {
  return D ? requestAnimationFrame(t) : -1;
}
function Nt(t) {
  D && cancelAnimationFrame(t);
}
function It(t) {
  ie(() => ie(t));
}
var je = (t) => t === window, ae = (t, e) => ({ top: 0, left: 0, right: t, bottom: e, width: t, height: e }), Vt = (t) => {
  const e = $(t);
  if (je(e)) {
    const n = e.innerWidth, r = e.innerHeight;
    return ae(n, r);
  }
  return (e == null ? void 0 : e.getBoundingClientRect) ? e.getBoundingClientRect() : ae(0, 0);
};
function Wt(t) {
  const e = ve(t, null);
  if (e) {
    const n = we(), { link: r, unlink: o, internalChildren: i } = e;
    r(n), he(() => o(n));
    const f = Ae(() => i.indexOf(n));
    return { parent: e, index: f };
  }
  return { parent: null, index: Y(-1) };
}
function Ne(t) {
  const e = [], n = (r) => {
    Array.isArray(r) && r.forEach((o) => {
      var i;
      De(o) && (e.push(o), (i = o.component) != null && i.subTree && (e.push(o.component.subTree), n(o.component.subTree.children)), o.children && n(o.children));
    });
  };
  return n(t), e;
}
var se = (t, e) => {
  const n = t.indexOf(e);
  return n === -1 ? t.findIndex((r) => e.key !== void 0 && e.key !== null && r.type === e.type && r.key === e.key) : n;
};
function Ie(t, e, n) {
  const r = Ne(t.subTree.children);
  n.sort((i, f) => se(r, i.vnode) - se(r, f.vnode));
  const o = n.map((i) => i.proxy);
  e.sort((i, f) => {
    const c = o.indexOf(i), u = o.indexOf(f);
    return c - u;
  });
}
function qt(t) {
  const e = oe([]), n = oe([]), r = we();
  return { children: e, linkChildren: (i) => {
    Ce(t, Object.assign({ link: (u) => {
      u.proxy && (n.push(u), e.push(u.proxy), Ie(r, e, n));
    }, unlink: (u) => {
      const l = n.indexOf(u);
      e.splice(l, 1), n.splice(l, 1);
    }, children: e, internalChildren: n }, i));
  } };
}
function Ve(t) {
  let e;
  me(() => {
    t(), Re(() => {
      e = true;
    });
  }), ke(() => {
    e && t();
  });
}
function We(t, e, n = {}) {
  if (!D)
    return;
  const { target: r = window, passive: o = false, capture: i = false } = n;
  let f = false, c;
  const u = (s) => {
    if (f)
      return;
    const p = $(s);
    p && !c && (p.addEventListener(t, e, { capture: i, passive: o }), c = true);
  }, l = (s) => {
    if (f)
      return;
    const p = $(s);
    p && c && (p.removeEventListener(t, e, i), c = false);
  };
  he(() => l(r)), Me(() => l(r)), Ve(() => u(r));
  let a;
  return Pe(r) && (a = ge(r, (s, p) => {
    l(p), u(s);
  })), () => {
    a == null ? void 0 : a(), l(r), f = true;
  };
}
function Yt(t, e, n = {}) {
  if (!D)
    return;
  const { eventName: r = "click" } = n;
  We(r, (i) => {
    (Array.isArray(t) ? t : [t]).every((u) => {
      const l = $(u);
      return l && !l.contains(i.target);
    }) && e(i);
  }, { target: document });
}
var X, Q;
function Bt() {
  if (!X && (X = Y(0), Q = Y(0), D)) {
    const t = () => {
      X.value = window.innerWidth, Q.value = window.innerHeight;
    };
    t(), window.addEventListener("resize", t, { passive: true }), window.addEventListener("orientationchange", t, { passive: true });
  }
  return { width: X, height: Q };
}
var qe = /scroll|auto|overlay/i, ye = D ? window : void 0;
function Ye(t) {
  return t.tagName !== "HTML" && t.tagName !== "BODY" && t.nodeType === 1;
}
function Be(t, e = ye) {
  let n = t;
  for (; n && n !== e && Ye(n); ) {
    const { overflowY: r } = window.getComputedStyle(n);
    if (qe.test(r))
      return n;
    n = n.parentNode;
  }
  return e;
}
function Xt(t, e = ye) {
  const n = Y();
  return me(() => {
    t.value && (n.value = Be(t.value, e));
  }), n;
}
var _;
function _t() {
  if (!_ && (_ = Y("visible"), D)) {
    const t = () => {
      _.value = document.hidden ? "hidden" : "visible";
    };
    t(), window.addEventListener("visibilitychange", t);
  }
  return _;
}
var Xe = Symbol("van-field");
function Ht(t) {
  const e = ve(Xe, null);
  e && !e.customValue.value && (e.customValue.value = t, ge(t, () => {
    e.resetValidation(), e.validateWithTrigger("onChange");
  }));
}
function S(t) {
  if (t == null)
    return window;
  if (t.toString() !== "[object Window]") {
    var e = t.ownerDocument;
    return e && e.defaultView || window;
  }
  return t;
}
function te(t) {
  var e = S(t).Element;
  return t instanceof e || t instanceof Element;
}
function x(t) {
  var e = S(t).HTMLElement;
  return t instanceof e || t instanceof HTMLElement;
}
function be(t) {
  if (typeof ShadowRoot > "u")
    return false;
  var e = S(t).ShadowRoot;
  return t instanceof e || t instanceof ShadowRoot;
}
var I = Math.round;
function Z() {
  var t = navigator.userAgentData;
  return t != null && t.brands ? t.brands.map(function(e) {
    return e.brand + "/" + e.version;
  }).join(" ") : navigator.userAgent;
}
function _e() {
  return !/^((?!chrome|android).)*safari/i.test(Z());
}
function K(t, e, n) {
  e === void 0 && (e = false), n === void 0 && (n = false);
  var r = t.getBoundingClientRect(), o = 1, i = 1;
  e && x(t) && (o = t.offsetWidth > 0 && I(r.width) / t.offsetWidth || 1, i = t.offsetHeight > 0 && I(r.height) / t.offsetHeight || 1);
  var f = te(t) ? S(t) : window, c = f.visualViewport, u = !_e() && n, l = (r.left + (u && c ? c.offsetLeft : 0)) / o, a = (r.top + (u && c ? c.offsetTop : 0)) / i, s = r.width / o, p = r.height / i;
  return { width: s, height: p, top: a, right: l + s, bottom: a + p, left: l, x: l, y: a };
}
function Oe(t) {
  var e = S(t), n = e.pageXOffset, r = e.pageYOffset;
  return { scrollLeft: n, scrollTop: r };
}
function He(t) {
  return { scrollLeft: t.scrollLeft, scrollTop: t.scrollTop };
}
function Fe(t) {
  return t === S(t) || !x(t) ? Oe(t) : He(t);
}
function L(t) {
  return t ? (t.nodeName || "").toLowerCase() : null;
}
function G(t) {
  return ((te(t) ? t.ownerDocument : t.document) || window.document).documentElement;
}
function $e(t) {
  return K(G(t)).left + Oe(t).scrollLeft;
}
function R(t) {
  return S(t).getComputedStyle(t);
}
function ne(t) {
  var e = R(t), n = e.overflow, r = e.overflowX, o = e.overflowY;
  return /auto|scroll|overlay|hidden/.test(n + o + r);
}
function Ke(t) {
  var e = t.getBoundingClientRect(), n = I(e.width) / t.offsetWidth || 1, r = I(e.height) / t.offsetHeight || 1;
  return n !== 1 || r !== 1;
}
function Ue(t, e, n) {
  n === void 0 && (n = false);
  var r = x(e), o = x(e) && Ke(e), i = G(e), f = K(t, o, n), c = { scrollLeft: 0, scrollTop: 0 }, u = { x: 0, y: 0 };
  return (r || !r && !n) && ((L(e) !== "body" || ne(i)) && (c = Fe(e)), x(e) ? (u = K(e, true), u.x += e.clientLeft, u.y += e.clientTop) : i && (u.x = $e(i))), { x: f.left + c.scrollLeft - u.x, y: f.top + c.scrollTop - u.y, width: f.width, height: f.height };
}
function ze(t) {
  var e = K(t), n = t.offsetWidth, r = t.offsetHeight;
  return Math.abs(e.width - n) <= 1 && (n = e.width), Math.abs(e.height - r) <= 1 && (r = e.height), { x: t.offsetLeft, y: t.offsetTop, width: n, height: r };
}
function re(t) {
  return L(t) === "html" ? t : t.assignedSlot || t.parentNode || (be(t) ? t.host : null) || G(t);
}
function Ee(t) {
  return ["html", "body", "#document"].indexOf(L(t)) >= 0 ? t.ownerDocument.body : x(t) && ne(t) ? t : Ee(re(t));
}
function F(t, e) {
  var n;
  e === void 0 && (e = []);
  var r = Ee(t), o = r === ((n = t.ownerDocument) == null ? void 0 : n.body), i = S(r), f = o ? [i].concat(i.visualViewport || [], ne(r) ? r : []) : r, c = e.concat(f);
  return o ? c : c.concat(F(re(f)));
}
function Ge(t) {
  return ["table", "td", "th"].indexOf(L(t)) >= 0;
}
function ue(t) {
  return !x(t) || R(t).position === "fixed" ? null : t.offsetParent;
}
function Je(t) {
  var e = /firefox/i.test(Z()), n = /Trident/i.test(Z());
  if (n && x(t)) {
    var r = R(t);
    if (r.position === "fixed")
      return null;
  }
  var o = re(t);
  for (be(o) && (o = o.host); x(o) && ["html", "body"].indexOf(L(o)) < 0; ) {
    var i = R(o);
    if (i.transform !== "none" || i.perspective !== "none" || i.contain === "paint" || ["transform", "perspective"].indexOf(i.willChange) !== -1 || e && i.willChange === "filter" || e && i.filter && i.filter !== "none")
      return o;
    o = o.parentNode;
  }
  return null;
}
function xe(t) {
  for (var e = S(t), n = ue(t); n && Ge(n) && R(n).position === "static"; )
    n = ue(n);
  return n && (L(n) === "html" || L(n) === "body" && R(n).position === "static") ? e : n || Je(t) || e;
}
var N = "top", U = "bottom", B = "right", C = "left", Se = "auto", Qe = [N, U, B, C], Te = "start", z = "end", Ze = [].concat(Qe, [Se]).reduce(function(t, e) {
  return t.concat([e, e + "-" + Te, e + "-" + z]);
}, []), et = "beforeRead", tt = "read", nt = "afterRead", rt = "beforeMain", ot = "main", it = "afterMain", at = "beforeWrite", st = "write", ut = "afterWrite", ee = [et, tt, nt, rt, ot, it, at, st, ut];
function ct(t) {
  var e = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Set(), r = [];
  t.forEach(function(i) {
    e.set(i.name, i);
  });
  function o(i) {
    n.add(i.name);
    var f = [].concat(i.requires || [], i.requiresIfExists || []);
    f.forEach(function(c) {
      if (!n.has(c)) {
        var u = e.get(c);
        u && o(u);
      }
    }), r.push(i);
  }
  return t.forEach(function(i) {
    n.has(i.name) || o(i);
  }), r;
}
function ft(t) {
  var e = ct(t);
  return ee.reduce(function(n, r) {
    return n.concat(e.filter(function(o) {
      return o.phase === r;
    }));
  }, []);
}
function lt(t) {
  var e;
  return function() {
    return e || (e = new Promise(function(n) {
      Promise.resolve().then(function() {
        e = void 0, n(t());
      });
    })), e;
  };
}
function M(t) {
  for (var e = arguments.length, n = new Array(e > 1 ? e - 1 : 0), r = 1; r < e; r++)
    n[r - 1] = arguments[r];
  return [].concat(n).reduce(function(o, i) {
    return o.replace(/%s/, i);
  }, t);
}
var A = 'Popper: modifier "%s" provided an invalid %s property, expected %s but got %s', pt = 'Popper: modifier "%s" requires "%s", but "%s" modifier is not available', ce = ["name", "enabled", "phase", "fn", "effect", "requires", "options"];
function dt(t) {
  t.forEach(function(e) {
    [].concat(Object.keys(e), ce).filter(function(n, r, o) {
      return o.indexOf(n) === r;
    }).forEach(function(n) {
      switch (n) {
        case "name":
          typeof e.name != "string" && console.error(M(A, String(e.name), '"name"', '"string"', '"' + String(e.name) + '"'));
          break;
        case "enabled":
          typeof e.enabled != "boolean" && console.error(M(A, e.name, '"enabled"', '"boolean"', '"' + String(e.enabled) + '"'));
          break;
        case "phase":
          ee.indexOf(e.phase) < 0 && console.error(M(A, e.name, '"phase"', "either " + ee.join(", "), '"' + String(e.phase) + '"'));
          break;
        case "fn":
          typeof e.fn != "function" && console.error(M(A, e.name, '"fn"', '"function"', '"' + String(e.fn) + '"'));
          break;
        case "effect":
          e.effect != null && typeof e.effect != "function" && console.error(M(A, e.name, '"effect"', '"function"', '"' + String(e.fn) + '"'));
          break;
        case "requires":
          e.requires != null && !Array.isArray(e.requires) && console.error(M(A, e.name, '"requires"', '"array"', '"' + String(e.requires) + '"'));
          break;
        case "requiresIfExists":
          Array.isArray(e.requiresIfExists) || console.error(M(A, e.name, '"requiresIfExists"', '"array"', '"' + String(e.requiresIfExists) + '"'));
          break;
        case "options":
        case "data":
          break;
        default:
          console.error('PopperJS: an invalid property has been provided to the "' + e.name + '" modifier, valid properties are ' + ce.map(function(r) {
            return '"' + r + '"';
          }).join(", ") + '; but "' + n + '" was provided.');
      }
      e.requires && e.requires.forEach(function(r) {
        t.find(function(o) {
          return o.name === r;
        }) == null && console.error(M(pt, String(e.name), r, r));
      });
    });
  });
}
function vt(t, e) {
  var n = /* @__PURE__ */ new Set();
  return t.filter(function(r) {
    var o = e(r);
    if (!n.has(o))
      return n.add(o), true;
  });
}
function J(t) {
  return t.split("-")[0];
}
function ht(t) {
  var e = t.reduce(function(n, r) {
    var o = n[r.name];
    return n[r.name] = o ? Object.assign({}, o, r, { options: Object.assign({}, o.options, r.options), data: Object.assign({}, o.data, r.data) }) : r, n;
  }, {});
  return Object.keys(e).map(function(n) {
    return e[n];
  });
}
function Le(t) {
  return t.split("-")[1];
}
function mt(t) {
  return ["top", "bottom"].indexOf(t) >= 0 ? "x" : "y";
}
function gt(t) {
  var e = t.reference, n = t.element, r = t.placement, o = r ? J(r) : null, i = r ? Le(r) : null, f = e.x + e.width / 2 - n.width / 2, c = e.y + e.height / 2 - n.height / 2, u;
  switch (o) {
    case N:
      u = { x: f, y: e.y - n.height };
      break;
    case U:
      u = { x: f, y: e.y + e.height };
      break;
    case B:
      u = { x: e.x + e.width, y: c };
      break;
    case C:
      u = { x: e.x - n.width, y: c };
      break;
    default:
      u = { x: e.x, y: e.y };
  }
  var l = o ? mt(o) : null;
  if (l != null) {
    var a = l === "y" ? "height" : "width";
    switch (i) {
      case Te:
        u[l] = u[l] - (e[a] / 2 - n[a] / 2);
        break;
      case z:
        u[l] = u[l] + (e[a] / 2 - n[a] / 2);
        break;
    }
  }
  return u;
}
var fe = "Popper: Invalid reference or popper argument provided. They must be either a DOM element or virtual element.", wt = "Popper: An infinite loop in the modifiers cycle has been detected! The cycle has been interrupted to prevent a browser crash.", le = { placement: "bottom", modifiers: [], strategy: "absolute" };
function pe() {
  for (var t = arguments.length, e = new Array(t), n = 0; n < t; n++)
    e[n] = arguments[n];
  return !e.some(function(r) {
    return !(r && typeof r.getBoundingClientRect == "function");
  });
}
function yt(t) {
  t === void 0 && (t = {});
  var e = t, n = e.defaultModifiers, r = n === void 0 ? [] : n, o = e.defaultOptions, i = o === void 0 ? le : o;
  return function(c, u, l) {
    l === void 0 && (l = i);
    var a = { placement: "bottom", orderedModifiers: [], options: Object.assign({}, le, i), modifiersData: {}, elements: { reference: c, popper: u }, attributes: {}, styles: {} }, s = [], p = false, d = { state: a, setOptions: function(O) {
      var T = typeof O == "function" ? O(a.options) : O;
      v(), a.options = Object.assign({}, i, a.options, T), a.scrollParents = { reference: te(c) ? F(c) : c.contextElement ? F(c.contextElement) : [], popper: F(u) };
      var b = ft(ht([].concat(r, a.options.modifiers)));
      a.orderedModifiers = b.filter(function(y) {
        return y.enabled;
      });
      {
        var E = vt([].concat(b, a.options.modifiers), function(y) {
          var j = y.name;
          return j;
        });
        if (dt(E), J(a.options.placement) === Se) {
          var g = a.orderedModifiers.find(function(y) {
            var j = y.name;
            return j === "flip";
          });
          g || console.error(['Popper: "auto" placements require the "flip" modifier be', "present and enabled to work."].join(" "));
        }
        var h = R(u), k = h.marginTop, P = h.marginRight, V = h.marginBottom, W = h.marginLeft;
        [k, P, V, W].some(function(y) {
          return parseFloat(y);
        }) && console.warn(['Popper: CSS "margin" styles cannot be used to apply padding', "between the popper and its reference element or boundary.", "To replicate margin, use the `offset` modifier, as well as", "the `padding` option in the `preventOverflow` and `flip`", "modifiers."].join(" "));
      }
      return w(), d.update();
    }, forceUpdate: function() {
      if (!p) {
        var O = a.elements, T = O.reference, b = O.popper;
        if (!pe(T, b)) {
          console.error(fe);
          return;
        }
        a.rects = { reference: Ue(T, xe(b), a.options.strategy === "fixed"), popper: ze(b) }, a.reset = false, a.placement = a.options.placement, a.orderedModifiers.forEach(function(y) {
          return a.modifiersData[y.name] = Object.assign({}, y.data);
        });
        for (var E = 0, g = 0; g < a.orderedModifiers.length; g++) {
          if (E += 1, E > 100) {
            console.error(wt);
            break;
          }
          if (a.reset === true) {
            a.reset = false, g = -1;
            continue;
          }
          var h = a.orderedModifiers[g], k = h.fn, P = h.options, V = P === void 0 ? {} : P, W = h.name;
          typeof k == "function" && (a = k({ state: a, options: V, name: W, instance: d }) || a);
        }
      }
    }, update: lt(function() {
      return new Promise(function(m) {
        d.forceUpdate(), m(a);
      });
    }), destroy: function() {
      v(), p = true;
    } };
    if (!pe(c, u))
      return console.error(fe), d;
    d.setOptions(l).then(function(m) {
      !p && l.onFirstUpdate && l.onFirstUpdate(m);
    });
    function w() {
      a.orderedModifiers.forEach(function(m) {
        var O = m.name, T = m.options, b = T === void 0 ? {} : T, E = m.effect;
        if (typeof E == "function") {
          var g = E({ state: a, name: O, instance: d, options: b }), h = function() {
          };
          s.push(g || h);
        }
      });
    }
    function v() {
      s.forEach(function(m) {
        return m();
      }), s = [];
    }
    return d;
  };
}
var H = { passive: true };
function bt(t) {
  var e = t.state, n = t.instance, r = t.options, o = r.scroll, i = o === void 0 ? true : o, f = r.resize, c = f === void 0 ? true : f, u = S(e.elements.popper), l = [].concat(e.scrollParents.reference, e.scrollParents.popper);
  return i && l.forEach(function(a) {
    a.addEventListener("scroll", n.update, H);
  }), c && u.addEventListener("resize", n.update, H), function() {
    i && l.forEach(function(a) {
      a.removeEventListener("scroll", n.update, H);
    }), c && u.removeEventListener("resize", n.update, H);
  };
}
var Ot = { name: "eventListeners", enabled: true, phase: "write", fn: function() {
}, effect: bt, data: {} };
function Et(t) {
  var e = t.state, n = t.name;
  e.modifiersData[n] = gt({ reference: e.rects.reference, element: e.rects.popper, strategy: "absolute", placement: e.placement });
}
var xt = { name: "popperOffsets", enabled: true, phase: "read", fn: Et, data: {} }, St = { top: "auto", right: "auto", bottom: "auto", left: "auto" };
function Tt(t) {
  var e = t.x, n = t.y, r = window, o = r.devicePixelRatio || 1;
  return { x: I(e * o) / o || 0, y: I(n * o) / o || 0 };
}
function de(t) {
  var e, n = t.popper, r = t.popperRect, o = t.placement, i = t.variation, f = t.offsets, c = t.position, u = t.gpuAcceleration, l = t.adaptive, a = t.roundOffsets, s = t.isFixed, p = f.x, d = p === void 0 ? 0 : p, w = f.y, v = w === void 0 ? 0 : w, m = typeof a == "function" ? a({ x: d, y: v }) : { x: d, y: v };
  d = m.x, v = m.y;
  var O = f.hasOwnProperty("x"), T = f.hasOwnProperty("y"), b = C, E = N, g = window;
  if (l) {
    var h = xe(n), k = "clientHeight", P = "clientWidth";
    if (h === S(n) && (h = G(n), R(h).position !== "static" && c === "absolute" && (k = "scrollHeight", P = "scrollWidth")), h = h, o === N || (o === C || o === B) && i === z) {
      E = U;
      var V = s && h === g && g.visualViewport ? g.visualViewport.height : h[k];
      v -= V - r.height, v *= u ? 1 : -1;
    }
    if (o === C || (o === N || o === U) && i === z) {
      b = B;
      var W = s && h === g && g.visualViewport ? g.visualViewport.width : h[P];
      d -= W - r.width, d *= u ? 1 : -1;
    }
  }
  var y = Object.assign({ position: c }, l && St), j = a === true ? Tt({ x: d, y: v }) : { x: d, y: v };
  if (d = j.x, v = j.y, u) {
    var q;
    return Object.assign({}, y, (q = {}, q[E] = T ? "0" : "", q[b] = O ? "0" : "", q.transform = (g.devicePixelRatio || 1) <= 1 ? "translate(" + d + "px, " + v + "px)" : "translate3d(" + d + "px, " + v + "px, 0)", q));
  }
  return Object.assign({}, y, (e = {}, e[E] = T ? v + "px" : "", e[b] = O ? d + "px" : "", e.transform = "", e));
}
function Lt(t) {
  var e = t.state, n = t.options, r = n.gpuAcceleration, o = r === void 0 ? true : r, i = n.adaptive, f = i === void 0 ? true : i, c = n.roundOffsets, u = c === void 0 ? true : c;
  {
    var l = R(e.elements.popper).transitionProperty || "";
    f && ["transform", "top", "right", "bottom", "left"].some(function(s) {
      return l.indexOf(s) >= 0;
    }) && console.warn(["Popper: Detected CSS transitions on at least one of the following", 'CSS properties: "transform", "top", "right", "bottom", "left".', "\n\n", 'Disable the "computeStyles" modifier\'s `adaptive` option to allow', "for smooth transitions, or remove these properties from the CSS", "transition declaration on the popper element if only transitioning", "opacity or background-color for example.", "\n\n", "We recommend using the popper element as a wrapper around an inner", "element that can have any CSS property transitioned for animations."].join(" "));
  }
  var a = { placement: J(e.placement), variation: Le(e.placement), popper: e.elements.popper, popperRect: e.rects.popper, gpuAcceleration: o, isFixed: e.options.strategy === "fixed" };
  e.modifiersData.popperOffsets != null && (e.styles.popper = Object.assign({}, e.styles.popper, de(Object.assign({}, a, { offsets: e.modifiersData.popperOffsets, position: e.options.strategy, adaptive: f, roundOffsets: u })))), e.modifiersData.arrow != null && (e.styles.arrow = Object.assign({}, e.styles.arrow, de(Object.assign({}, a, { offsets: e.modifiersData.arrow, position: "absolute", adaptive: false, roundOffsets: u })))), e.attributes.popper = Object.assign({}, e.attributes.popper, { "data-popper-placement": e.placement });
}
var Rt = { name: "computeStyles", enabled: true, phase: "beforeWrite", fn: Lt, data: {} };
function kt(t) {
  var e = t.state;
  Object.keys(e.elements).forEach(function(n) {
    var r = e.styles[n] || {}, o = e.attributes[n] || {}, i = e.elements[n];
    !x(i) || !L(i) || (Object.assign(i.style, r), Object.keys(o).forEach(function(f) {
      var c = o[f];
      c === false ? i.removeAttribute(f) : i.setAttribute(f, c === true ? "" : c);
    }));
  });
}
function Mt(t) {
  var e = t.state, n = { popper: { position: e.options.strategy, left: "0", top: "0", margin: "0" }, arrow: { position: "absolute" }, reference: {} };
  return Object.assign(e.elements.popper.style, n.popper), e.styles = n, e.elements.arrow && Object.assign(e.elements.arrow.style, n.arrow), function() {
    Object.keys(e.elements).forEach(function(r) {
      var o = e.elements[r], i = e.attributes[r] || {}, f = Object.keys(e.styles.hasOwnProperty(r) ? e.styles[r] : n[r]), c = f.reduce(function(u, l) {
        return u[l] = "", u;
      }, {});
      !x(o) || !L(o) || (Object.assign(o.style, c), Object.keys(i).forEach(function(u) {
        o.removeAttribute(u);
      }));
    });
  };
}
var Pt = { name: "applyStyles", enabled: true, phase: "write", fn: kt, effect: Mt, requires: ["computeStyles"] }, At = [Ot, xt, Rt, Pt], Ft = yt({ defaultModifiers: At });
function Ct(t, e, n) {
  var r = J(t), o = [C, N].indexOf(r) >= 0 ? -1 : 1, i = typeof n == "function" ? n(Object.assign({}, e, { placement: t })) : n, f = i[0], c = i[1];
  return f = f || 0, c = (c || 0) * o, [C, B].indexOf(r) >= 0 ? { x: c, y: f } : { x: f, y: c };
}
function Dt(t) {
  var e = t.state, n = t.options, r = t.name, o = n.offset, i = o === void 0 ? [0, 0] : o, f = Ze.reduce(function(a, s) {
    return a[s] = Ct(s, e.rects, i), a;
  }, {}), c = f[e.placement], u = c.x, l = c.y;
  e.modifiersData.popperOffsets != null && (e.modifiersData.popperOffsets.x += u, e.modifiersData.popperOffsets.y += l), e.modifiersData[r] = f;
}
var $t = { name: "offset", enabled: true, phase: "main", requires: ["popperOffsets"], fn: Dt };
(function() {
  if (typeof window > "u")
    return;
  var t, e = "ontouchstart" in window;
  document.createTouch || (document.createTouch = function(a, s, p, d, w, v, m) {
    return new n(s, p, { pageX: d, pageY: w, screenX: v, screenY: m, clientX: d - window.pageXOffset, clientY: w - window.pageYOffset }, 0, 0);
  }), document.createTouchList || (document.createTouchList = function() {
    for (var a = r(), s = 0; s < arguments.length; s++)
      a[s] = arguments[s];
    return a.length = arguments.length, a;
  }), Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector), Element.prototype.closest || (Element.prototype.closest = function(a) {
    var s = this;
    do {
      if (s.matches(a))
        return s;
      s = s.parentElement || s.parentNode;
    } while (s !== null && s.nodeType === 1);
    return null;
  });
  var n = function(s, p, d, w, v) {
    w = w || 0, v = v || 0, this.identifier = p, this.target = s, this.clientX = d.clientX + w, this.clientY = d.clientY + v, this.screenX = d.screenX + w, this.screenY = d.screenY + v, this.pageX = d.pageX + w, this.pageY = d.pageY + v;
  };
  function r() {
    var a = [];
    return a.item = function(s) {
      return this[s] || null;
    }, a.identifiedTouch = function(s) {
      return this[s + 1] || null;
    }, a;
  }
  var o = false;
  function i(a) {
    return function(s) {
      s.type === "mousedown" && (o = true), s.type === "mouseup" && (o = false), !(s.type === "mousemove" && !o) && ((s.type === "mousedown" || !t || t && !t.dispatchEvent) && (t = s.composed ? s.composedPath()[0] : s.target), t.closest("[data-no-touch-simulate]") == null && f(a, s), s.type === "mouseup" && (t = null));
    };
  }
  function f(a, s) {
    var p = new Event(a, { bubbles: true, cancelable: true, composed: true });
    p.altKey = s.altKey, p.ctrlKey = s.ctrlKey, p.metaKey = s.metaKey, p.shiftKey = s.shiftKey, p.touches = u(s), p.targetTouches = u(s), p.changedTouches = c(s), t.dispatchEvent(p);
  }
  function c(a) {
    var s = r();
    return s.push(new n(t, 1, a, 0, 0)), s;
  }
  function u(a) {
    return a.type === "mouseup" ? r() : c(a);
  }
  function l() {
    window.addEventListener("mousedown", i("touchstart"), true), window.addEventListener("mousemove", i("touchmove"), true), window.addEventListener("mouseup", i("touchend"), true);
  }
  l.multiTouchOffset = 75, e || new l();
})();
const Kt = Object.freeze(Object.defineProperty({ __proto__: null }, Symbol.toStringTag, { value: "Module" }));
export {
  Xe as C,
  Vt as a,
  We as b,
  Wt as c,
  Nt as d,
  Xt as e,
  _t as f,
  Be as g,
  qt as h,
  It as i,
  Ht as j,
  Yt as k,
  $t as l,
  Ft as m,
  Kt as n,
  Ve as o,
  ie as r,
  Bt as u
};
