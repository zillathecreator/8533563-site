import { av as h, _ as g, __tla as __tla_0 } from "./index.bb04cb73.js";
import { S as k, A as C, P as S, a as w } from "./swiper.e7c9d9a6.js";
import { u as A } from "./vuex.33ea5d58.js";
import { f as B, g as P, o as a, J as i, u as e, c as u, a as c, V as _, R as x, ab as I, L as d, W as L, ao as R, r as T, l as t } from "./@vue.b00de3e9.js";
import "./vue-router.c227d4ba.js";
import "./axios.853f16bf.js";
import "./element-plus.53baa8a9.js";
import "./@element-plus.e21ea623.js";
import "./@ctrl.11979b50.js";
import "./dayjs.9abdbee1.js";
import "./clipboard.aaae98d3.js";
import "./@vueuse.eccd744a.js";
import "./lodash-es.e1022fb5.js";
import "./@popperjs.da591b4f.js";
import "./vant.f7b4805b.js";
import "./@vant.f52f09a9.js";
import "./vue-i18n.07fcbeea.js";
import "./@intlify.928cb664.js";
import "./xe-utils.a532b55a.js";
import "./crypto-js.c184c643.js";
import "./decimal.js.2def1975.js";
import "./nprogress.9fc41f77.js";
import "./vconsole.0cfb1d33.js";
import "./perfect-scrollbar.19f80865.js";
let le;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e2) {
    }
  })()
]).then(async () => {
  let V, E;
  V = {
    class: "home-banner-box"
  };
  E = [
    "src"
  ];
  le = {
    __name: "banner",
    setup(D) {
      const v = R(() => g(() => import("./banner_and_quick.24fdbcac.js").then(async (m) => {
        await m.__tla;
        return m;
      }), ["js/banner_and_quick.24fdbcac.js","js/swiper.e7c9d9a6.js","js/@vue.b00de3e9.js","css/swiper.aa45c171.css","js/vuex.33ea5d58.js","js/index.bb04cb73.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/banner_and_quick.7d065e3f.css"])), l = A(), n = T(null), r = t(() => l.state.homeBannerInfo), p = t(() => {
        var _a;
        return ((_a = r.value) == null ? void 0 : _a.list) || [];
      }), y = t(() => {
        var _a;
        return ((_a = r.value) == null ? void 0 : _a.time) || 3;
      }), o = t(() => {
        var _a;
        return ((_a = r.value) == null ? void 0 : _a.bannerType) || 0;
      }), b = t(() => {
        var _a;
        return !!((_a = l.state.shortcut.one) == null ? void 0 : _a.status);
      }), f = (m) => {
        n.value = m;
      };
      return B(() => {
        var _a, _b;
        (_b = (_a = n.value) == null ? void 0 : _a.autoplay) == null ? void 0 : _b.start();
      }), P(() => {
        var _a, _b;
        (_b = (_a = n.value) == null ? void 0 : _a.autoplay) == null ? void 0 : _b.stop();
      }), (m, F) => o.value === 4 ? (a(), i(e(v), {
        key: 0
      })) : (a(), u("div", {
        key: 1,
        class: d([
          "home-banner",
          {
            "home-banner-big": o.value === 1,
            "home-banner-middle": o.value === 2,
            "panda-banner": o.value === 3
          }
        ])
      }, [
        c("div", V, [
          p.value.length ? (a(), i(e(w), {
            key: 0,
            preventClicksPropagation: "",
            onSwiper: f,
            loop: true,
            autoplay: {
              delay: y.value * 1e3,
              disableOnInteraction: false
            },
            modules: [
              e(C),
              e(S)
            ],
            pagination: {
              clickable: true
            },
            class: d([
              "mySwiper my-swipe",
              {
                notFullPage: b.value
              }
            ])
          }, {
            default: _(() => [
              (a(true), u(x, null, I(p.value, (s) => (a(), i(e(k), {
                key: s,
                onClick: (N) => e(h)(s)
              }, {
                default: _(() => [
                  c("img", {
                    src: s.image
                  }, null, 8, E)
                ]),
                _: 2
              }, 1032, [
                "onClick"
              ]))), 128))
            ]),
            _: 1
          }, 8, [
            "autoplay",
            "modules",
            "class"
          ])) : L("", true)
        ])
      ], 2));
    }
  };
});
export {
  __tla,
  le as default
};
