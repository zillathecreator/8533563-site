import { Q as d, _ as f, $ as k, __tla as __tla_0 } from "./index.bb04cb73.js";
import { u as v } from "./vuex.33ea5d58.js";
import { w as j, o as h, J as x, V as l, a as o, _ as e, a5 as c, u as i, W as y, ao as $, r as g, l as m } from "./@vue.b00de3e9.js";
import "./vue-router.c227d4ba.js";
import "./axios.853f16bf.js";
import "./element-plus.53baa8a9.js";
import "./@element-plus.e21ea623.js";
import "./@ctrl.11979b50.js";
import "./dayjs.9abdbee1.js";
import "./clipboard.aaae98d3.js";
import "./@vueuse.eccd744a.js";
import "./lodash-es.e1022fb5.js";
import "./@popperjs.da591b4f.js";
import "./vant.f7b4805b.js";
import "./@vant.f52f09a9.js";
import "./vue-i18n.07fcbeea.js";
import "./@intlify.928cb664.js";
import "./xe-utils.a532b55a.js";
import "./crypto-js.c184c643.js";
import "./decimal.js.2def1975.js";
import "./nprogress.9fc41f77.js";
import "./vconsole.0cfb1d33.js";
import "./perfect-scrollbar.19f80865.js";
let Z;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e2) {
    }
  })()
]).then(async () => {
  let C, z, I, N, R;
  C = {
    class: "main"
  };
  z = {
    class: "title"
  };
  I = {
    class: "prize-info"
  };
  N = {
    class: "text"
  };
  R = {
    class: "prize-amount"
  };
  Z = {
    __name: "index",
    setup(V) {
      const u = $(() => f(() => import("./index.bb04cb73.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }).then((t) => t.cg), ["js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css"])), a = v(), s = g(null), n = m(() => {
        var _a, _b;
        return (_b = (_a = a.state.jackpotInfo) == null ? void 0 : _a.ext) == null ? void 0 : _b.amount;
      }), _ = m(() => {
        var _a, _b;
        const t = (_b = (_a = a.state.jackpotInfo) == null ? void 0 : _a.ext) == null ? void 0 : _b.cycle;
        return +t == 1 ? $t("jackpot.day") : +t == 2 ? $t("jackpot.week") : +t == 3 ? $t("jackpot.month") : +t == 4 ? $t("jackpot.hour") : "";
      });
      j(() => {
        var _a, _b;
        return (_b = (_a = a.state.jackpotInfo) == null ? void 0 : _a.ext) == null ? void 0 : _b.amount;
      }, (t) => {
        t > 0 && s.value && (s.value.visible = true);
      });
      const p = () => {
        k.get("/user/promotion/JackpotPop").then((t) => {
          t.status === "OK" && a.dispatch("getJackpotDetail");
        });
      };
      return (t, r) => n.value > 0 ? (h(), x(i(u), {
        key: 0,
        ref_key: "prizeResRef",
        ref: s,
        class: "jackpot-prize-result-dialog",
        onInput: p,
        title: " ",
        modalClose: false,
        onCancel: p
      }, {
        footer: l(() => [
          ...r[1] || (r[1] = [])
        ]),
        default: l(() => [
          o("div", C, [
            o("div", z, e(t.$t("jackpot.result_text1")), 1),
            o("div", I, [
              o("div", N, [
                c(e(t.$t("jackpot.result_text2")) + " ", 1),
                r[0] || (r[0] = o("br", null, null, -1)),
                o("span", null, e(_.value), 1),
                c(" " + e(t.$t("jackpot.pool")) + " " + e(t.$t("jackpot.result_text3")), 1)
              ]),
              o("div", R, e(i(a).state.currency) + " " + e(i(d)(n.value)), 1)
            ])
          ])
        ]),
        _: 1
      }, 512)) : y("", true);
    }
  };
});
export {
  __tla,
  Z as default
};
