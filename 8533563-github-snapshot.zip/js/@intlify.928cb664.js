/*!
  * shared v9.14.5
  * (c) 2025 kazuya kawaguchi
  * Released under the MIT License.
  */
function Xt(e, t) {
  typeof console < "u" && (console.warn("[intlify] " + e), t && console.warn(t.stack));
}
const Tr = typeof window < "u", hr = (e, t = false) => t ? Symbol.for(e) : Symbol(e), Gt = (e, t, n) => Vt({ l: e, k: t, s: n }), Vt = (e) => JSON.stringify(e).replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029").replace(/\u0027/g, "\\u0027"), K = (e) => typeof e == "number" && isFinite(e), Ht = (e) => ze(e) === "[object Date]", Fe = (e) => ze(e) === "[object RegExp]", Se = (e) => U(e) && Object.keys(e).length === 0, oe = Object.assign, xt = Object.create, $ = (e = null) => xt(e);
let ve;
const he = () => ve || (ve = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : typeof global < "u" ? global : $());
function $e(e) {
  return e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;").replace(/\//g, "&#x2F;").replace(/=/g, "&#x3D;");
}
function We(e) {
  return e.replace(/&(?![a-zA-Z0-9#]{2,6};)/g, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&apos;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function jt(e) {
  return e = e.replace(/(\w+)\s*=\s*"([^"]*)"/g, (s, c, i) => "".concat(c, '="').concat(We(i), '"')), e = e.replace(/(\w+)\s*=\s*'([^']*)'/g, (s, c, i) => "".concat(c, "='").concat(We(i), "'")), /\s*on\w+\s*=\s*["']?[^"'>]+["']?/gi.test(e) && (e = e.replace(/(\s+)(on)(\w+\s*=)/gi, "$1&#111;n$3")), [/(\s+(?:href|src|action|formaction)\s*=\s*["']?)\s*javascript:/gi, /(style\s*=\s*["'][^"']*url\s*\(\s*)javascript:/gi].forEach((s) => {
    e = e.replace(s, "$1javascript&#58;");
  }), e;
}
const Bt = Object.prototype.hasOwnProperty;
function se(e, t) {
  return Bt.call(e, t);
}
const x = Array.isArray, v = (e) => typeof e == "function", S = (e) => typeof e == "string", X = (e) => typeof e == "boolean", F = (e) => e !== null && typeof e == "object", Jt = (e) => F(e) && v(e.then) && v(e.catch), Ze = Object.prototype.toString, ze = (e) => Ze.call(e), U = (e) => {
  if (!F(e))
    return false;
  const t = Object.getPrototypeOf(e);
  return t === null || t.constructor === Object;
}, Qt = (e) => e == null ? "" : x(e) || U(e) && e.toString === Ze ? JSON.stringify(e, null, 2) : String(e);
function qt(e, t = "") {
  return e.reduce((n, s, c) => c === 0 ? n + s : n + t + s, "");
}
function et(e) {
  let t = e;
  return () => ++t;
}
const Ee = (e) => !F(e) || x(e);
function Or(e, t) {
  if (Ee(e) || Ee(t))
    throw new Error("Invalid value");
  const n = [{ src: e, des: t }];
  for (; n.length; ) {
    const { src: s, des: c } = n.pop();
    Object.keys(s).forEach((i) => {
      i !== "__proto__" && (F(s[i]) && !F(c[i]) && (c[i] = Array.isArray(s[i]) ? [] : $()), Ee(c[i]) || Ee(s[i]) ? c[i] = s[i] : n.push({ src: s[i], des: c[i] }));
    });
  }
}
/*!
* message-compiler v9.14.5
* (c) 2025 kazuya kawaguchi
* Released under the MIT License.
*/
function Zt(e, t, n) {
  return { line: e, column: t, offset: n };
}
function Ne(e, t, n) {
  const s = { start: e, end: t };
  return n != null && (s.source = n), s;
}
const zt = /\{([0-9a-zA-Z]+)\}/g;
function tt(e, ...t) {
  return t.length === 1 && en(t[0]) && (t = t[0]), (!t || !t.hasOwnProperty) && (t = {}), e.replace(zt, (n, s) => t.hasOwnProperty(s) ? t[s] : "");
}
const nt = Object.assign, Ye = (e) => typeof e == "string", en = (e) => e !== null && typeof e == "object";
function rt(e, t = "") {
  return e.reduce((n, s, c) => c === 0 ? n + s : n + t + s, "");
}
const Pe = { USE_MODULO_SYNTAX: 1, __EXTEND_POINT__: 2 }, tn = { [Pe.USE_MODULO_SYNTAX]: "Use modulo before '{{0}}'." };
function nn(e, t, ...n) {
  const s = tt(tn[e] || "", ...n || []), c = { message: String(s), code: e };
  return t && (c.location = t), c;
}
const C = { EXPECTED_TOKEN: 1, INVALID_TOKEN_IN_PLACEHOLDER: 2, UNTERMINATED_SINGLE_QUOTE_IN_PLACEHOLDER: 3, UNKNOWN_ESCAPE_SEQUENCE: 4, INVALID_UNICODE_ESCAPE_SEQUENCE: 5, UNBALANCED_CLOSING_BRACE: 6, UNTERMINATED_CLOSING_BRACE: 7, EMPTY_PLACEHOLDER: 8, NOT_ALLOW_NEST_PLACEHOLDER: 9, INVALID_LINKED_FORMAT: 10, MUST_HAVE_MESSAGES_IN_PLURAL: 11, UNEXPECTED_EMPTY_LINKED_MODIFIER: 12, UNEXPECTED_EMPTY_LINKED_KEY: 13, UNEXPECTED_LEXICAL_ANALYSIS: 14, UNHANDLED_CODEGEN_NODE_TYPE: 15, UNHANDLED_MINIFIER_NODE_TYPE: 16, __EXTEND_POINT__: 17 }, rn = { [C.EXPECTED_TOKEN]: "Expected token: '{0}'", [C.INVALID_TOKEN_IN_PLACEHOLDER]: "Invalid token in placeholder: '{0}'", [C.UNTERMINATED_SINGLE_QUOTE_IN_PLACEHOLDER]: "Unterminated single quote in placeholder", [C.UNKNOWN_ESCAPE_SEQUENCE]: "Unknown escape sequence: \\{0}", [C.INVALID_UNICODE_ESCAPE_SEQUENCE]: "Invalid unicode escape sequence: {0}", [C.UNBALANCED_CLOSING_BRACE]: "Unbalanced closing brace", [C.UNTERMINATED_CLOSING_BRACE]: "Unterminated closing brace", [C.EMPTY_PLACEHOLDER]: "Empty placeholder", [C.NOT_ALLOW_NEST_PLACEHOLDER]: "Not allowed nest placeholder", [C.INVALID_LINKED_FORMAT]: "Invalid linked format", [C.MUST_HAVE_MESSAGES_IN_PLURAL]: "Plural must have messages", [C.UNEXPECTED_EMPTY_LINKED_MODIFIER]: "Unexpected empty linked modifier", [C.UNEXPECTED_EMPTY_LINKED_KEY]: "Unexpected empty linked key", [C.UNEXPECTED_LEXICAL_ANALYSIS]: "Unexpected lexical analysis in token: '{0}'", [C.UNHANDLED_CODEGEN_NODE_TYPE]: "unhandled codegen node type: '{0}'", [C.UNHANDLED_MINIFIER_NODE_TYPE]: "unhandled mimifier node type: '{0}'" };
function _e(e, t, n = {}) {
  const { domain: s, messages: c, args: i } = n, d = tt((c || rn)[e] || "", ...i || []), E = new SyntaxError(String(d));
  return E.code = e, t && (E.location = t), E.domain = s, E;
}
function sn(e) {
  throw e;
}
const Q = " ", an = "\r", Y = "\n", cn = String.fromCharCode(8232), ln = String.fromCharCode(8233);
function on(e) {
  const t = e;
  let n = 0, s = 1, c = 1, i = 0;
  const d = (N) => t[N] === an && t[N + 1] === Y, E = (N) => t[N] === Y, f = (N) => t[N] === ln, L = (N) => t[N] === cn, g = (N) => d(N) || E(N) || f(N) || L(N), h = () => n, p = () => s, P = () => c, y = () => i, b = (N) => d(N) || f(N) || L(N) ? Y : t[N], O = () => b(n), A = () => b(n + i);
  function D() {
    return i = 0, g(n) && (s++, c = 0), d(n) && n++, n++, c++, t[n];
  }
  function l() {
    return d(n + i) && i++, i++, t[n + i];
  }
  function o() {
    n = 0, s = 1, c = 1, i = 0;
  }
  function m(N = 0) {
    i = N;
  }
  function _() {
    const N = n + i;
    for (; N !== n; )
      D();
    i = 0;
  }
  return { index: h, line: p, column: P, peekOffset: y, charAt: b, currentChar: O, currentPeek: A, next: D, peek: l, reset: o, resetPeek: m, skipToPeek: _ };
}
const Z = void 0, un = ".", Ke = "'", fn = "tokenizer";
function _n(e, t = {}) {
  const n = t.location !== false, s = on(e), c = () => s.index(), i = () => Zt(s.line(), s.column(), s.index()), d = i(), E = c(), f = { currentType: 14, offset: E, startLoc: d, endLoc: d, lastType: 14, lastOffset: E, lastStartLoc: d, lastEndLoc: d, braceNest: 0, inLinked: false, text: "" }, L = () => f, { onError: g } = t;
  function h(r, a, u, ...T) {
    const w = L();
    if (a.column += u, a.offset += u, g) {
      const M = n ? Ne(w.startLoc, a) : null, q = _e(r, M, { domain: fn, args: T });
      g(q);
    }
  }
  function p(r, a, u) {
    r.endLoc = i(), r.currentType = a;
    const T = { type: a };
    return n && (T.loc = Ne(r.startLoc, r.endLoc)), u != null && (T.value = u), T;
  }
  const P = (r) => p(r, 14);
  function y(r, a) {
    return r.currentChar() === a ? (r.next(), a) : (h(C.EXPECTED_TOKEN, i(), 0, a), "");
  }
  function b(r) {
    let a = "";
    for (; r.currentPeek() === Q || r.currentPeek() === Y; )
      a += r.currentPeek(), r.peek();
    return a;
  }
  function O(r) {
    const a = b(r);
    return r.skipToPeek(), a;
  }
  function A(r) {
    if (r === Z)
      return false;
    const a = r.charCodeAt(0);
    return a >= 97 && a <= 122 || a >= 65 && a <= 90 || a === 95;
  }
  function D(r) {
    if (r === Z)
      return false;
    const a = r.charCodeAt(0);
    return a >= 48 && a <= 57;
  }
  function l(r, a) {
    const { currentType: u } = a;
    if (u !== 2)
      return false;
    b(r);
    const T = A(r.currentPeek());
    return r.resetPeek(), T;
  }
  function o(r, a) {
    const { currentType: u } = a;
    if (u !== 2)
      return false;
    b(r);
    const T = r.currentPeek() === "-" ? r.peek() : r.currentPeek(), w = D(T);
    return r.resetPeek(), w;
  }
  function m(r, a) {
    const { currentType: u } = a;
    if (u !== 2)
      return false;
    b(r);
    const T = r.currentPeek() === Ke;
    return r.resetPeek(), T;
  }
  function _(r, a) {
    const { currentType: u } = a;
    if (u !== 8)
      return false;
    b(r);
    const T = r.currentPeek() === ".";
    return r.resetPeek(), T;
  }
  function N(r, a) {
    const { currentType: u } = a;
    if (u !== 9)
      return false;
    b(r);
    const T = A(r.currentPeek());
    return r.resetPeek(), T;
  }
  function I(r, a) {
    const { currentType: u } = a;
    if (!(u === 8 || u === 12))
      return false;
    b(r);
    const T = r.currentPeek() === ":";
    return r.resetPeek(), T;
  }
  function R(r, a) {
    const { currentType: u } = a;
    if (u !== 10)
      return false;
    const T = () => {
      const M = r.currentPeek();
      return M === "{" ? A(r.peek()) : M === "@" || M === "%" || M === "|" || M === ":" || M === "." || M === Q || !M ? false : M === Y ? (r.peek(), T()) : k(r, false);
    }, w = T();
    return r.resetPeek(), w;
  }
  function W(r) {
    b(r);
    const a = r.currentPeek() === "|";
    return r.resetPeek(), a;
  }
  function J(r) {
    const a = b(r), u = r.currentPeek() === "%" && r.peek() === "{";
    return r.resetPeek(), { isModulo: u, hasSpace: a.length > 0 };
  }
  function k(r, a = true) {
    const u = (w = false, M = "", q = false) => {
      const te = r.currentPeek();
      return te === "{" ? M === "%" ? false : w : te === "@" || !te ? M === "%" ? true : w : te === "%" ? (r.peek(), u(w, "%", true)) : te === "|" ? M === "%" || q ? true : !(M === Q || M === Y) : te === Q ? (r.peek(), u(true, Q, q)) : te === Y ? (r.peek(), u(true, Y, q)) : true;
    }, T = u();
    return a && r.resetPeek(), T;
  }
  function G(r, a) {
    const u = r.currentChar();
    return u === Z ? Z : a(u) ? (r.next(), u) : null;
  }
  function At(r) {
    const a = r.charCodeAt(0);
    return a >= 97 && a <= 122 || a >= 65 && a <= 90 || a >= 48 && a <= 57 || a === 95 || a === 36;
  }
  function Ct(r) {
    return G(r, At);
  }
  function gt(r) {
    const a = r.charCodeAt(0);
    return a >= 97 && a <= 122 || a >= 65 && a <= 90 || a >= 48 && a <= 57 || a === 95 || a === 36 || a === 45;
  }
  function St(r) {
    return G(r, gt);
  }
  function Pt(r) {
    const a = r.charCodeAt(0);
    return a >= 48 && a <= 57;
  }
  function yt(r) {
    return G(r, Pt);
  }
  function bt(r) {
    const a = r.charCodeAt(0);
    return a >= 48 && a <= 57 || a >= 65 && a <= 70 || a >= 97 && a <= 102;
  }
  function Dt(r) {
    return G(r, bt);
  }
  function Me(r) {
    let a = "", u = "";
    for (; a = yt(r); )
      u += a;
    return u;
  }
  function kt(r) {
    O(r);
    const a = r.currentChar();
    return a !== "%" && h(C.EXPECTED_TOKEN, i(), 0, a), r.next(), "%";
  }
  function Ue(r) {
    let a = "";
    for (; ; ) {
      const u = r.currentChar();
      if (u === "{" || u === "}" || u === "@" || u === "|" || !u)
        break;
      if (u === "%")
        if (k(r))
          a += u, r.next();
        else
          break;
      else if (u === Q || u === Y)
        if (k(r))
          a += u, r.next();
        else {
          if (W(r))
            break;
          a += u, r.next();
        }
      else
        a += u, r.next();
    }
    return a;
  }
  function Rt(r) {
    O(r);
    let a = "", u = "";
    for (; a = St(r); )
      u += a;
    return r.currentChar() === Z && h(C.UNTERMINATED_CLOSING_BRACE, i(), 0), u;
  }
  function Mt(r) {
    O(r);
    let a = "";
    return r.currentChar() === "-" ? (r.next(), a += "-".concat(Me(r))) : a += Me(r), r.currentChar() === Z && h(C.UNTERMINATED_CLOSING_BRACE, i(), 0), a;
  }
  function Ut(r) {
    return r !== Ke && r !== Y;
  }
  function wt(r) {
    O(r), y(r, "'");
    let a = "", u = "";
    for (; a = G(r, Ut); )
      a === "\\" ? u += Ft(r) : u += a;
    const T = r.currentChar();
    return T === Y || T === Z ? (h(C.UNTERMINATED_SINGLE_QUOTE_IN_PLACEHOLDER, i(), 0), T === Y && (r.next(), y(r, "'")), u) : (y(r, "'"), u);
  }
  function Ft(r) {
    const a = r.currentChar();
    switch (a) {
      case "\\":
      case "'":
        return r.next(), "\\".concat(a);
      case "u":
        return we(r, a, 4);
      case "U":
        return we(r, a, 6);
      default:
        return h(C.UNKNOWN_ESCAPE_SEQUENCE, i(), 0, a), "";
    }
  }
  function we(r, a, u) {
    y(r, a);
    let T = "";
    for (let w = 0; w < u; w++) {
      const M = Dt(r);
      if (!M) {
        h(C.INVALID_UNICODE_ESCAPE_SEQUENCE, i(), 0, "\\".concat(a).concat(T).concat(r.currentChar()));
        break;
      }
      T += M;
    }
    return "\\".concat(a).concat(T);
  }
  function vt(r) {
    return r !== "{" && r !== "}" && r !== Q && r !== Y;
  }
  function $t(r) {
    O(r);
    let a = "", u = "";
    for (; a = G(r, vt); )
      u += a;
    return u;
  }
  function Wt(r) {
    let a = "", u = "";
    for (; a = Ct(r); )
      u += a;
    return u;
  }
  function Yt(r) {
    const a = (u) => {
      const T = r.currentChar();
      return T === "{" || T === "%" || T === "@" || T === "|" || T === "(" || T === ")" || !T || T === Q ? u : (u += T, r.next(), a(u));
    };
    return a("");
  }
  function Le(r) {
    O(r);
    const a = y(r, "|");
    return O(r), a;
  }
  function pe(r, a) {
    let u = null;
    switch (r.currentChar()) {
      case "{":
        return a.braceNest >= 1 && h(C.NOT_ALLOW_NEST_PLACEHOLDER, i(), 0), r.next(), u = p(a, 2, "{"), O(r), a.braceNest++, u;
      case "}":
        return a.braceNest > 0 && a.currentType === 2 && h(C.EMPTY_PLACEHOLDER, i(), 0), r.next(), u = p(a, 3, "}"), a.braceNest--, a.braceNest > 0 && O(r), a.inLinked && a.braceNest === 0 && (a.inLinked = false), u;
      case "@":
        return a.braceNest > 0 && h(C.UNTERMINATED_CLOSING_BRACE, i(), 0), u = de(r, a) || P(a), a.braceNest = 0, u;
      default: {
        let w = true, M = true, q = true;
        if (W(r))
          return a.braceNest > 0 && h(C.UNTERMINATED_CLOSING_BRACE, i(), 0), u = p(a, 1, Le(r)), a.braceNest = 0, a.inLinked = false, u;
        if (a.braceNest > 0 && (a.currentType === 5 || a.currentType === 6 || a.currentType === 7))
          return h(C.UNTERMINATED_CLOSING_BRACE, i(), 0), a.braceNest = 0, Te(r, a);
        if (w = l(r, a))
          return u = p(a, 5, Rt(r)), O(r), u;
        if (M = o(r, a))
          return u = p(a, 6, Mt(r)), O(r), u;
        if (q = m(r, a))
          return u = p(a, 7, wt(r)), O(r), u;
        if (!w && !M && !q)
          return u = p(a, 13, $t(r)), h(C.INVALID_TOKEN_IN_PLACEHOLDER, i(), 0, u.value), O(r), u;
        break;
      }
    }
    return u;
  }
  function de(r, a) {
    const { currentType: u } = a;
    let T = null;
    const w = r.currentChar();
    switch ((u === 8 || u === 9 || u === 12 || u === 10) && (w === Y || w === Q) && h(C.INVALID_LINKED_FORMAT, i(), 0), w) {
      case "@":
        return r.next(), T = p(a, 8, "@"), a.inLinked = true, T;
      case ".":
        return O(r), r.next(), p(a, 9, ".");
      case ":":
        return O(r), r.next(), p(a, 10, ":");
      default:
        return W(r) ? (T = p(a, 1, Le(r)), a.braceNest = 0, a.inLinked = false, T) : _(r, a) || I(r, a) ? (O(r), de(r, a)) : N(r, a) ? (O(r), p(a, 12, Wt(r))) : R(r, a) ? (O(r), w === "{" ? pe(r, a) || T : p(a, 11, Yt(r))) : (u === 8 && h(C.INVALID_LINKED_FORMAT, i(), 0), a.braceNest = 0, a.inLinked = false, Te(r, a));
    }
  }
  function Te(r, a) {
    let u = { type: 14 };
    if (a.braceNest > 0)
      return pe(r, a) || P(a);
    if (a.inLinked)
      return de(r, a) || P(a);
    switch (r.currentChar()) {
      case "{":
        return pe(r, a) || P(a);
      case "}":
        return h(C.UNBALANCED_CLOSING_BRACE, i(), 0), r.next(), p(a, 3, "}");
      case "@":
        return de(r, a) || P(a);
      default: {
        if (W(r))
          return u = p(a, 1, Le(r)), a.braceNest = 0, a.inLinked = false, u;
        const { isModulo: w, hasSpace: M } = J(r);
        if (w)
          return M ? p(a, 0, Ue(r)) : p(a, 4, kt(r));
        if (k(r))
          return p(a, 0, Ue(r));
        break;
      }
    }
    return u;
  }
  function Kt() {
    const { currentType: r, offset: a, startLoc: u, endLoc: T } = f;
    return f.lastType = r, f.lastOffset = a, f.lastStartLoc = u, f.lastEndLoc = T, f.offset = c(), f.startLoc = i(), s.currentChar() === Z ? p(f, 14) : Te(s, f);
  }
  return { nextToken: Kt, currentOffset: c, currentPosition: i, context: L };
}
const dn = "parser", En = /(?:\\\\|\\'|\\u([0-9a-fA-F]{4})|\\U([0-9a-fA-F]{6}))/g;
function mn(e, t, n) {
  switch (e) {
    case "\\\\":
      return "\\";
    case "\\'":
      return "'";
    default: {
      const s = parseInt(t || n, 16);
      return s <= 55295 || s >= 57344 ? String.fromCodePoint(s) : "\uFFFD";
    }
  }
}
function Nn(e = {}) {
  const t = e.location !== false, { onError: n, onWarn: s } = e;
  function c(l, o, m, _, ...N) {
    const I = l.currentPosition();
    if (I.offset += _, I.column += _, n) {
      const R = t ? Ne(m, I) : null, W = _e(o, R, { domain: dn, args: N });
      n(W);
    }
  }
  function i(l, o, m, _, ...N) {
    const I = l.currentPosition();
    if (I.offset += _, I.column += _, s) {
      const R = t ? Ne(m, I) : null;
      s(nn(o, R, N));
    }
  }
  function d(l, o, m) {
    const _ = { type: l };
    return t && (_.start = o, _.end = o, _.loc = { start: m, end: m }), _;
  }
  function E(l, o, m, _) {
    _ && (l.type = _), t && (l.end = o, l.loc && (l.loc.end = m));
  }
  function f(l, o) {
    const m = l.context(), _ = d(3, m.offset, m.startLoc);
    return _.value = o, E(_, l.currentOffset(), l.currentPosition()), _;
  }
  function L(l, o) {
    const m = l.context(), { lastOffset: _, lastStartLoc: N } = m, I = d(5, _, N);
    return I.index = parseInt(o, 10), l.nextToken(), E(I, l.currentOffset(), l.currentPosition()), I;
  }
  function g(l, o, m) {
    const _ = l.context(), { lastOffset: N, lastStartLoc: I } = _, R = d(4, N, I);
    return R.key = o, m === true && (R.modulo = true), l.nextToken(), E(R, l.currentOffset(), l.currentPosition()), R;
  }
  function h(l, o) {
    const m = l.context(), { lastOffset: _, lastStartLoc: N } = m, I = d(9, _, N);
    return I.value = o.replace(En, mn), l.nextToken(), E(I, l.currentOffset(), l.currentPosition()), I;
  }
  function p(l) {
    const o = l.nextToken(), m = l.context(), { lastOffset: _, lastStartLoc: N } = m, I = d(8, _, N);
    return o.type !== 12 ? (c(l, C.UNEXPECTED_EMPTY_LINKED_MODIFIER, m.lastStartLoc, 0), I.value = "", E(I, _, N), { nextConsumeToken: o, node: I }) : (o.value == null && c(l, C.UNEXPECTED_LEXICAL_ANALYSIS, m.lastStartLoc, 0, V(o)), I.value = o.value || "", E(I, l.currentOffset(), l.currentPosition()), { node: I });
  }
  function P(l, o) {
    const m = l.context(), _ = d(7, m.offset, m.startLoc);
    return _.value = o, E(_, l.currentOffset(), l.currentPosition()), _;
  }
  function y(l) {
    const o = l.context(), m = d(6, o.offset, o.startLoc);
    let _ = l.nextToken();
    if (_.type === 9) {
      const N = p(l);
      m.modifier = N.node, _ = N.nextConsumeToken || l.nextToken();
    }
    switch (_.type !== 10 && c(l, C.UNEXPECTED_LEXICAL_ANALYSIS, o.lastStartLoc, 0, V(_)), _ = l.nextToken(), _.type === 2 && (_ = l.nextToken()), _.type) {
      case 11:
        _.value == null && c(l, C.UNEXPECTED_LEXICAL_ANALYSIS, o.lastStartLoc, 0, V(_)), m.key = P(l, _.value || "");
        break;
      case 5:
        _.value == null && c(l, C.UNEXPECTED_LEXICAL_ANALYSIS, o.lastStartLoc, 0, V(_)), m.key = g(l, _.value || "");
        break;
      case 6:
        _.value == null && c(l, C.UNEXPECTED_LEXICAL_ANALYSIS, o.lastStartLoc, 0, V(_)), m.key = L(l, _.value || "");
        break;
      case 7:
        _.value == null && c(l, C.UNEXPECTED_LEXICAL_ANALYSIS, o.lastStartLoc, 0, V(_)), m.key = h(l, _.value || "");
        break;
      default: {
        c(l, C.UNEXPECTED_EMPTY_LINKED_KEY, o.lastStartLoc, 0);
        const N = l.context(), I = d(7, N.offset, N.startLoc);
        return I.value = "", E(I, N.offset, N.startLoc), m.key = I, E(m, N.offset, N.startLoc), { nextConsumeToken: _, node: m };
      }
    }
    return E(m, l.currentOffset(), l.currentPosition()), { node: m };
  }
  function b(l) {
    const o = l.context(), m = o.currentType === 1 ? l.currentOffset() : o.offset, _ = o.currentType === 1 ? o.endLoc : o.startLoc, N = d(2, m, _);
    N.items = [];
    let I = null, R = null;
    do {
      const k = I || l.nextToken();
      switch (I = null, k.type) {
        case 0:
          k.value == null && c(l, C.UNEXPECTED_LEXICAL_ANALYSIS, o.lastStartLoc, 0, V(k)), N.items.push(f(l, k.value || ""));
          break;
        case 6:
          k.value == null && c(l, C.UNEXPECTED_LEXICAL_ANALYSIS, o.lastStartLoc, 0, V(k)), N.items.push(L(l, k.value || ""));
          break;
        case 4:
          R = true;
          break;
        case 5:
          k.value == null && c(l, C.UNEXPECTED_LEXICAL_ANALYSIS, o.lastStartLoc, 0, V(k)), N.items.push(g(l, k.value || "", !!R)), R && (i(l, Pe.USE_MODULO_SYNTAX, o.lastStartLoc, 0, V(k)), R = null);
          break;
        case 7:
          k.value == null && c(l, C.UNEXPECTED_LEXICAL_ANALYSIS, o.lastStartLoc, 0, V(k)), N.items.push(h(l, k.value || ""));
          break;
        case 8: {
          const G = y(l);
          N.items.push(G.node), I = G.nextConsumeToken || null;
          break;
        }
      }
    } while (o.currentType !== 14 && o.currentType !== 1);
    const W = o.currentType === 1 ? o.lastOffset : l.currentOffset(), J = o.currentType === 1 ? o.lastEndLoc : l.currentPosition();
    return E(N, W, J), N;
  }
  function O(l, o, m, _) {
    const N = l.context();
    let I = _.items.length === 0;
    const R = d(1, o, m);
    R.cases = [], R.cases.push(_);
    do {
      const W = b(l);
      I || (I = W.items.length === 0), R.cases.push(W);
    } while (N.currentType !== 14);
    return I && c(l, C.MUST_HAVE_MESSAGES_IN_PLURAL, m, 0), E(R, l.currentOffset(), l.currentPosition()), R;
  }
  function A(l) {
    const o = l.context(), { offset: m, startLoc: _ } = o, N = b(l);
    return o.currentType === 14 ? N : O(l, m, _, N);
  }
  function D(l) {
    const o = _n(l, nt({}, e)), m = o.context(), _ = d(0, m.offset, m.startLoc);
    return t && _.loc && (_.loc.source = l), _.body = A(o), e.onCacheKey && (_.cacheKey = e.onCacheKey(l)), m.currentType !== 14 && c(o, C.UNEXPECTED_LEXICAL_ANALYSIS, m.lastStartLoc, 0, l[m.offset] || ""), E(_, o.currentOffset(), o.currentPosition()), _;
  }
  return { parse: D };
}
function V(e) {
  if (e.type === 14)
    return "EOF";
  const t = (e.value || "").replace(/\r?\n/gu, "\\n");
  return t.length > 10 ? t.slice(0, 9) + "\u2026" : t;
}
function Ln(e, t = {}) {
  const n = { ast: e, helpers: /* @__PURE__ */ new Set() };
  return { context: () => n, helper: (i) => (n.helpers.add(i), i) };
}
function Xe(e, t) {
  for (let n = 0; n < e.length; n++)
    ye(e[n], t);
}
function ye(e, t) {
  switch (e.type) {
    case 1:
      Xe(e.cases, t), t.helper("plural");
      break;
    case 2:
      Xe(e.items, t);
      break;
    case 6: {
      ye(e.key, t), t.helper("linked"), t.helper("type");
      break;
    }
    case 5:
      t.helper("interpolate"), t.helper("list");
      break;
    case 4:
      t.helper("interpolate"), t.helper("named");
      break;
  }
}
function pn(e, t = {}) {
  const n = Ln(e);
  n.helper("normalize"), e.body && ye(e.body, n);
  const s = n.context();
  e.helpers = Array.from(s.helpers);
}
function Tn(e) {
  const t = e.body;
  return t.type === 2 ? Ge(t) : t.cases.forEach((n) => Ge(n)), e;
}
function Ge(e) {
  if (e.items.length === 1) {
    const t = e.items[0];
    (t.type === 3 || t.type === 9) && (e.static = t.value, delete t.value);
  } else {
    const t = [];
    for (let n = 0; n < e.items.length; n++) {
      const s = e.items[n];
      if (!(s.type === 3 || s.type === 9) || s.value == null)
        break;
      t.push(s.value);
    }
    if (t.length === e.items.length) {
      e.static = rt(t);
      for (let n = 0; n < e.items.length; n++) {
        const s = e.items[n];
        (s.type === 3 || s.type === 9) && delete s.value;
      }
    }
  }
}
const hn = "minifier";
function ae(e) {
  switch (e.t = e.type, e.type) {
    case 0: {
      const t = e;
      ae(t.body), t.b = t.body, delete t.body;
      break;
    }
    case 1: {
      const t = e, n = t.cases;
      for (let s = 0; s < n.length; s++)
        ae(n[s]);
      t.c = n, delete t.cases;
      break;
    }
    case 2: {
      const t = e, n = t.items;
      for (let s = 0; s < n.length; s++)
        ae(n[s]);
      t.i = n, delete t.items, t.static && (t.s = t.static, delete t.static);
      break;
    }
    case 3:
    case 9:
    case 8:
    case 7: {
      const t = e;
      t.value && (t.v = t.value, delete t.value);
      break;
    }
    case 6: {
      const t = e;
      ae(t.key), t.k = t.key, delete t.key, t.modifier && (ae(t.modifier), t.m = t.modifier, delete t.modifier);
      break;
    }
    case 5: {
      const t = e;
      t.i = t.index, delete t.index;
      break;
    }
    case 4: {
      const t = e;
      t.k = t.key, delete t.key;
      break;
    }
    default:
      throw _e(C.UNHANDLED_MINIFIER_NODE_TYPE, null, { domain: hn, args: [e.type] });
  }
  delete e.type;
}
const On = "parser";
function In(e, t) {
  const { sourceMap: n, filename: s, breakLineCode: c, needIndent: i } = t, d = t.location !== false, E = { filename: s, code: "", column: 1, line: 1, offset: 0, map: void 0, breakLineCode: c, needIndent: i, indentLevel: 0 };
  d && e.loc && (E.source = e.loc.source);
  const f = () => E;
  function L(O, A) {
    E.code += O;
  }
  function g(O, A = true) {
    const D = A ? c : "";
    L(i ? D + "  ".repeat(O) : D);
  }
  function h(O = true) {
    const A = ++E.indentLevel;
    O && g(A);
  }
  function p(O = true) {
    const A = --E.indentLevel;
    O && g(A);
  }
  function P() {
    g(E.indentLevel);
  }
  return { context: f, push: L, indent: h, deindent: p, newline: P, helper: (O) => "_".concat(O), needIndent: () => E.needIndent };
}
function An(e, t) {
  const { helper: n } = e;
  e.push("".concat(n("linked"), "(")), ie(e, t.key), t.modifier ? (e.push(", "), ie(e, t.modifier), e.push(", _type")) : e.push(", undefined, _type"), e.push(")");
}
function Cn(e, t) {
  const { helper: n, needIndent: s } = e;
  e.push("".concat(n("normalize"), "([")), e.indent(s());
  const c = t.items.length;
  for (let i = 0; i < c && (ie(e, t.items[i]), i !== c - 1); i++)
    e.push(", ");
  e.deindent(s()), e.push("])");
}
function gn(e, t) {
  const { helper: n, needIndent: s } = e;
  if (t.cases.length > 1) {
    e.push("".concat(n("plural"), "([")), e.indent(s());
    const c = t.cases.length;
    for (let i = 0; i < c && (ie(e, t.cases[i]), i !== c - 1); i++)
      e.push(", ");
    e.deindent(s()), e.push("])");
  }
}
function Sn(e, t) {
  t.body ? ie(e, t.body) : e.push("null");
}
function ie(e, t) {
  const { helper: n } = e;
  switch (t.type) {
    case 0:
      Sn(e, t);
      break;
    case 1:
      gn(e, t);
      break;
    case 2:
      Cn(e, t);
      break;
    case 6:
      An(e, t);
      break;
    case 8:
      e.push(JSON.stringify(t.value), t);
      break;
    case 7:
      e.push(JSON.stringify(t.value), t);
      break;
    case 5:
      e.push("".concat(n("interpolate"), "(").concat(n("list"), "(").concat(t.index, "))"), t);
      break;
    case 4:
      e.push("".concat(n("interpolate"), "(").concat(n("named"), "(").concat(JSON.stringify(t.key), "))"), t);
      break;
    case 9:
      e.push(JSON.stringify(t.value), t);
      break;
    case 3:
      e.push(JSON.stringify(t.value), t);
      break;
    default:
      throw _e(C.UNHANDLED_CODEGEN_NODE_TYPE, null, { domain: On, args: [t.type] });
  }
}
const Pn = (e, t = {}) => {
  const n = Ye(t.mode) ? t.mode : "normal", s = Ye(t.filename) ? t.filename : "message.intl", c = !!t.sourceMap, i = t.breakLineCode != null ? t.breakLineCode : n === "arrow" ? ";" : "\n", d = t.needIndent ? t.needIndent : n !== "arrow", E = e.helpers || [], f = In(e, { mode: n, filename: s, sourceMap: c, breakLineCode: i, needIndent: d });
  f.push(n === "normal" ? "function __msg__ (ctx) {" : "(ctx) => {"), f.indent(d), E.length > 0 && (f.push("const { ".concat(rt(E.map((h) => "".concat(h, ": _").concat(h)), ", "), " } = ctx")), f.newline()), f.push("return "), ie(f, e), f.deindent(d), f.push("}"), delete e.helpers;
  const { code: L, map: g } = f.context();
  return { ast: e, code: L, map: g ? g.toJSON() : void 0 };
};
function yn(e, t = {}) {
  const n = nt({}, t), s = !!n.jit, c = !!n.minify, i = n.optimize == null ? true : n.optimize, E = Nn(n).parse(e);
  return s ? (i && Tn(E), c && ae(E), { ast: E, code: "" }) : (pn(E, n), Pn(E, n));
}
/*!
* core-base v9.14.5
* (c) 2025 kazuya kawaguchi
* Released under the MIT License.
*/
function bn() {
  typeof __INTLIFY_PROD_DEVTOOLS__ != "boolean" && (he().__INTLIFY_PROD_DEVTOOLS__ = false), typeof __INTLIFY_JIT_COMPILATION__ != "boolean" && (he().__INTLIFY_JIT_COMPILATION__ = false), typeof __INTLIFY_DROP_MESSAGE_COMPILER__ != "boolean" && (he().__INTLIFY_DROP_MESSAGE_COMPILER__ = false);
}
function le(e) {
  return F(e) && be(e) === 0 && (se(e, "b") || se(e, "body"));
}
const st = ["b", "body"];
function Dn(e) {
  return z(e, st);
}
const at = ["c", "cases"];
function kn(e) {
  return z(e, at, []);
}
const ct = ["s", "static"];
function Rn(e) {
  return z(e, ct);
}
const it = ["i", "items"];
function Mn(e) {
  return z(e, it, []);
}
const lt = ["t", "type"];
function be(e) {
  return z(e, lt);
}
const ot = ["v", "value"];
function me(e, t) {
  const n = z(e, ot);
  if (n != null)
    return n;
  throw ue(t);
}
const ut = ["m", "modifier"];
function Un(e) {
  return z(e, ut);
}
const ft = ["k", "key"];
function wn(e) {
  const t = z(e, ft);
  if (t)
    return t;
  throw ue(6);
}
function z(e, t, n) {
  for (let s = 0; s < t.length; s++) {
    const c = t[s];
    if (se(e, c) && e[c] != null)
      return e[c];
  }
  return n;
}
const Fn = [...st, ...at, ...ct, ...it, ...ft, ...ut, ...ot, ...lt];
function ue(e) {
  return new Error("unhandled node type: ".concat(e));
}
const ee = [];
ee[0] = { w: [0], i: [3, 0], "[": [4], o: [7] };
ee[1] = { w: [1], ".": [2], "[": [4], o: [7] };
ee[2] = { w: [2], i: [3, 0], 0: [3, 0] };
ee[3] = { i: [3, 0], 0: [3, 0], w: [1, 1], ".": [2, 1], "[": [4, 1], o: [7, 1] };
ee[4] = { "'": [5, 0], '"': [6, 0], "[": [4, 2], "]": [1, 3], o: 8, l: [4, 0] };
ee[5] = { "'": [4, 0], o: 8, l: [5, 0] };
ee[6] = { '"': [4, 0], o: 8, l: [6, 0] };
const vn = /^\s?(?:true|false|-?[\d.]+|'[^']*'|"[^"]*")\s?$/;
function $n(e) {
  return vn.test(e);
}
function Wn(e) {
  const t = e.charCodeAt(0), n = e.charCodeAt(e.length - 1);
  return t === n && (t === 34 || t === 39) ? e.slice(1, -1) : e;
}
function Yn(e) {
  if (e == null)
    return "o";
  switch (e.charCodeAt(0)) {
    case 91:
    case 93:
    case 46:
    case 34:
    case 39:
      return e;
    case 95:
    case 36:
    case 45:
      return "i";
    case 9:
    case 10:
    case 13:
    case 160:
    case 65279:
    case 8232:
    case 8233:
      return "w";
  }
  return "i";
}
function Kn(e) {
  const t = e.trim();
  return e.charAt(0) === "0" && isNaN(parseInt(e)) ? false : $n(t) ? Wn(t) : "*" + t;
}
function Xn(e) {
  const t = [];
  let n = -1, s = 0, c = 0, i, d, E, f, L, g, h;
  const p = [];
  p[0] = () => {
    d === void 0 ? d = E : d += E;
  }, p[1] = () => {
    d !== void 0 && (t.push(d), d = void 0);
  }, p[2] = () => {
    p[0](), c++;
  }, p[3] = () => {
    if (c > 0)
      c--, s = 4, p[0]();
    else {
      if (c = 0, d === void 0 || (d = Kn(d), d === false))
        return false;
      p[1]();
    }
  };
  function P() {
    const y = e[n + 1];
    if (s === 5 && y === "'" || s === 6 && y === '"')
      return n++, E = "\\" + y, p[0](), true;
  }
  for (; s !== null; )
    if (n++, i = e[n], !(i === "\\" && P())) {
      if (f = Yn(i), h = ee[s], L = h[f] || h.l || 8, L === 8 || (s = L[0], L[1] !== void 0 && (g = p[L[1]], g && (E = i, g() === false))))
        return;
      if (s === 7)
        return t;
    }
}
const Ve = /* @__PURE__ */ new Map();
function Gn(e, t) {
  return F(e) ? e[t] : null;
}
function Ir(e, t) {
  if (!F(e))
    return null;
  let n = Ve.get(t);
  if (n || (n = Xn(t), n && Ve.set(t, n)), !n)
    return null;
  const s = n.length;
  let c = e, i = 0;
  for (; i < s; ) {
    const d = n[i];
    if (Fn.includes(d) && le(c))
      return null;
    const E = c[d];
    if (E === void 0 || v(c))
      return null;
    c = E, i++;
  }
  return c;
}
const Vn = (e) => e, Hn = (e) => "", xn = "text", jn = (e) => e.length === 0 ? "" : qt(e), Bn = Qt;
function He(e, t) {
  return e = Math.abs(e), t === 2 ? e ? e > 1 ? 1 : 0 : 1 : e ? Math.min(e, 2) : 0;
}
function Jn(e) {
  const t = K(e.pluralIndex) ? e.pluralIndex : -1;
  return e.named && (K(e.named.count) || K(e.named.n)) ? K(e.named.count) ? e.named.count : K(e.named.n) ? e.named.n : t : t;
}
function Qn(e, t) {
  t.count || (t.count = e), t.n || (t.n = e);
}
function qn(e = {}) {
  const t = e.locale, n = Jn(e), s = F(e.pluralRules) && S(t) && v(e.pluralRules[t]) ? e.pluralRules[t] : He, c = F(e.pluralRules) && S(t) && v(e.pluralRules[t]) ? He : void 0, i = (A) => A[s(n, A.length, c)], d = e.list || [], E = (A) => d[A], f = e.named || $();
  K(e.pluralIndex) && Qn(n, f);
  const L = (A) => f[A];
  function g(A) {
    const D = v(e.messages) ? e.messages(A) : F(e.messages) ? e.messages[A] : false;
    return D || (e.parent ? e.parent.message(A) : Hn);
  }
  const h = (A) => e.modifiers ? e.modifiers[A] : Vn, p = U(e.processor) && v(e.processor.normalize) ? e.processor.normalize : jn, P = U(e.processor) && v(e.processor.interpolate) ? e.processor.interpolate : Bn, y = U(e.processor) && S(e.processor.type) ? e.processor.type : xn, O = { list: E, named: L, plural: i, linked: (A, ...D) => {
    const [l, o] = D;
    let m = "text", _ = "";
    D.length === 1 ? F(l) ? (_ = l.modifier || _, m = l.type || m) : S(l) && (_ = l || _) : D.length === 2 && (S(l) && (_ = l || _), S(o) && (m = o || m));
    const N = g(A)(O), I = m === "vnode" && x(N) && _ ? N[0] : N;
    return _ ? h(_)(I, m) : I;
  }, message: g, type: y, interpolate: P, normalize: p, values: oe($(), d, f) };
  return O;
}
let fe = null;
function Ar(e) {
  fe = e;
}
function Zn(e, t, n) {
  fe && fe.emit("i18n:init", { timestamp: Date.now(), i18n: e, version: t, meta: n });
}
const zn = er("function:translate");
function er(e) {
  return (t) => fe && fe.emit(e, t);
}
const _t = Pe.__EXTEND_POINT__, ne = et(_t), Cr = { NOT_FOUND_KEY: _t, FALLBACK_TO_TRANSLATE: ne(), CANNOT_FORMAT_NUMBER: ne(), FALLBACK_TO_NUMBER_FORMAT: ne(), CANNOT_FORMAT_DATE: ne(), FALLBACK_TO_DATE_FORMAT: ne(), EXPERIMENTAL_CUSTOM_MESSAGE_COMPILER: ne(), __EXTEND_POINT__: ne() }, dt = C.__EXTEND_POINT__, re = et(dt), j = { INVALID_ARGUMENT: dt, INVALID_DATE_ARGUMENT: re(), INVALID_ISO_DATE_ARGUMENT: re(), NOT_SUPPORT_NON_STRING_MESSAGE: re(), NOT_SUPPORT_LOCALE_PROMISE_VALUE: re(), NOT_SUPPORT_LOCALE_ASYNC_FUNCTION: re(), NOT_SUPPORT_LOCALE_TYPE: re(), __EXTEND_POINT__: re() };
function B(e) {
  return _e(e, null, void 0);
}
function De(e, t) {
  return t.locale != null ? xe(t.locale) : xe(e.locale);
}
let Oe;
function xe(e) {
  if (S(e))
    return e;
  if (v(e)) {
    if (e.resolvedOnce && Oe != null)
      return Oe;
    if (e.constructor.name === "Function") {
      const t = e();
      if (Jt(t))
        throw B(j.NOT_SUPPORT_LOCALE_PROMISE_VALUE);
      return Oe = t;
    } else
      throw B(j.NOT_SUPPORT_LOCALE_ASYNC_FUNCTION);
  } else
    throw B(j.NOT_SUPPORT_LOCALE_TYPE);
}
function tr(e, t, n) {
  return [.../* @__PURE__ */ new Set([n, ...x(t) ? t : F(t) ? Object.keys(t) : S(t) ? [t] : [n]])];
}
function gr(e, t, n) {
  const s = S(n) ? n : Ce, c = e;
  c.__localeChainCache || (c.__localeChainCache = /* @__PURE__ */ new Map());
  let i = c.__localeChainCache.get(s);
  if (!i) {
    i = [];
    let d = [n];
    for (; x(d); )
      d = je(i, d, t);
    const E = x(t) || !U(t) ? t : t.default ? t.default : null;
    d = S(E) ? [E] : E, x(d) && je(i, d, false), c.__localeChainCache.set(s, i);
  }
  return i;
}
function je(e, t, n) {
  let s = true;
  for (let c = 0; c < t.length && X(s); c++) {
    const i = t[c];
    S(i) && (s = nr(e, t[c], n));
  }
  return s;
}
function nr(e, t, n) {
  let s;
  const c = t.split("-");
  do {
    const i = c.join("-");
    s = rr(e, i, n), c.splice(-1, 1);
  } while (c.length && s === true);
  return s;
}
function rr(e, t, n) {
  let s = false;
  if (!e.includes(t) && (s = true, t)) {
    s = t[t.length - 1] !== "!";
    const c = t.replace(/!/g, "");
    e.push(c), (x(n) || U(n)) && n[c] && (s = n[c]);
  }
  return s;
}
const sr = "9.14.5", ke = -1, Ce = "en-US", Sr = "", Be = (e) => "".concat(e.charAt(0).toLocaleUpperCase()).concat(e.substr(1));
function ar() {
  return { upper: (e, t) => t === "text" && S(e) ? e.toUpperCase() : t === "vnode" && F(e) && "__v_isVNode" in e ? e.children.toUpperCase() : e, lower: (e, t) => t === "text" && S(e) ? e.toLowerCase() : t === "vnode" && F(e) && "__v_isVNode" in e ? e.children.toLowerCase() : e, capitalize: (e, t) => t === "text" && S(e) ? Be(e) : t === "vnode" && F(e) && "__v_isVNode" in e ? Be(e.children) : e };
}
let Et;
function Pr(e) {
  Et = e;
}
let mt;
function yr(e) {
  mt = e;
}
let Nt;
function br(e) {
  Nt = e;
}
let Lt = null;
const Dr = (e) => {
  Lt = e;
}, cr = () => Lt;
let pt = null;
const kr = (e) => {
  pt = e;
}, Rr = () => pt;
let Je = 0;
function Mr(e = {}) {
  const t = v(e.onWarn) ? e.onWarn : Xt, n = S(e.version) ? e.version : sr, s = S(e.locale) || v(e.locale) ? e.locale : Ce, c = v(s) ? Ce : s, i = x(e.fallbackLocale) || U(e.fallbackLocale) || S(e.fallbackLocale) || e.fallbackLocale === false ? e.fallbackLocale : c, d = U(e.messages) ? e.messages : Ie(c), E = U(e.datetimeFormats) ? e.datetimeFormats : Ie(c), f = U(e.numberFormats) ? e.numberFormats : Ie(c), L = oe($(), e.modifiers, ar()), g = e.pluralRules || $(), h = v(e.missing) ? e.missing : null, p = X(e.missingWarn) || Fe(e.missingWarn) ? e.missingWarn : true, P = X(e.fallbackWarn) || Fe(e.fallbackWarn) ? e.fallbackWarn : true, y = !!e.fallbackFormat, b = !!e.unresolving, O = v(e.postTranslation) ? e.postTranslation : null, A = U(e.processor) ? e.processor : null, D = X(e.warnHtmlMessage) ? e.warnHtmlMessage : true, l = !!e.escapeParameter, o = v(e.messageCompiler) ? e.messageCompiler : Et, m = v(e.messageResolver) ? e.messageResolver : mt || Gn, _ = v(e.localeFallbacker) ? e.localeFallbacker : Nt || tr, N = F(e.fallbackContext) ? e.fallbackContext : void 0, I = e, R = F(I.__datetimeFormatters) ? I.__datetimeFormatters : /* @__PURE__ */ new Map(), W = F(I.__numberFormatters) ? I.__numberFormatters : /* @__PURE__ */ new Map(), J = F(I.__meta) ? I.__meta : {};
  Je++;
  const k = { version: n, cid: Je, locale: s, fallbackLocale: i, messages: d, modifiers: L, pluralRules: g, missing: h, missingWarn: p, fallbackWarn: P, fallbackFormat: y, unresolving: b, postTranslation: O, processor: A, warnHtmlMessage: D, escapeParameter: l, messageCompiler: o, messageResolver: m, localeFallbacker: _, fallbackContext: N, onWarn: t, __meta: J };
  return k.datetimeFormats = E, k.numberFormats = f, k.__datetimeFormatters = R, k.__numberFormatters = W, __INTLIFY_PROD_DEVTOOLS__ && Zn(k, n, J), k;
}
const Ie = (e) => ({ [e]: $() });
function Re(e, t, n, s, c) {
  const { missing: i, onWarn: d } = e;
  if (i !== null) {
    const E = i(e, n, t, c);
    return S(E) ? E : t;
  } else
    return t;
}
function Ur(e, t, n) {
  const s = e;
  s.__localeChainCache = /* @__PURE__ */ new Map(), e.localeFallbacker(e, n, t);
}
function ir(e, t) {
  return e === t ? false : e.split("-")[0] === t.split("-")[0];
}
function lr(e, t) {
  const n = t.indexOf(e);
  if (n === -1)
    return false;
  for (let s = n + 1; s < t.length; s++)
    if (ir(e, t[s]))
      return true;
  return false;
}
function Ae(e) {
  return (n) => or(n, e);
}
function or(e, t) {
  const n = Dn(t);
  if (n == null)
    throw ue(0);
  if (be(n) === 1) {
    const i = kn(n);
    return e.plural(i.reduce((d, E) => [...d, Qe(e, E)], []));
  } else
    return Qe(e, n);
}
function Qe(e, t) {
  const n = Rn(t);
  if (n != null)
    return e.type === "text" ? n : e.normalize([n]);
  {
    const s = Mn(t).reduce((c, i) => [...c, ge(e, i)], []);
    return e.normalize(s);
  }
}
function ge(e, t) {
  const n = be(t);
  switch (n) {
    case 3:
      return me(t, n);
    case 9:
      return me(t, n);
    case 4: {
      const s = t;
      if (se(s, "k") && s.k)
        return e.interpolate(e.named(s.k));
      if (se(s, "key") && s.key)
        return e.interpolate(e.named(s.key));
      throw ue(n);
    }
    case 5: {
      const s = t;
      if (se(s, "i") && K(s.i))
        return e.interpolate(e.list(s.i));
      if (se(s, "index") && K(s.index))
        return e.interpolate(e.list(s.index));
      throw ue(n);
    }
    case 6: {
      const s = t, c = Un(s), i = wn(s);
      return e.linked(ge(e, i), c ? ge(e, c) : void 0, e.type);
    }
    case 7:
      return me(t, n);
    case 8:
      return me(t, n);
    default:
      throw new Error("unhandled node on format message part: ".concat(n));
  }
}
const Tt = (e) => e;
let ce = $();
function ht(e, t = {}) {
  let n = false;
  const s = t.onError || sn;
  return t.onError = (c) => {
    n = true, s(c);
  }, { ...yn(e, t), detectError: n };
}
const wr = (e, t) => {
  if (!S(e))
    throw B(j.NOT_SUPPORT_NON_STRING_MESSAGE);
  {
    X(t.warnHtmlMessage) && t.warnHtmlMessage;
    const s = (t.onCacheKey || Tt)(e), c = ce[s];
    if (c)
      return c;
    const { code: i, detectError: d } = ht(e, t), E = new Function("return ".concat(i))();
    return d ? E : ce[s] = E;
  }
};
function Fr(e, t) {
  if (__INTLIFY_JIT_COMPILATION__ && !__INTLIFY_DROP_MESSAGE_COMPILER__ && S(e)) {
    X(t.warnHtmlMessage) && t.warnHtmlMessage;
    const s = (t.onCacheKey || Tt)(e), c = ce[s];
    if (c)
      return c;
    const { ast: i, detectError: d } = ht(e, { ...t, location: false, jit: true }), E = Ae(i);
    return d ? E : ce[s] = E;
  } else {
    const n = e.cacheKey;
    if (n) {
      const s = ce[n];
      return s || (ce[n] = Ae(e));
    } else
      return Ae(e);
  }
}
const qe = () => "", H = (e) => v(e);
function vr(e, ...t) {
  const { fallbackFormat: n, postTranslation: s, unresolving: c, messageCompiler: i, fallbackLocale: d, messages: E } = e, [f, L] = _r(...t), g = X(L.missingWarn) ? L.missingWarn : e.missingWarn, h = X(L.fallbackWarn) ? L.fallbackWarn : e.fallbackWarn, p = X(L.escapeParameter) ? L.escapeParameter : e.escapeParameter, P = !!L.resolvedMessage, y = S(L.default) || X(L.default) ? X(L.default) ? i ? f : () => f : L.default : n ? i ? f : () => f : "", b = n || y !== "", O = De(e, L);
  p && ur(L);
  let [A, D, l] = P ? [f, O, E[O] || $()] : Ot(e, f, O, d, h, g), o = A, m = f;
  if (!P && !(S(o) || le(o) || H(o)) && b && (o = y, m = o), !P && (!(S(o) || le(o) || H(o)) || !S(D)))
    return c ? ke : f;
  let _ = false;
  const N = () => {
    _ = true;
  }, I = H(o) ? o : It(e, f, D, o, m, N);
  if (_)
    return o;
  const R = Er(e, D, l, L), W = qn(R), J = fr(e, I, W);
  let k = s ? s(J, f) : J;
  if (p && S(k) && (k = jt(k)), __INTLIFY_PROD_DEVTOOLS__) {
    const G = { timestamp: Date.now(), key: S(f) ? f : H(o) ? o.key : "", locale: D || (H(o) ? o.locale : ""), format: S(o) ? o : H(o) ? o.source : "", message: k };
    G.meta = oe({}, e.__meta, cr() || {}), zn(G);
  }
  return k;
}
function ur(e) {
  x(e.list) ? e.list = e.list.map((t) => S(t) ? $e(t) : t) : F(e.named) && Object.keys(e.named).forEach((t) => {
    S(e.named[t]) && (e.named[t] = $e(e.named[t]));
  });
}
function Ot(e, t, n, s, c, i) {
  const { messages: d, onWarn: E, messageResolver: f, localeFallbacker: L } = e, g = L(e, s, n);
  let h = $(), p, P = null;
  const y = "translate";
  for (let b = 0; b < g.length && (p = g[b], h = d[p] || $(), (P = f(h, t)) === null && (P = h[t]), !(S(P) || le(P) || H(P))); b++)
    if (!lr(p, g)) {
      const O = Re(e, t, p, i, y);
      O !== t && (P = O);
    }
  return [P, p, h];
}
function It(e, t, n, s, c, i) {
  const { messageCompiler: d, warnHtmlMessage: E } = e;
  if (H(s)) {
    const L = s;
    return L.locale = L.locale || n, L.key = L.key || t, L;
  }
  if (d == null) {
    const L = () => s;
    return L.locale = n, L.key = t, L;
  }
  const f = d(s, dr(e, n, c, s, E, i));
  return f.locale = n, f.key = t, f.source = s, f;
}
function fr(e, t, n) {
  return t(n);
}
function _r(...e) {
  const [t, n, s] = e, c = $();
  if (!S(t) && !K(t) && !H(t) && !le(t))
    throw B(j.INVALID_ARGUMENT);
  const i = K(t) ? String(t) : (H(t), t);
  return K(n) ? c.plural = n : S(n) ? c.default = n : U(n) && !Se(n) ? c.named = n : x(n) && (c.list = n), K(s) ? c.plural = s : S(s) ? c.default = s : U(s) && oe(c, s), [i, c];
}
function dr(e, t, n, s, c, i) {
  return { locale: t, key: n, warnHtmlMessage: c, onError: (d) => {
    throw i && i(d), d;
  }, onCacheKey: (d) => Gt(t, n, d) };
}
function Er(e, t, n, s) {
  const { modifiers: c, pluralRules: i, messageResolver: d, fallbackLocale: E, fallbackWarn: f, missingWarn: L, fallbackContext: g } = e, p = { locale: t, modifiers: c, pluralRules: i, messages: (P) => {
    let y = d(n, P);
    if (y == null && g) {
      const [, , b] = Ot(g, P, t, E, f, L);
      y = d(b, P);
    }
    if (S(y) || le(y)) {
      let b = false;
      const A = It(e, P, t, y, P, () => {
        b = true;
      });
      return b ? qe : A;
    } else
      return H(y) ? y : qe;
  } };
  return e.processor && (p.processor = e.processor), s.list && (p.list = s.list), s.named && (p.named = s.named), K(s.plural) && (p.pluralIndex = s.plural), p;
}
function $r(e, ...t) {
  const { datetimeFormats: n, unresolving: s, fallbackLocale: c, onWarn: i, localeFallbacker: d } = e, { __datetimeFormatters: E } = e, [f, L, g, h] = Nr(...t), p = X(g.missingWarn) ? g.missingWarn : e.missingWarn;
  X(g.fallbackWarn) ? g.fallbackWarn : e.fallbackWarn;
  const P = !!g.part, y = De(e, g), b = d(e, c, y);
  if (!S(f) || f === "")
    return new Intl.DateTimeFormat(y, h).format(L);
  let O = {}, A, D = null;
  const l = "datetime format";
  for (let _ = 0; _ < b.length && (A = b[_], O = n[A] || {}, D = O[f], !U(D)); _++)
    Re(e, f, A, p, l);
  if (!U(D) || !S(A))
    return s ? ke : f;
  let o = "".concat(A, "__").concat(f);
  Se(h) || (o = "".concat(o, "__").concat(JSON.stringify(h)));
  let m = E.get(o);
  return m || (m = new Intl.DateTimeFormat(A, oe({}, D, h)), E.set(o, m)), P ? m.formatToParts(L) : m.format(L);
}
const mr = ["localeMatcher", "weekday", "era", "year", "month", "day", "hour", "minute", "second", "timeZoneName", "formatMatcher", "hour12", "timeZone", "dateStyle", "timeStyle", "calendar", "dayPeriod", "numberingSystem", "hourCycle", "fractionalSecondDigits"];
function Nr(...e) {
  const [t, n, s, c] = e, i = $();
  let d = $(), E;
  if (S(t)) {
    const f = t.match(/(\d{4}-\d{2}-\d{2})(T|\s)?(.*)/);
    if (!f)
      throw B(j.INVALID_ISO_DATE_ARGUMENT);
    const L = f[3] ? f[3].trim().startsWith("T") ? "".concat(f[1].trim()).concat(f[3].trim()) : "".concat(f[1].trim(), "T").concat(f[3].trim()) : f[1].trim();
    E = new Date(L);
    try {
      E.toISOString();
    } catch (e2) {
      throw B(j.INVALID_ISO_DATE_ARGUMENT);
    }
  } else if (Ht(t)) {
    if (isNaN(t.getTime()))
      throw B(j.INVALID_DATE_ARGUMENT);
    E = t;
  } else if (K(t))
    E = t;
  else
    throw B(j.INVALID_ARGUMENT);
  return S(n) ? i.key = n : U(n) && Object.keys(n).forEach((f) => {
    mr.includes(f) ? d[f] = n[f] : i[f] = n[f];
  }), S(s) ? i.locale = s : U(s) && (d = s), U(c) && (d = c), [i.key || "", E, i, d];
}
function Wr(e, t, n) {
  const s = e;
  for (const c in n) {
    const i = "".concat(t, "__").concat(c);
    s.__datetimeFormatters.has(i) && s.__datetimeFormatters.delete(i);
  }
}
function Yr(e, ...t) {
  const { numberFormats: n, unresolving: s, fallbackLocale: c, onWarn: i, localeFallbacker: d } = e, { __numberFormatters: E } = e, [f, L, g, h] = pr(...t), p = X(g.missingWarn) ? g.missingWarn : e.missingWarn;
  X(g.fallbackWarn) ? g.fallbackWarn : e.fallbackWarn;
  const P = !!g.part, y = De(e, g), b = d(e, c, y);
  if (!S(f) || f === "")
    return new Intl.NumberFormat(y, h).format(L);
  let O = {}, A, D = null;
  const l = "number format";
  for (let _ = 0; _ < b.length && (A = b[_], O = n[A] || {}, D = O[f], !U(D)); _++)
    Re(e, f, A, p, l);
  if (!U(D) || !S(A))
    return s ? ke : f;
  let o = "".concat(A, "__").concat(f);
  Se(h) || (o = "".concat(o, "__").concat(JSON.stringify(h)));
  let m = E.get(o);
  return m || (m = new Intl.NumberFormat(A, oe({}, D, h)), E.set(o, m)), P ? m.formatToParts(L) : m.format(L);
}
const Lr = ["localeMatcher", "style", "currency", "currencyDisplay", "currencySign", "useGrouping", "minimumIntegerDigits", "minimumFractionDigits", "maximumFractionDigits", "minimumSignificantDigits", "maximumSignificantDigits", "compactDisplay", "notation", "signDisplay", "unit", "unitDisplay", "roundingMode", "roundingPriority", "roundingIncrement", "trailingZeroDisplay"];
function pr(...e) {
  const [t, n, s, c] = e, i = $();
  let d = $();
  if (!K(t))
    throw B(j.INVALID_ARGUMENT);
  const E = t;
  return S(n) ? i.key = n : U(n) && Object.keys(n).forEach((f) => {
    Lr.includes(f) ? d[f] = n[f] : i[f] = n[f];
  }), S(s) ? i.locale = s : U(s) && (d = s), U(c) && (d = c), [i.key || "", E, i, d];
}
function Kr(e, t, n) {
  const s = e;
  for (const c in n) {
    const i = "".concat(t, "__").concat(c);
    s.__numberFormatters.has(i) && s.__numberFormatters.delete(i);
  }
}
bn();
export {
  se as A,
  Mr as B,
  Wr as C,
  Ce as D,
  Kr as E,
  j as F,
  et as G,
  le as H,
  Fn as I,
  Dr as J,
  Rr as K,
  ke as L,
  _r as M,
  Lr as N,
  vr as O,
  Sr as P,
  Nr as Q,
  $r as R,
  pr as S,
  Yr as T,
  H as U,
  Cr as V,
  kr as W,
  oe as a,
  S as b,
  $ as c,
  F as d,
  X as e,
  yr as f,
  br as g,
  he as h,
  K as i,
  _e as j,
  x as k,
  U as l,
  hr as m,
  Fe as n,
  v as o,
  Tr as p,
  mr as q,
  Pr as r,
  Ar as s,
  Se as t,
  Ur as u,
  Fr as v,
  wr as w,
  Ir as x,
  gr as y,
  Or as z
};
