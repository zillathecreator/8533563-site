import { _, __tla as __tla_0 } from "./index.bb04cb73.js";
import { u as T } from "./vuex.33ea5d58.js";
import { o, c as V, u as e, J as u, W as n, R as x, ao as a, r as p } from "./@vue.b00de3e9.js";
import "./vue-router.c227d4ba.js";
import "./axios.853f16bf.js";
import "./element-plus.53baa8a9.js";
import "./@element-plus.e21ea623.js";
import "./@ctrl.11979b50.js";
import "./dayjs.9abdbee1.js";
import "./clipboard.aaae98d3.js";
import "./@vueuse.eccd744a.js";
import "./lodash-es.e1022fb5.js";
import "./@popperjs.da591b4f.js";
import "./vant.f7b4805b.js";
import "./@vant.f52f09a9.js";
import "./vue-i18n.07fcbeea.js";
import "./@intlify.928cb664.js";
import "./xe-utils.a532b55a.js";
import "./crypto-js.c184c643.js";
import "./decimal.js.2def1975.js";
import "./nprogress.9fc41f77.js";
import "./vconsole.0cfb1d33.js";
import "./perfect-scrollbar.19f80865.js";
let Y;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e2) {
    }
  })()
]).then(async () => {
  Y = {
    __name: "index",
    setup(A, { expose: i }) {
      const s = a(() => _(() => import("./complex_1.9a2cdb04.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/complex_1.9a2cdb04.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/index.5f74bd60.js","css/complex_1.c9505283.css"])), f = a(() => _(() => import("./complex_3.c2364213.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/complex_3.c2364213.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/index.5f74bd60.js","css/complex_3.da6c0c48.css"])), d = a(() => _(() => import("./complex_4.929ed6a5.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/complex_4.929ed6a5.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/index.5f74bd60.js","css/complex_4.6a7567de.css"])), c = a(() => _(() => import("./custom_template_1.e7d7304c.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/custom_template_1.e7d7304c.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/index.5f74bd60.js","css/custom_template_1.1cd6d4c1.css"])), k = a(() => _(() => import("./custom_template_2.2a8f7125.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/custom_template_2.2a8f7125.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/custom_template_2.e6d68cd9.css"])), y = a(() => _(() => import("./complex_5.16a53bfb.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/complex_5.16a53bfb.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/index.5f74bd60.js","css/complex_5.208091dd.css"])), M = a(() => _(() => import("./complex_6.5f5bc9eb.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/complex_6.5f5bc9eb.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/index.5f74bd60.js","css/complex_6.f7341c76.css"])), R = a(() => _(() => import("./complex_7.8a193047.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/complex_7.8a193047.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/index.5f74bd60.js","css/complex_7.ce3c667b.css"])), E = a(() => _(() => import("./complex_8.2d83780a.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/complex_8.2d83780a.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/index.5f74bd60.js","css/complex_8.28b503cd.css"])), v = a(() => _(() => import("./digital_version1.01f71eed.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/digital_version1.01f71eed.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/index.5f74bd60.js","js/wg_dv1_login.3e6f97d2.js","css/digital_version1.2e9bdc33.css"])), r = T(), t = p(null), m = p(null);
      return i({
        setTop: (l) => {
          m.value && m.value.setTop(l), t.value && t.value.setTop(l);
        }
      }), (l, D) => (o(), V(x, null, [
        e(r).state.layoutMode === 3 ? (o(), u(e(s), {
          key: 0,
          ref_key: "darkMenuRef",
          ref: t
        }, null, 512)) : n("", true),
        e(r).state.layoutMode === 8 ? (o(), u(e(f), {
          key: 1,
          ref_key: "darkMenuRef",
          ref: t
        }, null, 512)) : n("", true),
        e(r).state.layoutMode === 9 ? (o(), u(e(c), {
          key: 2,
          ref_key: "darkMenuRef",
          ref: t
        }, null, 512)) : n("", true),
        e(r).state.layoutMode === 16 ? (o(), u(e(k), {
          key: 3,
          ref_key: "darkMenuRef",
          ref: t
        }, null, 512)) : n("", true),
        e(r).state.layoutMode === 10 ? (o(), u(e(d), {
          key: 4,
          ref_key: "darkMenuRef",
          ref: t
        }, null, 512)) : n("", true),
        e(r).state.layoutMode === 11 ? (o(), u(e(y), {
          key: 5,
          ref_key: "darkMenuRef",
          ref: t
        }, null, 512)) : n("", true),
        e(r).state.layoutMode === 12 ? (o(), u(e(M), {
          key: 6,
          ref_key: "darkMenuRef",
          ref: t
        }, null, 512)) : n("", true),
        e(r).state.layoutMode === 13 ? (o(), u(e(R), {
          key: 7,
          ref_key: "darkMenuRef",
          ref: t
        }, null, 512)) : n("", true),
        e(r).state.layoutMode === 14 ? (o(), u(e(E), {
          key: 8,
          ref_key: "darkMenuRef",
          ref: t
        }, null, 512)) : n("", true),
        e(r).state.layoutMode === 15 ? (o(), u(e(v), {
          key: 9,
          ref_key: "darkMenuRef",
          ref: t
        }, null, 512)) : n("", true)
      ], 64));
    }
  };
});
export {
  __tla,
  Y as default
};
