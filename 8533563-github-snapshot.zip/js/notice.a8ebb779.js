import { _ as X, a as x, $ as z, __tla as __tla_0 } from "./index.bb04cb73.js";
import { S as O, A as H, a as K } from "./swiper.e7c9d9a6.js";
import { u as F } from "./vue-i18n.07fcbeea.js";
import { b as G } from "./vue-router.c227d4ba.js";
import { u as J } from "./vuex.33ea5d58.js";
import "./xe-utils.a532b55a.js";
import { f as Y, n as B, g as j, e as Q, b as Z, a9 as ee, o as a, c as i, u as t, U as te, M as oe, J as g, V as D, R as k, ab as ae, a as M, W as T, L as C, ao as se, r as _ } from "./@vue.b00de3e9.js";
import "./axios.853f16bf.js";
import "./element-plus.53baa8a9.js";
import "./@element-plus.e21ea623.js";
import "./@ctrl.11979b50.js";
import "./dayjs.9abdbee1.js";
import "./clipboard.aaae98d3.js";
import "./@vueuse.eccd744a.js";
import "./lodash-es.e1022fb5.js";
import "./@popperjs.da591b4f.js";
import "./vant.f7b4805b.js";
import "./@vant.f52f09a9.js";
import "./crypto-js.c184c643.js";
import "./decimal.js.2def1975.js";
import "./nprogress.9fc41f77.js";
import "./vconsole.0cfb1d33.js";
import "./perfect-scrollbar.19f80865.js";
import "./@intlify.928cb664.js";
let Re;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e) {
    }
  })()
]).then(async () => {
  let ne, ie, le, re, ce, de, ue, me;
  ne = {
    key: 0
  };
  ie = [
    "src"
  ];
  le = {
    class: "text-content"
  };
  re = [
    "innerHTML"
  ];
  ce = [
    "src"
  ];
  de = [
    "src"
  ];
  ue = {
    key: 1,
    class: "icon"
  };
  me = {
    key: 0,
    class: "badge-10"
  };
  Re = {
    __name: "notice",
    props: {
      noticeContentColor: {
        type: String,
        default: "#fff"
      }
    },
    setup(L) {
      const b = se(() => X(() => import("./index.829d73d9.js"), ["js/index.829d73d9.js","js/@vue.b00de3e9.js","js/img_xzapp_jl.d99abebb.js","js/vuex.33ea5d58.js","css/index.1e446410.css"])), S = G();
      F();
      const o = J(), c = _(null), v = _([]), y = _(0), I = _(null), $ = _(0), q = () => new URL("/img/colors/" + x() + "/notice_gif.png", import.meta.url).href, E = () => new URL("/img/colors/" + x() + "/unread.png", import.meta.url).href, R = () => new URL("/img/colors/" + x() + "/read.png", import.meta.url).href, P = (e) => {
        e.id ? S.push("/home/notice/detail?noticeType=3&msgId=".concat(e.msgId, "&id=").concat(e.id)) : S.push("/home/notice/detail?noticeType=3&msgId=".concat(e.msgId));
      }, U = (e) => {
        I.value = e, N(e, "start");
      }, N = async (e, l) => {
        var _a;
        console.log("slideNextTransitionStart");
        let s = document.querySelectorAll(".notice-content .swiper .swiper-wrapper .text-content");
        if (s)
          if (s.length > 1) {
            for (let m = 0; m < s.length; m++) {
              let p = s[m];
              p.style.transform = "none", p.style.transition = "none";
            }
            let u = s[0], w = document.querySelector(".notice-content .swiper .swiper-wrapper .swiper-slide-active .text-content");
            if (l == "start") {
              var n = u.getElementsByTagName("p")[0], d = (n == null ? void 0 : n.offsetWidth) - w.offsetWidth, r = d / 60;
              y.value = Math.ceil(r) + 1;
            } else {
              var n = document.querySelectorAll(".notice-content .swiper .swiper-wrapper .swiper-slide-active .text-content p")[0], d = (n == null ? void 0 : n.offsetWidth) - w.offsetWidth, r = d / 60;
              y.value = Math.ceil(r) + 1;
            }
            e.autoplay.start(), d > 0 ? (u.style = "transform: none; transition: none;", w.style = "transform: translateX(-".concat(d, "px); transition: ").concat(r, "s linear 0.5s;")) : y.value = 10;
          } else {
            let u = document.querySelector(".notice-content .swiper .swiper-wrapper .swiper-slide-active .text-content");
            if (!u)
              return;
            const m = (_a = u == null ? void 0 : u.getElementsByTagName("p")[0]) == null ? void 0 : _a.offsetWidth;
            let p = m - u.offsetWidth;
            var r = Math.ceil(p / 60), h = Math.ceil(m / 60);
            p > 0 && (u.style = "transform: translateX(-".concat(p, "px); transition: ").concat(r, "s linear 0.5s;"), c.value = setTimeout(async () => {
              await A(p, m, h);
            }, (r + 0.5) * 1e3));
          }
      }, A = async (e, l, s) => {
        let n = document.querySelector(".notice-content .swiper .swiper-wrapper .swiper-slide-active .text-content"), r = (n == null ? void 0 : n.getElementsByTagName("p")[0]).cloneNode(true), h = document.querySelector(".notice-content .swiper .swiper-wrapper .swiper-slide-active .text-content");
        h.childNodes.length > 2 ? (h.removeChild(h.firstChild), e -= l, n.style = "transform: translateX(-".concat(e, "px); transition:none;"), await B(), setTimeout(() => {
          n.appendChild(r), e += l, n.style = "transform: translateX(-".concat(e, "px); transition: ").concat(s, "s linear 0.5s;");
        }, 100)) : (n.appendChild(r), e += l, n.style = "transform: translateX(-".concat(e, "px); transition: ").concat(s, "s linear 0.5s;")), c.value = setTimeout(async () => {
          await A(e, l, s);
        }, (s + 0.8) * 1e3);
      }, V = () => {
        z.get("/user/msg/list", {
          _page: 1,
          _size: 100,
          type: 3,
          marqueeStatus: 1
        }).then((e) => {
          e.status === "OK" && e.data && e.data.list.length && (e.data.list.length == 1 ? e.data.list = [
            ...e.data.list,
            ...e.data.list
          ] : [
            ...e.data.list
          ], y.value = 0, e.data.list.forEach((l) => {
            try {
              l.html = l.content;
            } catch (e2) {
            }
          }), v.value = e.data.list);
        });
      }, W = () => {
        V();
      }, f = () => {
        S.push("/home/notice?noticeType=1");
      };
      return Y(async () => {
        c.value && clearTimeout(c.value), $.value++, await B(), y.value = 0;
      }), j(() => {
        c.value && clearTimeout(c.value);
      }), Q(() => {
        setTimeout(() => {
          W();
        });
      }), Z(() => {
        c.value && clearTimeout(c.value), v.value = [];
      }), (e, l) => {
        const s = ee("svg-icon");
        return a(), i("div", {
          class: C([
            "notice",
            [
              "notice-".concat(t(o).state.layoutMode)
            ]
          ])
        }, [
          [
            12
          ].includes(t(o).state.layoutMode) ? (a(), i("i", ne, [
            te(s, {
              iconClass: "wg_notice12"
            })
          ])) : (a(), i("img", {
            key: 1,
            src: q(),
            alt: "",
            class: "noticeIcon"
          }, null, 8, ie)),
          v.value.length ? (a(), i("div", {
            key: 2,
            class: "notice-content",
            style: oe({
              color: L.noticeContentColor
            })
          }, [
            v.value.length ? (a(), g(t(K), {
              key: $.value,
              onSwiper: U,
              allowTouchMove: false,
              preventClicksPropagation: "",
              autoplay: {
                delay: y.value * 1e3,
                disableOnInteraction: false
              },
              modules: [
                t(H)
              ],
              loop: true,
              ref_key: "mySwiper",
              ref: I,
              direction: "vertical",
              onSlideChangeTransitionStart: N,
              class: "mySwiper"
            }, {
              default: D(() => [
                (a(true), i(k, null, ae(v.value, (n) => (a(), g(t(O), {
                  key: n,
                  onClick: (d) => P(n)
                }, {
                  default: D(() => [
                    M("div", le, [
                      M("p", {
                        innerHTML: n.html,
                        style: {
                          display: "inline"
                        }
                      }, null, 8, re)
                    ])
                  ]),
                  _: 2
                }, 1032, [
                  "onClick"
                ]))), 128))
              ]),
              _: 1
            }, 8, [
              "autoplay",
              "modules"
            ])) : T("", true)
          ], 4)) : T("", true),
          M("div", {
            class: C([
              "emailBox",
              [
                "emailBox-".concat(t(o).state.layoutMode)
              ]
            ])
          }, [
            [
              13
            ].includes(t(o).state.layoutMode) ? (a(), i("i", ue, [
              t(o).state.badges && t(o).state.badges.msg.badge > 0 ? (a(), g(s, {
                key: 0,
                iconClass: "wg_unread_13",
                onClick: f
              })) : (a(), g(s, {
                key: 1,
                iconClass: "wg_read_13",
                onClick: f
              }))
            ])) : (a(), i(k, {
              key: 0
            }, [
              t(o).state.badges && t(o).state.badges.msg.badge > 0 ? (a(), i("img", {
                key: 0,
                src: E(),
                class: C([
                  t(o).state.layoutMode === 10 ? "emailIcon-10" : t(o).state.layoutMode === 12 ? "emailIcon-12" : "emailIcon"
                ]),
                onClick: f
              }, null, 10, ce)) : (a(), i("img", {
                key: 1,
                src: R(),
                class: C([
                  t(o).state.layoutMode === 10 ? "emailIcon-10" : t(o).state.layoutMode === 12 ? "emailIcon-read-12" : "emailIcon"
                ]),
                onClick: f
              }, null, 10, de))
            ], 64)),
            t(o).state.badges && t(o).state.badges.msg.badge > 0 ? (a(), i(k, {
              key: 2
            }, [
              [
                10,
                12
              ].includes(t(o).state.layoutMode) ? (a(), i("div", me)) : (a(), i(k, {
                key: 1
              }, [
                t(o).state.layoutMode === 15 ? (a(), g(t(b), {
                  key: 0,
                  text: t(o).state.badges.msg.badge,
                  customStyle: {
                    transform: "translateY(-50%)"
                  },
                  top: "0",
                  right: "0"
                }, null, 8, [
                  "text"
                ])) : (a(), g(t(b), {
                  key: 1,
                  text: t(o).state.badges.msg.badge,
                  top: "-.04rem",
                  right: "-.04rem",
                  onClick: f
                }, null, 8, [
                  "text"
                ]))
              ], 64))
            ], 64)) : T("", true)
          ], 2)
        ], 2);
      };
    }
  };
});
export {
  __tla,
  Re as default
};
