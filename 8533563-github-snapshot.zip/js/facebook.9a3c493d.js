const o = "/img/im/facebook.png";
export {
  o as _
};
