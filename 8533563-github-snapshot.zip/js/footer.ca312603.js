import { $ as O, ao as v, bo as P, bp as H, bq as J, R as x, aS as k, _ as E, br as N, bs as y, T as R, __tla as __tla_0 } from "./index.bb04cb73.js";
import { _ as j, a as A } from "./self_forbid.0de6beaf.js";
import { u as B } from "./vuex.33ea5d58.js";
import { b as D, u as V } from "./vue-router.c227d4ba.js";
import { u as Y } from "./vue-i18n.07fcbeea.js";
import { e as G, o, c as i, a as r, R as _, ab as p, u as a, _ as u, W as l, U as K, ao as Q, m as W, l as h } from "./@vue.b00de3e9.js";
import "./axios.853f16bf.js";
import "./element-plus.53baa8a9.js";
import "./@element-plus.e21ea623.js";
import "./@ctrl.11979b50.js";
import "./dayjs.9abdbee1.js";
import "./clipboard.aaae98d3.js";
import "./@vueuse.eccd744a.js";
import "./lodash-es.e1022fb5.js";
import "./@popperjs.da591b4f.js";
import "./vant.f7b4805b.js";
import "./@vant.f52f09a9.js";
import "./xe-utils.a532b55a.js";
import "./crypto-js.c184c643.js";
import "./decimal.js.2def1975.js";
import "./nprogress.9fc41f77.js";
import "./vconsole.0cfb1d33.js";
import "./perfect-scrollbar.19f80865.js";
import "./@intlify.928cb664.js";
let ne;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e) {
    }
  })()
]).then(async () => {
  let z, X, Z, tt, et, st, ot, it, at, nt, rt, lt, ct, ut, _t, pt, dt, ht, mt, ft, vt, kt, bt, gt, wt, yt, Ct, Ft, Lt, St, It, Tt, $t, qt, Mt, Ut, Ot, Pt;
  z = {
    class: "home-footer-wg"
  };
  X = {
    class: "innerBox"
  };
  Z = {
    key: 0,
    class: "footer-top"
  };
  tt = {
    key: 0,
    class: "textlink-box"
  };
  et = {
    key: 0,
    class: "textlink-item"
  };
  st = {
    class: "link-list-title"
  };
  ot = {
    class: "item-list"
  };
  it = [
    "onClick"
  ];
  at = {
    key: 1,
    class: "textlink-item"
  };
  nt = {
    class: "link-list-title"
  };
  rt = {
    class: "item-list"
  };
  lt = [
    "onClick"
  ];
  ct = {
    key: 2,
    class: "textlink-item"
  };
  ut = {
    class: "link-list-title"
  };
  _t = {
    class: "item-list"
  };
  pt = [
    "onClick"
  ];
  dt = {
    key: 1,
    class: "license-compliance"
  };
  ht = {
    class: "license-compliance-title"
  };
  mt = {
    class: "license-compliance-list"
  };
  ft = [
    "onClick"
  ];
  vt = [
    "src"
  ];
  kt = {
    key: 0
  };
  bt = {
    key: 1,
    src: j
  };
  gt = {
    key: 2,
    src: A
  };
  wt = {
    key: 2,
    class: "contact-box"
  };
  yt = {
    class: "contact-box-title"
  };
  Ct = [
    "onClick"
  ];
  Ft = [
    "src"
  ];
  Lt = {
    key: 3,
    class: "companyInfo"
  };
  St = [
    "innerHTML"
  ];
  It = {
    key: 4,
    class: "partnerInfo"
  };
  Tt = [
    "innerHTML"
  ];
  $t = {
    key: 5,
    class: "copyrightInfo"
  };
  qt = [
    "innerHTML"
  ];
  Mt = {
    key: 6,
    class: "officialChannel"
  };
  Ut = {
    class: "officialChannel-title"
  };
  Ot = {
    class: "official-img"
  };
  Pt = [
    "src",
    "onClick"
  ];
  ne = {
    __name: "footer",
    setup(Ht) {
      const C = Q(() => E(() => import("./index.0a0ffc46.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index.0a0ffc46.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css"])), e = B(), m = D();
      V();
      const { t: F } = Y(), f = W([]), L = (t) => {
        var _a, _b, _c, _d, _e;
        let s = true;
        switch (t) {
          case 2:
            s = !!((_a = e.state.featureSwitch) == null ? void 0 : _a.task);
            break;
          case 4:
            s = !!((_b = e.state.featureSwitch) == null ? void 0 : _b.rebate);
            break;
          case 5:
            s = !!((_c = e.state.featureSwitch) == null ? void 0 : _c.vip);
            break;
          case 6:
            s = !!((_d = e.state.featureSwitch) == null ? void 0 : _d.agent);
            break;
          case 7:
            s = !!((_e = e.state.featureSwitch) == null ? void 0 : _e.depositPool);
            break;
          default:
            s = true;
            break;
        }
        return s;
      }, S = (t) => {
        var _a, _b;
        let s = true;
        switch (t) {
          case 3:
            s = !!((_a = e.state.featureSwitch) == null ? void 0 : _a.feedback);
            break;
          case 4:
            s = !!((_b = e.state.featureSwitch) == null ? void 0 : _b.aboutUs);
            break;
          default:
            s = true;
            break;
        }
        return s;
      }, I = h(() => e.state.webFooter.module.filter((t) => t.status)), b = h(() => {
        let t = [];
        return t = e.state.webFooter.quickJump.game && e.state.webFooter.quickJump.game.filter((s) => s.status && s.value !== -1), t;
      }), g = h(() => {
        let t = [];
        return t = e.state.webFooter.quickJump.feature && e.state.webFooter.quickJump.feature.filter((s) => s.status && s.value !== 0 && L(s.value)), t;
      }), w = h(() => {
        let t = [];
        return t = e.state.webFooter.quickJump.support && e.state.webFooter.quickJump.support.filter((s) => s.status && s.value !== 0 && S(s.value)), t;
      }), T = h(() => {
        const t = [];
        return f.forEach((s) => {
          s.details.forEach((c) => {
            c.icon = s.icon, t.push(c);
          });
        }), t;
      }), $ = (t) => {
        if (t.jumpUrl) {
          let s = t.jumpUrl.indexOf("http") > -1 ? t.jumpUrl : "https://" + t.jumpUrl;
          k(s);
        }
      }, q = (t) => {
        m.push(N[t]);
      }, M = (t) => {
        m.push("/sub-game?typeId=" + t.value);
      }, U = (t) => {
        if (!y[t])
          return R(F("footer.none"));
        m.push(y[t]);
      };
      return G(() => {
        O.get("/user/faq/otherCSList").then((t) => {
          t.status === "OK" && t.data && f.push(...t.data);
        });
      }), (t, s) => (o(), i("div", z, [
        r("div", X, [
          (o(true), i(_, null, p(I.value, (c) => (o(), i(_, null, [
            c.alias === "quickJump" ? (o(), i("div", Z, [
              a(e).state.webFooter.quickJump ? (o(), i("div", tt, [
                g.value.length ? (o(), i("div", et, [
                  r("div", st, u(t.$t("footer.cassino")), 1),
                  r("div", ot, [
                    (o(true), i(_, null, p(g.value, (n) => (o(), i("div", {
                      class: "item-list-item",
                      key: n.value,
                      onClick: (d) => q(n.value)
                    }, u(a(v)(a(P)(n.value))), 9, it))), 128))
                  ])
                ])) : l("", true),
                b.value.length ? (o(), i("div", at, [
                  r("div", nt, u(t.$t("footer.games")), 1),
                  r("div", rt, [
                    (o(true), i(_, null, p(b.value, (n) => (o(), i("div", {
                      class: "item-list-item",
                      key: n.value,
                      onClick: (d) => M(n)
                    }, u(a(v)(a(H)(n.value))), 9, lt))), 128))
                  ])
                ])) : l("", true),
                w.value.length ? (o(), i("div", ct, [
                  r("div", ut, u(t.$t("footer.support")), 1),
                  r("div", _t, [
                    (o(true), i(_, null, p(w.value, (n) => (o(), i("div", {
                      class: "item-list-item",
                      key: n.value,
                      onClick: (d) => U(n.value)
                    }, u(a(v)(a(J)(n.value))), 9, pt))), 128))
                  ])
                ])) : l("", true)
              ])) : l("", true)
            ])) : l("", true),
            c.alias === "licenseCompliance" && a(e).state.webFooter.licenseCompliance ? (o(), i("div", dt, [
              r("div", ht, u(t.$t("footer.title1")), 1),
              r("div", mt, [
                a(e).state.webFooter.licenseCompliance.licenseImageStatus ? (o(true), i(_, {
                  key: 0
                }, p(a(e).state.webFooter.licenseCompliance.imageList, (n) => (o(), i("div", {
                  class: "itemBox",
                  onClick: (d) => $(n)
                }, [
                  r("img", {
                    src: n.licenseImage,
                    alt: ""
                  }, null, 8, vt),
                  n.showTime ? (o(), i("span", kt, u(a(x)("", "DD/MM/YYYY HH:II:SS")), 1)) : l("", true)
                ], 8, ft))), 256)) : l("", true),
                a(e).state.webFooter.licenseCompliance.ageLimitStatus ? (o(), i("img", bt)) : l("", true),
                a(e).state.webFooter.licenseCompliance.selfForbidStatus ? (o(), i("img", gt)) : l("", true)
              ])
            ])) : l("", true),
            c.alias === "contactUs" && f.length ? (o(), i("div", wt, [
              r("div", yt, u(t.$t("footer.title2")), 1),
              r("ul", null, [
                (o(true), i(_, null, p(T.value, (n) => (o(), i("li", {
                  onClick: (d) => a(k)(n.link)
                }, [
                  r("img", {
                    src: n.icon,
                    alt: ""
                  }, null, 8, Ft)
                ], 8, Ct))), 256))
              ])
            ])) : l("", true),
            c.alias === "companyInfo" && a(e).state.webFooter.companyInfo ? (o(), i("div", Lt, [
              r("div", {
                innerHTML: a(e).state.webFooter.companyInfo
              }, null, 8, St)
            ])) : l("", true),
            c.alias === "partnerInfo" && a(e).state.webFooter.partnerInfo ? (o(), i("div", It, [
              r("div", {
                innerHTML: a(e).state.webFooter.partnerInfo
              }, null, 8, Tt)
            ])) : l("", true),
            c.alias === "copyrightInfo" && a(e).state.webFooter.copyrightInfo ? (o(), i("div", $t, [
              r("div", {
                innerHTML: a(e).state.webFooter.copyrightInfo
              }, null, 8, qt)
            ])) : l("", true),
            c.alias === "officialChannel" && a(e).state.featureSwitch.officialMedia && a(e).state.mediaList.length ? (o(), i("div", Mt, [
              r("div", Ut, u(t.$t("footer.title3")), 1),
              r("div", Ot, [
                (o(true), i(_, null, p(a(e).state.mediaList, (n) => (o(), i("img", {
                  src: n.icon,
                  alt: "",
                  onClick: (d) => a(k)(n.url)
                }, null, 8, Pt))), 256))
              ])
            ])) : l("", true)
          ], 64))), 256)),
          K(a(C), {
            position: 10
          })
        ])
      ]));
    }
  };
});
export {
  __tla,
  ne as default
};
