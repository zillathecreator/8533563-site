import { S as Y, h as A } from "./vant.f7b4805b.js";
import { e as G, a9 as P, o, c as s, a as l, U as r, V as m, u as c, R as w, ab as b, a3 as M, W as i, Y as q, J as N, L as Q, a5 as X, _ as O, r as v } from "./@vue.b00de3e9.js";
import { _ as B, a as K, b as Z, c as ee } from "./float_box2.c6e3f09a.js";
import { _ as te } from "./comm_btn_top.bd498d23.js";
import { av as oe, $ as U, __tla as __tla_0 } from "./index.bb04cb73.js";
import { u as se } from "./vue-router.c227d4ba.js";
import { u as le } from "./vuex.33ea5d58.js";
import "./@vant.f52f09a9.js";
import "./axios.853f16bf.js";
import "./element-plus.53baa8a9.js";
import "./@element-plus.e21ea623.js";
import "./@ctrl.11979b50.js";
import "./dayjs.9abdbee1.js";
import "./clipboard.aaae98d3.js";
import "./@vueuse.eccd744a.js";
import "./lodash-es.e1022fb5.js";
import "./@popperjs.da591b4f.js";
import "./vue-i18n.07fcbeea.js";
import "./@intlify.928cb664.js";
import "./xe-utils.a532b55a.js";
import "./crypto-js.c184c643.js";
import "./decimal.js.2def1975.js";
import "./nprogress.9fc41f77.js";
import "./vconsole.0cfb1d33.js";
import "./perfect-scrollbar.19f80865.js";
let It;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e) {
    }
  })()
]).then(async () => {
  let ae, ne, ie, ce, de, re, ue, _e, pe, he, me, ve, fe, ye, ge, ke, we, Ce, Te, xe, Se, be, Me, Be, $e, qe, Ie, Le, Fe, De, Re, Ve, Ne, Oe, Ue, Ke, je, ze, Ee, He, Je, We, Ye, Ae, Ge, Pe, Qe, Xe, Ze, et, tt, ot, st, lt;
  ae = {
    class: "home-float-box"
  };
  ne = {
    class: "float-left"
  };
  ie = {
    class: "fastList"
  };
  ce = {
    key: 0,
    class: "float-bar-scroll-content"
  };
  de = [
    "onClick"
  ];
  re = {
    class: "fastBtn"
  };
  ue = {
    class: "fastBackground"
  };
  _e = [
    "src"
  ];
  pe = [
    "onClick"
  ];
  he = {
    key: 0,
    class: "float-bar-scroll-content"
  };
  me = [
    "onClick"
  ];
  ve = {
    class: "fastBtn"
  };
  fe = {
    class: "fastBackground"
  };
  ye = [
    "src"
  ];
  ge = [
    "onClick"
  ];
  ke = {
    key: 0,
    class: "swiper"
  };
  we = {
    class: "entryItem"
  };
  Ce = {
    class: "fastBtn"
  };
  Te = {
    class: "fastBackground"
  };
  xe = [
    "src"
  ];
  Se = [
    "onClick"
  ];
  be = {
    key: 0,
    class: "expandBtn"
  };
  Me = {
    key: 0
  };
  Be = {
    key: 1,
    src: K,
    alt: ""
  };
  $e = {
    class: "float-right"
  };
  qe = {
    class: "float-right-box"
  };
  Ie = {
    class: "fastList"
  };
  Le = {
    key: 0,
    class: "float-bar-scroll-content"
  };
  Fe = [
    "onClick"
  ];
  De = {
    class: "fastBtn"
  };
  Re = {
    class: "fastBackground"
  };
  Ve = [
    "src"
  ];
  Ne = [
    "onClick"
  ];
  Oe = {
    key: 0,
    class: "float-bar-scroll-content float-bar-scroll-content1"
  };
  Ue = [
    "onClick"
  ];
  Ke = {
    class: "fastBtn"
  };
  je = {
    class: "fastBackground"
  };
  ze = [
    "src"
  ];
  Ee = [
    "onClick"
  ];
  He = {
    key: 0,
    class: "swiper"
  };
  Je = {
    class: "entryItem"
  };
  We = {
    class: "fastBtn"
  };
  Ye = {
    class: "fastBackground"
  };
  Ae = [
    "src"
  ];
  Ge = [
    "onClick"
  ];
  Pe = {
    key: 0,
    class: "expandBtn"
  };
  Qe = {
    key: 0
  };
  Xe = {
    key: 1,
    src: K,
    alt: ""
  };
  Ze = {
    key: 0,
    class: "icon-wrap"
  };
  et = {
    class: "icon"
  };
  tt = {
    key: 1,
    class: "foot"
  };
  ot = {
    class: "icon"
  };
  st = {
    key: 2,
    class: "icon-wrap-img"
  };
  lt = {
    class: "topIcon"
  };
  It = {
    __name: "index",
    setup(at) {
      const a = le(), D = v(3), F = v(false), I = v(null), h = se();
      let L = false;
      const f = v(), y = v(), _ = v(), p = v(), C = v(false), T = v(false), x = (t) => {
        let e;
        t.linkType === 1 ? e = {
          redirect: Number(t.linkInfo)
        } : t.linkType === 2 ? e = {
          redirect: 2,
          redirectUrl: t.linkInfo
        } : t.linkType === 0 ? e = {
          redirect: 1,
          redirectUrl: t.linkInfo
        } : t.linkType === 100 && (e = {
          redirect: 100,
          redirectUrl: t.linkInfo
        }), oe(e);
      }, S = (t) => t.indexOf("http") > -1 ? t : t == "1" ? Z : ee, j = () => {
        let t;
        t = document.querySelector("#app .home-page-scroll"), t.scrollTop, t.scrollTo({
          top: 0,
          behavior: "smooth"
        });
      }, z = () => {
        let e = document.querySelector("#app .home-page-scroll").scrollTop;
        document.querySelector("#app .dark-home-page-wg") || document.querySelector("#app .complex2-home-page-wg") || document.querySelector("#app .custom_template_1-home-page-wg") || document.querySelector("#app .complex4-home-page-wg") || document.querySelector("#app .dark-home-page-wg-casino") || document.querySelector("#app .dark-home-page-wg12") || document.querySelector("#app .digital-version1-page-wg"), a.state.layoutMode !== 15 && (e >= 100 ? F.value = true : F.value = false);
        const g = document.querySelector("#app .home-float-box .float-right-box"), k = document.querySelector("#app .home-float-box .float-left");
        L || (L || (L = true, g && g.classList.add("isScroll"), k && k.classList.add("isScroll"), I.value = null), I.value && clearTimeout(I.value), I.value = setTimeout(() => {
          L = false, g && g.classList.remove("isScroll"), k && k.classList.remove("isScroll");
        }, 500));
      }, E = () => {
        U.get("/user/module-management/list").then((t) => {
          t.status === "OK" && t.data && t.data.length && (a.state.floatModules = t.data.filter((e) => e.showType === 2), a.state.midModules = t.data.filter((e) => e.showType === 3), a.state.bigModules = t.data.filter((e) => e.showType === 5), a.state.leftOneRightTwoModules = t.data.filter((e) => e.showType === 6), a.state.quickModulesStyle5 = t.data.filter((e) => e.showType === 7), a.state.quickModulesStyle6 = t.data.filter((e) => e.showType === 8), a.state.quickModulesStyle7 = t.data.filter((e) => e.showType === 9), a.state.quickModulesStyle8 = t.data.filter((e) => e.showType === 10), a.state.midModuleList = t.data || [], f.value = t.data.find((e) => e.position === 1 && e.showType === 1), _.value = t.data.find((e) => e.position === 1 && e.showType === 0), y.value = t.data.find((e) => e.position === 0 && e.showType === 1), p.value = t.data.find((e) => e.position === 0 && e.showType === 0));
        });
      }, H = () => {
        U.get("/user/module-management/list").then((t) => {
          t.status === "OK" && t.data && t.data.length && (a.state.floatModules = t.data.filter((e) => e.showType === 2), a.state.midModules = t.data.filter((e) => e.showType === 3), a.state.bigModules = t.data.filter((e) => e.showType === 5), a.state.leftOneRightTwoModules = t.data.filter((e) => e.showType === 6), a.state.quickModulesStyle5 = t.data.filter((e) => e.showType === 7), a.state.quickModulesStyle6 = t.data.filter((e) => e.showType === 8), a.state.quickModulesStyle7 = t.data.filter((e) => e.showType === 9), a.state.quickModulesStyle8 = t.data.filter((e) => e.showType === 10));
        });
      }, R = (t) => {
        f.value.list.splice(t, 1);
      }, J = (t) => {
        y.value.list.splice(t, 1);
      }, W = (t) => {
        _.value.list.splice(t, 1);
      }, V = (t) => {
        p.value.list.splice(t, 1);
      };
      return G(() => {
        E(), globalVBus.$on("checkHomeFloat", z, {
          passive: true
        }), globalVBus.$on("refreshFloatBanner", H);
      }), (t, e) => {
        var _a, _b, _c, _d, _e2, _f, _g, _h;
        const g = Y, k = A, $ = P("svg-icon");
        return o(), s("div", ae, [
          l("div", ne, [
            l("div", ie, [
              l("section", null, [
                r(q, {
                  name: "float-translate"
                }, {
                  default: m(() => [
                    [
                      "homeCasino",
                      "index"
                    ].includes(c(h).name) && f.value && !T.value ? (o(), s("div", ce, [
                      (o(true), s(w, null, b(f.value.list, (n, d) => (o(), s("div", {
                        class: "entryItem",
                        onClick: (u) => x(n)
                      }, [
                        l("div", re, [
                          l("div", ue, [
                            l("img", {
                              src: S(n.icon),
                              alt: ""
                            }, null, 8, _e)
                          ]),
                          f.value.closeable ? (o(), s("img", {
                            key: 0,
                            src: B,
                            alt: "",
                            class: "closeIcon",
                            onClick: M((u) => R(d), [
                              "stop"
                            ])
                          }, null, 8, pe)) : i("", true)
                        ])
                      ], 8, de))), 256))
                    ])) : i("", true)
                  ]),
                  _: 1
                }),
                [
                  "homeCasino",
                  "index"
                ].includes(c(h).name) && T.value && _.value.list ? (o(), s("div", he, [
                  (o(true), s(w, null, b(_.value.list, (n, d) => (o(), s("div", {
                    class: "entryItem",
                    onClick: (u) => x(n)
                  }, [
                    l("div", ve, [
                      l("div", fe, [
                        l("img", {
                          src: S(n.icon),
                          alt: ""
                        }, null, 8, ye)
                      ]),
                      _.value.closeable ? (o(), s("img", {
                        key: 0,
                        src: B,
                        alt: "",
                        class: "closeIcon",
                        onClick: M((u) => R(d), [
                          "stop"
                        ])
                      }, null, 8, ge)) : i("", true)
                    ])
                  ], 8, me))), 256))
                ])) : i("", true),
                r(q, {
                  name: "float-translate"
                }, {
                  default: m(() => [
                    [
                      "homeCasino",
                      "index"
                    ].includes(c(h).name) && _.value && !T.value ? (o(), s("div", ke, [
                      r(k, {
                        class: "fixed-swipe",
                        autoplay: D.value * 1e3,
                        "show-indicators": false,
                        "stop-propagation": false,
                        ref: "swipe"
                      }, {
                        default: m(() => [
                          (o(true), s(w, null, b(_.value.list, (n, d) => (o(), N(g, {
                            key: d,
                            onClick: (u) => x(n)
                          }, {
                            default: m(() => [
                              l("div", we, [
                                l("div", Ce, [
                                  l("div", Te, [
                                    l("img", {
                                      src: S(n.icon),
                                      alt: ""
                                    }, null, 8, xe)
                                  ]),
                                  _.value.closeable ? (o(), s("img", {
                                    key: 0,
                                    src: B,
                                    alt: "",
                                    class: "closeIcon",
                                    onClick: M((u) => W(d), [
                                      "stop"
                                    ])
                                  }, null, 8, Se)) : i("", true)
                                ])
                              ])
                            ]),
                            _: 2
                          }, 1032, [
                            "onClick"
                          ]))), 128))
                        ]),
                        _: 1
                      }, 8, [
                        "autoplay"
                      ])
                    ])) : i("", true)
                  ]),
                  _: 1
                }),
                [
                  "homeCasino",
                  "index"
                ].includes(c(h).name) && !((_a = f.value) == null ? void 0 : _a.list.length) && ((_b = _.value) == null ? void 0 : _b.list.length) > 1 ? (o(), s("div", {
                  key: 1,
                  class: "expand",
                  onClick: e[0] || (e[0] = (n) => T.value = !T.value)
                }, [
                  ((_c = _.value) == null ? void 0 : _c.list.length) || ((_d = f.value) == null ? void 0 : _d.list.length) ? (o(), s("div", be, [
                    T.value ? (o(), s("img", Be)) : (o(), s("i", Me, [
                      r($, {
                        iconClass: "wg_home_float_arrow"
                      })
                    ]))
                  ])) : i("", true)
                ])) : i("", true)
              ])
            ])
          ]),
          l("div", $e, [
            l("div", qe, [
              l("div", Ie, [
                l("section", null, [
                  r(q, {
                    name: "float-translate"
                  }, {
                    default: m(() => [
                      [
                        "homeCasino",
                        "index"
                      ].includes(c(h).name) && y.value && !C.value ? (o(), s("div", Le, [
                        (o(true), s(w, null, b(y.value.list, (n, d) => (o(), s("div", {
                          class: "entryItem",
                          onClick: (u) => x(n)
                        }, [
                          l("div", De, [
                            l("div", Re, [
                              l("img", {
                                src: S(n.icon),
                                alt: ""
                              }, null, 8, Ve)
                            ]),
                            y.value.closeable ? (o(), s("img", {
                              key: 0,
                              src: B,
                              alt: "",
                              class: "closeIcon",
                              onClick: M((u) => J(d), [
                                "stop"
                              ])
                            }, null, 8, Ne)) : i("", true)
                          ])
                        ], 8, Fe))), 256))
                      ])) : i("", true)
                    ]),
                    _: 1
                  }),
                  [
                    "homeCasino",
                    "index"
                  ].includes(c(h).name) && C.value && p.value.list ? (o(), s("div", Oe, [
                    (o(true), s(w, null, b(p.value.list, (n, d) => (o(), s("div", {
                      class: "entryItem",
                      onClick: (u) => x(n)
                    }, [
                      l("div", Ke, [
                        l("div", je, [
                          l("img", {
                            src: S(n.icon),
                            alt: ""
                          }, null, 8, ze)
                        ]),
                        p.value.closeable ? (o(), s("img", {
                          key: 0,
                          src: B,
                          alt: "",
                          class: "closeIcon",
                          onClick: M((u) => V(d), [
                            "stop"
                          ])
                        }, null, 8, Ee)) : i("", true)
                      ])
                    ], 8, Ue))), 256))
                  ])) : i("", true),
                  r(q, {
                    name: "float-translate"
                  }, {
                    default: m(() => [
                      [
                        "homeCasino",
                        "index"
                      ].includes(c(h).name) && p.value && !C.value ? (o(), s("div", He, [
                        r(k, {
                          class: "fixed-swipe",
                          autoplay: D.value * 1e3,
                          "show-indicators": false,
                          "stop-propagation": false,
                          ref: "swipe"
                        }, {
                          default: m(() => [
                            (o(true), s(w, null, b(p.value.list, (n, d) => (o(), N(g, {
                              key: d,
                              onClick: (u) => x(n)
                            }, {
                              default: m(() => [
                                l("div", Je, [
                                  l("div", We, [
                                    l("div", Ye, [
                                      l("img", {
                                        src: S(n.icon),
                                        alt: ""
                                      }, null, 8, Ae)
                                    ]),
                                    p.value.closeable ? (o(), s("img", {
                                      key: 0,
                                      src: B,
                                      alt: "",
                                      class: "closeIcon",
                                      onClick: M((u) => V(d), [
                                        "stop"
                                      ])
                                    }, null, 8, Ge)) : i("", true)
                                  ])
                                ])
                              ]),
                              _: 2
                            }, 1032, [
                              "onClick"
                            ]))), 128))
                          ]),
                          _: 1
                        }, 8, [
                          "autoplay"
                        ])
                      ])) : i("", true)
                    ]),
                    _: 1
                  }),
                  c(h).name === "index" && !((_e2 = y.value) == null ? void 0 : _e2.list.length) && ((_f = p.value) == null ? void 0 : _f.list.length) > 1 ? (o(), s("div", {
                    key: 1,
                    class: "expand",
                    onClick: e[1] || (e[1] = (n) => C.value = !C.value)
                  }, [
                    ((_g = p.value) == null ? void 0 : _g.list.length) || ((_h = y.value) == null ? void 0 : _h.list.length) ? (o(), s("div", Pe, [
                      C.value ? (o(), s("img", Xe)) : (o(), s("i", Qe, [
                        r($, {
                          iconClass: "wg_home_float_arrow"
                        })
                      ]))
                    ])) : i("", true)
                  ])) : i("", true)
                ])
              ])
            ]),
            r(q, {
              name: "fade"
            }, {
              default: m(() => [
                F.value && [
                  "homeCasino",
                  "index"
                ].includes(c(h).name) ? (o(), s("div", {
                  key: 0,
                  class: Q([
                    "toTop",
                    [
                      "toTop-".concat(c(a).state.layoutMode)
                    ]
                  ]),
                  onClick: j
                }, [
                  [
                    10,
                    11,
                    13,
                    12
                  ].includes(c(a).state.layoutMode) ? (o(), s("div", Ze, [
                    l("i", et, [
                      r($, {
                        iconClass: "wg_home_toTop_".concat(c(a).state.layoutMode)
                      }, null, 8, [
                        "iconClass"
                      ])
                    ])
                  ])) : [
                    14
                  ].includes(c(a).state.layoutMode) ? (o(), s("div", tt, [
                    l("i", ot, [
                      r($, {
                        iconClass: "wg_home_toTop_".concat(c(a).state.layoutMode)
                      }, null, 8, [
                        "iconClass"
                      ])
                    ]),
                    X(" " + O(t.$t("home.top2")), 1)
                  ])) : [
                    15
                  ].includes(c(a).state.layoutMode) ? (o(), s("div", st, [
                    ...e[2] || (e[2] = [
                      l("img", {
                        src: te,
                        alt: ""
                      }, null, -1)
                    ])
                  ])) : (o(), s(w, {
                    key: 3
                  }, [
                    l("div", lt, [
                      r($, {
                        iconClass: "wg_home_toTop"
                      })
                    ]),
                    l("span", null, O(t.$t("home.top")), 1)
                  ], 64))
                ], 2)) : i("", true)
              ]),
              _: 1
            })
          ])
        ]);
      };
    }
  };
});
export {
  __tla,
  It as default
};
