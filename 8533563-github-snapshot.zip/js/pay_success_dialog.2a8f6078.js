import { al as u, _ as m, am as w, __tla as __tla_0 } from "./index.bb04cb73.js";
import { _ as C } from "./success.65a38cdf.js";
import { u as $ } from "./usdt.c352bfdb.js";
import { _ as D } from "./USDC.a2ba449c.js";
import { u as b } from "./vuex.33ea5d58.js";
import { o as r, c as n, U as p, V as k, a as s, _ as e, a5 as l, u as i, W as S, ao as v, l as _ } from "./@vue.b00de3e9.js";
import "./vue-router.c227d4ba.js";
import "./axios.853f16bf.js";
import "./element-plus.53baa8a9.js";
import "./@element-plus.e21ea623.js";
import "./@ctrl.11979b50.js";
import "./dayjs.9abdbee1.js";
import "./clipboard.aaae98d3.js";
import "./@vueuse.eccd744a.js";
import "./lodash-es.e1022fb5.js";
import "./@popperjs.da591b4f.js";
import "./vant.f7b4805b.js";
import "./@vant.f52f09a9.js";
import "./vue-i18n.07fcbeea.js";
import "./@intlify.928cb664.js";
import "./xe-utils.a532b55a.js";
import "./crypto-js.c184c643.js";
import "./decimal.js.2def1975.js";
import "./nprogress.9fc41f77.js";
import "./vconsole.0cfb1d33.js";
import "./perfect-scrollbar.19f80865.js";
let Ds;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e2) {
    }
  })()
]).then(async () => {
  let A, V, I, B, E, P, N, O, R, x, T, U, L, z, W, j, q, F, G, H, J, K, M;
  A = {
    class: "main"
  };
  V = {
    class: "title"
  };
  I = {
    class: "icon-info"
  };
  B = {
    class: "text"
  };
  E = {
    class: "info-box"
  };
  P = {
    class: "row"
  };
  N = {
    class: "label"
  };
  O = {
    class: "value"
  };
  R = {
    class: "currency"
  };
  x = {
    class: "row"
  };
  T = {
    class: "label"
  };
  U = {
    class: "value"
  };
  L = {
    class: "currency"
  };
  z = {
    class: "row"
  };
  W = {
    class: "label"
  };
  j = {
    class: "value"
  };
  q = {
    class: "currency"
  };
  F = {
    class: "row"
  };
  G = {
    class: "label"
  };
  H = {
    class: "value"
  };
  J = {
    key: 0,
    src: $,
    alt: "",
    class: "icon"
  };
  K = {
    key: 1,
    src: D,
    alt: "",
    class: "icon"
  };
  M = [
    "src"
  ];
  Ds = {
    __name: "pay_success_dialog",
    setup(Q) {
      const g = v(() => m(() => import("./index.e415b222.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index.e415b222.js","js/@vue.b00de3e9.js","js/vuex.33ea5d58.js","js/index.bb04cb73.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/index.36ac8329.css"])), c = b(), h = _(() => c.state.rechargeSuccessDialog), y = v(() => m(() => import("./download_close.c6269472.js"), ["js/download_close.c6269472.js","js/@vue.b00de3e9.js"])), o = _(() => c.state.payInfo), f = _(() => {
        const { amount: a = 0, giftAmount: t = 0 } = o.value || {};
        return w(a, t);
      });
      return (a, t) => (r(), n("div", null, [
        p(i(g), {
          "custom-class": "recharge-success-popup",
          visible: h.value,
          zIndexBase: 4e3,
          onClose: t[2] || (t[2] = (d) => i(c).state.rechargeSuccessDialog = false)
        }, {
          default: k(() => [
            s("div", A, [
              s("div", V, e(a.$t("recharge_wg.recharge_notice")), 1),
              s("div", I, [
                t[3] || (t[3] = s("img", {
                  src: C,
                  class: "icon"
                }, null, -1)),
                s("div", B, e(a.$t("recharge_wg.recharge_success")), 1)
              ]),
              s("div", E, [
                s("div", P, [
                  s("div", N, e(a.$t("recharge_wg.receive_amount")), 1),
                  s("div", O, [
                    l(e(f.value) + " ", 1),
                    s("span", R, e(o.value.currency), 1)
                  ])
                ]),
                s("div", x, [
                  s("div", T, e(a.$t("recharge_wg.reward")), 1),
                  s("div", U, [
                    l(e(o.value.giftAmount) + " ", 1),
                    s("span", L, e(o.value.currency), 1)
                  ])
                ]),
                s("div", z, [
                  s("div", W, e(a.$t("recharge_wg.pay_amount")), 1),
                  s("div", j, [
                    l(e(o.value.amount) + " ", 1),
                    s("span", q, e(o.value.currency), 1)
                  ])
                ]),
                s("div", F, [
                  s("div", G, e(a.$t("recharge_wg.pay_type")), 1),
                  s("div", H, [
                    o.value.payCode.indexOf("USD_") > -1 ? (r(), n("img", J)) : o.value.payCode.indexOf("USC_") > -1 ? (r(), n("img", K)) : i(u)(o.value.payCode) ? (r(), n("img", {
                      key: 2,
                      src: i(u)(o.value.payCode),
                      class: "icon"
                    }, null, 8, M)) : S("", true),
                    l(" " + e(o.value.payCode_), 1)
                  ])
                ]),
                s("div", {
                  class: "btn",
                  onClick: t[0] || (t[0] = (d) => i(c).state.rechargeSuccessDialog = false)
                }, e(a.$t("recharge_wg.understand")), 1)
              ]),
              s("div", {
                class: "close",
                onClick: t[1] || (t[1] = (d) => i(c).state.rechargeSuccessDialog = false)
              }, [
                p(i(y), {
                  class: "svg-icon"
                })
              ])
            ])
          ]),
          _: 1
        }, 8, [
          "visible"
        ])
      ]));
    }
  };
});
export {
  __tla,
  Ds as default
};
