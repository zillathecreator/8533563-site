import { u as v } from "./vue-i18n.07fcbeea.js";
import { t as u, $ as M, __tla as __tla_0 } from "./index.bb04cb73.js";
import { u as E } from "./vuex.33ea5d58.js";
import { u as x, __tla as __tla_1 } from "./index.5f74bd60.js";
import { w as R, e as k, f as A, b as w, o as C, c as F, a as s, _, u as b, M as y, W as D, d as I, r as S, n as K, l as m } from "./@vue.b00de3e9.js";
import "./@intlify.928cb664.js";
import "./vue-router.c227d4ba.js";
import "./axios.853f16bf.js";
import "./element-plus.53baa8a9.js";
import "./@element-plus.e21ea623.js";
import "./@ctrl.11979b50.js";
import "./dayjs.9abdbee1.js";
import "./clipboard.aaae98d3.js";
import "./@vueuse.eccd744a.js";
import "./lodash-es.e1022fb5.js";
import "./@popperjs.da591b4f.js";
import "./vant.f7b4805b.js";
import "./@vant.f52f09a9.js";
import "./xe-utils.a532b55a.js";
import "./crypto-js.c184c643.js";
import "./decimal.js.2def1975.js";
import "./nprogress.9fc41f77.js";
import "./vconsole.0cfb1d33.js";
import "./perfect-scrollbar.19f80865.js";
let gt;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e) {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch (e) {
    }
  })()
]).then(async () => {
  let $, L, N, V, X, B, W;
  $ = {
    key: 0,
    class: "task-content-right"
  };
  L = {
    class: "task-head"
  };
  N = [
    "src"
  ];
  V = {
    class: "task-right"
  };
  X = {
    class: "task-name"
  };
  B = {
    class: "schedule-text"
  };
  W = I({
    name: "true"
  });
  gt = Object.assign(W, {
    setup(H) {
      const { balanceAmount: d } = x(), o = S({}), r = E(), { t: p } = v(), i = (t) => {
        r.state.showFloatPromotionDialog = t;
      }, h = async () => {
        r.state.showFloatPromotionDialog && (i(false), await K()), i(true);
      }, c = (t) => {
        const e = Number(String(t != null ? t : 0).replace(/,/g, ""));
        return Number.isFinite(e) ? e : 0;
      }, n = m(() => {
        const t = c(o.value.target), e = t ? Math.min(Math.max(c(d.value) / t, 0), 1) : 0, g = e > 0.85 ? -0.56 : 0.08, T = Math.min(Math.max(3.48 * e + g, 0.18), 2.7);
        return {
          text: "".concat((e * 100).toFixed(2).replace(/\.00$/, ""), "%"),
          width: "".concat((3.48 * e).toFixed(4), "rem"),
          textLeft: "".concat(T, "rem")
        };
      }), f = m(() => ({
        "--progress-width": n.value.width,
        "--progress-text-left": n.value.textLeft
      })), a = async () => {
        const t = await M.get("/user/work/schedule");
        t.status === "OK" && (o.value = t.data);
      }, l = () => {
        a();
      };
      return R(() => {
        var _a;
        return (_a = r.state.accountInfo) == null ? void 0 : _a.id;
      }, (t) => {
        t && a();
      }), k(() => {
        globalVBus.$on("getSchedule", l), u() && a();
      }), A(() => {
        u() && a();
      }), w(() => {
        globalVBus.$off("getSchedule", l);
      }), (t, e) => {
        var _a;
        return ((_a = o.value) == null ? void 0 : _a.levelIcon) ? (C(), F("div", $, [
          s("div", {
            class: "task-hit-area",
            onClick: h
          }),
          s("div", L, [
            s("img", {
              src: o.value.levelIcon,
              class: "task-img"
            }, null, 8, N),
            s("div", V, [
              s("div", X, _(b(p)("pinch_hitter_guide.task_progress")), 1),
              s("div", {
                class: "schedule",
                style: y(f.value)
              }, [
                e[0] || (e[0] = s("div", {
                  class: "schedule-percentage"
                }, null, -1)),
                s("div", B, _(n.value.text), 1)
              ], 4)
            ])
          ])
        ])) : D("", true);
      };
    }
  });
});
export {
  __tla,
  gt as default
};
