import { o as r, c as t, a as e } from "./@vue.b00de3e9.js";
const l = { xmlns: "http://www.w3.org/2000/svg", fill: "currentColor", viewBox: "0 0 52 40" };
function n(o, a) {
  return r(), t("svg", l, [...a[0] || (a[0] = [e("g", { id: "wg_side_pink_unClaim__8fbdeea5800252f9a77d79e278a5d0a6-icon_sy_zc_jl", fill: "currentColor", transform: "translate(5082.123 19238)" }, [e("path", { id: "wg_side_pink_unClaim__8fbdeea5800252f9a77d79e278a5d0a6-Path_6343", fill: "currentColor", d: "M72.294 1121.946A10.415 10.415 0 1 1 62 1132.365a10.415 10.415 0 0 1 10.3-10.419Zm1.228 6.737a1.7 1.7 0 0 0-.562-.383 1.76 1.76 0 0 0-1.328 0 1.7 1.7 0 0 0-.562.383l-2.454 2.448a1.8 1.8 0 0 0-.377.565 1.8 1.8 0 0 0-.132.669 1.7 1.7 0 0 0 .132.66 1.6 1.6 0 0 0 .377.565l2.454 2.457a1.745 1.745 0 0 0 2.453 0l2.454-2.457a1.6 1.6 0 0 0 .377-.565 1.7 1.7 0 0 0 .132-.66 1.8 1.8 0 0 0-.132-.669 1.8 1.8 0 0 0-.377-.565ZM77.5 1115a1.734 1.734 0 0 1 1.734 1.733v3.468l-1.363 1.363a12.2 12.2 0 0 0-3.845-1.225v-3.606h-3.47v3.612a12.2 12.2 0 0 0-3.844 1.224l-1.363-1.363v-3.468a1.734 1.734 0 0 1 1.739-1.738Z", "data-name": "Path 6343", transform: "translate(-5128.121 -20347)" })], -1)])]);
}
const s = { render: n };
export {
  s as default,
  n as render
};
