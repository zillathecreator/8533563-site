import { a4 as Me, p as Pe, w as ke, n as He, e as Le, F as Oe, h as k, aj as je, r as N, l as qe } from "./@vue.b00de3e9.js";
function ye(t) {
  return t !== null && typeof t == "object" && "constructor" in t && t.constructor === Object;
}
function ge(t, e) {
  t === void 0 && (t = {}), e === void 0 && (e = {}), Object.keys(e).forEach((i) => {
    typeof t[i] > "u" ? t[i] = e[i] : ye(e[i]) && ye(t[i]) && Object.keys(e[i]).length > 0 && ge(t[i], e[i]);
  });
}
const Ie = { body: {}, addEventListener() {
}, removeEventListener() {
}, activeElement: { blur() {
}, nodeName: "" }, querySelector() {
  return null;
}, querySelectorAll() {
  return [];
}, getElementById() {
  return null;
}, createEvent() {
  return { initEvent() {
  } };
}, createElement() {
  return { children: [], childNodes: [], style: {}, setAttribute() {
  }, getElementsByTagName() {
    return [];
  } };
}, createElementNS() {
  return {};
}, importNode() {
  return null;
}, location: { hash: "", host: "", hostname: "", href: "", origin: "", pathname: "", protocol: "", search: "" } };
function j() {
  const t = typeof document < "u" ? document : {};
  return ge(t, Ie), t;
}
const We = { document: Ie, navigator: { userAgent: "" }, location: { hash: "", host: "", hostname: "", href: "", origin: "", pathname: "", protocol: "", search: "" }, history: { replaceState() {
}, pushState() {
}, go() {
}, back() {
} }, CustomEvent: function() {
  return this;
}, addEventListener() {
}, removeEventListener() {
}, getComputedStyle() {
  return { getPropertyValue() {
    return "";
  } };
}, Image() {
}, Date() {
}, screen: {}, setTimeout() {
}, clearTimeout() {
}, matchMedia() {
  return {};
}, requestAnimationFrame(t) {
  return typeof setTimeout > "u" ? (t(), null) : setTimeout(t, 0);
}, cancelAnimationFrame(t) {
  typeof setTimeout > "u" || clearTimeout(t);
} };
function F() {
  const t = typeof window < "u" ? window : {};
  return ge(t, We), t;
}
function Xe(t) {
  const e = t;
  Object.keys(e).forEach((i) => {
    try {
      e[i] = null;
    } catch (e2) {
    }
    try {
      delete e[i];
    } catch (e2) {
    }
  });
}
function pe(t, e) {
  return e === void 0 && (e = 0), setTimeout(t, e);
}
function U() {
  return Date.now();
}
function Ye(t) {
  const e = F();
  let i;
  return e.getComputedStyle && (i = e.getComputedStyle(t, null)), !i && t.currentStyle && (i = t.currentStyle), i || (i = t.style), i;
}
function Ue(t, e) {
  e === void 0 && (e = "x");
  const i = F();
  let s, r, n;
  const o = Ye(t);
  return i.WebKitCSSMatrix ? (r = o.transform || o.webkitTransform, r.split(",").length > 6 && (r = r.split(", ").map((l) => l.replace(",", ".")).join(", ")), n = new i.WebKitCSSMatrix(r === "none" ? "" : r)) : (n = o.MozTransform || o.OTransform || o.MsTransform || o.msTransform || o.transform || o.getPropertyValue("transform").replace("translate(", "matrix(1, 0, 0, 1,"), s = n.toString().split(",")), e === "x" && (i.WebKitCSSMatrix ? r = n.m41 : s.length === 16 ? r = parseFloat(s[12]) : r = parseFloat(s[4])), e === "y" && (i.WebKitCSSMatrix ? r = n.m42 : s.length === 16 ? r = parseFloat(s[13]) : r = parseFloat(s[5])), r || 0;
}
function te(t) {
  return typeof t == "object" && t !== null && t.constructor && Object.prototype.toString.call(t).slice(8, -1) === "Object";
}
function Ke(t) {
  return typeof window < "u" && typeof window.HTMLElement < "u" ? t instanceof HTMLElement : t && (t.nodeType === 1 || t.nodeType === 11);
}
function V() {
  const t = Object(arguments.length <= 0 ? void 0 : arguments[0]), e = ["__proto__", "constructor", "prototype"];
  for (let i = 1; i < arguments.length; i += 1) {
    const s = i < 0 || arguments.length <= i ? void 0 : arguments[i];
    if (s != null && !Ke(s)) {
      const r = Object.keys(Object(s)).filter((n) => e.indexOf(n) < 0);
      for (let n = 0, o = r.length; n < o; n += 1) {
        const l = r[n], a = Object.getOwnPropertyDescriptor(s, l);
        a !== void 0 && a.enumerable && (te(t[l]) && te(s[l]) ? s[l].__swiper__ ? t[l] = s[l] : V(t[l], s[l]) : !te(t[l]) && te(s[l]) ? (t[l] = {}, s[l].__swiper__ ? t[l] = s[l] : V(t[l], s[l])) : t[l] = s[l]);
      }
    }
  }
  return t;
}
function Q(t, e, i) {
  t.style.setProperty(e, i);
}
function ze(t) {
  let { swiper: e, targetPosition: i, side: s } = t;
  const r = F(), n = -e.translate;
  let o = null, l;
  const a = e.params.speed;
  e.wrapperEl.style.scrollSnapType = "none", r.cancelAnimationFrame(e.cssModeFrameID);
  const p = i > n ? "next" : "prev", f = (b, h) => p === "next" && b >= h || p === "prev" && b <= h, c = () => {
    l = (/* @__PURE__ */ new Date()).getTime(), o === null && (o = l);
    const b = Math.max(Math.min((l - o) / a, 1), 0), h = 0.5 - Math.cos(b * Math.PI) / 2;
    let w = n + h * (i - n);
    if (f(w, i) && (w = i), e.wrapperEl.scrollTo({ [s]: w }), f(w, i)) {
      e.wrapperEl.style.overflow = "hidden", e.wrapperEl.style.scrollSnapType = "", setTimeout(() => {
        e.wrapperEl.style.overflow = "", e.wrapperEl.scrollTo({ [s]: w });
      }), r.cancelAnimationFrame(e.cssModeFrameID);
      return;
    }
    e.cssModeFrameID = r.requestAnimationFrame(c);
  };
  c();
}
function we(t) {
  return t.querySelector(".swiper-slide-transform") || t.shadowRoot && t.shadowRoot.querySelector(".swiper-slide-transform") || t;
}
function H(t, e) {
  return e === void 0 && (e = ""), [...t.children].filter((i) => i.matches(e));
}
function ee(t, e) {
  e === void 0 && (e = []);
  const i = document.createElement(t);
  return i.classList.add(...Array.isArray(e) ? e : [e]), i;
}
function Ze(t, e) {
  const i = [];
  for (; t.previousElementSibling; ) {
    const s = t.previousElementSibling;
    e ? s.matches(e) && i.push(s) : i.push(s), t = s;
  }
  return i;
}
function Je(t, e) {
  const i = [];
  for (; t.nextElementSibling; ) {
    const s = t.nextElementSibling;
    e ? s.matches(e) && i.push(s) : i.push(s), t = s;
  }
  return i;
}
function W(t, e) {
  return F().getComputedStyle(t, null).getPropertyValue(e);
}
function se(t) {
  let e = t, i;
  if (e) {
    for (i = 0; (e = e.previousSibling) !== null; )
      e.nodeType === 1 && (i += 1);
    return i;
  }
}
function Ae(t, e) {
  const i = [];
  let s = t.parentElement;
  for (; s; )
    e ? s.matches(e) && i.push(s) : i.push(s), s = s.parentElement;
  return i;
}
function re(t, e) {
  function i(s) {
    s.target === t && (e.call(t, s), t.removeEventListener("transitionend", i));
  }
  e && t.addEventListener("transitionend", i);
}
function me(t, e, i) {
  const s = F();
  return i ? t[e === "width" ? "offsetWidth" : "offsetHeight"] + parseFloat(s.getComputedStyle(t, null).getPropertyValue(e === "width" ? "margin-right" : "margin-top")) + parseFloat(s.getComputedStyle(t, null).getPropertyValue(e === "width" ? "margin-left" : "margin-bottom")) : t.offsetWidth;
}
let ae;
function Qe() {
  const t = F(), e = j();
  return { smoothScroll: e.documentElement && e.documentElement.style && "scrollBehavior" in e.documentElement.style, touch: !!("ontouchstart" in t || t.DocumentTouch && e instanceof t.DocumentTouch) };
}
function Be() {
  return ae || (ae = Qe()), ae;
}
let le;
function et(t) {
  let { userAgent: e } = t === void 0 ? {} : t;
  const i = Be(), s = F(), r = s.navigator.platform, n = e || s.navigator.userAgent, o = { ios: false, android: false }, l = s.screen.width, a = s.screen.height, p = n.match(/(Android);?[\s\/]+([\d.]+)?/);
  let f = n.match(/(iPad).*OS\s([\d_]+)/);
  const c = n.match(/(iPod)(.*OS\s([\d_]+))?/), b = !f && n.match(/(iPhone\sOS|iOS)\s([\d_]+)/), h = r === "Win32";
  let w = r === "MacIntel";
  const m = ["1024x1366", "1366x1024", "834x1194", "1194x834", "834x1112", "1112x834", "768x1024", "1024x768", "820x1180", "1180x820", "810x1080", "1080x810"];
  return !f && w && i.touch && m.indexOf("".concat(l, "x").concat(a)) >= 0 && (f = n.match(/(Version)\/([\d.]+)/), f || (f = [0, 1, "13_0_0"]), w = false), p && !h && (o.os = "android", o.android = true), (f || b || c) && (o.os = "ios", o.ios = true), o;
}
function tt(t) {
  return t === void 0 && (t = {}), le || (le = et(t)), le;
}
let oe;
function it() {
  const t = F();
  let e = false;
  function i() {
    const s = t.navigator.userAgent.toLowerCase();
    return s.indexOf("safari") >= 0 && s.indexOf("chrome") < 0 && s.indexOf("android") < 0;
  }
  if (i()) {
    const s = String(t.navigator.userAgent);
    if (s.includes("Version/")) {
      const [r, n] = s.split("Version/")[1].split(" ")[0].split(".").map((o) => Number(o));
      e = r < 16 || r === 16 && n < 2;
    }
  }
  return { isSafari: e || i(), needPerspectiveFix: e, isWebView: /(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/i.test(t.navigator.userAgent) };
}
function st() {
  return oe || (oe = it()), oe;
}
function nt(t) {
  let { swiper: e, on: i, emit: s } = t;
  const r = F();
  let n = null, o = null;
  const l = () => {
    !e || e.destroyed || !e.initialized || (s("beforeResize"), s("resize"));
  }, a = () => {
    !e || e.destroyed || !e.initialized || (n = new ResizeObserver((c) => {
      o = r.requestAnimationFrame(() => {
        const { width: b, height: h } = e;
        let w = b, m = h;
        c.forEach((S) => {
          let { contentBoxSize: v, contentRect: d, target: u } = S;
          u && u !== e.el || (w = d ? d.width : (v[0] || v).inlineSize, m = d ? d.height : (v[0] || v).blockSize);
        }), (w !== b || m !== h) && l();
      });
    }), n.observe(e.el));
  }, p = () => {
    o && r.cancelAnimationFrame(o), n && n.unobserve && e.el && (n.unobserve(e.el), n = null);
  }, f = () => {
    !e || e.destroyed || !e.initialized || s("orientationchange");
  };
  i("init", () => {
    if (e.params.resizeObserver && typeof r.ResizeObserver < "u") {
      a();
      return;
    }
    r.addEventListener("resize", l), r.addEventListener("orientationchange", f);
  }), i("destroy", () => {
    p(), r.removeEventListener("resize", l), r.removeEventListener("orientationchange", f);
  });
}
function rt(t) {
  let { swiper: e, extendParams: i, on: s, emit: r } = t;
  const n = [], o = F(), l = function(f, c) {
    c === void 0 && (c = {});
    const b = o.MutationObserver || o.WebkitMutationObserver, h = new b((w) => {
      if (e.__preventObserver__)
        return;
      if (w.length === 1) {
        r("observerUpdate", w[0]);
        return;
      }
      const m = function() {
        r("observerUpdate", w[0]);
      };
      o.requestAnimationFrame ? o.requestAnimationFrame(m) : o.setTimeout(m, 0);
    });
    h.observe(f, { attributes: typeof c.attributes > "u" ? true : c.attributes, childList: typeof c.childList > "u" ? true : c.childList, characterData: typeof c.characterData > "u" ? true : c.characterData }), n.push(h);
  }, a = () => {
    if (e.params.observer) {
      if (e.params.observeParents) {
        const f = Ae(e.hostEl);
        for (let c = 0; c < f.length; c += 1)
          l(f[c]);
      }
      l(e.hostEl, { childList: e.params.observeSlideChildren }), l(e.wrapperEl, { attributes: false });
    }
  }, p = () => {
    n.forEach((f) => {
      f.disconnect();
    }), n.splice(0, n.length);
  };
  i({ observer: false, observeParents: false, observeSlideChildren: false }), s("init", a), s("destroy", p);
}
var at = { on(t, e, i) {
  const s = this;
  if (!s.eventsListeners || s.destroyed || typeof e != "function")
    return s;
  const r = i ? "unshift" : "push";
  return t.split(" ").forEach((n) => {
    s.eventsListeners[n] || (s.eventsListeners[n] = []), s.eventsListeners[n][r](e);
  }), s;
}, once(t, e, i) {
  const s = this;
  if (!s.eventsListeners || s.destroyed || typeof e != "function")
    return s;
  function r() {
    s.off(t, r), r.__emitterProxy && delete r.__emitterProxy;
    for (var n = arguments.length, o = new Array(n), l = 0; l < n; l++)
      o[l] = arguments[l];
    e.apply(s, o);
  }
  return r.__emitterProxy = e, s.on(t, r, i);
}, onAny(t, e) {
  const i = this;
  if (!i.eventsListeners || i.destroyed || typeof t != "function")
    return i;
  const s = e ? "unshift" : "push";
  return i.eventsAnyListeners.indexOf(t) < 0 && i.eventsAnyListeners[s](t), i;
}, offAny(t) {
  const e = this;
  if (!e.eventsListeners || e.destroyed || !e.eventsAnyListeners)
    return e;
  const i = e.eventsAnyListeners.indexOf(t);
  return i >= 0 && e.eventsAnyListeners.splice(i, 1), e;
}, off(t, e) {
  const i = this;
  return !i.eventsListeners || i.destroyed || !i.eventsListeners || t.split(" ").forEach((s) => {
    typeof e > "u" ? i.eventsListeners[s] = [] : i.eventsListeners[s] && i.eventsListeners[s].forEach((r, n) => {
      (r === e || r.__emitterProxy && r.__emitterProxy === e) && i.eventsListeners[s].splice(n, 1);
    });
  }), i;
}, emit() {
  const t = this;
  if (!t.eventsListeners || t.destroyed || !t.eventsListeners)
    return t;
  let e, i, s;
  for (var r = arguments.length, n = new Array(r), o = 0; o < r; o++)
    n[o] = arguments[o];
  return typeof n[0] == "string" || Array.isArray(n[0]) ? (e = n[0], i = n.slice(1, n.length), s = t) : (e = n[0].events, i = n[0].data, s = n[0].context || t), i.unshift(s), (Array.isArray(e) ? e : e.split(" ")).forEach((a) => {
    t.eventsAnyListeners && t.eventsAnyListeners.length && t.eventsAnyListeners.forEach((p) => {
      p.apply(s, [a, ...i]);
    }), t.eventsListeners && t.eventsListeners[a] && t.eventsListeners[a].forEach((p) => {
      p.apply(s, i);
    });
  }), t;
} };
function lt() {
  const t = this;
  let e, i;
  const s = t.el;
  typeof t.params.width < "u" && t.params.width !== null ? e = t.params.width : e = s.clientWidth, typeof t.params.height < "u" && t.params.height !== null ? i = t.params.height : i = s.clientHeight, !(e === 0 && t.isHorizontal() || i === 0 && t.isVertical()) && (e = e - parseInt(W(s, "padding-left") || 0, 10) - parseInt(W(s, "padding-right") || 0, 10), i = i - parseInt(W(s, "padding-top") || 0, 10) - parseInt(W(s, "padding-bottom") || 0, 10), Number.isNaN(e) && (e = 0), Number.isNaN(i) && (i = 0), Object.assign(t, { width: e, height: i, size: t.isHorizontal() ? e : i }));
}
function ot() {
  const t = this;
  function e(x) {
    return t.isHorizontal() ? x : { width: "height", "margin-top": "margin-left", "margin-bottom ": "margin-right", "margin-left": "margin-top", "margin-right": "margin-bottom", "padding-left": "padding-top", "padding-right": "padding-bottom", marginRight: "marginBottom" }[x];
  }
  function i(x, L) {
    return parseFloat(x.getPropertyValue(e(L)) || 0);
  }
  const s = t.params, { wrapperEl: r, slidesEl: n, size: o, rtlTranslate: l, wrongRTL: a } = t, p = t.virtual && s.virtual.enabled, f = p ? t.virtual.slides.length : t.slides.length, c = H(n, ".".concat(t.params.slideClass, ", swiper-slide")), b = p ? t.virtual.slides.length : c.length;
  let h = [];
  const w = [], m = [];
  let S = s.slidesOffsetBefore;
  typeof S == "function" && (S = s.slidesOffsetBefore.call(t));
  let v = s.slidesOffsetAfter;
  typeof v == "function" && (v = s.slidesOffsetAfter.call(t));
  const d = t.snapGrid.length, u = t.slidesGrid.length;
  let y = s.spaceBetween, T = -S, C = 0, E = 0;
  if (typeof o > "u")
    return;
  typeof y == "string" && y.indexOf("%") >= 0 ? y = parseFloat(y.replace("%", "")) / 100 * o : typeof y == "string" && (y = parseFloat(y)), t.virtualSize = -y, c.forEach((x) => {
    l ? x.style.marginLeft = "" : x.style.marginRight = "", x.style.marginBottom = "", x.style.marginTop = "";
  }), s.centeredSlides && s.cssMode && (Q(r, "--swiper-centered-offset-before", ""), Q(r, "--swiper-centered-offset-after", ""));
  const M = s.grid && s.grid.rows > 1 && t.grid;
  M && t.grid.initSlides(b);
  let g;
  const I = s.slidesPerView === "auto" && s.breakpoints && Object.keys(s.breakpoints).filter((x) => typeof s.breakpoints[x].slidesPerView < "u").length > 0;
  for (let x = 0; x < b; x += 1) {
    g = 0;
    let L;
    if (c[x] && (L = c[x]), M && t.grid.updateSlide(x, L, b, e), !(c[x] && W(L, "display") === "none")) {
      if (s.slidesPerView === "auto") {
        I && (c[x].style[e("width")] = "");
        const P = getComputedStyle(L), O = L.style.transform, B = L.style.webkitTransform;
        if (O && (L.style.transform = "none"), B && (L.style.webkitTransform = "none"), s.roundLengths)
          g = t.isHorizontal() ? me(L, "width", true) : me(L, "height", true);
        else {
          const D = i(P, "width"), A = i(P, "padding-left"), _ = i(P, "padding-right"), G = i(P, "margin-left"), R = i(P, "margin-right"), X = P.getPropertyValue("box-sizing");
          if (X && X === "border-box")
            g = D + G + R;
          else {
            const { clientWidth: ne, offsetWidth: z } = L;
            g = D + A + _ + G + R + (z - ne);
          }
        }
        O && (L.style.transform = O), B && (L.style.webkitTransform = B), s.roundLengths && (g = Math.floor(g));
      } else
        g = (o - (s.slidesPerView - 1) * y) / s.slidesPerView, s.roundLengths && (g = Math.floor(g)), c[x] && (c[x].style[e("width")] = "".concat(g, "px"));
      c[x] && (c[x].swiperSlideSize = g), m.push(g), s.centeredSlides ? (T = T + g / 2 + C / 2 + y, C === 0 && x !== 0 && (T = T - o / 2 - y), x === 0 && (T = T - o / 2 - y), Math.abs(T) < 1 / 1e3 && (T = 0), s.roundLengths && (T = Math.floor(T)), E % s.slidesPerGroup === 0 && h.push(T), w.push(T)) : (s.roundLengths && (T = Math.floor(T)), (E - Math.min(t.params.slidesPerGroupSkip, E)) % t.params.slidesPerGroup === 0 && h.push(T), w.push(T), T = T + g + y), t.virtualSize += g + y, C = g, E += 1;
    }
  }
  if (t.virtualSize = Math.max(t.virtualSize, o) + v, l && a && (s.effect === "slide" || s.effect === "coverflow") && (r.style.width = "".concat(t.virtualSize + y, "px")), s.setWrapperSize && (r.style[e("width")] = "".concat(t.virtualSize + y, "px")), M && t.grid.updateWrapperSize(g, h, e), !s.centeredSlides) {
    const x = [];
    for (let L = 0; L < h.length; L += 1) {
      let P = h[L];
      s.roundLengths && (P = Math.floor(P)), h[L] <= t.virtualSize - o && x.push(P);
    }
    h = x, Math.floor(t.virtualSize - o) - Math.floor(h[h.length - 1]) > 1 && h.push(t.virtualSize - o);
  }
  if (p && s.loop) {
    const x = m[0] + y;
    if (s.slidesPerGroup > 1) {
      const L = Math.ceil((t.virtual.slidesBefore + t.virtual.slidesAfter) / s.slidesPerGroup), P = x * s.slidesPerGroup;
      for (let O = 0; O < L; O += 1)
        h.push(h[h.length - 1] + P);
    }
    for (let L = 0; L < t.virtual.slidesBefore + t.virtual.slidesAfter; L += 1)
      s.slidesPerGroup === 1 && h.push(h[h.length - 1] + x), w.push(w[w.length - 1] + x), t.virtualSize += x;
  }
  if (h.length === 0 && (h = [0]), y !== 0) {
    const x = t.isHorizontal() && l ? "marginLeft" : e("marginRight");
    c.filter((L, P) => !s.cssMode || s.loop ? true : P !== c.length - 1).forEach((L) => {
      L.style[x] = "".concat(y, "px");
    });
  }
  if (s.centeredSlides && s.centeredSlidesBounds) {
    let x = 0;
    m.forEach((P) => {
      x += P + (y || 0);
    }), x -= y;
    const L = x - o;
    h = h.map((P) => P <= 0 ? -S : P > L ? L + v : P);
  }
  if (s.centerInsufficientSlides) {
    let x = 0;
    if (m.forEach((L) => {
      x += L + (y || 0);
    }), x -= y, x < o) {
      const L = (o - x) / 2;
      h.forEach((P, O) => {
        h[O] = P - L;
      }), w.forEach((P, O) => {
        w[O] = P + L;
      });
    }
  }
  if (Object.assign(t, { slides: c, snapGrid: h, slidesGrid: w, slidesSizesGrid: m }), s.centeredSlides && s.cssMode && !s.centeredSlidesBounds) {
    Q(r, "--swiper-centered-offset-before", "".concat(-h[0], "px")), Q(r, "--swiper-centered-offset-after", "".concat(t.size / 2 - m[m.length - 1] / 2, "px"));
    const x = -t.snapGrid[0], L = -t.slidesGrid[0];
    t.snapGrid = t.snapGrid.map((P) => P + x), t.slidesGrid = t.slidesGrid.map((P) => P + L);
  }
  if (b !== f && t.emit("slidesLengthChange"), h.length !== d && (t.params.watchOverflow && t.checkOverflow(), t.emit("snapGridLengthChange")), w.length !== u && t.emit("slidesGridLengthChange"), s.watchSlidesProgress && t.updateSlidesOffset(), !p && !s.cssMode && (s.effect === "slide" || s.effect === "fade")) {
    const x = "".concat(s.containerModifierClass, "backface-hidden"), L = t.el.classList.contains(x);
    b <= s.maxBackfaceHiddenSlides ? L || t.el.classList.add(x) : L && t.el.classList.remove(x);
  }
}
function dt(t) {
  const e = this, i = [], s = e.virtual && e.params.virtual.enabled;
  let r = 0, n;
  typeof t == "number" ? e.setTransition(t) : t === true && e.setTransition(e.params.speed);
  const o = (l) => s ? e.slides[e.getSlideIndexByData(l)] : e.slides[l];
  if (e.params.slidesPerView !== "auto" && e.params.slidesPerView > 1)
    if (e.params.centeredSlides)
      (e.visibleSlides || []).forEach((l) => {
        i.push(l);
      });
    else
      for (n = 0; n < Math.ceil(e.params.slidesPerView); n += 1) {
        const l = e.activeIndex + n;
        if (l > e.slides.length && !s)
          break;
        i.push(o(l));
      }
  else
    i.push(o(e.activeIndex));
  for (n = 0; n < i.length; n += 1)
    if (typeof i[n] < "u") {
      const l = i[n].offsetHeight;
      r = l > r ? l : r;
    }
  (r || r === 0) && (e.wrapperEl.style.height = "".concat(r, "px"));
}
function ft() {
  const t = this, e = t.slides, i = t.isElement ? t.isHorizontal() ? t.wrapperEl.offsetLeft : t.wrapperEl.offsetTop : 0;
  for (let s = 0; s < e.length; s += 1)
    e[s].swiperSlideOffset = (t.isHorizontal() ? e[s].offsetLeft : e[s].offsetTop) - i - t.cssOverflowAdjustment();
}
function ut(t) {
  t === void 0 && (t = this && this.translate || 0);
  const e = this, i = e.params, { slides: s, rtlTranslate: r, snapGrid: n } = e;
  if (s.length === 0)
    return;
  typeof s[0].swiperSlideOffset > "u" && e.updateSlidesOffset();
  let o = -t;
  r && (o = t), s.forEach((a) => {
    a.classList.remove(i.slideVisibleClass);
  }), e.visibleSlidesIndexes = [], e.visibleSlides = [];
  let l = i.spaceBetween;
  typeof l == "string" && l.indexOf("%") >= 0 ? l = parseFloat(l.replace("%", "")) / 100 * e.size : typeof l == "string" && (l = parseFloat(l));
  for (let a = 0; a < s.length; a += 1) {
    const p = s[a];
    let f = p.swiperSlideOffset;
    i.cssMode && i.centeredSlides && (f -= s[0].swiperSlideOffset);
    const c = (o + (i.centeredSlides ? e.minTranslate() : 0) - f) / (p.swiperSlideSize + l), b = (o - n[0] + (i.centeredSlides ? e.minTranslate() : 0) - f) / (p.swiperSlideSize + l), h = -(o - f), w = h + e.slidesSizesGrid[a];
    (h >= 0 && h < e.size - 1 || w > 1 && w <= e.size || h <= 0 && w >= e.size) && (e.visibleSlides.push(p), e.visibleSlidesIndexes.push(a), s[a].classList.add(i.slideVisibleClass)), p.progress = r ? -c : c, p.originalProgress = r ? -b : b;
  }
}
function ct(t) {
  const e = this;
  if (typeof t > "u") {
    const f = e.rtlTranslate ? -1 : 1;
    t = e && e.translate && e.translate * f || 0;
  }
  const i = e.params, s = e.maxTranslate() - e.minTranslate();
  let { progress: r, isBeginning: n, isEnd: o, progressLoop: l } = e;
  const a = n, p = o;
  if (s === 0)
    r = 0, n = true, o = true;
  else {
    r = (t - e.minTranslate()) / s;
    const f = Math.abs(t - e.minTranslate()) < 1, c = Math.abs(t - e.maxTranslate()) < 1;
    n = f || r <= 0, o = c || r >= 1, f && (r = 0), c && (r = 1);
  }
  if (i.loop) {
    const f = e.getSlideIndexByData(0), c = e.getSlideIndexByData(e.slides.length - 1), b = e.slidesGrid[f], h = e.slidesGrid[c], w = e.slidesGrid[e.slidesGrid.length - 1], m = Math.abs(t);
    m >= b ? l = (m - b) / w : l = (m + w - h) / w, l > 1 && (l -= 1);
  }
  Object.assign(e, { progress: r, progressLoop: l, isBeginning: n, isEnd: o }), (i.watchSlidesProgress || i.centeredSlides && i.autoHeight) && e.updateSlidesProgress(t), n && !a && e.emit("reachBeginning toEdge"), o && !p && e.emit("reachEnd toEdge"), (a && !n || p && !o) && e.emit("fromEdge"), e.emit("progress", r);
}
function pt() {
  const t = this, { slides: e, params: i, slidesEl: s, activeIndex: r } = t, n = t.virtual && i.virtual.enabled, o = (a) => H(s, ".".concat(i.slideClass).concat(a, ", swiper-slide").concat(a))[0];
  e.forEach((a) => {
    a.classList.remove(i.slideActiveClass, i.slideNextClass, i.slidePrevClass);
  });
  let l;
  if (n)
    if (i.loop) {
      let a = r - t.virtual.slidesBefore;
      a < 0 && (a = t.virtual.slides.length + a), a >= t.virtual.slides.length && (a -= t.virtual.slides.length), l = o('[data-swiper-slide-index="'.concat(a, '"]'));
    } else
      l = o('[data-swiper-slide-index="'.concat(r, '"]'));
  else
    l = e[r];
  if (l) {
    l.classList.add(i.slideActiveClass);
    let a = Je(l, ".".concat(i.slideClass, ", swiper-slide"))[0];
    i.loop && !a && (a = e[0]), a && a.classList.add(i.slideNextClass);
    let p = Ze(l, ".".concat(i.slideClass, ", swiper-slide"))[0];
    i.loop && !p === 0 && (p = e[e.length - 1]), p && p.classList.add(i.slidePrevClass);
  }
  t.emitSlidesClasses();
}
const ie = (t, e) => {
  if (!t || t.destroyed || !t.params)
    return;
  const i = () => t.isElement ? "swiper-slide" : ".".concat(t.params.slideClass), s = e.closest(i());
  if (s) {
    let r = s.querySelector(".".concat(t.params.lazyPreloaderClass));
    !r && t.isElement && (s.shadowRoot ? r = s.shadowRoot.querySelector(".".concat(t.params.lazyPreloaderClass)) : requestAnimationFrame(() => {
      s.shadowRoot && (r = s.shadowRoot.querySelector(".".concat(t.params.lazyPreloaderClass)), r && r.remove());
    })), r && r.remove();
  }
}, de = (t, e) => {
  if (!t.slides[e])
    return;
  const i = t.slides[e].querySelector('[loading="lazy"]');
  i && i.removeAttribute("loading");
}, he = (t) => {
  if (!t || t.destroyed || !t.params)
    return;
  let e = t.params.lazyPreloadPrevNext;
  const i = t.slides.length;
  if (!i || !e || e < 0)
    return;
  e = Math.min(e, i);
  const s = t.params.slidesPerView === "auto" ? t.slidesPerViewDynamic() : Math.ceil(t.params.slidesPerView), r = t.activeIndex;
  if (t.params.grid && t.params.grid.rows > 1) {
    const o = r, l = [o - e];
    l.push(...Array.from({ length: e }).map((a, p) => o + s + p)), t.slides.forEach((a, p) => {
      l.includes(a.column) && de(t, p);
    });
    return;
  }
  const n = r + s - 1;
  if (t.params.rewind || t.params.loop)
    for (let o = r - e; o <= n + e; o += 1) {
      const l = (o % i + i) % i;
      (l < r || l > n) && de(t, l);
    }
  else
    for (let o = Math.max(r - e, 0); o <= Math.min(n + e, i - 1); o += 1)
      o !== r && (o > n || o < r) && de(t, o);
};
function mt(t) {
  const { slidesGrid: e, params: i } = t, s = t.rtlTranslate ? t.translate : -t.translate;
  let r;
  for (let n = 0; n < e.length; n += 1)
    typeof e[n + 1] < "u" ? s >= e[n] && s < e[n + 1] - (e[n + 1] - e[n]) / 2 ? r = n : s >= e[n] && s < e[n + 1] && (r = n + 1) : s >= e[n] && (r = n);
  return i.normalizeSlideIndex && (r < 0 || typeof r > "u") && (r = 0), r;
}
function ht(t) {
  const e = this, i = e.rtlTranslate ? e.translate : -e.translate, { snapGrid: s, params: r, activeIndex: n, realIndex: o, snapIndex: l } = e;
  let a = t, p;
  const f = (b) => {
    let h = b - e.virtual.slidesBefore;
    return h < 0 && (h = e.virtual.slides.length + h), h >= e.virtual.slides.length && (h -= e.virtual.slides.length), h;
  };
  if (typeof a > "u" && (a = mt(e)), s.indexOf(i) >= 0)
    p = s.indexOf(i);
  else {
    const b = Math.min(r.slidesPerGroupSkip, a);
    p = b + Math.floor((a - b) / r.slidesPerGroup);
  }
  if (p >= s.length && (p = s.length - 1), a === n) {
    p !== l && (e.snapIndex = p, e.emit("snapIndexChange")), e.params.loop && e.virtual && e.params.virtual.enabled && (e.realIndex = f(a));
    return;
  }
  let c;
  e.virtual && r.virtual.enabled && r.loop ? c = f(a) : e.slides[a] ? c = parseInt(e.slides[a].getAttribute("data-swiper-slide-index") || a, 10) : c = a, Object.assign(e, { previousSnapIndex: l, snapIndex: p, previousRealIndex: o, realIndex: c, previousIndex: n, activeIndex: a }), e.initialized && he(e), e.emit("activeIndexChange"), e.emit("snapIndexChange"), (e.initialized || e.params.runCallbacksOnInit) && (o !== c && e.emit("realIndexChange"), e.emit("slideChange"));
}
function vt(t, e) {
  const i = this, s = i.params;
  let r = t.closest(".".concat(s.slideClass, ", swiper-slide"));
  !r && i.isElement && e && e.length > 1 && e.includes(t) && [...e.slice(e.indexOf(t) + 1, e.length)].forEach((l) => {
    !r && l.matches && l.matches(".".concat(s.slideClass, ", swiper-slide")) && (r = l);
  });
  let n = false, o;
  if (r) {
    for (let l = 0; l < i.slides.length; l += 1)
      if (i.slides[l] === r) {
        n = true, o = l;
        break;
      }
  }
  if (r && n)
    i.clickedSlide = r, i.virtual && i.params.virtual.enabled ? i.clickedIndex = parseInt(r.getAttribute("data-swiper-slide-index"), 10) : i.clickedIndex = o;
  else {
    i.clickedSlide = void 0, i.clickedIndex = void 0;
    return;
  }
  s.slideToClickedSlide && i.clickedIndex !== void 0 && i.clickedIndex !== i.activeIndex && i.slideToClickedSlide();
}
var gt = { updateSize: lt, updateSlides: ot, updateAutoHeight: dt, updateSlidesOffset: ft, updateSlidesProgress: ut, updateProgress: ct, updateSlidesClasses: pt, updateActiveIndex: ht, updateClickedSlide: vt };
function wt(t) {
  t === void 0 && (t = this.isHorizontal() ? "x" : "y");
  const e = this, { params: i, rtlTranslate: s, translate: r, wrapperEl: n } = e;
  if (i.virtualTranslate)
    return s ? -r : r;
  if (i.cssMode)
    return r;
  let o = Ue(n, t);
  return o += e.cssOverflowAdjustment(), s && (o = -o), o || 0;
}
function St(t, e) {
  const i = this, { rtlTranslate: s, params: r, wrapperEl: n, progress: o } = i;
  let l = 0, a = 0;
  const p = 0;
  i.isHorizontal() ? l = s ? -t : t : a = t, r.roundLengths && (l = Math.floor(l), a = Math.floor(a)), i.previousTranslate = i.translate, i.translate = i.isHorizontal() ? l : a, r.cssMode ? n[i.isHorizontal() ? "scrollLeft" : "scrollTop"] = i.isHorizontal() ? -l : -a : r.virtualTranslate || (i.isHorizontal() ? l -= i.cssOverflowAdjustment() : a -= i.cssOverflowAdjustment(), n.style.transform = "translate3d(".concat(l, "px, ").concat(a, "px, ").concat(p, "px)"));
  let f;
  const c = i.maxTranslate() - i.minTranslate();
  c === 0 ? f = 0 : f = (t - i.minTranslate()) / c, f !== o && i.updateProgress(t), i.emit("setTranslate", i.translate, e);
}
function yt() {
  return -this.snapGrid[0];
}
function bt() {
  return -this.snapGrid[this.snapGrid.length - 1];
}
function Tt(t, e, i, s, r) {
  t === void 0 && (t = 0), e === void 0 && (e = this.params.speed), i === void 0 && (i = true), s === void 0 && (s = true);
  const n = this, { params: o, wrapperEl: l } = n;
  if (n.animating && o.preventInteractionOnTransition)
    return false;
  const a = n.minTranslate(), p = n.maxTranslate();
  let f;
  if (s && t > a ? f = a : s && t < p ? f = p : f = t, n.updateProgress(f), o.cssMode) {
    const c = n.isHorizontal();
    if (e === 0)
      l[c ? "scrollLeft" : "scrollTop"] = -f;
    else {
      if (!n.support.smoothScroll)
        return ze({ swiper: n, targetPosition: -f, side: c ? "left" : "top" }), true;
      l.scrollTo({ [c ? "left" : "top"]: -f, behavior: "smooth" });
    }
    return true;
  }
  return e === 0 ? (n.setTransition(0), n.setTranslate(f), i && (n.emit("beforeTransitionStart", e, r), n.emit("transitionEnd"))) : (n.setTransition(e), n.setTranslate(f), i && (n.emit("beforeTransitionStart", e, r), n.emit("transitionStart")), n.animating || (n.animating = true, n.onTranslateToWrapperTransitionEnd || (n.onTranslateToWrapperTransitionEnd = function(b) {
    !n || n.destroyed || b.target === this && (n.wrapperEl.removeEventListener("transitionend", n.onTranslateToWrapperTransitionEnd), n.onTranslateToWrapperTransitionEnd = null, delete n.onTranslateToWrapperTransitionEnd, i && n.emit("transitionEnd"));
  }), n.wrapperEl.addEventListener("transitionend", n.onTranslateToWrapperTransitionEnd))), true;
}
var xt = { getTranslate: wt, setTranslate: St, minTranslate: yt, maxTranslate: bt, translateTo: Tt };
function Et(t, e) {
  const i = this;
  i.params.cssMode || (i.wrapperEl.style.transitionDuration = "".concat(t, "ms"), i.wrapperEl.style.transitionDelay = t === 0 ? "0ms" : ""), i.emit("setTransition", t, e);
}
function De(t) {
  let { swiper: e, runCallbacks: i, direction: s, step: r } = t;
  const { activeIndex: n, previousIndex: o } = e;
  let l = s;
  if (l || (n > o ? l = "next" : n < o ? l = "prev" : l = "reset"), e.emit("transition".concat(r)), i && n !== o) {
    if (l === "reset") {
      e.emit("slideResetTransition".concat(r));
      return;
    }
    e.emit("slideChangeTransition".concat(r)), l === "next" ? e.emit("slideNextTransition".concat(r)) : e.emit("slidePrevTransition".concat(r));
  }
}
function Ct(t, e) {
  t === void 0 && (t = true);
  const i = this, { params: s } = i;
  s.cssMode || (s.autoHeight && i.updateAutoHeight(), De({ swiper: i, runCallbacks: t, direction: e, step: "Start" }));
}
function Mt(t, e) {
  t === void 0 && (t = true);
  const i = this, { params: s } = i;
  i.animating = false, !s.cssMode && (i.setTransition(0), De({ swiper: i, runCallbacks: t, direction: e, step: "End" }));
}
var Pt = { setTransition: Et, transitionStart: Ct, transitionEnd: Mt };
function Lt(t, e, i, s, r) {
  t === void 0 && (t = 0), e === void 0 && (e = this.params.speed), i === void 0 && (i = true), typeof t == "string" && (t = parseInt(t, 10));
  const n = this;
  let o = t;
  o < 0 && (o = 0);
  const { params: l, snapGrid: a, slidesGrid: p, previousIndex: f, activeIndex: c, rtlTranslate: b, wrapperEl: h, enabled: w } = n;
  if (n.animating && l.preventInteractionOnTransition || !w && !s && !r)
    return false;
  const m = Math.min(n.params.slidesPerGroupSkip, o);
  let S = m + Math.floor((o - m) / n.params.slidesPerGroup);
  S >= a.length && (S = a.length - 1);
  const v = -a[S];
  if (l.normalizeSlideIndex)
    for (let u = 0; u < p.length; u += 1) {
      const y = -Math.floor(v * 100), T = Math.floor(p[u] * 100), C = Math.floor(p[u + 1] * 100);
      typeof p[u + 1] < "u" ? y >= T && y < C - (C - T) / 2 ? o = u : y >= T && y < C && (o = u + 1) : y >= T && (o = u);
    }
  if (n.initialized && o !== c && (!n.allowSlideNext && (b ? v > n.translate && v > n.minTranslate() : v < n.translate && v < n.minTranslate()) || !n.allowSlidePrev && v > n.translate && v > n.maxTranslate() && (c || 0) !== o))
    return false;
  o !== (f || 0) && i && n.emit("beforeSlideChangeStart"), n.updateProgress(v);
  let d;
  if (o > c ? d = "next" : o < c ? d = "prev" : d = "reset", b && -v === n.translate || !b && v === n.translate)
    return n.updateActiveIndex(o), l.autoHeight && n.updateAutoHeight(), n.updateSlidesClasses(), l.effect !== "slide" && n.setTranslate(v), d !== "reset" && (n.transitionStart(i, d), n.transitionEnd(i, d)), false;
  if (l.cssMode) {
    const u = n.isHorizontal(), y = b ? v : -v;
    if (e === 0) {
      const T = n.virtual && n.params.virtual.enabled;
      T && (n.wrapperEl.style.scrollSnapType = "none", n._immediateVirtual = true), T && !n._cssModeVirtualInitialSet && n.params.initialSlide > 0 ? (n._cssModeVirtualInitialSet = true, requestAnimationFrame(() => {
        h[u ? "scrollLeft" : "scrollTop"] = y;
      })) : h[u ? "scrollLeft" : "scrollTop"] = y, T && requestAnimationFrame(() => {
        n.wrapperEl.style.scrollSnapType = "", n._immediateVirtual = false;
      });
    } else {
      if (!n.support.smoothScroll)
        return ze({ swiper: n, targetPosition: y, side: u ? "left" : "top" }), true;
      h.scrollTo({ [u ? "left" : "top"]: y, behavior: "smooth" });
    }
    return true;
  }
  return n.setTransition(e), n.setTranslate(v), n.updateActiveIndex(o), n.updateSlidesClasses(), n.emit("beforeTransitionStart", e, s), n.transitionStart(i, d), e === 0 ? n.transitionEnd(i, d) : n.animating || (n.animating = true, n.onSlideToWrapperTransitionEnd || (n.onSlideToWrapperTransitionEnd = function(y) {
    !n || n.destroyed || y.target === this && (n.wrapperEl.removeEventListener("transitionend", n.onSlideToWrapperTransitionEnd), n.onSlideToWrapperTransitionEnd = null, delete n.onSlideToWrapperTransitionEnd, n.transitionEnd(i, d));
  }), n.wrapperEl.addEventListener("transitionend", n.onSlideToWrapperTransitionEnd)), true;
}
function Ot(t, e, i, s) {
  t === void 0 && (t = 0), e === void 0 && (e = this.params.speed), i === void 0 && (i = true), typeof t == "string" && (t = parseInt(t, 10));
  const r = this;
  let n = t;
  return r.params.loop && (r.virtual && r.params.virtual.enabled ? n = n + r.virtual.slidesBefore : n = r.getSlideIndexByData(n)), r.slideTo(n, e, i, s);
}
function It(t, e, i) {
  t === void 0 && (t = this.params.speed), e === void 0 && (e = true);
  const s = this, { enabled: r, params: n, animating: o } = s;
  if (!r)
    return s;
  let l = n.slidesPerGroup;
  n.slidesPerView === "auto" && n.slidesPerGroup === 1 && n.slidesPerGroupAuto && (l = Math.max(s.slidesPerViewDynamic("current", true), 1));
  const a = s.activeIndex < n.slidesPerGroupSkip ? 1 : l, p = s.virtual && n.virtual.enabled;
  if (n.loop) {
    if (o && !p && n.loopPreventsSliding)
      return false;
    if (s.loopFix({ direction: "next" }), s._clientLeft = s.wrapperEl.clientLeft, s.activeIndex === s.slides.length - 1 && n.cssMode)
      return requestAnimationFrame(() => {
        s.slideTo(s.activeIndex + a, t, e, i);
      }), true;
  }
  return n.rewind && s.isEnd ? s.slideTo(0, t, e, i) : s.slideTo(s.activeIndex + a, t, e, i);
}
function zt(t, e, i) {
  t === void 0 && (t = this.params.speed), e === void 0 && (e = true);
  const s = this, { params: r, snapGrid: n, slidesGrid: o, rtlTranslate: l, enabled: a, animating: p } = s;
  if (!a)
    return s;
  const f = s.virtual && r.virtual.enabled;
  if (r.loop) {
    if (p && !f && r.loopPreventsSliding)
      return false;
    s.loopFix({ direction: "prev" }), s._clientLeft = s.wrapperEl.clientLeft;
  }
  const c = l ? s.translate : -s.translate;
  function b(v) {
    return v < 0 ? -Math.floor(Math.abs(v)) : Math.floor(v);
  }
  const h = b(c), w = n.map((v) => b(v));
  let m = n[w.indexOf(h) - 1];
  if (typeof m > "u" && r.cssMode) {
    let v;
    n.forEach((d, u) => {
      h >= d && (v = u);
    }), typeof v < "u" && (m = n[v > 0 ? v - 1 : v]);
  }
  let S = 0;
  if (typeof m < "u" && (S = o.indexOf(m), S < 0 && (S = s.activeIndex - 1), r.slidesPerView === "auto" && r.slidesPerGroup === 1 && r.slidesPerGroupAuto && (S = S - s.slidesPerViewDynamic("previous", true) + 1, S = Math.max(S, 0))), r.rewind && s.isBeginning) {
    const v = s.params.virtual && s.params.virtual.enabled && s.virtual ? s.virtual.slides.length - 1 : s.slides.length - 1;
    return s.slideTo(v, t, e, i);
  } else if (r.loop && s.activeIndex === 0 && r.cssMode)
    return requestAnimationFrame(() => {
      s.slideTo(S, t, e, i);
    }), true;
  return s.slideTo(S, t, e, i);
}
function At(t, e, i) {
  t === void 0 && (t = this.params.speed), e === void 0 && (e = true);
  const s = this;
  return s.slideTo(s.activeIndex, t, e, i);
}
function Bt(t, e, i, s) {
  t === void 0 && (t = this.params.speed), e === void 0 && (e = true), s === void 0 && (s = 0.5);
  const r = this;
  let n = r.activeIndex;
  const o = Math.min(r.params.slidesPerGroupSkip, n), l = o + Math.floor((n - o) / r.params.slidesPerGroup), a = r.rtlTranslate ? r.translate : -r.translate;
  if (a >= r.snapGrid[l]) {
    const p = r.snapGrid[l], f = r.snapGrid[l + 1];
    a - p > (f - p) * s && (n += r.params.slidesPerGroup);
  } else {
    const p = r.snapGrid[l - 1], f = r.snapGrid[l];
    a - p <= (f - p) * s && (n -= r.params.slidesPerGroup);
  }
  return n = Math.max(n, 0), n = Math.min(n, r.slidesGrid.length - 1), r.slideTo(n, t, e, i);
}
function Dt() {
  const t = this, { params: e, slidesEl: i } = t, s = e.slidesPerView === "auto" ? t.slidesPerViewDynamic() : e.slidesPerView;
  let r = t.clickedIndex, n;
  const o = t.isElement ? "swiper-slide" : ".".concat(e.slideClass);
  if (e.loop) {
    if (t.animating)
      return;
    n = parseInt(t.clickedSlide.getAttribute("data-swiper-slide-index"), 10), e.centeredSlides ? r < t.loopedSlides - s / 2 || r > t.slides.length - t.loopedSlides + s / 2 ? (t.loopFix(), r = t.getSlideIndex(H(i, "".concat(o, '[data-swiper-slide-index="').concat(n, '"]'))[0]), pe(() => {
      t.slideTo(r);
    })) : t.slideTo(r) : r > t.slides.length - s ? (t.loopFix(), r = t.getSlideIndex(H(i, "".concat(o, '[data-swiper-slide-index="').concat(n, '"]'))[0]), pe(() => {
      t.slideTo(r);
    })) : t.slideTo(r);
  } else
    t.slideTo(r);
}
var $t = { slideTo: Lt, slideToLoop: Ot, slideNext: It, slidePrev: zt, slideReset: At, slideToClosest: Bt, slideToClickedSlide: Dt };
function Gt(t) {
  const e = this, { params: i, slidesEl: s } = e;
  if (!i.loop || e.virtual && e.params.virtual.enabled)
    return;
  H(s, ".".concat(i.slideClass, ", swiper-slide")).forEach((n, o) => {
    n.setAttribute("data-swiper-slide-index", o);
  }), e.loopFix({ slideRealIndex: t, direction: i.centeredSlides ? void 0 : "next" });
}
function _t(t) {
  let { slideRealIndex: e, slideTo: i = true, direction: s, setTranslate: r, activeSlideIndex: n, byController: o, byMousewheel: l } = t === void 0 ? {} : t;
  const a = this;
  if (!a.params.loop)
    return;
  a.emit("beforeLoopFix");
  const { slides: p, allowSlidePrev: f, allowSlideNext: c, slidesEl: b, params: h } = a;
  if (a.allowSlidePrev = true, a.allowSlideNext = true, a.virtual && h.virtual.enabled) {
    i && (!h.centeredSlides && a.snapIndex === 0 ? a.slideTo(a.virtual.slides.length, 0, false, true) : h.centeredSlides && a.snapIndex < h.slidesPerView ? a.slideTo(a.virtual.slides.length + a.snapIndex, 0, false, true) : a.snapIndex === a.snapGrid.length - 1 && a.slideTo(a.virtual.slidesBefore, 0, false, true)), a.allowSlidePrev = f, a.allowSlideNext = c, a.emit("loopFix");
    return;
  }
  const w = h.slidesPerView === "auto" ? a.slidesPerViewDynamic() : Math.ceil(parseFloat(h.slidesPerView, 10));
  let m = h.loopedSlides || w;
  m % h.slidesPerGroup !== 0 && (m += h.slidesPerGroup - m % h.slidesPerGroup), a.loopedSlides = m;
  const S = [], v = [];
  let d = a.activeIndex;
  typeof n > "u" ? n = a.getSlideIndex(a.slides.filter((E) => E.classList.contains(h.slideActiveClass))[0]) : d = n;
  const u = s === "next" || !s, y = s === "prev" || !s;
  let T = 0, C = 0;
  if (n < m) {
    T = Math.max(m - n, h.slidesPerGroup);
    for (let E = 0; E < m - n; E += 1) {
      const M = E - Math.floor(E / p.length) * p.length;
      S.push(p.length - M - 1);
    }
  } else if (n > a.slides.length - m * 2) {
    C = Math.max(n - (a.slides.length - m * 2), h.slidesPerGroup);
    for (let E = 0; E < C; E += 1) {
      const M = E - Math.floor(E / p.length) * p.length;
      v.push(M);
    }
  }
  if (y && S.forEach((E) => {
    a.slides[E].swiperLoopMoveDOM = true, b.prepend(a.slides[E]), a.slides[E].swiperLoopMoveDOM = false;
  }), u && v.forEach((E) => {
    a.slides[E].swiperLoopMoveDOM = true, b.append(a.slides[E]), a.slides[E].swiperLoopMoveDOM = false;
  }), a.recalcSlides(), h.slidesPerView === "auto" && a.updateSlides(), h.watchSlidesProgress && a.updateSlidesOffset(), i) {
    if (S.length > 0 && y)
      if (typeof e > "u") {
        const E = a.slidesGrid[d], g = a.slidesGrid[d + T] - E;
        l ? a.setTranslate(a.translate - g) : (a.slideTo(d + T, 0, false, true), r && (a.touches[a.isHorizontal() ? "startX" : "startY"] += g, a.touchEventsData.currentTranslate = a.translate));
      } else
        r && (a.slideToLoop(e, 0, false, true), a.touchEventsData.currentTranslate = a.translate);
    else if (v.length > 0 && u)
      if (typeof e > "u") {
        const E = a.slidesGrid[d], g = a.slidesGrid[d - C] - E;
        l ? a.setTranslate(a.translate - g) : (a.slideTo(d - C, 0, false, true), r && (a.touches[a.isHorizontal() ? "startX" : "startY"] += g, a.touchEventsData.currentTranslate = a.translate));
      } else
        a.slideToLoop(e, 0, false, true);
  }
  if (a.allowSlidePrev = f, a.allowSlideNext = c, a.controller && a.controller.control && !o) {
    const E = { slideRealIndex: e, direction: s, setTranslate: r, activeSlideIndex: n, byController: true };
    Array.isArray(a.controller.control) ? a.controller.control.forEach((M) => {
      !M.destroyed && M.params.loop && M.loopFix({ ...E, slideTo: M.params.slidesPerView === h.slidesPerView ? i : false });
    }) : a.controller.control instanceof a.constructor && a.controller.control.params.loop && a.controller.control.loopFix({ ...E, slideTo: a.controller.control.params.slidesPerView === h.slidesPerView ? i : false });
  }
  a.emit("loopFix");
}
function Nt() {
  const t = this, { params: e, slidesEl: i } = t;
  if (!e.loop || t.virtual && t.params.virtual.enabled)
    return;
  t.recalcSlides();
  const s = [];
  t.slides.forEach((r) => {
    const n = typeof r.swiperSlideIndex > "u" ? r.getAttribute("data-swiper-slide-index") * 1 : r.swiperSlideIndex;
    s[n] = r;
  }), t.slides.forEach((r) => {
    r.removeAttribute("data-swiper-slide-index");
  }), s.forEach((r) => {
    i.append(r);
  }), t.recalcSlides(), t.slideTo(t.realIndex, 0);
}
var Vt = { loopCreate: Gt, loopFix: _t, loopDestroy: Nt };
function Ft(t) {
  const e = this;
  if (!e.params.simulateTouch || e.params.watchOverflow && e.isLocked || e.params.cssMode)
    return;
  const i = e.params.touchEventsTarget === "container" ? e.el : e.wrapperEl;
  e.isElement && (e.__preventObserver__ = true), i.style.cursor = "move", i.style.cursor = t ? "grabbing" : "grab", e.isElement && requestAnimationFrame(() => {
    e.__preventObserver__ = false;
  });
}
function Rt() {
  const t = this;
  t.params.watchOverflow && t.isLocked || t.params.cssMode || (t.isElement && (t.__preventObserver__ = true), t[t.params.touchEventsTarget === "container" ? "el" : "wrapperEl"].style.cursor = "", t.isElement && requestAnimationFrame(() => {
    t.__preventObserver__ = false;
  }));
}
var kt = { setGrabCursor: Ft, unsetGrabCursor: Rt };
function Ht(t, e) {
  e === void 0 && (e = this);
  function i(s) {
    if (!s || s === j() || s === F())
      return null;
    s.assignedSlot && (s = s.assignedSlot);
    const r = s.closest(t);
    return !r && !s.getRootNode ? null : r || i(s.getRootNode().host);
  }
  return i(e);
}
function jt(t) {
  const e = this, i = j(), s = F(), r = e.touchEventsData;
  r.evCache.push(t);
  const { params: n, touches: o, enabled: l } = e;
  if (!l || !n.simulateTouch && t.pointerType === "mouse" || e.animating && n.preventInteractionOnTransition)
    return;
  !e.animating && n.cssMode && n.loop && e.loopFix();
  let a = t;
  a.originalEvent && (a = a.originalEvent);
  let p = a.target;
  if (n.touchEventsTarget === "wrapper" && !e.wrapperEl.contains(p) || "which" in a && a.which === 3 || "button" in a && a.button > 0 || r.isTouched && r.isMoved)
    return;
  const f = !!n.noSwipingClass && n.noSwipingClass !== "", c = t.composedPath ? t.composedPath() : t.path;
  f && a.target && a.target.shadowRoot && c && (p = c[0]);
  const b = n.noSwipingSelector ? n.noSwipingSelector : ".".concat(n.noSwipingClass), h = !!(a.target && a.target.shadowRoot);
  if (n.noSwiping && (h ? Ht(b, p) : p.closest(b))) {
    e.allowClick = true;
    return;
  }
  if (n.swipeHandler && !p.closest(n.swipeHandler))
    return;
  o.currentX = a.pageX, o.currentY = a.pageY;
  const w = o.currentX, m = o.currentY, S = n.edgeSwipeDetection || n.iOSEdgeSwipeDetection, v = n.edgeSwipeThreshold || n.iOSEdgeSwipeThreshold;
  if (S && (w <= v || w >= s.innerWidth - v))
    if (S === "prevent")
      t.preventDefault();
    else
      return;
  Object.assign(r, { isTouched: true, isMoved: false, allowTouchCallbacks: true, isScrolling: void 0, startMoving: void 0 }), o.startX = w, o.startY = m, r.touchStartTime = U(), e.allowClick = true, e.updateSize(), e.swipeDirection = void 0, n.threshold > 0 && (r.allowThresholdMove = false);
  let d = true;
  p.matches(r.focusableElements) && (d = false, p.nodeName === "SELECT" && (r.isTouched = false)), i.activeElement && i.activeElement.matches(r.focusableElements) && i.activeElement !== p && i.activeElement.blur();
  const u = d && e.allowTouchMove && n.touchStartPreventDefault;
  (n.touchStartForcePreventDefault || u) && !p.isContentEditable && a.preventDefault(), n.freeMode && n.freeMode.enabled && e.freeMode && e.animating && !n.cssMode && e.freeMode.onTouchStart(), e.emit("touchStart", a);
}
function qt(t) {
  const e = j(), i = this, s = i.touchEventsData, { params: r, touches: n, rtlTranslate: o, enabled: l } = i;
  if (!l || !r.simulateTouch && t.pointerType === "mouse")
    return;
  let a = t;
  if (a.originalEvent && (a = a.originalEvent), !s.isTouched) {
    s.startMoving && s.isScrolling && i.emit("touchMoveOpposite", a);
    return;
  }
  const p = s.evCache.findIndex((E) => E.pointerId === a.pointerId);
  p >= 0 && (s.evCache[p] = a);
  const f = s.evCache.length > 1 ? s.evCache[0] : a, c = f.pageX, b = f.pageY;
  if (a.preventedByNestedSwiper) {
    n.startX = c, n.startY = b;
    return;
  }
  if (!i.allowTouchMove) {
    a.target.matches(s.focusableElements) || (i.allowClick = false), s.isTouched && (Object.assign(n, { startX: c, startY: b, prevX: i.touches.currentX, prevY: i.touches.currentY, currentX: c, currentY: b }), s.touchStartTime = U());
    return;
  }
  if (r.touchReleaseOnEdges && !r.loop) {
    if (i.isVertical()) {
      if (b < n.startY && i.translate <= i.maxTranslate() || b > n.startY && i.translate >= i.minTranslate()) {
        s.isTouched = false, s.isMoved = false;
        return;
      }
    } else if (c < n.startX && i.translate <= i.maxTranslate() || c > n.startX && i.translate >= i.minTranslate())
      return;
  }
  if (e.activeElement && a.target === e.activeElement && a.target.matches(s.focusableElements)) {
    s.isMoved = true, i.allowClick = false;
    return;
  }
  if (s.allowTouchCallbacks && i.emit("touchMove", a), a.targetTouches && a.targetTouches.length > 1)
    return;
  n.currentX = c, n.currentY = b;
  const h = n.currentX - n.startX, w = n.currentY - n.startY;
  if (i.params.threshold && Math.sqrt(h ** 2 + w ** 2) < i.params.threshold)
    return;
  if (typeof s.isScrolling > "u") {
    let E;
    i.isHorizontal() && n.currentY === n.startY || i.isVertical() && n.currentX === n.startX ? s.isScrolling = false : h * h + w * w >= 25 && (E = Math.atan2(Math.abs(w), Math.abs(h)) * 180 / Math.PI, s.isScrolling = i.isHorizontal() ? E > r.touchAngle : 90 - E > r.touchAngle);
  }
  if (s.isScrolling && i.emit("touchMoveOpposite", a), typeof s.startMoving > "u" && (n.currentX !== n.startX || n.currentY !== n.startY) && (s.startMoving = true), s.isScrolling || i.zoom && i.params.zoom && i.params.zoom.enabled && s.evCache.length > 1) {
    s.isTouched = false;
    return;
  }
  if (!s.startMoving)
    return;
  i.allowClick = false, !r.cssMode && a.cancelable && a.preventDefault(), r.touchMoveStopPropagation && !r.nested && a.stopPropagation();
  let m = i.isHorizontal() ? h : w, S = i.isHorizontal() ? n.currentX - n.previousX : n.currentY - n.previousY;
  r.oneWayMovement && (m = Math.abs(m) * (o ? 1 : -1), S = Math.abs(S) * (o ? 1 : -1)), n.diff = m, m *= r.touchRatio, o && (m = -m, S = -S);
  const v = i.touchesDirection;
  i.swipeDirection = m > 0 ? "prev" : "next", i.touchesDirection = S > 0 ? "prev" : "next";
  const d = i.params.loop && !r.cssMode, u = i.swipeDirection === "next" && i.allowSlideNext || i.swipeDirection === "prev" && i.allowSlidePrev;
  if (!s.isMoved) {
    if (d && u && i.loopFix({ direction: i.swipeDirection }), s.startTranslate = i.getTranslate(), i.setTransition(0), i.animating) {
      const E = new window.CustomEvent("transitionend", { bubbles: true, cancelable: true });
      i.wrapperEl.dispatchEvent(E);
    }
    s.allowMomentumBounce = false, r.grabCursor && (i.allowSlideNext === true || i.allowSlidePrev === true) && i.setGrabCursor(true), i.emit("sliderFirstMove", a);
  }
  let y;
  s.isMoved && v !== i.touchesDirection && d && u && Math.abs(m) >= 1 && (i.loopFix({ direction: i.swipeDirection, setTranslate: true }), y = true), i.emit("sliderMove", a), s.isMoved = true, s.currentTranslate = m + s.startTranslate;
  let T = true, C = r.resistanceRatio;
  if (r.touchReleaseOnEdges && (C = 0), m > 0 ? (d && u && !y && s.currentTranslate > (r.centeredSlides ? i.minTranslate() - i.size / 2 : i.minTranslate()) && i.loopFix({ direction: "prev", setTranslate: true, activeSlideIndex: 0 }), s.currentTranslate > i.minTranslate() && (T = false, r.resistance && (s.currentTranslate = i.minTranslate() - 1 + (-i.minTranslate() + s.startTranslate + m) ** C))) : m < 0 && (d && u && !y && s.currentTranslate < (r.centeredSlides ? i.maxTranslate() + i.size / 2 : i.maxTranslate()) && i.loopFix({ direction: "next", setTranslate: true, activeSlideIndex: i.slides.length - (r.slidesPerView === "auto" ? i.slidesPerViewDynamic() : Math.ceil(parseFloat(r.slidesPerView, 10))) }), s.currentTranslate < i.maxTranslate() && (T = false, r.resistance && (s.currentTranslate = i.maxTranslate() + 1 - (i.maxTranslate() - s.startTranslate - m) ** C))), T && (a.preventedByNestedSwiper = true), !i.allowSlideNext && i.swipeDirection === "next" && s.currentTranslate < s.startTranslate && (s.currentTranslate = s.startTranslate), !i.allowSlidePrev && i.swipeDirection === "prev" && s.currentTranslate > s.startTranslate && (s.currentTranslate = s.startTranslate), !i.allowSlidePrev && !i.allowSlideNext && (s.currentTranslate = s.startTranslate), r.threshold > 0)
    if (Math.abs(m) > r.threshold || s.allowThresholdMove) {
      if (!s.allowThresholdMove) {
        s.allowThresholdMove = true, n.startX = n.currentX, n.startY = n.currentY, s.currentTranslate = s.startTranslate, n.diff = i.isHorizontal() ? n.currentX - n.startX : n.currentY - n.startY;
        return;
      }
    } else {
      s.currentTranslate = s.startTranslate;
      return;
    }
  !r.followFinger || r.cssMode || ((r.freeMode && r.freeMode.enabled && i.freeMode || r.watchSlidesProgress) && (i.updateActiveIndex(), i.updateSlidesClasses()), r.freeMode && r.freeMode.enabled && i.freeMode && i.freeMode.onTouchMove(), i.updateProgress(s.currentTranslate), i.setTranslate(s.currentTranslate));
}
function Wt(t) {
  const e = this, i = e.touchEventsData, s = i.evCache.findIndex((u) => u.pointerId === t.pointerId);
  if (s >= 0 && i.evCache.splice(s, 1), ["pointercancel", "pointerout", "pointerleave", "contextmenu"].includes(t.type) && !(["pointercancel", "contextmenu"].includes(t.type) && (e.browser.isSafari || e.browser.isWebView)))
    return;
  const { params: r, touches: n, rtlTranslate: o, slidesGrid: l, enabled: a } = e;
  if (!a || !r.simulateTouch && t.pointerType === "mouse")
    return;
  let p = t;
  if (p.originalEvent && (p = p.originalEvent), i.allowTouchCallbacks && e.emit("touchEnd", p), i.allowTouchCallbacks = false, !i.isTouched) {
    i.isMoved && r.grabCursor && e.setGrabCursor(false), i.isMoved = false, i.startMoving = false;
    return;
  }
  r.grabCursor && i.isMoved && i.isTouched && (e.allowSlideNext === true || e.allowSlidePrev === true) && e.setGrabCursor(false);
  const f = U(), c = f - i.touchStartTime;
  if (e.allowClick) {
    const u = p.path || p.composedPath && p.composedPath();
    e.updateClickedSlide(u && u[0] || p.target, u), e.emit("tap click", p), c < 300 && f - i.lastClickTime < 300 && e.emit("doubleTap doubleClick", p);
  }
  if (i.lastClickTime = U(), pe(() => {
    e.destroyed || (e.allowClick = true);
  }), !i.isTouched || !i.isMoved || !e.swipeDirection || n.diff === 0 || i.currentTranslate === i.startTranslate) {
    i.isTouched = false, i.isMoved = false, i.startMoving = false;
    return;
  }
  i.isTouched = false, i.isMoved = false, i.startMoving = false;
  let b;
  if (r.followFinger ? b = o ? e.translate : -e.translate : b = -i.currentTranslate, r.cssMode)
    return;
  if (r.freeMode && r.freeMode.enabled) {
    e.freeMode.onTouchEnd({ currentPos: b });
    return;
  }
  let h = 0, w = e.slidesSizesGrid[0];
  for (let u = 0; u < l.length; u += u < r.slidesPerGroupSkip ? 1 : r.slidesPerGroup) {
    const y = u < r.slidesPerGroupSkip - 1 ? 1 : r.slidesPerGroup;
    typeof l[u + y] < "u" ? b >= l[u] && b < l[u + y] && (h = u, w = l[u + y] - l[u]) : b >= l[u] && (h = u, w = l[l.length - 1] - l[l.length - 2]);
  }
  let m = null, S = null;
  r.rewind && (e.isBeginning ? S = r.virtual && r.virtual.enabled && e.virtual ? e.virtual.slides.length - 1 : e.slides.length - 1 : e.isEnd && (m = 0));
  const v = (b - l[h]) / w, d = h < r.slidesPerGroupSkip - 1 ? 1 : r.slidesPerGroup;
  if (c > r.longSwipesMs) {
    if (!r.longSwipes) {
      e.slideTo(e.activeIndex);
      return;
    }
    e.swipeDirection === "next" && (v >= r.longSwipesRatio ? e.slideTo(r.rewind && e.isEnd ? m : h + d) : e.slideTo(h)), e.swipeDirection === "prev" && (v > 1 - r.longSwipesRatio ? e.slideTo(h + d) : S !== null && v < 0 && Math.abs(v) > r.longSwipesRatio ? e.slideTo(S) : e.slideTo(h));
  } else {
    if (!r.shortSwipes) {
      e.slideTo(e.activeIndex);
      return;
    }
    e.navigation && (p.target === e.navigation.nextEl || p.target === e.navigation.prevEl) ? p.target === e.navigation.nextEl ? e.slideTo(h + d) : e.slideTo(h) : (e.swipeDirection === "next" && e.slideTo(m !== null ? m : h + d), e.swipeDirection === "prev" && e.slideTo(S !== null ? S : h));
  }
}
function be() {
  const t = this, { params: e, el: i } = t;
  if (i && i.offsetWidth === 0)
    return;
  e.breakpoints && t.setBreakpoint();
  const { allowSlideNext: s, allowSlidePrev: r, snapGrid: n } = t, o = t.virtual && t.params.virtual.enabled;
  t.allowSlideNext = true, t.allowSlidePrev = true, t.updateSize(), t.updateSlides(), t.updateSlidesClasses();
  const l = o && e.loop;
  (e.slidesPerView === "auto" || e.slidesPerView > 1) && t.isEnd && !t.isBeginning && !t.params.centeredSlides && !l ? t.slideTo(t.slides.length - 1, 0, false, true) : t.params.loop && !o ? t.slideToLoop(t.realIndex, 0, false, true) : t.slideTo(t.activeIndex, 0, false, true), t.autoplay && t.autoplay.running && t.autoplay.paused && (clearTimeout(t.autoplay.resizeTimeout), t.autoplay.resizeTimeout = setTimeout(() => {
    t.autoplay && t.autoplay.running && t.autoplay.paused && t.autoplay.resume();
  }, 500)), t.allowSlidePrev = r, t.allowSlideNext = s, t.params.watchOverflow && n !== t.snapGrid && t.checkOverflow();
}
function Xt(t) {
  const e = this;
  e.enabled && (e.allowClick || (e.params.preventClicks && t.preventDefault(), e.params.preventClicksPropagation && e.animating && (t.stopPropagation(), t.stopImmediatePropagation())));
}
function Yt() {
  const t = this, { wrapperEl: e, rtlTranslate: i, enabled: s } = t;
  if (!s)
    return;
  t.previousTranslate = t.translate, t.isHorizontal() ? t.translate = -e.scrollLeft : t.translate = -e.scrollTop, t.translate === 0 && (t.translate = 0), t.updateActiveIndex(), t.updateSlidesClasses();
  let r;
  const n = t.maxTranslate() - t.minTranslate();
  n === 0 ? r = 0 : r = (t.translate - t.minTranslate()) / n, r !== t.progress && t.updateProgress(i ? -t.translate : t.translate), t.emit("setTranslate", t.translate, false);
}
function Ut(t) {
  const e = this;
  ie(e, t.target), !(e.params.cssMode || e.params.slidesPerView !== "auto" && !e.params.autoHeight) && e.update();
}
let Te = false;
function Kt() {
}
const $e = (t, e) => {
  const i = j(), { params: s, el: r, wrapperEl: n, device: o } = t, l = !!s.nested, a = e === "on" ? "addEventListener" : "removeEventListener", p = e;
  r[a]("pointerdown", t.onTouchStart, { passive: false }), i[a]("pointermove", t.onTouchMove, { passive: false, capture: l }), i[a]("pointerup", t.onTouchEnd, { passive: true }), i[a]("pointercancel", t.onTouchEnd, { passive: true }), i[a]("pointerout", t.onTouchEnd, { passive: true }), i[a]("pointerleave", t.onTouchEnd, { passive: true }), i[a]("contextmenu", t.onTouchEnd, { passive: true }), (s.preventClicks || s.preventClicksPropagation) && r[a]("click", t.onClick, true), s.cssMode && n[a]("scroll", t.onScroll), s.updateOnWindowResize ? t[p](o.ios || o.android ? "resize orientationchange observerUpdate" : "resize observerUpdate", be, true) : t[p]("observerUpdate", be, true), r[a]("load", t.onLoad, { capture: true });
};
function Zt() {
  const t = this, e = j(), { params: i } = t;
  t.onTouchStart = jt.bind(t), t.onTouchMove = qt.bind(t), t.onTouchEnd = Wt.bind(t), i.cssMode && (t.onScroll = Yt.bind(t)), t.onClick = Xt.bind(t), t.onLoad = Ut.bind(t), Te || (e.addEventListener("touchstart", Kt), Te = true), $e(t, "on");
}
function Jt() {
  $e(this, "off");
}
var Qt = { attachEvents: Zt, detachEvents: Jt };
const xe = (t, e) => t.grid && e.grid && e.grid.rows > 1;
function ei() {
  const t = this, { realIndex: e, initialized: i, params: s, el: r } = t, n = s.breakpoints;
  if (!n || n && Object.keys(n).length === 0)
    return;
  const o = t.getBreakpoint(n, t.params.breakpointsBase, t.el);
  if (!o || t.currentBreakpoint === o)
    return;
  const a = (o in n ? n[o] : void 0) || t.originalParams, p = xe(t, s), f = xe(t, a), c = s.enabled;
  p && !f ? (r.classList.remove("".concat(s.containerModifierClass, "grid"), "".concat(s.containerModifierClass, "grid-column")), t.emitContainerClasses()) : !p && f && (r.classList.add("".concat(s.containerModifierClass, "grid")), (a.grid.fill && a.grid.fill === "column" || !a.grid.fill && s.grid.fill === "column") && r.classList.add("".concat(s.containerModifierClass, "grid-column")), t.emitContainerClasses()), ["navigation", "pagination", "scrollbar"].forEach((v) => {
    if (typeof a[v] > "u")
      return;
    const d = s[v] && s[v].enabled, u = a[v] && a[v].enabled;
    d && !u && t[v].disable(), !d && u && t[v].enable();
  });
  const b = a.direction && a.direction !== s.direction, h = s.loop && (a.slidesPerView !== s.slidesPerView || b), w = s.loop;
  b && i && t.changeDirection(), V(t.params, a);
  const m = t.params.enabled, S = t.params.loop;
  Object.assign(t, { allowTouchMove: t.params.allowTouchMove, allowSlideNext: t.params.allowSlideNext, allowSlidePrev: t.params.allowSlidePrev }), c && !m ? t.disable() : !c && m && t.enable(), t.currentBreakpoint = o, t.emit("_beforeBreakpoint", a), i && (h ? (t.loopDestroy(), t.loopCreate(e), t.updateSlides()) : !w && S ? (t.loopCreate(e), t.updateSlides()) : w && !S && t.loopDestroy()), t.emit("breakpoint", a);
}
function ti(t, e, i) {
  if (e === void 0 && (e = "window"), !t || e === "container" && !i)
    return;
  let s = false;
  const r = F(), n = e === "window" ? r.innerHeight : i.clientHeight, o = Object.keys(t).map((l) => {
    if (typeof l == "string" && l.indexOf("@") === 0) {
      const a = parseFloat(l.substr(1));
      return { value: n * a, point: l };
    }
    return { value: l, point: l };
  });
  o.sort((l, a) => parseInt(l.value, 10) - parseInt(a.value, 10));
  for (let l = 0; l < o.length; l += 1) {
    const { point: a, value: p } = o[l];
    e === "window" ? r.matchMedia("(min-width: ".concat(p, "px)")).matches && (s = a) : p <= i.clientWidth && (s = a);
  }
  return s || "max";
}
var ii = { setBreakpoint: ei, getBreakpoint: ti };
function si(t, e) {
  const i = [];
  return t.forEach((s) => {
    typeof s == "object" ? Object.keys(s).forEach((r) => {
      s[r] && i.push(e + r);
    }) : typeof s == "string" && i.push(e + s);
  }), i;
}
function ni() {
  const t = this, { classNames: e, params: i, rtl: s, el: r, device: n } = t, o = si(["initialized", i.direction, { "free-mode": t.params.freeMode && i.freeMode.enabled }, { autoheight: i.autoHeight }, { rtl: s }, { grid: i.grid && i.grid.rows > 1 }, { "grid-column": i.grid && i.grid.rows > 1 && i.grid.fill === "column" }, { android: n.android }, { ios: n.ios }, { "css-mode": i.cssMode }, { centered: i.cssMode && i.centeredSlides }, { "watch-progress": i.watchSlidesProgress }], i.containerModifierClass);
  e.push(...o), r.classList.add(...e), t.emitContainerClasses();
}
function ri() {
  const t = this, { el: e, classNames: i } = t;
  e.classList.remove(...i), t.emitContainerClasses();
}
var ai = { addClasses: ni, removeClasses: ri };
function li() {
  const t = this, { isLocked: e, params: i } = t, { slidesOffsetBefore: s } = i;
  if (s) {
    const r = t.slides.length - 1, n = t.slidesGrid[r] + t.slidesSizesGrid[r] + s * 2;
    t.isLocked = t.size > n;
  } else
    t.isLocked = t.snapGrid.length === 1;
  i.allowSlideNext === true && (t.allowSlideNext = !t.isLocked), i.allowSlidePrev === true && (t.allowSlidePrev = !t.isLocked), e && e !== t.isLocked && (t.isEnd = false), e !== t.isLocked && t.emit(t.isLocked ? "lock" : "unlock");
}
var oi = { checkOverflow: li }, ve = { init: true, direction: "horizontal", oneWayMovement: false, touchEventsTarget: "wrapper", initialSlide: 0, speed: 300, cssMode: false, updateOnWindowResize: true, resizeObserver: true, nested: false, createElements: false, enabled: true, focusableElements: "input, select, option, textarea, button, video, label", width: null, height: null, preventInteractionOnTransition: false, userAgent: null, url: null, edgeSwipeDetection: false, edgeSwipeThreshold: 20, autoHeight: false, setWrapperSize: false, virtualTranslate: false, effect: "slide", breakpoints: void 0, breakpointsBase: "window", spaceBetween: 0, slidesPerView: 1, slidesPerGroup: 1, slidesPerGroupSkip: 0, slidesPerGroupAuto: false, centeredSlides: false, centeredSlidesBounds: false, slidesOffsetBefore: 0, slidesOffsetAfter: 0, normalizeSlideIndex: true, centerInsufficientSlides: false, watchOverflow: true, roundLengths: false, touchRatio: 1, touchAngle: 45, simulateTouch: true, shortSwipes: true, longSwipes: true, longSwipesRatio: 0.5, longSwipesMs: 300, followFinger: true, allowTouchMove: true, threshold: 5, touchMoveStopPropagation: false, touchStartPreventDefault: true, touchStartForcePreventDefault: false, touchReleaseOnEdges: false, uniqueNavElements: true, resistance: true, resistanceRatio: 0.85, watchSlidesProgress: false, grabCursor: false, preventClicks: true, preventClicksPropagation: true, slideToClickedSlide: false, loop: false, loopedSlides: null, loopPreventsSliding: true, rewind: false, allowSlidePrev: true, allowSlideNext: true, swipeHandler: null, noSwiping: true, noSwipingClass: "swiper-no-swiping", noSwipingSelector: null, passiveListeners: true, maxBackfaceHiddenSlides: 10, containerModifierClass: "swiper-", slideClass: "swiper-slide", slideActiveClass: "swiper-slide-active", slideVisibleClass: "swiper-slide-visible", slideNextClass: "swiper-slide-next", slidePrevClass: "swiper-slide-prev", wrapperClass: "swiper-wrapper", lazyPreloaderClass: "swiper-lazy-preloader", lazyPreloadPrevNext: 0, runCallbacksOnInit: true, _emitClasses: false };
function di(t, e) {
  return function(s) {
    s === void 0 && (s = {});
    const r = Object.keys(s)[0], n = s[r];
    if (typeof n != "object" || n === null) {
      V(e, s);
      return;
    }
    if (t[r] === true && (t[r] = { enabled: true }), r === "navigation" && t[r] && t[r].enabled && !t[r].prevEl && !t[r].nextEl && (t[r].auto = true), ["pagination", "scrollbar"].indexOf(r) >= 0 && t[r] && t[r].enabled && !t[r].el && (t[r].auto = true), !(r in t && "enabled" in n)) {
      V(e, s);
      return;
    }
    typeof t[r] == "object" && !("enabled" in t[r]) && (t[r].enabled = true), t[r] || (t[r] = { enabled: false }), V(e, s);
  };
}
const fe = { eventsEmitter: at, update: gt, translate: xt, transition: Pt, slide: $t, loop: Vt, grabCursor: kt, events: Qt, breakpoints: ii, checkOverflow: oi, classes: ai }, ue = {};
let Se = class q {
  constructor() {
    let e, i;
    for (var s = arguments.length, r = new Array(s), n = 0; n < s; n++)
      r[n] = arguments[n];
    r.length === 1 && r[0].constructor && Object.prototype.toString.call(r[0]).slice(8, -1) === "Object" ? i = r[0] : [e, i] = r, i || (i = {}), i = V({}, i), e && !i.el && (i.el = e);
    const o = j();
    if (i.el && typeof i.el == "string" && o.querySelectorAll(i.el).length > 1) {
      const f = [];
      return o.querySelectorAll(i.el).forEach((c) => {
        const b = V({}, i, { el: c });
        f.push(new q(b));
      }), f;
    }
    const l = this;
    l.__swiper__ = true, l.support = Be(), l.device = tt({ userAgent: i.userAgent }), l.browser = st(), l.eventsListeners = {}, l.eventsAnyListeners = [], l.modules = [...l.__modules__], i.modules && Array.isArray(i.modules) && l.modules.push(...i.modules);
    const a = {};
    l.modules.forEach((f) => {
      f({ params: i, swiper: l, extendParams: di(i, a), on: l.on.bind(l), once: l.once.bind(l), off: l.off.bind(l), emit: l.emit.bind(l) });
    });
    const p = V({}, ve, a);
    return l.params = V({}, p, ue, i), l.originalParams = V({}, l.params), l.passedParams = V({}, i), l.params && l.params.on && Object.keys(l.params.on).forEach((f) => {
      l.on(f, l.params.on[f]);
    }), l.params && l.params.onAny && l.onAny(l.params.onAny), Object.assign(l, { enabled: l.params.enabled, el: e, classNames: [], slides: [], slidesGrid: [], snapGrid: [], slidesSizesGrid: [], isHorizontal() {
      return l.params.direction === "horizontal";
    }, isVertical() {
      return l.params.direction === "vertical";
    }, activeIndex: 0, realIndex: 0, isBeginning: true, isEnd: false, translate: 0, previousTranslate: 0, progress: 0, velocity: 0, animating: false, cssOverflowAdjustment() {
      return Math.trunc(this.translate / 2 ** 23) * 2 ** 23;
    }, allowSlideNext: l.params.allowSlideNext, allowSlidePrev: l.params.allowSlidePrev, touchEventsData: { isTouched: void 0, isMoved: void 0, allowTouchCallbacks: void 0, touchStartTime: void 0, isScrolling: void 0, currentTranslate: void 0, startTranslate: void 0, allowThresholdMove: void 0, focusableElements: l.params.focusableElements, lastClickTime: 0, clickTimeout: void 0, velocities: [], allowMomentumBounce: void 0, startMoving: void 0, evCache: [] }, allowClick: true, allowTouchMove: l.params.allowTouchMove, touches: { startX: 0, startY: 0, currentX: 0, currentY: 0, diff: 0 }, imagesToLoad: [], imagesLoaded: 0 }), l.emit("_swiper"), l.params.init && l.init(), l;
  }
  getSlideIndex(e) {
    const { slidesEl: i, params: s } = this, r = H(i, ".".concat(s.slideClass, ", swiper-slide")), n = se(r[0]);
    return se(e) - n;
  }
  getSlideIndexByData(e) {
    return this.getSlideIndex(this.slides.filter((i) => i.getAttribute("data-swiper-slide-index") * 1 === e)[0]);
  }
  recalcSlides() {
    const e = this, { slidesEl: i, params: s } = e;
    e.slides = H(i, ".".concat(s.slideClass, ", swiper-slide"));
  }
  enable() {
    const e = this;
    e.enabled || (e.enabled = true, e.params.grabCursor && e.setGrabCursor(), e.emit("enable"));
  }
  disable() {
    const e = this;
    e.enabled && (e.enabled = false, e.params.grabCursor && e.unsetGrabCursor(), e.emit("disable"));
  }
  setProgress(e, i) {
    const s = this;
    e = Math.min(Math.max(e, 0), 1);
    const r = s.minTranslate(), o = (s.maxTranslate() - r) * e + r;
    s.translateTo(o, typeof i > "u" ? 0 : i), s.updateActiveIndex(), s.updateSlidesClasses();
  }
  emitContainerClasses() {
    const e = this;
    if (!e.params._emitClasses || !e.el)
      return;
    const i = e.el.className.split(" ").filter((s) => s.indexOf("swiper") === 0 || s.indexOf(e.params.containerModifierClass) === 0);
    e.emit("_containerClasses", i.join(" "));
  }
  getSlideClasses(e) {
    const i = this;
    return i.destroyed ? "" : e.className.split(" ").filter((s) => s.indexOf("swiper-slide") === 0 || s.indexOf(i.params.slideClass) === 0).join(" ");
  }
  emitSlidesClasses() {
    const e = this;
    if (!e.params._emitClasses || !e.el)
      return;
    const i = [];
    e.slides.forEach((s) => {
      const r = e.getSlideClasses(s);
      i.push({ slideEl: s, classNames: r }), e.emit("_slideClass", s, r);
    }), e.emit("_slideClasses", i);
  }
  slidesPerViewDynamic(e, i) {
    e === void 0 && (e = "current"), i === void 0 && (i = false);
    const s = this, { params: r, slides: n, slidesGrid: o, slidesSizesGrid: l, size: a, activeIndex: p } = s;
    let f = 1;
    if (typeof r.slidesPerView == "number")
      return r.slidesPerView;
    if (r.centeredSlides) {
      let c = n[p] ? n[p].swiperSlideSize : 0, b;
      for (let h = p + 1; h < n.length; h += 1)
        n[h] && !b && (c += n[h].swiperSlideSize, f += 1, c > a && (b = true));
      for (let h = p - 1; h >= 0; h -= 1)
        n[h] && !b && (c += n[h].swiperSlideSize, f += 1, c > a && (b = true));
    } else if (e === "current")
      for (let c = p + 1; c < n.length; c += 1)
        (i ? o[c] + l[c] - o[p] < a : o[c] - o[p] < a) && (f += 1);
    else
      for (let c = p - 1; c >= 0; c -= 1)
        o[p] - o[c] < a && (f += 1);
    return f;
  }
  update() {
    const e = this;
    if (!e || e.destroyed)
      return;
    const { snapGrid: i, params: s } = e;
    s.breakpoints && e.setBreakpoint(), [...e.el.querySelectorAll('[loading="lazy"]')].forEach((o) => {
      o.complete && ie(e, o);
    }), e.updateSize(), e.updateSlides(), e.updateProgress(), e.updateSlidesClasses();
    function r() {
      const o = e.rtlTranslate ? e.translate * -1 : e.translate, l = Math.min(Math.max(o, e.maxTranslate()), e.minTranslate());
      e.setTranslate(l), e.updateActiveIndex(), e.updateSlidesClasses();
    }
    let n;
    if (s.freeMode && s.freeMode.enabled && !s.cssMode)
      r(), s.autoHeight && e.updateAutoHeight();
    else {
      if ((s.slidesPerView === "auto" || s.slidesPerView > 1) && e.isEnd && !s.centeredSlides) {
        const o = e.virtual && s.virtual.enabled ? e.virtual.slides : e.slides;
        n = e.slideTo(o.length - 1, 0, false, true);
      } else
        n = e.slideTo(e.activeIndex, 0, false, true);
      n || r();
    }
    s.watchOverflow && i !== e.snapGrid && e.checkOverflow(), e.emit("update");
  }
  changeDirection(e, i) {
    i === void 0 && (i = true);
    const s = this, r = s.params.direction;
    return e || (e = r === "horizontal" ? "vertical" : "horizontal"), e === r || e !== "horizontal" && e !== "vertical" || (s.el.classList.remove("".concat(s.params.containerModifierClass).concat(r)), s.el.classList.add("".concat(s.params.containerModifierClass).concat(e)), s.emitContainerClasses(), s.params.direction = e, s.slides.forEach((n) => {
      e === "vertical" ? n.style.width = "" : n.style.height = "";
    }), s.emit("changeDirection"), i && s.update()), s;
  }
  changeLanguageDirection(e) {
    const i = this;
    i.rtl && e === "rtl" || !i.rtl && e === "ltr" || (i.rtl = e === "rtl", i.rtlTranslate = i.params.direction === "horizontal" && i.rtl, i.rtl ? (i.el.classList.add("".concat(i.params.containerModifierClass, "rtl")), i.el.dir = "rtl") : (i.el.classList.remove("".concat(i.params.containerModifierClass, "rtl")), i.el.dir = "ltr"), i.update());
  }
  mount(e) {
    const i = this;
    if (i.mounted)
      return true;
    let s = e || i.params.el;
    if (typeof s == "string" && (s = document.querySelector(s)), !s)
      return false;
    s.swiper = i, s.parentNode && s.parentNode.host && s.parentNode.host.nodeName === "SWIPER-CONTAINER" && (i.isElement = true);
    const r = () => ".".concat((i.params.wrapperClass || "").trim().split(" ").join("."));
    let o = (() => s && s.shadowRoot && s.shadowRoot.querySelector ? s.shadowRoot.querySelector(r()) : H(s, r())[0])();
    return !o && i.params.createElements && (o = ee("div", i.params.wrapperClass), s.append(o), H(s, ".".concat(i.params.slideClass)).forEach((l) => {
      o.append(l);
    })), Object.assign(i, { el: s, wrapperEl: o, slidesEl: i.isElement && !s.parentNode.host.slideSlots ? s.parentNode.host : o, hostEl: i.isElement ? s.parentNode.host : s, mounted: true, rtl: s.dir.toLowerCase() === "rtl" || W(s, "direction") === "rtl", rtlTranslate: i.params.direction === "horizontal" && (s.dir.toLowerCase() === "rtl" || W(s, "direction") === "rtl"), wrongRTL: W(o, "display") === "-webkit-box" }), true;
  }
  init(e) {
    const i = this;
    if (i.initialized || i.mount(e) === false)
      return i;
    i.emit("beforeInit"), i.params.breakpoints && i.setBreakpoint(), i.addClasses(), i.updateSize(), i.updateSlides(), i.params.watchOverflow && i.checkOverflow(), i.params.grabCursor && i.enabled && i.setGrabCursor(), i.params.loop && i.virtual && i.params.virtual.enabled ? i.slideTo(i.params.initialSlide + i.virtual.slidesBefore, 0, i.params.runCallbacksOnInit, false, true) : i.slideTo(i.params.initialSlide, 0, i.params.runCallbacksOnInit, false, true), i.params.loop && i.loopCreate(), i.attachEvents();
    const r = [...i.el.querySelectorAll('[loading="lazy"]')];
    return i.isElement && r.push(...i.hostEl.querySelectorAll('[loading="lazy"]')), r.forEach((n) => {
      n.complete ? ie(i, n) : n.addEventListener("load", (o) => {
        ie(i, o.target);
      });
    }), he(i), i.initialized = true, he(i), i.emit("init"), i.emit("afterInit"), i;
  }
  destroy(e, i) {
    e === void 0 && (e = true), i === void 0 && (i = true);
    const s = this, { params: r, el: n, wrapperEl: o, slides: l } = s;
    return typeof s.params > "u" || s.destroyed || (s.emit("beforeDestroy"), s.initialized = false, s.detachEvents(), r.loop && s.loopDestroy(), i && (s.removeClasses(), n.removeAttribute("style"), o.removeAttribute("style"), l && l.length && l.forEach((a) => {
      a.classList.remove(r.slideVisibleClass, r.slideActiveClass, r.slideNextClass, r.slidePrevClass), a.removeAttribute("style"), a.removeAttribute("data-swiper-slide-index");
    })), s.emit("destroy"), Object.keys(s.eventsListeners).forEach((a) => {
      s.off(a);
    }), e !== false && (s.el.swiper = null, Xe(s)), s.destroyed = true), null;
  }
  static extendDefaults(e) {
    V(ue, e);
  }
  static get extendedDefaults() {
    return ue;
  }
  static get defaults() {
    return ve;
  }
  static installModule(e) {
    q.prototype.__modules__ || (q.prototype.__modules__ = []);
    const i = q.prototype.__modules__;
    typeof e == "function" && i.indexOf(e) < 0 && i.push(e);
  }
  static use(e) {
    return Array.isArray(e) ? (e.forEach((i) => q.installModule(i)), q) : (q.installModule(e), q);
  }
};
Object.keys(fe).forEach((t) => {
  Object.keys(fe[t]).forEach((e) => {
    Se.prototype[e] = fe[t][e];
  });
});
Se.use([nt, rt]);
const Ge = ["eventsPrefix", "injectStyles", "injectStylesUrls", "modules", "init", "_direction", "oneWayMovement", "touchEventsTarget", "initialSlide", "_speed", "cssMode", "updateOnWindowResize", "resizeObserver", "nested", "focusableElements", "_enabled", "_width", "_height", "preventInteractionOnTransition", "userAgent", "url", "_edgeSwipeDetection", "_edgeSwipeThreshold", "_freeMode", "_autoHeight", "setWrapperSize", "virtualTranslate", "_effect", "breakpoints", "breakpointsBase", "_spaceBetween", "_slidesPerView", "maxBackfaceHiddenSlides", "_grid", "_slidesPerGroup", "_slidesPerGroupSkip", "_slidesPerGroupAuto", "_centeredSlides", "_centeredSlidesBounds", "_slidesOffsetBefore", "_slidesOffsetAfter", "normalizeSlideIndex", "_centerInsufficientSlides", "_watchOverflow", "roundLengths", "touchRatio", "touchAngle", "simulateTouch", "_shortSwipes", "_longSwipes", "longSwipesRatio", "longSwipesMs", "_followFinger", "allowTouchMove", "_threshold", "touchMoveStopPropagation", "touchStartPreventDefault", "touchStartForcePreventDefault", "touchReleaseOnEdges", "uniqueNavElements", "_resistance", "_resistanceRatio", "_watchSlidesProgress", "_grabCursor", "preventClicks", "preventClicksPropagation", "_slideToClickedSlide", "_loop", "loopedSlides", "loopPreventsSliding", "_rewind", "_allowSlidePrev", "_allowSlideNext", "_swipeHandler", "_noSwiping", "noSwipingClass", "noSwipingSelector", "passiveListeners", "containerModifierClass", "slideClass", "slideActiveClass", "slideVisibleClass", "slideNextClass", "slidePrevClass", "wrapperClass", "lazyPreloaderClass", "lazyPreloadPrevNext", "runCallbacksOnInit", "observer", "observeParents", "observeSlideChildren", "a11y", "_autoplay", "_controller", "coverflowEffect", "cubeEffect", "fadeEffect", "flipEffect", "creativeEffect", "cardsEffect", "hashNavigation", "history", "keyboard", "mousewheel", "_navigation", "_pagination", "parallax", "_scrollbar", "_thumbs", "virtual", "zoom", "control"];
function Z(t) {
  return typeof t == "object" && t !== null && t.constructor && Object.prototype.toString.call(t).slice(8, -1) === "Object" && !t.__swiper__;
}
function K(t, e) {
  const i = ["__proto__", "constructor", "prototype"];
  Object.keys(e).filter((s) => i.indexOf(s) < 0).forEach((s) => {
    typeof t[s] > "u" ? t[s] = e[s] : Z(e[s]) && Z(t[s]) && Object.keys(e[s]).length > 0 ? e[s].__swiper__ ? t[s] = e[s] : K(t[s], e[s]) : t[s] = e[s];
  });
}
function _e(t) {
  return t === void 0 && (t = {}), t.navigation && typeof t.navigation.nextEl > "u" && typeof t.navigation.prevEl > "u";
}
function Ne(t) {
  return t === void 0 && (t = {}), t.pagination && typeof t.pagination.el > "u";
}
function Ve(t) {
  return t === void 0 && (t = {}), t.scrollbar && typeof t.scrollbar.el > "u";
}
function Fe(t) {
  t === void 0 && (t = "");
  const e = t.split(" ").map((s) => s.trim()).filter((s) => !!s), i = [];
  return e.forEach((s) => {
    i.indexOf(s) < 0 && i.push(s);
  }), i.join(" ");
}
function fi(t) {
  return t === void 0 && (t = ""), t ? t.includes("swiper-wrapper") ? t : "swiper-wrapper ".concat(t) : "swiper-wrapper";
}
function ui(t) {
  let { swiper: e, slides: i, passedParams: s, changedParams: r, nextEl: n, prevEl: o, scrollbarEl: l, paginationEl: a } = t;
  const p = r.filter((g) => g !== "children" && g !== "direction" && g !== "wrapperClass"), { params: f, pagination: c, navigation: b, scrollbar: h, virtual: w, thumbs: m } = e;
  let S, v, d, u, y, T, C, E;
  r.includes("thumbs") && s.thumbs && s.thumbs.swiper && f.thumbs && !f.thumbs.swiper && (S = true), r.includes("controller") && s.controller && s.controller.control && f.controller && !f.controller.control && (v = true), r.includes("pagination") && s.pagination && (s.pagination.el || a) && (f.pagination || f.pagination === false) && c && !c.el && (d = true), r.includes("scrollbar") && s.scrollbar && (s.scrollbar.el || l) && (f.scrollbar || f.scrollbar === false) && h && !h.el && (u = true), r.includes("navigation") && s.navigation && (s.navigation.prevEl || o) && (s.navigation.nextEl || n) && (f.navigation || f.navigation === false) && b && !b.prevEl && !b.nextEl && (y = true);
  const M = (g) => {
    e[g] && (e[g].destroy(), g === "navigation" ? (e.isElement && (e[g].prevEl.remove(), e[g].nextEl.remove()), f[g].prevEl = void 0, f[g].nextEl = void 0, e[g].prevEl = void 0, e[g].nextEl = void 0) : (e.isElement && e[g].el.remove(), f[g].el = void 0, e[g].el = void 0));
  };
  r.includes("loop") && e.isElement && (f.loop && !s.loop ? T = true : !f.loop && s.loop ? C = true : E = true), p.forEach((g) => {
    if (Z(f[g]) && Z(s[g]))
      K(f[g], s[g]), (g === "navigation" || g === "pagination" || g === "scrollbar") && "enabled" in s[g] && !s[g].enabled && M(g);
    else {
      const I = s[g];
      (I === true || I === false) && (g === "navigation" || g === "pagination" || g === "scrollbar") ? I === false && M(g) : f[g] = s[g];
    }
  }), p.includes("controller") && !v && e.controller && e.controller.control && f.controller && f.controller.control && (e.controller.control = f.controller.control), r.includes("children") && i && w && f.virtual.enabled && (w.slides = i, w.update(true)), r.includes("children") && i && f.loop && (E = true), S && m.init() && m.update(true), v && (e.controller.control = f.controller.control), d && (e.isElement && (!a || typeof a == "string") && (a = document.createElement("div"), a.classList.add("swiper-pagination"), a.part.add("pagination"), e.el.appendChild(a)), a && (f.pagination.el = a), c.init(), c.render(), c.update()), u && (e.isElement && (!l || typeof l == "string") && (l = document.createElement("div"), l.classList.add("swiper-scrollbar"), l.part.add("scrollbar"), e.el.appendChild(l)), l && (f.scrollbar.el = l), h.init(), h.updateSize(), h.setTranslate()), y && (e.isElement && ((!n || typeof n == "string") && (n = document.createElement("div"), n.classList.add("swiper-button-next"), n.innerHTML = e.hostEl.constructor.nextButtonSvg, n.part.add("button-next"), e.el.appendChild(n)), (!o || typeof o == "string") && (o = document.createElement("div"), o.classList.add("swiper-button-prev"), o.innerHTML = e.hostEl.constructor.prevButtonSvg, o.part.add("button-prev"), e.el.appendChild(o))), n && (f.navigation.nextEl = n), o && (f.navigation.prevEl = o), b.init(), b.update()), r.includes("allowSlideNext") && (e.allowSlideNext = s.allowSlideNext), r.includes("allowSlidePrev") && (e.allowSlidePrev = s.allowSlidePrev), r.includes("direction") && e.changeDirection(s.direction, false), (T || E) && e.loopDestroy(), (C || E) && e.loopCreate(), e.update();
}
function Ee(t, e) {
  t === void 0 && (t = {}), e === void 0 && (e = true);
  const i = { on: {} }, s = {}, r = {};
  K(i, ve), i._emitClasses = true, i.init = false;
  const n = {}, o = Ge.map((a) => a.replace(/_/, "")), l = Object.assign({}, t);
  return Object.keys(l).forEach((a) => {
    typeof t[a] > "u" || (o.indexOf(a) >= 0 ? Z(t[a]) ? (i[a] = {}, r[a] = {}, K(i[a], t[a]), K(r[a], t[a])) : (i[a] = t[a], r[a] = t[a]) : a.search(/on[A-Z]/) === 0 && typeof t[a] == "function" ? e ? s["".concat(a[2].toLowerCase()).concat(a.substr(3))] = t[a] : i.on["".concat(a[2].toLowerCase()).concat(a.substr(3))] = t[a] : n[a] = t[a]);
  }), ["navigation", "pagination", "scrollbar"].forEach((a) => {
    i[a] === true && (i[a] = {}), i[a] === false && delete i[a];
  }), { params: i, passedParams: r, rest: n, events: s };
}
function ci(t, e) {
  let { el: i, nextEl: s, prevEl: r, paginationEl: n, scrollbarEl: o, swiper: l } = t;
  _e(e) && s && r && (l.params.navigation.nextEl = s, l.originalParams.navigation.nextEl = s, l.params.navigation.prevEl = r, l.originalParams.navigation.prevEl = r), Ne(e) && n && (l.params.pagination.el = n, l.originalParams.pagination.el = n), Ve(e) && o && (l.params.scrollbar.el = o, l.originalParams.scrollbar.el = o), l.init(i);
}
function pi(t, e, i, s, r) {
  const n = [];
  if (!e)
    return n;
  const o = (a) => {
    n.indexOf(a) < 0 && n.push(a);
  };
  if (i && s) {
    const a = s.map(r), p = i.map(r);
    a.join("") !== p.join("") && o("children"), s.length !== i.length && o("children");
  }
  return Ge.filter((a) => a[0] === "_").map((a) => a.replace(/_/, "")).forEach((a) => {
    if (a in t && a in e)
      if (Z(t[a]) && Z(e[a])) {
        const p = Object.keys(t[a]), f = Object.keys(e[a]);
        p.length !== f.length ? o(a) : (p.forEach((c) => {
          t[a][c] !== e[a][c] && o(a);
        }), f.forEach((c) => {
          t[a][c] !== e[a][c] && o(a);
        }));
      } else
        t[a] !== e[a] && o(a);
  }), n;
}
const mi = (t) => {
  !t || t.destroyed || !t.params.virtual || t.params.virtual && !t.params.virtual.enabled || (t.updateSlides(), t.updateProgress(), t.updateSlidesClasses(), t.parallax && t.params.parallax && t.params.parallax.enabled && t.parallax.setTranslate());
};
function ce(t, e, i) {
  t === void 0 && (t = {});
  const s = [], r = { "container-start": [], "container-end": [], "wrapper-start": [], "wrapper-end": [] }, n = (o, l) => {
    Array.isArray(o) && o.forEach((a) => {
      const p = typeof a.type == "symbol";
      l === "default" && (l = "container-end"), p && a.children ? n(a.children, l) : a.type && (a.type.name === "SwiperSlide" || a.type.name === "AsyncComponentWrapper") ? s.push(a) : r[l] && r[l].push(a);
    });
  };
  return Object.keys(t).forEach((o) => {
    if (typeof t[o] != "function")
      return;
    const l = t[o]();
    n(l, o);
  }), i.value = e.value, e.value = s, { slides: s, slots: r };
}
function hi(t, e, i) {
  if (!i)
    return null;
  const s = (f) => {
    let c = f;
    return f < 0 ? c = e.length + f : c >= e.length && (c = c - e.length), c;
  }, r = t.value.isHorizontal() ? { [t.value.rtlTranslate ? "right" : "left"]: "".concat(i.offset, "px") } : { top: "".concat(i.offset, "px") }, { from: n, to: o } = i, l = t.value.params.loop ? -e.length : 0, a = t.value.params.loop ? e.length * 2 : e.length, p = [];
  for (let f = l; f < a; f += 1)
    f >= n && f <= o && p.push(e[s(f)]);
  return p.map((f) => (f.props || (f.props = {}), f.props.style || (f.props.style = {}), f.props.swiperRef = t, f.props.style = r, k(f.type, { ...f.props }, f.children)));
}
const Si = { name: "Swiper", props: { tag: { type: String, default: "div" }, wrapperTag: { type: String, default: "div" }, modules: { type: Array, default: void 0 }, init: { type: Boolean, default: void 0 }, direction: { type: String, default: void 0 }, oneWayMovement: { type: Boolean, default: void 0 }, touchEventsTarget: { type: String, default: void 0 }, initialSlide: { type: Number, default: void 0 }, speed: { type: Number, default: void 0 }, cssMode: { type: Boolean, default: void 0 }, updateOnWindowResize: { type: Boolean, default: void 0 }, resizeObserver: { type: Boolean, default: void 0 }, nested: { type: Boolean, default: void 0 }, focusableElements: { type: String, default: void 0 }, width: { type: Number, default: void 0 }, height: { type: Number, default: void 0 }, preventInteractionOnTransition: { type: Boolean, default: void 0 }, userAgent: { type: String, default: void 0 }, url: { type: String, default: void 0 }, edgeSwipeDetection: { type: [Boolean, String], default: void 0 }, edgeSwipeThreshold: { type: Number, default: void 0 }, autoHeight: { type: Boolean, default: void 0 }, setWrapperSize: { type: Boolean, default: void 0 }, virtualTranslate: { type: Boolean, default: void 0 }, effect: { type: String, default: void 0 }, breakpoints: { type: Object, default: void 0 }, spaceBetween: { type: [Number, String], default: void 0 }, slidesPerView: { type: [Number, String], default: void 0 }, maxBackfaceHiddenSlides: { type: Number, default: void 0 }, slidesPerGroup: { type: Number, default: void 0 }, slidesPerGroupSkip: { type: Number, default: void 0 }, slidesPerGroupAuto: { type: Boolean, default: void 0 }, centeredSlides: { type: Boolean, default: void 0 }, centeredSlidesBounds: { type: Boolean, default: void 0 }, slidesOffsetBefore: { type: Number, default: void 0 }, slidesOffsetAfter: { type: Number, default: void 0 }, normalizeSlideIndex: { type: Boolean, default: void 0 }, centerInsufficientSlides: { type: Boolean, default: void 0 }, watchOverflow: { type: Boolean, default: void 0 }, roundLengths: { type: Boolean, default: void 0 }, touchRatio: { type: Number, default: void 0 }, touchAngle: { type: Number, default: void 0 }, simulateTouch: { type: Boolean, default: void 0 }, shortSwipes: { type: Boolean, default: void 0 }, longSwipes: { type: Boolean, default: void 0 }, longSwipesRatio: { type: Number, default: void 0 }, longSwipesMs: { type: Number, default: void 0 }, followFinger: { type: Boolean, default: void 0 }, allowTouchMove: { type: Boolean, default: void 0 }, threshold: { type: Number, default: void 0 }, touchMoveStopPropagation: { type: Boolean, default: void 0 }, touchStartPreventDefault: { type: Boolean, default: void 0 }, touchStartForcePreventDefault: { type: Boolean, default: void 0 }, touchReleaseOnEdges: { type: Boolean, default: void 0 }, uniqueNavElements: { type: Boolean, default: void 0 }, resistance: { type: Boolean, default: void 0 }, resistanceRatio: { type: Number, default: void 0 }, watchSlidesProgress: { type: Boolean, default: void 0 }, grabCursor: { type: Boolean, default: void 0 }, preventClicks: { type: Boolean, default: void 0 }, preventClicksPropagation: { type: Boolean, default: void 0 }, slideToClickedSlide: { type: Boolean, default: void 0 }, loop: { type: Boolean, default: void 0 }, loopedSlides: { type: Number, default: void 0 }, loopPreventsSliding: { type: Boolean, default: void 0 }, rewind: { type: Boolean, default: void 0 }, allowSlidePrev: { type: Boolean, default: void 0 }, allowSlideNext: { type: Boolean, default: void 0 }, swipeHandler: { type: Boolean, default: void 0 }, noSwiping: { type: Boolean, default: void 0 }, noSwipingClass: { type: String, default: void 0 }, noSwipingSelector: { type: String, default: void 0 }, passiveListeners: { type: Boolean, default: void 0 }, containerModifierClass: { type: String, default: void 0 }, slideClass: { type: String, default: void 0 }, slideActiveClass: { type: String, default: void 0 }, slideVisibleClass: { type: String, default: void 0 }, slideNextClass: { type: String, default: void 0 }, slidePrevClass: { type: String, default: void 0 }, wrapperClass: { type: String, default: void 0 }, lazyPreloaderClass: { type: String, default: void 0 }, lazyPreloadPrevNext: { type: Number, default: void 0 }, runCallbacksOnInit: { type: Boolean, default: void 0 }, observer: { type: Boolean, default: void 0 }, observeParents: { type: Boolean, default: void 0 }, observeSlideChildren: { type: Boolean, default: void 0 }, a11y: { type: [Boolean, Object], default: void 0 }, autoplay: { type: [Boolean, Object], default: void 0 }, controller: { type: Object, default: void 0 }, coverflowEffect: { type: Object, default: void 0 }, cubeEffect: { type: Object, default: void 0 }, fadeEffect: { type: Object, default: void 0 }, flipEffect: { type: Object, default: void 0 }, creativeEffect: { type: Object, default: void 0 }, cardsEffect: { type: Object, default: void 0 }, hashNavigation: { type: [Boolean, Object], default: void 0 }, history: { type: [Boolean, Object], default: void 0 }, keyboard: { type: [Boolean, Object], default: void 0 }, mousewheel: { type: [Boolean, Object], default: void 0 }, navigation: { type: [Boolean, Object], default: void 0 }, pagination: { type: [Boolean, Object], default: void 0 }, parallax: { type: [Boolean, Object], default: void 0 }, scrollbar: { type: [Boolean, Object], default: void 0 }, thumbs: { type: Object, default: void 0 }, virtual: { type: [Boolean, Object], default: void 0 }, zoom: { type: [Boolean, Object], default: void 0 }, grid: { type: [Object], default: void 0 }, freeMode: { type: [Boolean, Object], default: void 0 }, enabled: { type: Boolean, default: void 0 } }, emits: ["_beforeBreakpoint", "_containerClasses", "_slideClass", "_slideClasses", "_swiper", "_freeModeNoMomentumRelease", "activeIndexChange", "afterInit", "autoplay", "autoplayStart", "autoplayStop", "autoplayPause", "autoplayResume", "autoplayTimeLeft", "beforeDestroy", "beforeInit", "beforeLoopFix", "beforeResize", "beforeSlideChangeStart", "beforeTransitionStart", "breakpoint", "breakpointsBase", "changeDirection", "click", "disable", "doubleTap", "doubleClick", "destroy", "enable", "fromEdge", "hashChange", "hashSet", "init", "keyPress", "lock", "loopFix", "momentumBounce", "navigationHide", "navigationShow", "navigationPrev", "navigationNext", "observerUpdate", "orientationchange", "paginationHide", "paginationRender", "paginationShow", "paginationUpdate", "progress", "reachBeginning", "reachEnd", "realIndexChange", "resize", "scroll", "scrollbarDragEnd", "scrollbarDragMove", "scrollbarDragStart", "setTransition", "setTranslate", "slideChange", "slideChangeTransitionEnd", "slideChangeTransitionStart", "slideNextTransitionEnd", "slideNextTransitionStart", "slidePrevTransitionEnd", "slidePrevTransitionStart", "slideResetTransitionStart", "slideResetTransitionEnd", "sliderMove", "sliderFirstMove", "slidesLengthChange", "slidesGridLengthChange", "snapGridLengthChange", "snapIndexChange", "swiper", "tap", "toEdge", "touchEnd", "touchMove", "touchMoveOpposite", "touchStart", "transitionEnd", "transitionStart", "unlock", "update", "virtualUpdate", "zoomChange"], setup(t, e) {
  let { slots: i, emit: s } = e;
  const { tag: r, wrapperTag: n } = t, o = N("swiper"), l = N(null), a = N(false), p = N(false), f = N(null), c = N(null), b = N(null), h = { value: [] }, w = { value: [] }, m = N(null), S = N(null), v = N(null), d = N(null), { params: u, passedParams: y } = Ee(t, false);
  ce(i, h, w), b.value = y, w.value = h.value;
  const T = () => {
    ce(i, h, w), a.value = true;
  };
  u.onAny = function(M) {
    for (var g = arguments.length, I = new Array(g > 1 ? g - 1 : 0), x = 1; x < g; x++)
      I[x - 1] = arguments[x];
    s(M, ...I);
  }, Object.assign(u.on, { _beforeBreakpoint: T, _containerClasses(M, g) {
    o.value = g;
  } });
  const C = { ...u };
  if (delete C.wrapperClass, c.value = new Se(C), c.value.virtual && c.value.params.virtual.enabled) {
    c.value.virtual.slides = h.value;
    const M = { cache: false, slides: h.value, renderExternal: (g) => {
      l.value = g;
    }, renderExternalUpdate: false };
    K(c.value.params.virtual, M), K(c.value.originalParams.virtual, M);
  }
  Me(() => {
    !p.value && c.value && (c.value.emitSlidesClasses(), p.value = true);
    const { passedParams: M } = Ee(t, false), g = pi(M, b.value, h.value, w.value, (I) => I.props && I.props.key);
    b.value = M, (g.length || a.value) && c.value && !c.value.destroyed && ui({ swiper: c.value, slides: h.value, passedParams: M, changedParams: g, nextEl: m.value, prevEl: S.value, scrollbarEl: d.value, paginationEl: v.value }), a.value = false;
  }), Pe("swiper", c), ke(l, () => {
    He(() => {
      mi(c.value);
    });
  }), Le(() => {
    f.value && (ci({ el: f.value, nextEl: m.value, prevEl: S.value, paginationEl: v.value, scrollbarEl: d.value, swiper: c.value }, u), s("swiper", c.value));
  }), Oe(() => {
    c.value && !c.value.destroyed && c.value.destroy(true, false);
  });
  function E(M) {
    return u.virtual ? hi(c, M, l.value) : (M.forEach((g, I) => {
      g.props || (g.props = {}), g.props.swiperRef = c, g.props.swiperSlideIndex = I;
    }), M);
  }
  return () => {
    const { slides: M, slots: g } = ce(i, h, w);
    return k(r, { ref: f, class: Fe(o.value) }, [g["container-start"], k(n, { class: fi(u.wrapperClass) }, [g["wrapper-start"], E(M), g["wrapper-end"]]), _e(t) && [k("div", { ref: S, class: "swiper-button-prev" }), k("div", { ref: m, class: "swiper-button-next" })], Ve(t) && k("div", { ref: d, class: "swiper-scrollbar" }), Ne(t) && k("div", { ref: v, class: "swiper-pagination" }), g["container-end"]]);
  };
} }, yi = { name: "SwiperSlide", props: { tag: { type: String, default: "div" }, swiperRef: { type: Object, required: false }, swiperSlideIndex: { type: Number, default: void 0, required: false }, zoom: { type: Boolean, default: void 0, required: false }, lazy: { type: Boolean, default: false, required: false }, virtualIndex: { type: [String, Number], default: void 0 } }, setup(t, e) {
  let { slots: i } = e, s = false;
  const { swiperRef: r } = t, n = N(null), o = N("swiper-slide"), l = N(false);
  function a(c, b, h) {
    b === n.value && (o.value = h);
  }
  Le(() => {
    !r || !r.value || (r.value.on("_slideClass", a), s = true);
  }), je(() => {
    s || !r || !r.value || (r.value.on("_slideClass", a), s = true);
  }), Me(() => {
    !n.value || !r || !r.value || (typeof t.swiperSlideIndex < "u" && (n.value.swiperSlideIndex = t.swiperSlideIndex), r.value.destroyed && o.value !== "swiper-slide" && (o.value = "swiper-slide"));
  }), Oe(() => {
    !r || !r.value || r.value.off("_slideClass", a);
  });
  const p = qe(() => ({ isActive: o.value.indexOf("swiper-slide-active") >= 0, isVisible: o.value.indexOf("swiper-slide-visible") >= 0, isPrev: o.value.indexOf("swiper-slide-prev") >= 0, isNext: o.value.indexOf("swiper-slide-next") >= 0 }));
  Pe("swiperSlide", p);
  const f = () => {
    l.value = true;
  };
  return () => k(t.tag, { class: Fe("".concat(o.value)), ref: n, "data-swiper-slide-index": typeof t.virtualIndex > "u" && r && r.value && r.value.params.loop ? t.swiperSlideIndex : t.virtualIndex, onLoadCapture: f }, t.zoom ? k("div", { class: "swiper-zoom-container", "data-swiper-zoom": typeof t.zoom == "number" ? t.zoom : void 0 }, [i.default && i.default(p.value), t.lazy && !l.value && k("div", { class: "swiper-lazy-preloader" })]) : [i.default && i.default(p.value), t.lazy && !l.value && k("div", { class: "swiper-lazy-preloader" })]);
} };
function bi(t) {
  let { swiper: e, extendParams: i, on: s, emit: r } = t;
  i({ virtual: { enabled: false, slides: [], cache: true, renderSlide: null, renderExternal: null, renderExternalUpdate: true, addSlidesBefore: 0, addSlidesAfter: 0 } });
  let n;
  const o = j();
  e.virtual = { cache: {}, from: void 0, to: void 0, slides: [], offset: 0, slidesGrid: [] };
  const l = o.createElement("div");
  function a(w, m) {
    const S = e.params.virtual;
    if (S.cache && e.virtual.cache[m])
      return e.virtual.cache[m];
    let v;
    return S.renderSlide ? (v = S.renderSlide.call(e, w, m), typeof v == "string" && (l.innerHTML = v, v = l.children[0])) : e.isElement ? v = ee("swiper-slide") : v = ee("div", e.params.slideClass), v.setAttribute("data-swiper-slide-index", m), S.renderSlide || (v.innerHTML = w), S.cache && (e.virtual.cache[m] = v), v;
  }
  function p(w) {
    const { slidesPerView: m, slidesPerGroup: S, centeredSlides: v, loop: d } = e.params, { addSlidesBefore: u, addSlidesAfter: y } = e.params.virtual, { from: T, to: C, slides: E, slidesGrid: M, offset: g } = e.virtual;
    e.params.cssMode || e.updateActiveIndex();
    const I = e.activeIndex || 0;
    let x;
    e.rtlTranslate ? x = "right" : x = e.isHorizontal() ? "left" : "top";
    let L, P;
    v ? (L = Math.floor(m / 2) + S + y, P = Math.floor(m / 2) + S + u) : (L = m + (S - 1) + y, P = (d ? m : S) + u);
    let O = I - P, B = I + L;
    d || (O = Math.max(O, 0), B = Math.min(B, E.length - 1));
    let D = (e.slidesGrid[O] || 0) - (e.slidesGrid[0] || 0);
    d && I >= P ? (O -= P, v || (D += e.slidesGrid[0])) : d && I < P && (O = -P, v && (D += e.slidesGrid[0])), Object.assign(e.virtual, { from: O, to: B, offset: D, slidesGrid: e.slidesGrid, slidesBefore: P, slidesAfter: L });
    function A() {
      e.updateSlides(), e.updateProgress(), e.updateSlidesClasses(), r("virtualUpdate");
    }
    if (T === O && C === B && !w) {
      e.slidesGrid !== M && D !== g && e.slides.forEach((z) => {
        z.style[x] = "".concat(D - Math.abs(e.cssOverflowAdjustment()), "px");
      }), e.updateProgress(), r("virtualUpdate");
      return;
    }
    if (e.params.virtual.renderExternal) {
      e.params.virtual.renderExternal.call(e, { offset: D, from: O, to: B, slides: function() {
        const $ = [];
        for (let Y = O; Y <= B; Y += 1)
          $.push(E[Y]);
        return $;
      }() }), e.params.virtual.renderExternalUpdate ? A() : r("virtualUpdate");
      return;
    }
    const _ = [], G = [], R = (z) => {
      let $ = z;
      return z < 0 ? $ = E.length + z : $ >= E.length && ($ = $ - E.length), $;
    };
    if (w)
      e.slides.filter((z) => z.matches(".".concat(e.params.slideClass, ", swiper-slide"))).forEach((z) => {
        z.remove();
      });
    else
      for (let z = T; z <= C; z += 1)
        if (z < O || z > B) {
          const $ = R(z);
          e.slides.filter((Y) => Y.matches(".".concat(e.params.slideClass, '[data-swiper-slide-index="').concat($, '"], swiper-slide[data-swiper-slide-index="').concat($, '"]'))).forEach((Y) => {
            Y.remove();
          });
        }
    const X = d ? -E.length : 0, ne = d ? E.length * 2 : E.length;
    for (let z = X; z < ne; z += 1)
      if (z >= O && z <= B) {
        const $ = R(z);
        typeof C > "u" || w ? G.push($) : (z > C && G.push($), z < T && _.push($));
      }
    if (G.forEach((z) => {
      e.slidesEl.append(a(E[z], z));
    }), d)
      for (let z = _.length - 1; z >= 0; z -= 1) {
        const $ = _[z];
        e.slidesEl.prepend(a(E[$], $));
      }
    else
      _.sort((z, $) => $ - z), _.forEach((z) => {
        e.slidesEl.prepend(a(E[z], z));
      });
    H(e.slidesEl, ".swiper-slide, swiper-slide").forEach((z) => {
      z.style[x] = "".concat(D - Math.abs(e.cssOverflowAdjustment()), "px");
    }), A();
  }
  function f(w) {
    if (typeof w == "object" && "length" in w)
      for (let m = 0; m < w.length; m += 1)
        w[m] && e.virtual.slides.push(w[m]);
    else
      e.virtual.slides.push(w);
    p(true);
  }
  function c(w) {
    const m = e.activeIndex;
    let S = m + 1, v = 1;
    if (Array.isArray(w)) {
      for (let d = 0; d < w.length; d += 1)
        w[d] && e.virtual.slides.unshift(w[d]);
      S = m + w.length, v = w.length;
    } else
      e.virtual.slides.unshift(w);
    if (e.params.virtual.cache) {
      const d = e.virtual.cache, u = {};
      Object.keys(d).forEach((y) => {
        const T = d[y], C = T.getAttribute("data-swiper-slide-index");
        C && T.setAttribute("data-swiper-slide-index", parseInt(C, 10) + v), u[parseInt(y, 10) + v] = T;
      }), e.virtual.cache = u;
    }
    p(true), e.slideTo(S, 0);
  }
  function b(w) {
    if (typeof w > "u" || w === null)
      return;
    let m = e.activeIndex;
    if (Array.isArray(w))
      for (let S = w.length - 1; S >= 0; S -= 1)
        e.params.virtual.cache && (delete e.virtual.cache[w[S]], Object.keys(e.virtual.cache).forEach((v) => {
          v > w && (e.virtual.cache[v - 1] = e.virtual.cache[v], e.virtual.cache[v - 1].setAttribute("data-swiper-slide-index", v - 1), delete e.virtual.cache[v]);
        })), e.virtual.slides.splice(w[S], 1), w[S] < m && (m -= 1), m = Math.max(m, 0);
    else
      e.params.virtual.cache && (delete e.virtual.cache[w], Object.keys(e.virtual.cache).forEach((S) => {
        S > w && (e.virtual.cache[S - 1] = e.virtual.cache[S], e.virtual.cache[S - 1].setAttribute("data-swiper-slide-index", S - 1), delete e.virtual.cache[S]);
      })), e.virtual.slides.splice(w, 1), w < m && (m -= 1), m = Math.max(m, 0);
    p(true), e.slideTo(m, 0);
  }
  function h() {
    e.virtual.slides = [], e.params.virtual.cache && (e.virtual.cache = {}), p(true), e.slideTo(0, 0);
  }
  s("beforeInit", () => {
    if (!e.params.virtual.enabled)
      return;
    let w;
    if (typeof e.passedParams.virtual.slides > "u") {
      const m = [...e.slidesEl.children].filter((S) => S.matches(".".concat(e.params.slideClass, ", swiper-slide")));
      m && m.length && (e.virtual.slides = [...m], w = true, m.forEach((S, v) => {
        S.setAttribute("data-swiper-slide-index", v), e.virtual.cache[v] = S, S.remove();
      }));
    }
    w || (e.virtual.slides = e.params.virtual.slides), e.classNames.push("".concat(e.params.containerModifierClass, "virtual")), e.params.watchSlidesProgress = true, e.originalParams.watchSlidesProgress = true, p();
  }), s("setTranslate", () => {
    e.params.virtual.enabled && (e.params.cssMode && !e._immediateVirtual ? (clearTimeout(n), n = setTimeout(() => {
      p();
    }, 100)) : p());
  }), s("init update resize", () => {
    e.params.virtual.enabled && e.params.cssMode && Q(e.wrapperEl, "--swiper-virtual-size", "".concat(e.virtualSize, "px"));
  }), Object.assign(e.virtual, { appendSlide: f, prependSlide: c, removeSlide: b, removeAllSlides: h, update: p });
}
function Re(t, e, i, s) {
  return t.params.createElements && Object.keys(s).forEach((r) => {
    if (!i[r] && i.auto === true) {
      let n = H(t.el, ".".concat(s[r]))[0];
      n || (n = ee("div", s[r]), n.className = s[r], t.el.append(n)), i[r] = n, e[r] = n;
    }
  }), i;
}
function Ti(t) {
  let { swiper: e, extendParams: i, on: s, emit: r } = t;
  i({ navigation: { nextEl: null, prevEl: null, hideOnClick: false, disabledClass: "swiper-button-disabled", hiddenClass: "swiper-button-hidden", lockClass: "swiper-button-lock", navigationDisabledClass: "swiper-navigation-disabled" } }), e.navigation = { nextEl: null, prevEl: null };
  const n = (m) => (Array.isArray(m) ? m : [m]).filter((S) => !!S);
  function o(m) {
    let S;
    return m && typeof m == "string" && e.isElement && (S = e.el.querySelector(m), S) ? S : (m && (typeof m == "string" && (S = [...document.querySelectorAll(m)]), e.params.uniqueNavElements && typeof m == "string" && S.length > 1 && e.el.querySelectorAll(m).length === 1 && (S = e.el.querySelector(m))), m && !S ? m : S);
  }
  function l(m, S) {
    const v = e.params.navigation;
    m = n(m), m.forEach((d) => {
      d && (d.classList[S ? "add" : "remove"](...v.disabledClass.split(" ")), d.tagName === "BUTTON" && (d.disabled = S), e.params.watchOverflow && e.enabled && d.classList[e.isLocked ? "add" : "remove"](v.lockClass));
    });
  }
  function a() {
    const { nextEl: m, prevEl: S } = e.navigation;
    if (e.params.loop) {
      l(S, false), l(m, false);
      return;
    }
    l(S, e.isBeginning && !e.params.rewind), l(m, e.isEnd && !e.params.rewind);
  }
  function p(m) {
    m.preventDefault(), !(e.isBeginning && !e.params.loop && !e.params.rewind) && (e.slidePrev(), r("navigationPrev"));
  }
  function f(m) {
    m.preventDefault(), !(e.isEnd && !e.params.loop && !e.params.rewind) && (e.slideNext(), r("navigationNext"));
  }
  function c() {
    const m = e.params.navigation;
    if (e.params.navigation = Re(e, e.originalParams.navigation, e.params.navigation, { nextEl: "swiper-button-next", prevEl: "swiper-button-prev" }), !(m.nextEl || m.prevEl))
      return;
    let S = o(m.nextEl), v = o(m.prevEl);
    Object.assign(e.navigation, { nextEl: S, prevEl: v }), S = n(S), v = n(v);
    const d = (u, y) => {
      u && u.addEventListener("click", y === "next" ? f : p), !e.enabled && u && u.classList.add(...m.lockClass.split(" "));
    };
    S.forEach((u) => d(u, "next")), v.forEach((u) => d(u, "prev"));
  }
  function b() {
    let { nextEl: m, prevEl: S } = e.navigation;
    m = n(m), S = n(S);
    const v = (d, u) => {
      d.removeEventListener("click", u === "next" ? f : p), d.classList.remove(...e.params.navigation.disabledClass.split(" "));
    };
    m.forEach((d) => v(d, "next")), S.forEach((d) => v(d, "prev"));
  }
  s("init", () => {
    e.params.navigation.enabled === false ? w() : (c(), a());
  }), s("toEdge fromEdge lock unlock", () => {
    a();
  }), s("destroy", () => {
    b();
  }), s("enable disable", () => {
    let { nextEl: m, prevEl: S } = e.navigation;
    if (m = n(m), S = n(S), e.enabled) {
      a();
      return;
    }
    [...m, ...S].filter((v) => !!v).forEach((v) => v.classList.add(e.params.navigation.lockClass));
  }), s("click", (m, S) => {
    let { nextEl: v, prevEl: d } = e.navigation;
    v = n(v), d = n(d);
    const u = S.target;
    if (e.params.navigation.hideOnClick && !d.includes(u) && !v.includes(u)) {
      if (e.pagination && e.params.pagination && e.params.pagination.clickable && (e.pagination.el === u || e.pagination.el.contains(u)))
        return;
      let y;
      v.length ? y = v[0].classList.contains(e.params.navigation.hiddenClass) : d.length && (y = d[0].classList.contains(e.params.navigation.hiddenClass)), r(y === true ? "navigationShow" : "navigationHide"), [...v, ...d].filter((T) => !!T).forEach((T) => T.classList.toggle(e.params.navigation.hiddenClass));
    }
  });
  const h = () => {
    e.el.classList.remove(...e.params.navigation.navigationDisabledClass.split(" ")), c(), a();
  }, w = () => {
    e.el.classList.add(...e.params.navigation.navigationDisabledClass.split(" ")), b();
  };
  Object.assign(e.navigation, { enable: h, disable: w, update: a, init: c, destroy: b });
}
function J(t) {
  return t === void 0 && (t = ""), ".".concat(t.trim().replace(/([\.:!+\/])/g, "\\$1").replace(/ /g, "."));
}
function xi(t) {
  let { swiper: e, extendParams: i, on: s, emit: r } = t;
  const n = "swiper-pagination";
  i({ pagination: { el: null, bulletElement: "span", clickable: false, hideOnClick: false, renderBullet: null, renderProgressbar: null, renderFraction: null, renderCustom: null, progressbarOpposite: false, type: "bullets", dynamicBullets: false, dynamicMainBullets: 1, formatFractionCurrent: (d) => d, formatFractionTotal: (d) => d, bulletClass: "".concat(n, "-bullet"), bulletActiveClass: "".concat(n, "-bullet-active"), modifierClass: "".concat(n, "-"), currentClass: "".concat(n, "-current"), totalClass: "".concat(n, "-total"), hiddenClass: "".concat(n, "-hidden"), progressbarFillClass: "".concat(n, "-progressbar-fill"), progressbarOppositeClass: "".concat(n, "-progressbar-opposite"), clickableClass: "".concat(n, "-clickable"), lockClass: "".concat(n, "-lock"), horizontalClass: "".concat(n, "-horizontal"), verticalClass: "".concat(n, "-vertical"), paginationDisabledClass: "".concat(n, "-disabled") } }), e.pagination = { el: null, bullets: [] };
  let o, l = 0;
  const a = (d) => (Array.isArray(d) ? d : [d]).filter((u) => !!u);
  function p() {
    return !e.params.pagination.el || !e.pagination.el || Array.isArray(e.pagination.el) && e.pagination.el.length === 0;
  }
  function f(d, u) {
    const { bulletActiveClass: y } = e.params.pagination;
    d && (d = d["".concat(u === "prev" ? "previous" : "next", "ElementSibling")], d && (d.classList.add("".concat(y, "-").concat(u)), d = d["".concat(u === "prev" ? "previous" : "next", "ElementSibling")], d && d.classList.add("".concat(y, "-").concat(u, "-").concat(u))));
  }
  function c(d) {
    const u = d.target.closest(J(e.params.pagination.bulletClass));
    if (!u)
      return;
    d.preventDefault();
    const y = se(u) * e.params.slidesPerGroup;
    if (e.params.loop) {
      if (e.realIndex === y)
        return;
      const T = e.realIndex, C = e.getSlideIndexByData(y), E = e.getSlideIndexByData(e.realIndex), M = (g) => {
        const I = e.activeIndex;
        e.loopFix({ direction: g, activeSlideIndex: C, slideTo: false });
        const x = e.activeIndex;
        I === x && e.slideToLoop(T, 0, false, true);
      };
      if (C > e.slides.length - e.loopedSlides)
        M(C > E ? "next" : "prev");
      else if (e.params.centeredSlides) {
        const g = e.params.slidesPerView === "auto" ? e.slidesPerViewDynamic() : Math.ceil(parseFloat(e.params.slidesPerView, 10));
        C < Math.floor(g / 2) && M("prev");
      }
      e.slideToLoop(y);
    } else
      e.slideTo(y);
  }
  function b() {
    const d = e.rtl, u = e.params.pagination;
    if (p())
      return;
    let y = e.pagination.el;
    y = a(y);
    let T, C;
    const E = e.virtual && e.params.virtual.enabled ? e.virtual.slides.length : e.slides.length, M = e.params.loop ? Math.ceil(E / e.params.slidesPerGroup) : e.snapGrid.length;
    if (e.params.loop ? (C = e.previousRealIndex || 0, T = e.params.slidesPerGroup > 1 ? Math.floor(e.realIndex / e.params.slidesPerGroup) : e.realIndex) : typeof e.snapIndex < "u" ? (T = e.snapIndex, C = e.previousSnapIndex) : (C = e.previousIndex || 0, T = e.activeIndex || 0), u.type === "bullets" && e.pagination.bullets && e.pagination.bullets.length > 0) {
      const g = e.pagination.bullets;
      let I, x, L;
      if (u.dynamicBullets && (o = me(g[0], e.isHorizontal() ? "width" : "height", true), y.forEach((P) => {
        P.style[e.isHorizontal() ? "width" : "height"] = "".concat(o * (u.dynamicMainBullets + 4), "px");
      }), u.dynamicMainBullets > 1 && C !== void 0 && (l += T - (C || 0), l > u.dynamicMainBullets - 1 ? l = u.dynamicMainBullets - 1 : l < 0 && (l = 0)), I = Math.max(T - l, 0), x = I + (Math.min(g.length, u.dynamicMainBullets) - 1), L = (x + I) / 2), g.forEach((P) => {
        const O = [...["", "-next", "-next-next", "-prev", "-prev-prev", "-main"].map((B) => "".concat(u.bulletActiveClass).concat(B))].map((B) => typeof B == "string" && B.includes(" ") ? B.split(" ") : B).flat();
        P.classList.remove(...O);
      }), y.length > 1)
        g.forEach((P) => {
          const O = se(P);
          O === T ? P.classList.add(...u.bulletActiveClass.split(" ")) : e.isElement && P.setAttribute("part", "bullet"), u.dynamicBullets && (O >= I && O <= x && P.classList.add(..."".concat(u.bulletActiveClass, "-main").split(" ")), O === I && f(P, "prev"), O === x && f(P, "next"));
        });
      else {
        const P = g[T];
        if (P && P.classList.add(...u.bulletActiveClass.split(" ")), e.isElement && g.forEach((O, B) => {
          O.setAttribute("part", B === T ? "bullet-active" : "bullet");
        }), u.dynamicBullets) {
          const O = g[I], B = g[x];
          for (let D = I; D <= x; D += 1)
            g[D] && g[D].classList.add(..."".concat(u.bulletActiveClass, "-main").split(" "));
          f(O, "prev"), f(B, "next");
        }
      }
      if (u.dynamicBullets) {
        const P = Math.min(g.length, u.dynamicMainBullets + 4), O = (o * P - o) / 2 - L * o, B = d ? "right" : "left";
        g.forEach((D) => {
          D.style[e.isHorizontal() ? B : "top"] = "".concat(O, "px");
        });
      }
    }
    y.forEach((g, I) => {
      if (u.type === "fraction" && (g.querySelectorAll(J(u.currentClass)).forEach((x) => {
        x.textContent = u.formatFractionCurrent(T + 1);
      }), g.querySelectorAll(J(u.totalClass)).forEach((x) => {
        x.textContent = u.formatFractionTotal(M);
      })), u.type === "progressbar") {
        let x;
        u.progressbarOpposite ? x = e.isHorizontal() ? "vertical" : "horizontal" : x = e.isHorizontal() ? "horizontal" : "vertical";
        const L = (T + 1) / M;
        let P = 1, O = 1;
        x === "horizontal" ? P = L : O = L, g.querySelectorAll(J(u.progressbarFillClass)).forEach((B) => {
          B.style.transform = "translate3d(0,0,0) scaleX(".concat(P, ") scaleY(").concat(O, ")"), B.style.transitionDuration = "".concat(e.params.speed, "ms");
        });
      }
      u.type === "custom" && u.renderCustom ? (g.innerHTML = u.renderCustom(e, T + 1, M), I === 0 && r("paginationRender", g)) : (I === 0 && r("paginationRender", g), r("paginationUpdate", g)), e.params.watchOverflow && e.enabled && g.classList[e.isLocked ? "add" : "remove"](u.lockClass);
    });
  }
  function h() {
    const d = e.params.pagination;
    if (p())
      return;
    const u = e.virtual && e.params.virtual.enabled ? e.virtual.slides.length : e.slides.length;
    let y = e.pagination.el;
    y = a(y);
    let T = "";
    if (d.type === "bullets") {
      let C = e.params.loop ? Math.ceil(u / e.params.slidesPerGroup) : e.snapGrid.length;
      e.params.freeMode && e.params.freeMode.enabled && C > u && (C = u);
      for (let E = 0; E < C; E += 1)
        d.renderBullet ? T += d.renderBullet.call(e, E, d.bulletClass) : T += "<".concat(d.bulletElement, " ").concat(e.isElement ? 'part="bullet"' : "", ' class="').concat(d.bulletClass, '"></').concat(d.bulletElement, ">");
    }
    d.type === "fraction" && (d.renderFraction ? T = d.renderFraction.call(e, d.currentClass, d.totalClass) : T = '<span class="'.concat(d.currentClass, '"></span> / <span class="').concat(d.totalClass, '"></span>')), d.type === "progressbar" && (d.renderProgressbar ? T = d.renderProgressbar.call(e, d.progressbarFillClass) : T = '<span class="'.concat(d.progressbarFillClass, '"></span>')), e.pagination.bullets = [], y.forEach((C) => {
      d.type !== "custom" && (C.innerHTML = T || ""), d.type === "bullets" && e.pagination.bullets.push(...C.querySelectorAll(J(d.bulletClass)));
    }), d.type !== "custom" && r("paginationRender", y[0]);
  }
  function w() {
    e.params.pagination = Re(e, e.originalParams.pagination, e.params.pagination, { el: "swiper-pagination" });
    const d = e.params.pagination;
    if (!d.el)
      return;
    let u;
    typeof d.el == "string" && e.isElement && (u = e.el.querySelector(d.el)), !u && typeof d.el == "string" && (u = [...document.querySelectorAll(d.el)]), u || (u = d.el), !(!u || u.length === 0) && (e.params.uniqueNavElements && typeof d.el == "string" && Array.isArray(u) && u.length > 1 && (u = [...e.el.querySelectorAll(d.el)], u.length > 1 && (u = u.filter((y) => Ae(y, ".swiper")[0] === e.el)[0])), Array.isArray(u) && u.length === 1 && (u = u[0]), Object.assign(e.pagination, { el: u }), u = a(u), u.forEach((y) => {
      d.type === "bullets" && d.clickable && y.classList.add(...(d.clickableClass || "").split(" ")), y.classList.add(d.modifierClass + d.type), y.classList.add(e.isHorizontal() ? d.horizontalClass : d.verticalClass), d.type === "bullets" && d.dynamicBullets && (y.classList.add("".concat(d.modifierClass).concat(d.type, "-dynamic")), l = 0, d.dynamicMainBullets < 1 && (d.dynamicMainBullets = 1)), d.type === "progressbar" && d.progressbarOpposite && y.classList.add(d.progressbarOppositeClass), d.clickable && y.addEventListener("click", c), e.enabled || y.classList.add(d.lockClass);
    }));
  }
  function m() {
    const d = e.params.pagination;
    if (p())
      return;
    let u = e.pagination.el;
    u && (u = a(u), u.forEach((y) => {
      y.classList.remove(d.hiddenClass), y.classList.remove(d.modifierClass + d.type), y.classList.remove(e.isHorizontal() ? d.horizontalClass : d.verticalClass), d.clickable && (y.classList.remove(...(d.clickableClass || "").split(" ")), y.removeEventListener("click", c));
    })), e.pagination.bullets && e.pagination.bullets.forEach((y) => y.classList.remove(...d.bulletActiveClass.split(" ")));
  }
  s("changeDirection", () => {
    if (!e.pagination || !e.pagination.el)
      return;
    const d = e.params.pagination;
    let { el: u } = e.pagination;
    u = a(u), u.forEach((y) => {
      y.classList.remove(d.horizontalClass, d.verticalClass), y.classList.add(e.isHorizontal() ? d.horizontalClass : d.verticalClass);
    });
  }), s("init", () => {
    e.params.pagination.enabled === false ? v() : (w(), h(), b());
  }), s("activeIndexChange", () => {
    typeof e.snapIndex > "u" && b();
  }), s("snapIndexChange", () => {
    b();
  }), s("snapGridLengthChange", () => {
    h(), b();
  }), s("destroy", () => {
    m();
  }), s("enable disable", () => {
    let { el: d } = e.pagination;
    d && (d = a(d), d.forEach((u) => u.classList[e.enabled ? "remove" : "add"](e.params.pagination.lockClass)));
  }), s("lock unlock", () => {
    b();
  }), s("click", (d, u) => {
    const y = u.target, T = a(e.pagination.el);
    if (e.params.pagination.el && e.params.pagination.hideOnClick && T && T.length > 0 && !y.classList.contains(e.params.pagination.bulletClass)) {
      if (e.navigation && (e.navigation.nextEl && y === e.navigation.nextEl || e.navigation.prevEl && y === e.navigation.prevEl))
        return;
      const C = T[0].classList.contains(e.params.pagination.hiddenClass);
      r(C === true ? "paginationShow" : "paginationHide"), T.forEach((E) => E.classList.toggle(e.params.pagination.hiddenClass));
    }
  });
  const S = () => {
    e.el.classList.remove(e.params.pagination.paginationDisabledClass);
    let { el: d } = e.pagination;
    d && (d = a(d), d.forEach((u) => u.classList.remove(e.params.pagination.paginationDisabledClass))), w(), h(), b();
  }, v = () => {
    e.el.classList.add(e.params.pagination.paginationDisabledClass);
    let { el: d } = e.pagination;
    d && (d = a(d), d.forEach((u) => u.classList.add(e.params.pagination.paginationDisabledClass))), m();
  };
  Object.assign(e.pagination, { enable: S, disable: v, render: h, update: b, init: w, destroy: m });
}
function Ei(t) {
  let { swiper: e, extendParams: i, on: s, emit: r, params: n } = t;
  e.autoplay = { running: false, paused: false, timeLeft: 0 }, i({ autoplay: { enabled: false, delay: 3e3, waitForTransition: true, disableOnInteraction: true, stopOnLastSlide: false, reverseDirection: false, pauseOnMouseEnter: false } });
  let o, l, a = n && n.autoplay ? n.autoplay.delay : 3e3, p = n && n.autoplay ? n.autoplay.delay : 3e3, f, c = (/* @__PURE__ */ new Date()).getTime, b, h, w, m, S, v;
  function d(A) {
    !e || e.destroyed || !e.wrapperEl || A.target === e.wrapperEl && (e.wrapperEl.removeEventListener("transitionend", d), g());
  }
  const u = () => {
    if (e.destroyed || !e.autoplay.running)
      return;
    e.autoplay.paused ? b = true : b && (p = f, b = false);
    const A = e.autoplay.paused ? f : c + p - (/* @__PURE__ */ new Date()).getTime();
    e.autoplay.timeLeft = A, r("autoplayTimeLeft", A, A / a), l = requestAnimationFrame(() => {
      u();
    });
  }, y = () => {
    let A;
    return e.virtual && e.params.virtual.enabled ? A = e.slides.filter((G) => G.classList.contains("swiper-slide-active"))[0] : A = e.slides[e.activeIndex], A ? parseInt(A.getAttribute("data-swiper-autoplay"), 10) : void 0;
  }, T = (A) => {
    if (e.destroyed || !e.autoplay.running)
      return;
    cancelAnimationFrame(l), u();
    let _ = typeof A > "u" ? e.params.autoplay.delay : A;
    a = e.params.autoplay.delay, p = e.params.autoplay.delay;
    const G = y();
    !Number.isNaN(G) && G > 0 && typeof A > "u" && (_ = G, a = G, p = G), f = _;
    const R = e.params.speed, X = () => {
      !e || e.destroyed || (e.params.autoplay.reverseDirection ? !e.isBeginning || e.params.loop || e.params.rewind ? (e.slidePrev(R, true, true), r("autoplay")) : e.params.autoplay.stopOnLastSlide || (e.slideTo(e.slides.length - 1, R, true, true), r("autoplay")) : !e.isEnd || e.params.loop || e.params.rewind ? (e.slideNext(R, true, true), r("autoplay")) : e.params.autoplay.stopOnLastSlide || (e.slideTo(0, R, true, true), r("autoplay")), e.params.cssMode && (c = (/* @__PURE__ */ new Date()).getTime(), requestAnimationFrame(() => {
        T();
      })));
    };
    return _ > 0 ? (clearTimeout(o), o = setTimeout(() => {
      X();
    }, _)) : requestAnimationFrame(() => {
      X();
    }), _;
  }, C = () => {
    e.autoplay.running = true, T(), r("autoplayStart");
  }, E = () => {
    e.autoplay.running = false, clearTimeout(o), cancelAnimationFrame(l), r("autoplayStop");
  }, M = (A, _) => {
    if (e.destroyed || !e.autoplay.running)
      return;
    clearTimeout(o), A || (v = true);
    const G = () => {
      r("autoplayPause"), e.params.autoplay.waitForTransition ? e.wrapperEl.addEventListener("transitionend", d) : g();
    };
    if (e.autoplay.paused = true, _) {
      S && (f = e.params.autoplay.delay), S = false, G();
      return;
    }
    f = (f || e.params.autoplay.delay) - ((/* @__PURE__ */ new Date()).getTime() - c), !(e.isEnd && f < 0 && !e.params.loop) && (f < 0 && (f = 0), G());
  }, g = () => {
    e.isEnd && f < 0 && !e.params.loop || e.destroyed || !e.autoplay.running || (c = (/* @__PURE__ */ new Date()).getTime(), v ? (v = false, T(f)) : T(), e.autoplay.paused = false, r("autoplayResume"));
  }, I = () => {
    if (e.destroyed || !e.autoplay.running)
      return;
    const A = j();
    A.visibilityState === "hidden" && (v = true, M(true)), A.visibilityState === "visible" && g();
  }, x = (A) => {
    A.pointerType === "mouse" && (v = true, !(e.animating || e.autoplay.paused) && M(true));
  }, L = (A) => {
    A.pointerType === "mouse" && e.autoplay.paused && g();
  }, P = () => {
    e.params.autoplay.pauseOnMouseEnter && (e.el.addEventListener("pointerenter", x), e.el.addEventListener("pointerleave", L));
  }, O = () => {
    e.el.removeEventListener("pointerenter", x), e.el.removeEventListener("pointerleave", L);
  }, B = () => {
    j().addEventListener("visibilitychange", I);
  }, D = () => {
    j().removeEventListener("visibilitychange", I);
  };
  s("init", () => {
    e.params.autoplay.enabled && (P(), B(), c = (/* @__PURE__ */ new Date()).getTime(), C());
  }), s("destroy", () => {
    O(), D(), e.autoplay.running && E();
  }), s("beforeTransitionStart", (A, _, G) => {
    e.destroyed || !e.autoplay.running || (G || !e.params.autoplay.disableOnInteraction ? M(true, true) : E());
  }), s("sliderFirstMove", () => {
    if (!(e.destroyed || !e.autoplay.running)) {
      if (e.params.autoplay.disableOnInteraction) {
        E();
        return;
      }
      h = true, w = false, v = false, m = setTimeout(() => {
        v = true, w = true, M(true);
      }, 200);
    }
  }), s("touchEnd", () => {
    if (!(e.destroyed || !e.autoplay.running || !h)) {
      if (clearTimeout(m), clearTimeout(o), e.params.autoplay.disableOnInteraction) {
        w = false, h = false;
        return;
      }
      w && e.params.cssMode && g(), w = false, h = false;
    }
  }), s("slideChange", () => {
    e.destroyed || !e.autoplay.running || (S = true);
  }), Object.assign(e.autoplay, { start: C, stop: E, pause: M, resume: g });
}
function Ci(t) {
  let { swiper: e, extendParams: i, emit: s, once: r } = t;
  i({ freeMode: { enabled: false, momentum: true, momentumRatio: 1, momentumBounce: true, momentumBounceRatio: 1, momentumVelocityRatio: 1, sticky: false, minimumVelocity: 0.02 } });
  function n() {
    if (e.params.cssMode)
      return;
    const a = e.getTranslate();
    e.setTranslate(a), e.setTransition(0), e.touchEventsData.velocities.length = 0, e.freeMode.onTouchEnd({ currentPos: e.rtl ? e.translate : -e.translate });
  }
  function o() {
    if (e.params.cssMode)
      return;
    const { touchEventsData: a, touches: p } = e;
    a.velocities.length === 0 && a.velocities.push({ position: p[e.isHorizontal() ? "startX" : "startY"], time: a.touchStartTime }), a.velocities.push({ position: p[e.isHorizontal() ? "currentX" : "currentY"], time: U() });
  }
  function l(a) {
    let { currentPos: p } = a;
    if (e.params.cssMode)
      return;
    const { params: f, wrapperEl: c, rtlTranslate: b, snapGrid: h, touchEventsData: w } = e, S = U() - w.touchStartTime;
    if (p < -e.minTranslate()) {
      e.slideTo(e.activeIndex);
      return;
    }
    if (p > -e.maxTranslate()) {
      e.slides.length < h.length ? e.slideTo(h.length - 1) : e.slideTo(e.slides.length - 1);
      return;
    }
    if (f.freeMode.momentum) {
      if (w.velocities.length > 1) {
        const M = w.velocities.pop(), g = w.velocities.pop(), I = M.position - g.position, x = M.time - g.time;
        e.velocity = I / x, e.velocity /= 2, Math.abs(e.velocity) < f.freeMode.minimumVelocity && (e.velocity = 0), (x > 150 || U() - M.time > 300) && (e.velocity = 0);
      } else
        e.velocity = 0;
      e.velocity *= f.freeMode.momentumVelocityRatio, w.velocities.length = 0;
      let v = 1e3 * f.freeMode.momentumRatio;
      const d = e.velocity * v;
      let u = e.translate + d;
      b && (u = -u);
      let y = false, T;
      const C = Math.abs(e.velocity) * 20 * f.freeMode.momentumBounceRatio;
      let E;
      if (u < e.maxTranslate())
        f.freeMode.momentumBounce ? (u + e.maxTranslate() < -C && (u = e.maxTranslate() - C), T = e.maxTranslate(), y = true, w.allowMomentumBounce = true) : u = e.maxTranslate(), f.loop && f.centeredSlides && (E = true);
      else if (u > e.minTranslate())
        f.freeMode.momentumBounce ? (u - e.minTranslate() > C && (u = e.minTranslate() + C), T = e.minTranslate(), y = true, w.allowMomentumBounce = true) : u = e.minTranslate(), f.loop && f.centeredSlides && (E = true);
      else if (f.freeMode.sticky) {
        let M;
        for (let g = 0; g < h.length; g += 1)
          if (h[g] > -u) {
            M = g;
            break;
          }
        Math.abs(h[M] - u) < Math.abs(h[M - 1] - u) || e.swipeDirection === "next" ? u = h[M] : u = h[M - 1], u = -u;
      }
      if (E && r("transitionEnd", () => {
        e.loopFix();
      }), e.velocity !== 0) {
        if (b ? v = Math.abs((-u - e.translate) / e.velocity) : v = Math.abs((u - e.translate) / e.velocity), f.freeMode.sticky) {
          const M = Math.abs((b ? -u : u) - e.translate), g = e.slidesSizesGrid[e.activeIndex];
          M < g ? v = f.speed : M < 2 * g ? v = f.speed * 1.5 : v = f.speed * 2.5;
        }
      } else if (f.freeMode.sticky) {
        e.slideToClosest();
        return;
      }
      f.freeMode.momentumBounce && y ? (e.updateProgress(T), e.setTransition(v), e.setTranslate(u), e.transitionStart(true, e.swipeDirection), e.animating = true, re(c, () => {
        !e || e.destroyed || !w.allowMomentumBounce || (s("momentumBounce"), e.setTransition(f.speed), setTimeout(() => {
          e.setTranslate(T), re(c, () => {
            !e || e.destroyed || e.transitionEnd();
          });
        }, 0));
      })) : e.velocity ? (s("_freeModeNoMomentumRelease"), e.updateProgress(u), e.setTransition(v), e.setTranslate(u), e.transitionStart(true, e.swipeDirection), e.animating || (e.animating = true, re(c, () => {
        !e || e.destroyed || e.transitionEnd();
      }))) : e.updateProgress(u), e.updateActiveIndex(), e.updateSlidesClasses();
    } else if (f.freeMode.sticky) {
      e.slideToClosest();
      return;
    } else
      f.freeMode && s("_freeModeNoMomentumRelease");
    (!f.freeMode.momentum || S >= f.longSwipesMs) && (e.updateProgress(), e.updateActiveIndex(), e.updateSlidesClasses());
  }
  Object.assign(e, { freeMode: { onTouchStart: n, onTouchMove: o, onTouchEnd: l } });
}
function vi(t) {
  const { effect: e, swiper: i, on: s, setTranslate: r, setTransition: n, overwriteParams: o, perspective: l, recreateShadows: a, getEffectParams: p } = t;
  s("beforeInit", () => {
    if (i.params.effect !== e)
      return;
    i.classNames.push("".concat(i.params.containerModifierClass).concat(e)), l && l() && i.classNames.push("".concat(i.params.containerModifierClass, "3d"));
    const c = o ? o() : {};
    Object.assign(i.params, c), Object.assign(i.originalParams, c);
  }), s("setTranslate", () => {
    i.params.effect === e && r();
  }), s("setTransition", (c, b) => {
    i.params.effect === e && n(b);
  }), s("transitionEnd", () => {
    if (i.params.effect === e && a) {
      if (!p || !p().slideShadows)
        return;
      i.slides.forEach((c) => {
        c.querySelectorAll(".swiper-slide-shadow-top, .swiper-slide-shadow-right, .swiper-slide-shadow-bottom, .swiper-slide-shadow-left").forEach((b) => b.remove());
      }), a();
    }
  });
  let f;
  s("virtualUpdate", () => {
    i.params.effect === e && (i.slides.length || (f = true), requestAnimationFrame(() => {
      f && i.slides && i.slides.length && (r(), f = false);
    }));
  });
}
function gi(t, e) {
  const i = we(e);
  return i !== e && (i.style.backfaceVisibility = "hidden", i.style["-webkit-backface-visibility"] = "hidden"), i;
}
function Ce(t, e, i) {
  const s = "swiper-slide-shadow".concat(i ? "-".concat(i) : "").concat(t ? " swiper-slide-shadow-".concat(t) : ""), r = we(e);
  let n = r.querySelector(".".concat(s.split(" ").join(".")));
  return n || (n = ee("div", s.split(" ")), r.append(n)), n;
}
function Mi(t) {
  let { swiper: e, extendParams: i, on: s } = t;
  i({ coverflowEffect: { rotate: 50, stretch: 0, depth: 100, scale: 1, modifier: 1, slideShadows: true } }), vi({ effect: "coverflow", swiper: e, on: s, setTranslate: () => {
    const { width: o, height: l, slides: a, slidesSizesGrid: p } = e, f = e.params.coverflowEffect, c = e.isHorizontal(), b = e.translate, h = c ? -b + o / 2 : -b + l / 2, w = c ? f.rotate : -f.rotate, m = f.depth;
    for (let S = 0, v = a.length; S < v; S += 1) {
      const d = a[S], u = p[S], y = d.swiperSlideOffset, T = (h - y - u / 2) / u, C = typeof f.modifier == "function" ? f.modifier(T) : T * f.modifier;
      let E = c ? w * C : 0, M = c ? 0 : w * C, g = -m * Math.abs(C), I = f.stretch;
      typeof I == "string" && I.indexOf("%") !== -1 && (I = parseFloat(f.stretch) / 100 * u);
      let x = c ? 0 : I * C, L = c ? I * C : 0, P = 1 - (1 - f.scale) * Math.abs(C);
      Math.abs(L) < 1e-3 && (L = 0), Math.abs(x) < 1e-3 && (x = 0), Math.abs(g) < 1e-3 && (g = 0), Math.abs(E) < 1e-3 && (E = 0), Math.abs(M) < 1e-3 && (M = 0), Math.abs(P) < 1e-3 && (P = 0);
      const O = "translate3d(".concat(L, "px,").concat(x, "px,").concat(g, "px)  rotateX(").concat(M, "deg) rotateY(").concat(E, "deg) scale(").concat(P, ")"), B = gi(f, d);
      if (B.style.transform = O, d.style.zIndex = -Math.abs(Math.round(C)) + 1, f.slideShadows) {
        let D = c ? d.querySelector(".swiper-slide-shadow-left") : d.querySelector(".swiper-slide-shadow-top"), A = c ? d.querySelector(".swiper-slide-shadow-right") : d.querySelector(".swiper-slide-shadow-bottom");
        D || (D = Ce("coverflow", d, c ? "left" : "top")), A || (A = Ce("coverflow", d, c ? "right" : "bottom")), D && (D.style.opacity = C > 0 ? C : 0), A && (A.style.opacity = -C > 0 ? -C : 0);
      }
    }
  }, setTransition: (o) => {
    e.slides.map((a) => we(a)).forEach((a) => {
      a.style.transitionDuration = "".concat(o, "ms"), a.querySelectorAll(".swiper-slide-shadow-top, .swiper-slide-shadow-right, .swiper-slide-shadow-bottom, .swiper-slide-shadow-left").forEach((p) => {
        p.style.transitionDuration = "".concat(o, "ms");
      });
    });
  }, perspective: () => true, overwriteParams: () => ({ watchSlidesProgress: true }) });
}
export {
  Ei as A,
  Mi as E,
  Ti as N,
  xi as P,
  yi as S,
  bi as V,
  Si as a,
  Ci as f
};
