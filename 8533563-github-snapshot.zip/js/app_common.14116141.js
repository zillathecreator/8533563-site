import { s as n, g, $ as u, __tla as __tla_0 } from "./index.bb04cb73.js";
let C, E, q, T;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e) {
    }
  })()
]).then(async () => {
  T = function(e, o) {
    let a = g();
    if (!(a.fbPixId && a.channelId && e.atFirst === 1 && !n.state.kwaiToken)) {
      let i = o.findIndex((r) => r === e.orderNo);
      i !== -1 && o.splice(i, 1);
      let c = o.findIndex((r) => r == e.id);
      c !== -1 && o.splice(c, 1);
    }
    let d = e.atFirst === 1 ? "firstDeposit" : "depositAgain", t = {
      amount: e.amount,
      currency: e.currency
    };
    window.jsAppObj && window.jsAppObj.reportEvent(d, JSON.stringify(t));
    try {
      const i = g();
      if (i.fbPixId && i.rand && i.fbclid && i.domain) {
        let c = i.domain;
        c.indexOf("http") === -1 && (c = "https://" + c);
        let r = e.atFirst === 1 ? "".concat(c, "/facebook/pixed/sendFBFirstRechatge") : "".concat(c, "/facebook/pixed/sendFBRechatge"), l = i.fbPixId, s = i.rand, p = i.fbclid, m = i.utm_medium || 1, f = i.utm_source || 1, I = i.utm_id || 1, h = i.utm_content || 1, k = i.utm_term || 1, _ = i.utm_campaign || 1;
        axios({
          method: "get",
          url: "".concat(r, "?rand=").concat(s, "&pixed_id=").concat(l, "&fbclid=").concat(p, "&utm_medium=").concat(m, "&utm_source=").concat(f, "&utm_id=").concat(I, "&utm_content=").concat(h, "&utm_term=").concat(k, "&utm_campaign=").concat(_)
        }).then((N) => {
          console.log("dou peng submit success");
        });
      }
    } catch (e2) {
    }
    try {
      const i = g();
      if (i.fbPixId && i.channelId && !n.state.kwaiToken)
        if (e.atFirst === 1) {
          n.state.sendPurchase && fbq("track", "Purchase", {
            customerId: n.state.accountInfo.id,
            customerName: n.state.accountInfo.username,
            currency: e.currency,
            revenue: e.amount,
            value: e.amount,
            amount: e.amount
          }, {
            eventID: "deposit." + e.orderNo
          }), fbq("trackCustom", "firstPurchase", {
            customerId: n.state.accountInfo.id,
            customerName: n.state.accountInfo.username,
            currency: e.currency,
            revenue: e.amount,
            value: e.amount,
            amount: e.amount
          }, {
            eventID: "firstDeposit." + e.orderNo
          });
          let c = o.findIndex((s) => s === e.orderNo);
          c !== -1 && o.splice(c, 1);
          let r = o.findIndex((s) => s == e.id);
          r !== -1 && o.splice(r, 1);
          let l = i.channelId;
          u.get("/game/game/report", {
            userid: n.state.accountInfo.id,
            channelid: l,
            paramsType: "firstPurchase",
            orderNo: e.orderNo,
            orderId: e.id
          }).then((s) => {
            e.atFirst;
          });
        } else
          n.state.sendPurchase && fbq("track", "Purchase", {
            customerId: n.state.accountInfo.id,
            customerName: n.state.accountInfo.username,
            currency: e.currency,
            revenue: e.amount,
            value: e.amount,
            amount: e.amount
          }, {
            eventID: "deposit." + e.orderNo
          });
    } catch (e2) {
    }
    try {
      const i = g();
      let c = i.kwaiPixId || localStorage.getItem("kwaiPixId");
      if (c && !n.state.kwaiToken) {
        let r = c;
        kwaiq.instance(r).track("purchase", {
          value: e.amount,
          currency: e.currency
        });
        let l = i.channelId || localStorage.getItem("channelId");
        u.get("/game/game/report", {
          userid: n.state.accountInfo.id,
          channelid: l,
          paramsType: "firstPurchase",
          orderNo: e.orderNo,
          orderId: e.id
        }).then((s) => {
          e.atFirst;
        });
      }
    } catch (e2) {
    }
    try {
      e.atFirst === 1 && ttq.track("Purchase", {
        value: Number(e.amount),
        currency: n.state.metaConfig.currency[0].value,
        contents: [
          {
            content_id: e.id,
            price: Number(e.amount),
            quantity: 1
          }
        ]
      }, {
        event_id: "deposit." + e.id
      });
    } catch (e2) {
    }
    try {
      const i = g();
      if (i.bigoPixId) {
        let c = i.bigoPixId;
        bge("event", "ec_purchase", {
          configId: c
        });
      }
    } catch (e2) {
    }
    try {
      gtag("event", "purchase", {
        currency: n.state.metaConfig.currency[0].value,
        value: e.amount,
        transaction_id: e.id
      }), e.atFirst === 1 && gtag("event", "firstPurchase", {
        currency: n.state.metaConfig.currency[0].value,
        value: e.amount,
        transaction_id: e.id
      });
    } catch (e2) {
    }
    try {
      e.atFirst === 1 ? n.state.adjustApi.apiFirstPurchase && Adjust.trackEvent({
        eventToken: n.state.adjustApi.apiFirstPurchase,
        revenue: e.amount,
        currency: e.currency
      }) : n.state.adjustApi.apiPurchase && Adjust.trackEvent({
        eventToken: n.state.adjustApi.apiPurchase,
        revenue: e.amount,
        currency: e.currency
      });
    } catch (e2) {
    }
  };
  q = async function() {
    const e = g();
    let o = e.kwaiPixId || localStorage.getItem("kwaiPixId"), a = e.fbPixId || localStorage.getItem("fbPixelId"), d = e.channelId || localStorage.getItem("channelId");
    if (e.kwaiPixId && localStorage.setItem("kwaiPixId", e.kwaiPixId), e.adAppAId && localStorage.setItem("adAppAId", e.adAppAId), e.adAppAId && e.ggAdid && localStorage.setItem("click_id", e.ggAdid), e.adAppAId && e.idfa && localStorage.setItem("click_id", e.idfa), e.adAppAId && e.adid && localStorage.setItem("adid", e.adid), e.channelId && localStorage.setItem("channelId", e.channelId), e.click_id && d && (localStorage.setItem("click_id", e.click_id), u.get("/game/game/report", {
      _channelId: e.channelId,
      _click_id: e.click_id,
      _type: "init"
    })), d ? (await u.post("/trade/channel/report", {
      channelId: d,
      type: 10
    }), (a || o || e.adAppHId) && await u.get("/trade/channel/data", {
      channelId: d
    }).then((t) => {
      t.status === "OK" && t.data && ((o || a) && (n.state.kwaiToken = t.data.existToken || false), e.fbPixId && (n.state.sendPurchase = t.data.sendPurchase), e.adAppHId && (n.state.adjustApi = {
        apiRegister: t.data.apiRegister,
        apiFirstPurchase: t.data.apiFirstPurchase,
        apiPurchase: t.data.apiPurchase
      }));
    })) : localStorage.removeItem("channelId"), e.fbPixId && !e.rand ? (localStorage.setItem("fbPixelId", a), x(a)) : localStorage.removeItem("fbPixelId"), o && P(o), e.bigoPixId) {
      let t = e.bigoPixId;
      w(t);
    }
    if (e.ttPixId) {
      let t = e.ttPixId;
      b(t);
    }
    if (e.gtagId) {
      let t = e.gtagId;
      v(t);
    }
    if (e.pixel_click_id && e.channelId && e.oksId) {
      let t = e.pixel_click_id, i = e.oksId;
      A(i), localStorage.setItem("pixel_click_id", t), localStorage.setItem("oksId", i);
    }
    if (e.adAppHId) {
      let t = e.adAppHId;
      n.state.haveInitAdjust || S(t);
    }
    if (e.pixel_click_id && e.channelId && e.mgsky) {
      let t = e.pixel_click_id, i = e.channelId, c = e.mgsky;
      if (localStorage.getItem("pixel_click_id") && localStorage.getItem("mgsky")) {
        if (localStorage.getItem("pixel_click_id") === t && localStorage.getItem("mgsky") === c)
          return;
        u.post("/user/channel/pageOpen", {
          clickId: t,
          channelId: i
        });
      } else
        u.post("/user/channel/pageOpen", {
          clickId: t,
          channelId: i
        });
      localStorage.setItem("pixel_click_id", t), localStorage.setItem("mgsky", c);
    }
    if (e.cid && localStorage.setItem("cid", e.cid), e.agentCode ? localStorage.setItem("agentCode", e.agentCode) : localStorage.removeItem("agentCode"), e.dl || e.id || e.pid ? localStorage.setItem("agentId", e.dl || e.id || e.pid) : localStorage.removeItem("agentId"), e.dl || e.agentCode || e.pid || e.id) {
      let t = e.agentCode ? e.agentCode.split("_")[0] : "", i = e.dl ? e.dl.split("_")[0] : "";
      e.id ? i = e.id : e.pid && (i = e.pid), y(t, i);
    }
    e.dealerCode ? localStorage.setItem("dealerCode", e.dealerCode) : localStorage.removeItem("dealerCode");
  };
  C = async function(e) {
    let o = {
      userId: e.data.id
    };
    window.jsAppObj && window.jsAppObj.reportEvent("registration", JSON.stringify(o));
    const a = g();
    try {
      if (a.fbPixId && a.rand && a.fbclid && a.domain) {
        let d = a.fbPixId, t = a.rand, i = a.fbclid, c = a.domain, r = a.utm_medium || 1, l = a.utm_source || 1, s = a.utm_id || 1, p = a.utm_content || 1, m = a.utm_term || 1, f = a.utm_campaign || 1;
        c.indexOf("http") === -1 && (c = "https://" + c), axios({
          method: "get",
          url: "".concat(c, "/facebook/pixed/sendFBregister?rand=").concat(t, "&pixed_id=").concat(d, "&fbclid=").concat(i, "&utm_medium=").concat(r, "&utm_source=").concat(l, "&utm_id=").concat(s, "&utm_content=").concat(p, "&utm_term=").concat(m, "&utm_campaign=").concat(f)
        }).then((I) => {
          console.log("dou peng submit success");
        });
      }
    } catch (e2) {
    }
    try {
      if (a.fbPixId && a.channelId && !n.state.kwaiToken) {
        fbq("track", "CompleteRegistration", {
          customerId: n.state.accountInfo.id,
          customerName: n.state.accountInfo.username,
          method: "username"
        }, {
          eventID: "signin." + n.state.accountInfo.id
        });
        let d = a.channelId;
        u.get("/game/game/report", {
          userid: n.state.accountInfo.id,
          channelid: d,
          paramsType: "register",
          url: location.href
        }).then((t) => {
          "upload fb register pixel";
        });
      }
    } catch (e2) {
    }
    try {
      let d = a.kwaiPixId || localStorage.getItem("kwaiPixId");
      if (d && !n.state.kwaiToken) {
        let t = d;
        kwaiq.instance(t).track("completeRegistration");
      }
    } catch (e2) {
    }
    try {
      ttq.track("CompleteRegistration", {
        content_id: n.state.accountInfo.id
      }, {
        event_id: "signup." + n.state.accountInfo.id
      });
    } catch (e2) {
    }
    try {
      if (a.bigoPixId) {
        let d = a.bigoPixId;
        bge("event", "ec_register", {
          configId: d
        });
      }
    } catch (e2) {
    }
    try {
      gtag("event", "sign_up");
    } catch (e2) {
    }
    try {
      n.state.adjustApi.apiRegister && Adjust.trackEvent({
        eventToken: n.state.adjustApi.apiRegister
      });
    } catch (e2) {
    }
  };
  E = async function(e, o) {
    let a = {
      amount: e,
      currency: n.state.metaConfig.currency[0].label
    };
    window.jsAppObj && window.jsAppObj.reportEvent("createDeposit", JSON.stringify(a));
    try {
      const d = g();
      d.fbPixId && d.channelId && !n.state.kwaiToken && (fbq("track", "InitiateCheckout", {
        customerId: n.state.accountInfo.id,
        customerName: n.state.accountInfo.username,
        currency: n.state.metaConfig.currency[0].value,
        revenue: e,
        value: e
      }, {
        eventID: "startDeposit." + o.ext.orderNo
      }), u.get("/game/game/report", {
        userid: n.state.accountInfo.id,
        channelid: d.channelId,
        orderNo: o.ext.orderNo,
        paramsType: "InitiateCheckout"
      }).then((t) => {
        console.log("open pop success");
      }));
    } catch (e2) {
    }
    try {
      let d = params.kwaiPixId || localStorage.getItem("kwaiPixId");
      if (d && !n.state.kwaiToken) {
        let t = d;
        kwaiq.instance(t).track("addToCart", {
          value: e,
          currency: n.state.metaConfig.currency[0].value
        });
      }
    } catch (e2) {
    }
    try {
      ttq.track("InitiateCheckout", {
        value: e,
        currency: n.state.metaConfig.currency[0].value,
        contents: [
          {
            content_id: o.ext.orderNo,
            price: e,
            quantity: 1
          }
        ]
      }, {
        event_id: "startDeposit." + o.ext.id
      });
    } catch (e2) {
    }
    try {
      const d = g();
      if (d.bigoPixId) {
        let t = d.bigoPixId;
        bge("event", "ec_order", {
          configId: t
        });
      }
    } catch (e2) {
    }
    try {
      gtag("event", "begin_checkout", {
        currency: n.state.metaConfig.currency[0].value,
        value: e,
        debug_mode: true
      });
    } catch (e2) {
    }
  };
  function y(e, o) {
    u.post("/user/user/agentHit", {
      agentCode: e,
      agentId: o
    }).then((a) => {
      a.code === 0 && console.log("\u6709\u9080\u8BF7\u7801\u8FDB\u5165");
    });
  }
  function x(e) {
    (function(o, a, d, t, i, c, r) {
      o.fbq || (i = o.fbq = function() {
        i.callMethod ? i.callMethod.apply(i, arguments) : i.queue.push(arguments);
      }, o._fbq || (o._fbq = i), i.push = i, i.loaded = true, i.version = "2.0", i.queue = [], c = a.createElement(d), c.async = true, c.src = t, r = a.getElementsByTagName(d)[0], r.parentNode.insertBefore(c, r));
    })(window, document, "script", "https://connect.facebook.net/en_US/fbevents.js"), fbq("init", e), console.log("pageView"), fbq("track", "PageView");
  }
  function P(e) {
    let o = document.querySelector("head");
    const a = document.createElement("script");
    a.id = "kwaiq-script-load", a.type = "text/javascript", a.innerHTML = "kwaiq.load(".concat(e, ");kwaiq.page();kwaiq.instance(").concat(e, ").track('contentView')"), o.append(a);
  }
  function b(e) {
    (function(o, a, d) {
      o.TiktokAnalyticsObject = d;
      var t = o[d] = o[d] || [];
      t.methods = [
        "page",
        "track",
        "identify",
        "instances",
        "debug",
        "on",
        "off",
        "once",
        "ready",
        "alias",
        "group",
        "enableCookie",
        "disableCookie"
      ], t.setAndDefer = function(c, r) {
        c[r] = function() {
          c.push([
            r
          ].concat(Array.prototype.slice.call(arguments, 0)));
        };
      };
      for (var i = 0; i < t.methods.length; i++)
        t.setAndDefer(t, t.methods[i]);
      t.instance = function(c) {
        for (var r = t._i[c] || []; r.length > 0; )
          t.apply(null, r.shift());
        return t;
      }, t.load = function(c, r) {
        var l = "https://analytics.tiktok.com/i18n/pixel/events.js";
        t._i = t._i || {}, t._i[c] = [], t._i[c]._u = l, t._t = t._t || {}, t._t[c] = +/* @__PURE__ */ new Date(), t._o = t._o || {}, t._o[c] = r || {};
        var s = document.createElement("script");
        s.type = "text/javascript", s.async = true, s.src = l + "?sdkid=" + c + "&lib=" + d;
        var p = document.getElementsByTagName("script")[0];
        p.parentNode.insertBefore(s, p);
      };
    })(window, document, "ttq"), ttq.load(e), ttq.page();
  }
  function w(e) {
    if (document.getElementById("bigoPixId"))
      return;
    let o = document.querySelector("head");
    const a = document.createElement("script");
    a.src = "https://api.imotech.video/ad/events.js?pixel_id=".concat(e), a.id = "bigoPixId", a.async = true, o.append(a);
  }
  function v(e) {
    if (document.getElementById("gtagId"))
      return;
    let o = document.querySelector("head");
    const a = document.createElement("script");
    a.src = "https://www.googletagmanager.com/gtag/js?id=".concat(e), a.async = true, a.id = "gtagId", o.append(a), a.onload = () => {
      window.dataLayer = window.dataLayer || [], window.gtag = function() {
        dataLayer.push(arguments);
      }, gtag("js", /* @__PURE__ */ new Date()), gtag("config", e);
    };
  }
  function A(e) {
    if (document.getElementById("oksId"))
      return;
    let o = document.querySelector("head");
    const a = document.createElement("script");
    a.src = "https://s.oksp.in/js/tag.js?aa=".concat(e), a.async = true, a.id = "oksId", o.append(a), a.onload = () => {
      window._okTag = window._okTag || [], window._okTag.push({
        eid: "EVENT_CONTENT_VIEW"
      }), localStorage.getItem("EVENT_PWA_OPEN") || (window._okTag.push({
        eid: "EVENT_PWA_OPEN"
      }), localStorage.setItem("EVENT_PWA_OPEN", 1));
    };
  }
  function S(e) {
    Adjust.initSdk({
      appToken: e,
      environment: "production",
      logLevel: "verbose"
    });
  }
});
export {
  __tla,
  C as a,
  E as b,
  q as c,
  T as h
};
