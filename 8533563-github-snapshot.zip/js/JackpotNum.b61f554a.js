import { a8 as x, ad as A, Q as Y, __tla as __tla_0 } from "./index.bb04cb73.js";
import { b as B, u as E } from "./vue-router.c227d4ba.js";
import { u as $ } from "./vuex.33ea5d58.js";
import { u as z, __tla as __tla_1 } from "./useNumberAnimation.b686b495.js";
import { w as C, n as D, e as U, g as F, f as L, o as m, c as f, a as g, _ as J, u as d, R as Z, ab as H, M as Q, L as W, r as h, l as T } from "./@vue.b00de3e9.js";
import "./axios.853f16bf.js";
import "./element-plus.53baa8a9.js";
import "./@element-plus.e21ea623.js";
import "./@ctrl.11979b50.js";
import "./dayjs.9abdbee1.js";
import "./clipboard.aaae98d3.js";
import "./@vueuse.eccd744a.js";
import "./lodash-es.e1022fb5.js";
import "./@popperjs.da591b4f.js";
import "./vant.f7b4805b.js";
import "./@vant.f52f09a9.js";
import "./vue-i18n.07fcbeea.js";
import "./@intlify.928cb664.js";
import "./xe-utils.a532b55a.js";
import "./crypto-js.c184c643.js";
import "./decimal.js.2def1975.js";
import "./nprogress.9fc41f77.js";
import "./vconsole.0cfb1d33.js";
import "./perfect-scrollbar.19f80865.js";
let Dt;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e) {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch (e) {
    }
  })()
]).then(async () => {
  let G, K, O, V, tt, et, v;
  G = {
    class: "count-box"
  };
  K = {
    key: 0,
    class: "count-to"
  };
  O = {
    class: "num"
  };
  V = {
    key: 1,
    class: "notranslate count-to"
  };
  tt = [
    "data-text"
  ];
  et = "2024-01-01T00:00:00Z";
  v = 5e3;
  Dt = {
    __name: "JackpotNum",
    props: [
      "itemInfo",
      "noNumberBg"
    ],
    setup(b) {
      const X = $();
      B();
      const S = E(), a = b, u = h(), c = h(null), M = [
        "0",
        "-.44",
        "-.88",
        "-1.32",
        "-1.76",
        "-2.18",
        "-2.62",
        "-3.06",
        "-3.5",
        "-3.96"
      ], p = h(0), { animatedValue: N } = z(() => p.value || 0, {
        interval: 20
      }), R = T(() => {
        let e = [];
        return u.value && (e = u.value.split("")), e;
      }), j = T(() => a.itemInfo.styleImg);
      C(u, (e, t) => {
        c.value && D(() => {
          const o = document.querySelectorAll(".jackpot-box-".concat(a.itemInfo.showPosition, " .count-to li"));
          if (o.length && !(!t || !t.length))
            if (P(), e.length >= t.length)
              if (e.length > t.length) {
                let i = e.length - t.length;
                for (var r = 0; r < i; r++)
                  t = "7" + t;
                t && t.length && t.split("").forEach((n, s) => {
                  let l = o[s].querySelector("i");
                  (e[s] === "," || e[s] === ".") && (l.style.width = ".22rem", l.style.backgroundPositionY = "0", e[s] === "," && (l.style.backgroundPositionX = "-4.4rem"), e[s] === "." && (l.style.backgroundPositionX = "-4.62rem")), k(n, e[s], l);
                });
              } else
                t && t.length && t.split("").forEach((i, n) => {
                  if (i !== e[n]) {
                    let s = o[n].querySelector("i");
                    (e[n] === "," || e[n] === ".") && (s.style.width = ".22rem", s.style.backgroundPositionY = "0", e[n] === "," && (s.style.backgroundPositionX = "-4.4rem"), e[n] === "." && (s.style.backgroundPositionX = "-4.62rem")), k(i, e[n], s);
                  }
                });
            else
              e.split("").forEach((i, n) => {
                let s = o[n].querySelector("i");
                (i === "," || i === ".") && (s.style.width = ".22rem", s.style.backgroundPositionY = "0", i === "," && (s.style.backgroundPositionX = "-4.4rem"), i === "." && (s.style.backgroundPositionX = "-4.62rem")), k(1, i, s);
              });
        });
      });
      const P = () => {
        const e = document.querySelectorAll(".jackpot-box-".concat(a.itemInfo.showPosition, " .count-to li"));
        for (let t = 0; t < e.length; t++) {
          let o = e[t].dataset.text, r = e[t].querySelector("i");
          r.style.backgroundPosition = q(o), (o === "," || o === ".") && (r.style.width = ".22rem");
        }
      }, q = (e) => {
        let t = "";
        switch (e) {
          case ".":
            t = "-4.62rem 0";
            break;
          case ",":
            t = "-4.4rem 0";
            break;
          case "0":
            t = "0 0";
            break;
          case "1":
            t = "-.44rem 0";
            break;
          case "2":
            t = "-.88rem  0";
            break;
          case "3":
            t = "-1.32rem 0";
            break;
          case "4":
            t = "-1.76rem 0";
            break;
          case "5":
            t = "-2.18rem 0";
            break;
          case "6":
            t = "-2.62rem 0";
            break;
          case "7":
            t = "-3.06rem 0";
            break;
          case "8":
            t = "-3.5rem 0";
            break;
          case "9":
            t = "-3.96rem 0";
            break;
        }
        return t;
      }, k = (e, t, o) => {
        let r = 0, i = setInterval(() => {
          if ((e === "," || e === ".") && (t === "," || t === ".")) {
            o.style.width = ".22rem", o.style.backgroundPositionY = "0", t === "," && (o.style.backgroundPositionX = "-4.4rem"), t === "." && (o.style.backgroundPositionX = "-4.62rem"), clearInterval(i);
            return;
          }
          if (e !== "," && e !== "." && t !== "," && t !== "." && (o.style.width = ".44rem", o.style.backgroundPositionY = "0"), e !== "," && e !== "." && (t === "," || t === ".")) {
            t === "," ? o.style.backgroundPositionX = "-4.4rem" : t === "." && (o.style.backgroundPositionX = "-4.62rem"), o.style.width = ".22rem", o.style.backgroundPositionY = "0", clearInterval(i);
            return;
          }
          e === 0 ? e = 1 : e++, o.style.width = ".44rem", o.style.backgroundPositionX = M[e] + "rem", e >= 9 && (r++, e == t && r === 6 ? clearInterval(i) : e = -1), e == t && r === 6 && clearInterval(i);
        }, 20);
      };
      U(() => {
        y(), typeof document.hidden < "u" && document.addEventListener("visibilitychange", function() {
          document.visibilityState === "visible" ? S.name === "index" && y() : c.value && clearInterval(c.value);
        });
      });
      const I = (e) => {
        const t = (/* @__PURE__ */ new Date("2024-01-01T00:00:00Z")).getTime(), o = Math.max((/* @__PURE__ */ new Date()).getUTCMinutes(), 1) * Math.max((/* @__PURE__ */ new Date()).getUTCHours(), 1) * w()(), r = Math.floor(Date.now() / e) * e;
        let i = Math.floor((r - t) / e) * o;
        const n = a.itemInfo.minAmount + i % (a.itemInfo.maxAmount - a.itemInfo.minAmount + 1);
        return Math.min(n, a.itemInfo.maxAmount).toFixed(2);
      };
      function w() {
        let e = parseInt(new Date(et).getTime()), t = 987654321;
        const o = 4294967295;
        return function() {
          t = 36969 * (t & 65535) + (t >> 16) & o, e = 18e3 * (e & 65535) + (e >> 16) & o;
          let r = (t << 16) + (e & 65535) >>> 0;
          return r /= 2147483648, r;
        };
      }
      F(() => {
        _();
      }), L(() => {
        y();
      });
      const y = () => {
        const e = I(v);
        u.value = x(A(e)), p.value = e, D(() => {
          P();
        }), _(), c.value = setInterval(() => {
          const t = I(v);
          u.value = x(A(t)), p.value = t;
        }, v);
      }, _ = () => {
        c.value && (clearInterval(c.value), c.value = null);
      };
      return (e, t) => (m(), f("div", {
        class: W([
          "jackpot-box",
          "jackpot-box-".concat(b.itemInfo.showPosition, " jackpot-box-").concat(d(X).state.layoutMode)
        ])
      }, [
        g("div", {
          class: "jackpot-box-item",
          style: Q("background-image:url(".concat(j.value, ")"))
        }, [
          g("div", G, [
            b.noNumberBg ? (m(), f("div", K, [
              g("span", O, J(d(Y)(d(N))), 1)
            ])) : (m(), f("ul", V, [
              (m(true), f(Z, null, H(R.value, (o) => (m(), f("li", {
                "data-text": o
              }, [
                ...t[0] || (t[0] = [
                  g("i", {
                    style: {
                      display: "inline-block",
                      position: "relative",
                      "background-position": "-.44rem 0",
                      "background-size": "8.36rem .72rem"
                    }
                  }, null, -1)
                ])
              ], 8, tt))), 256))
            ]))
          ])
        ], 4)
      ], 2));
    }
  };
});
export {
  __tla,
  Dt as default
};
