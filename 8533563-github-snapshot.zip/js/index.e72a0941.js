import { $ as l, t as w, d as b, __tla as __tla_0 } from "./index.bb04cb73.js";
import { u as B } from "./vuex.33ea5d58.js";
import { b as k } from "./vue-router.c227d4ba.js";
import { X as d } from "./xe-utils.a532b55a.js";
import { H as y, e as I, r as m } from "./@vue.b00de3e9.js";
let _;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e) {
    }
  })()
]).then(async () => {
  _ = function() {
    const t = B(), p = k(), g = m(false), u = m("");
    y(() => {
      if (!document.getElementById("googleApi")) {
        const i = document.createElement("script");
        i.id = "googleApi", i.src = "https://accounts.google.com/gsi/client", document.querySelector("head").append(i);
      }
    }), I(() => {
      window.googleLoginBack = (e, i) => {
        let s = {
          alias: "google",
          identityToken: e.credential,
          identity: e.client_id
        };
        if (g.value && (s.forBind = 1), localStorage.getItem("agentId")) {
          let o = localStorage.getItem("agentId").split("_")[0];
          s.agentId = o;
        }
        l.post("/user/oauth/auth", s).then(async (o) => {
          o.code === 0 && (globalVBus.$emit("closeLoginDialog"), globalVBus.$emit("thirdLoginSuccess"), c(o.data));
        });
      }, window.onTelegramAuth = (e) => {
        const i = e.user || e;
        if (!i || !i.id)
          return;
        let s = {
          alias: "telegram",
          identityToken: e.id_token,
          identity: u.value
        };
        if (g.value && (s.forBind = 1), localStorage.getItem("agentId")) {
          let o = localStorage.getItem("agentId").split("_")[0];
          s.agentId = o;
        }
        l.post("/user/oauth/auth", s).then(async (o) => {
          o.code === 0 && (globalVBus.$emit("closeLoginDialog"), globalVBus.$emit("thirdLoginSuccess"), c(o.data));
        });
      };
    });
    const f = (e) => {
      window.fbAsyncInit = function() {
        FB.init({
          appId: e,
          cookie: true,
          xfbml: true,
          version: "v22.0"
        });
      }, function(i, s, o) {
        if (i.getElementById(o))
          return;
        const r = i.createElement(s);
        r.id = o, r.src = "https://connect.facebook.net/en_US/sdk.js";
        const n = i.getElementsByTagName(s)[0];
        n.parentNode.insertBefore(r, n);
      }(document, "script", "facebook-jssdk");
    }, c = async (e, i = "") => {
      w(e.token), localStorage.setItem("haveAccount", 1), t.state.accountInfo = e, e.csLink && e.csLink.length && (t.state.csLink = e.csLink), b("login"), t.state.popDialogList = [], i === "register" ? (t.state.popStep = 99, await t.dispatch("getRegisterPopInfo")) : t.state.popStep = 1, t.state.showLoginDialog = false, await t.dispatch("getNoticeList"), localStorage.setItem("userInfo", JSON.stringify(e)), t.state.goldWheelActivityId && await t.dispatch("goldWheelActivityDetail"), globalVBus.$emit("refreshNewPlayerTask"), globalVBus.$emit("getRankPop"), globalVBus.$emit("getTicketsPop"), globalVBus.$emit("getUnreadMsg"), globalVBus.$emit("refreshGameTypeVendorList"), await t.dispatch("getUserInfo", 1), t.dispatch("getBadge"), t.dispatch("getNewerUnfinished"), await t.dispatch("refreshBalance"), await t.dispatch("getAllBadges"), await t.dispatch("getAllBadgesSelf"), await t.dispatch("checkRedEnvelopes_wg"), await t.dispatch("getVipList"), await t.dispatch("getReliefCheck"), await t.dispatch("getUserVipDetail"), t.state.isApp && l.post("/user/task/shortcut"), d.cookie("promoteRegistrationSysPop", null, {
        expires: -1
      }), d.cookie("bonusWheelDialogPop", null, {
        expires: -1
      }), globalVBus.$emit("resetMineProcess"), globalVBus.$emit("refreshFloatBanner");
    };
    return {
      store: t,
      router: p,
      $http: l,
      handleAfterLogin: c,
      bindGoogle: (e, i, s) => {
        google.accounts.id.initialize({
          client_id: e,
          callback: googleLoginBack
        }), i && (g.value = true);
        let o = s || "google_btn";
        const r = document.getElementById(o);
        google.accounts.id.renderButton(r, {
          theme: "filled_blue"
        });
      },
      bindFacebook: (e, i) => {
        e && FB.login(function(s) {
          if (s.authResponse) {
            const o = s.authResponse.accessToken, r = s.authResponse.userID, n = {
              alias: "facebook",
              identityToken: o,
              identity: r
            };
            i && (n.forBind = 1), l.post("/user/oauth/auth", n).then(async (a) => {
              a.code === 0 && (c(a.data), globalVBus.$emit("thirdLoginSuccess"));
            });
          }
        }, {
          scope: "public_profile,email"
        });
      },
      bindTelegram: (e, i) => {
        if (!e) {
          console.warn("Telegram Client ID \u672A\u914D\u7F6E");
          return;
        }
        if (i && (g.value = true), u.value = e, !document.getElementById("telegramLoginScript")) {
          const n = document.createElement("script");
          n.id = "telegramLoginScript", n.src = "https://telegram.org/js/telegram-login.js", n.async = true, document.head.appendChild(n);
        }
        const o = (n) => {
          if (n.origin !== "https://oauth.telegram.org")
            return;
          let a = n.data;
          if (typeof a == "string" && a.startsWith("tgAuthResult="))
            try {
              a = JSON.parse(a.substring(13));
            } catch (h) {
              console.log("\u89E3\u6790 Telegram \u56DE\u8C03\u6570\u636E\u5931\u8D25:", h);
              return;
            }
          a && (a.id_token || a.user) ? window.onTelegramAuth(a) : a && a.error && console.log("Telegram \u767B\u5F55\u5931\u8D25:", a.error), window.removeEventListener("message", o);
        };
        window.addEventListener("message", o);
        const r = () => {
          window.Telegram && window.Telegram.Login ? window.Telegram.Login.auth({
            client_id: Number(e),
            request_access: [
              "write"
            ],
            lang: localStorage.getItem("language") || "en"
          }, (n) => {
            if (n.error) {
              window.removeEventListener("message", o);
              return;
            }
            if (!n.user || !n.user.id) {
              window.removeEventListener("message", o);
              return;
            }
            window.onTelegramAuth(n), window.removeEventListener("message", o);
          }) : setTimeout(r, 200);
        };
        r();
      },
      initFacebookSDK: f
    };
  };
});
export {
  __tla,
  _ as u
};
