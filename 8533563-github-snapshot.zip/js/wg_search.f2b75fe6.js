import { o, c as s, a as e } from "./@vue.b00de3e9.js";
const r = { xmlns: "http://www.w3.org/2000/svg", "xmlns:xlink": "http://www.w3.org/1999/xlink", width: "1", height: "1", fill: "currentColor" };
function l(n, t) {
  return o(), s("svg", r, [...t[0] || (t[0] = [e("defs", null, [e("symbol", { id: "wg_search__icon_top_ss", viewBox: "0 0 19 20" }, [e("path", { d: "M8.127 2.254a5.9 5.9 0 1 0-.038 11.8 5.9 5.9 0 0 0 .038-11.8m0-2.254A8.156 8.156 0 1 1 0 8.156 8.14 8.14 0 0 1 8.127 0" }), e("path", { d: "M17.105 20a1.08 1.08 0 0 1-.766-.317l-4.709-4.709a1.085 1.085 0 0 1 1.18-1.767q.2.083.352.235l4.709 4.709A1.083 1.083 0 0 1 17.105 20" })])], -1), e("use", { "xlink:href": "#wg_search__icon_top_ss" }, null, -1)])]);
}
const c = { render: l };
export {
  c as default,
  l as render
};
