import { _ as s, __tla as __tla_0 } from "./index.bb04cb73.js";
import { P as u } from "./vant.f7b4805b.js";
import { o as d, J as v, V as _, U as c, u as f, ao as x, l as g } from "./@vue.b00de3e9.js";
import "./vue-router.c227d4ba.js";
import "./axios.853f16bf.js";
import "./element-plus.53baa8a9.js";
import "./@element-plus.e21ea623.js";
import "./@ctrl.11979b50.js";
import "./dayjs.9abdbee1.js";
import "./clipboard.aaae98d3.js";
import "./@vueuse.eccd744a.js";
import "./lodash-es.e1022fb5.js";
import "./@popperjs.da591b4f.js";
import "./vue-i18n.07fcbeea.js";
import "./@intlify.928cb664.js";
import "./vuex.33ea5d58.js";
import "./xe-utils.a532b55a.js";
import "./crypto-js.c184c643.js";
import "./decimal.js.2def1975.js";
import "./nprogress.9fc41f77.js";
import "./vconsole.0cfb1d33.js";
import "./perfect-scrollbar.19f80865.js";
import "./@vant.f52f09a9.js";
let q;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e) {
    }
  })()
]).then(async () => {
  q = {
    __name: "recharge_detail_popup",
    props: {
      item: {
        type: Object,
        default: () => ({})
      },
      zIndex: {
        type: Number,
        default: 1e3
      },
      value: {
        type: Boolean,
        default: false
      }
    },
    emits: [
      "update:value"
    ],
    setup(p, { emit: a }) {
      const r = x(() => s(() => import("./record_detail_dialog.20a71fed.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/record_detail_dialog.20a71fed.js","js/USDC.a2ba449c.js","js/usdt.c352bfdb.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/record_detail_dialog.35afacdf.css"])), l = a, m = p, t = g({
        get() {
          return m.value;
        },
        set(i) {
          l("update:value", i);
        }
      });
      return (i, e) => {
        const n = u;
        return d(), v(n, {
          show: t.value,
          "onUpdate:show": e[2] || (e[2] = (o) => t.value = o),
          position: "bottom",
          closeable: false,
          "z-index": p.zIndex,
          style: {
            height: "calc(100vh - .9rem)"
          },
          class: "online-recharge-detail-popup"
        }, {
          default: _(() => [
            c(f(r), {
              value: t.value,
              "onUpdate:value": e[0] || (e[0] = (o) => t.value = o),
              item: p.item,
              onClose: e[1] || (e[1] = (o) => t.value = false)
            }, null, 8, [
              "value",
              "item"
            ])
          ]),
          _: 1
        }, 8, [
          "show",
          "z-index"
        ]);
      };
    }
  };
});
export {
  __tla,
  q as default
};
