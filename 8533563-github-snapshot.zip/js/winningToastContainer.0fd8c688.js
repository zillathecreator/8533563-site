import { u as p } from "./useWinningToast.fa7f6a2b.js";
import { e as u, o as e, J as _, V as l, c as i, W as c, a as d, _ as f, Y as g, r as v, R as y, ab as x, u as T } from "./@vue.b00de3e9.js";
import { _ as h } from "./cry.d9cd19a0.js";
import { _ as k } from "./xyzp_icon_gglq.56b3b0c7.js";
import { k as m, __tla as __tla_0 } from "./index.bb04cb73.js";
import "./vue-router.c227d4ba.js";
import "./axios.853f16bf.js";
import "./element-plus.53baa8a9.js";
import "./@element-plus.e21ea623.js";
import "./@ctrl.11979b50.js";
import "./dayjs.9abdbee1.js";
import "./clipboard.aaae98d3.js";
import "./@vueuse.eccd744a.js";
import "./lodash-es.e1022fb5.js";
import "./@popperjs.da591b4f.js";
import "./vant.f7b4805b.js";
import "./@vant.f52f09a9.js";
import "./vue-i18n.07fcbeea.js";
import "./@intlify.928cb664.js";
import "./vuex.33ea5d58.js";
import "./xe-utils.a532b55a.js";
import "./crypto-js.c184c643.js";
import "./decimal.js.2def1975.js";
import "./nprogress.9fc41f77.js";
import "./vconsole.0cfb1d33.js";
import "./perfect-scrollbar.19f80865.js";
let ne;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e2) {
    }
  })()
]).then(async () => {
  const w = {
    key: 0,
    class: "toast"
  }, b = {
    key: 0,
    class: "icon",
    src: h
  }, C = {
    key: 1,
    class: "icon",
    src: k
  }, B = {
    class: "text"
  }, I = {
    __name: "winningToast",
    props: {
      message: String,
      icon: {
        type: String,
        default: ""
      },
      duration: {
        type: Number,
        default: 2e3
      }
    },
    setup(o) {
      const s = o, n = v(false);
      return u(() => {
        n.value = true, setTimeout(() => {
          n.value = false;
        }, s.duration);
      }), (r, a) => (e(), _(g, {
        name: "slide-fade"
      }, {
        default: l(() => [
          n.value ? (e(), i("div", w, [
            o.icon === "fail" ? (e(), i("img", b)) : c("", true),
            o.icon === "success" ? (e(), i("img", C)) : c("", true),
            d("span", B, f(o.message), 1)
          ])) : c("", true)
        ]),
        _: 1
      }));
    }
  }, M = m(I, [
    [
      "__scopeId",
      "data-v-cf692c9e"
    ]
  ]);
  let N, S;
  N = {
    class: "toast-wrapper"
  };
  S = {
    __name: "winningToastContainer",
    setup(o) {
      const { queue: s } = p();
      function n(r) {
        const a = s.value.findIndex((t) => t.id === r);
        a !== -1 && s.value.splice(a, 1);
      }
      return (r, a) => (e(), i("div", N, [
        (e(true), i(y, null, x(T(s), (t) => (e(), _(M, {
          key: t.id,
          icon: t.icon,
          message: t.message,
          onMouseleave: (V) => n(t.id)
        }, null, 8, [
          "icon",
          "message",
          "onMouseleave"
        ]))), 128))
      ]));
    }
  };
  ne = m(S, [
    [
      "__scopeId",
      "data-v-069b7e82"
    ]
  ]);
});
export {
  __tla,
  ne as default
};
