import { _ as W } from "./customer_service.4571aa27.js";
import { c as E, __tla as __tla_0 } from "./index.bb04cb73.js";
import { u as b } from "./vuex.33ea5d58.js";
import { e as T, o as g, c as h, u as x, M as X, r as a } from "./@vue.b00de3e9.js";
import "./vue-router.c227d4ba.js";
import "./axios.853f16bf.js";
import "./element-plus.53baa8a9.js";
import "./@element-plus.e21ea623.js";
import "./@ctrl.11979b50.js";
import "./dayjs.9abdbee1.js";
import "./clipboard.aaae98d3.js";
import "./@vueuse.eccd744a.js";
import "./lodash-es.e1022fb5.js";
import "./@popperjs.da591b4f.js";
import "./vant.f7b4805b.js";
import "./@vant.f52f09a9.js";
import "./vue-i18n.07fcbeea.js";
import "./@intlify.928cb664.js";
import "./xe-utils.a532b55a.js";
import "./crypto-js.c184c643.js";
import "./decimal.js.2def1975.js";
import "./nprogress.9fc41f77.js";
import "./vconsole.0cfb1d33.js";
import "./perfect-scrollbar.19f80865.js";
let se;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e) {
    }
  })()
]).then(async () => {
  let q, D;
  q = [
    "src"
  ];
  D = 5;
  se = {
    __name: "drag_customer_service",
    props: [
      "parentDom"
    ],
    setup(k) {
      const d = b(), o = a({}), v = a(null), y = k;
      let n = {
        x: 0,
        y: 0
      }, i = a(false);
      const p = a(false), c = a(false), _ = () => {
        p.value || d.dispatch("goCustomer");
      }, C = (e) => {
        const t = e.touches ? e.touches[0] : e;
        return {
          x: t.clientX,
          y: t.clientY
        };
      }, M = (e) => {
        E() || e.preventDefault(), i.value = true, c.value = false;
        const t = C(e);
        n = {
          x: t.x - o.value.x,
          y: t.y - o.value.y
        }, document.addEventListener("mousemove", u), document.addEventListener("mouseup", l), document.addEventListener("touchmove", u, {
          passive: false
        }), document.addEventListener("touchend", l);
      }, u = (e) => {
        if (!i.value)
          return;
        E() || e.preventDefault();
        const t = C(e);
        if (!c.value) {
          const R = t.x - n.x - o.value.x, S = t.y - n.y - o.value.y;
          if (Math.abs(R) > D || Math.abs(S) > D)
            c.value = true;
          else
            return;
        }
        const r = y.parentDom, m = v.value;
        document.querySelector(".bottomMenu");
        let s = t.x - n.x, f = t.y - n.y;
        const L = r.clientWidth - m.clientWidth, B = r.clientHeight - m.clientHeight;
        s = Math.max(0, Math.min(s, L)), f = Math.max(0, Math.min(f, B)), o.value = {
          x: s,
          y: f
        };
      }, l = (e) => {
        if (c.value) {
          const t = y.parentDom, r = v.value, m = t.clientWidth - r.clientWidth, s = t.clientWidth / 2;
          o.value.x = o.value.x + r.clientWidth / 2 < s ? 10 : m - 10, p.value = true, setTimeout(() => {
            p.value = false;
          }, 200);
        }
        i.value = false, document.removeEventListener("mousemove", u), document.removeEventListener("mouseup", l), document.removeEventListener("touchmove", u), document.removeEventListener("touchend", l);
      };
      return T(() => {
        setTimeout(() => {
          let e = document.querySelector(".drag-customer-service"), t = document.querySelector(".home-page-box");
          e && (o.value.x = e.getBoundingClientRect().left - t.getBoundingClientRect().left, o.value.y = e.getBoundingClientRect().top - t.getBoundingClientRect().top, console.log(o.value.y), e.style.bottom = "auto", e.style.left = "auto");
        }, 500);
      }), (e, t) => (g(), h("div", {
        class: "drag-customer-service",
        ref_key: "dragRef",
        ref: v,
        onMousedown: M,
        onTouchstart: M,
        style: X(o.value.x || x(i) ? {
          left: "".concat(o.value.x, "px"),
          top: "".concat(o.value.y, "px")
        } : "")
      }, [
        x(d).state.customerConfig.av ? (g(), h("img", {
          key: 0,
          src: x(d).state.customerConfig.av,
          alt: "",
          onClick: _
        }, null, 8, q)) : (g(), h("img", {
          key: 1,
          src: W,
          alt: "",
          onClick: _
        }))
      ], 36));
    }
  };
});
export {
  __tla,
  se as default
};
