import { o as r, c as t, a as e } from "./@vue.b00de3e9.js";
const o = { xmlns: "http://www.w3.org/2000/svg", fill: "currentColor", viewBox: "0 0 52 40" };
function l(n, a) {
  return r(), t("svg", o, [...a[0] || (a[0] = [e("g", { id: "wg_side_pink_history__f1e7360d27fbdfd2feb3ac7192283680-icon_sy_zc_lqjl", fill: "currentColor", transform: "translate(5082.123 19238)" }, [e("path", { id: "wg_side_pink_history__f1e7360d27fbdfd2feb3ac7192283680-\u8054\u5408_190", fill: "currentColor", d: "M7324.968 1617.755a10.34 10.34 0 0 1-3.09-7.288v-.109a10.407 10.407 0 0 1 10.294-10.415h.116a10.409 10.409 0 0 1 .112 20.818h-.114a10.35 10.35 0 0 1-7.318-3.006m2.993-8.4a1.49 1.49 0 0 0 .006 2.114l2.546 2.554a2 2 0 0 0 .147.133l.017.02.017.018a1.483 1.483 0 0 0 2.1.057l4.749-4.506a1.51 1.51 0 0 0 .072-2.121 1.49 1.49 0 0 0-1.074-.475 1.47 1.47 0 0 0-1.019.409l-3.706 3.512-1.71-1.714a1.5 1.5 0 0 0-1.058-.442h-.024a1.48 1.48 0 0 0-1.063.436Zm-2.724-11.147v-3.464a1.73 1.73 0 0 1 1.729-1.736h10.41a1.73 1.73 0 0 1 1.732 1.734v3.466l-1.36 1.362a12.2 12.2 0 0 0-3.844-1.224v-3.6h-3.468v3.608a12.3 12.3 0 0 0-3.841 1.224Z", "data-name": "\u8054\u5408 190", transform: "translate(-12388.002 -20824.881)" })], -1)])]);
}
const i = { render: l };
export {
  i as default,
  l as render
};
