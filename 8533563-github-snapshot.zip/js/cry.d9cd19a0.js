const p = "/png/cry.f71f2a87.png";
export {
  p as _
};
