const _ = "/png/btm_menu_wheel.2bb8210e.png";
export {
  _
};
