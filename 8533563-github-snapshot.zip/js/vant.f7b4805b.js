import { u as Qn, r as O, m as Ce, i as Bt, w as Y, k as Ye, d as X, U as c, l as z, K as re, g as st, F as je, Y as At, T as Dt, O as Pe, Z as Re, n as ae, e as Ie, f as Rt, p as rt, R as bn, s as zt, aj as ea, L as ta, ak as na, M as aa, a5 as oa, af as la, aa as ia, a4 as ra } from "./@vue.b00de3e9.js";
import { u as ca, a as me, o as ut, g as sa, b as Se, c as _e, d as yn, r as Je, e as dt, f as ua, h as ft, i as De, C as da, j as _t, k as xn, l as fa, m as va } from "./@vant.f52f09a9.js";
function ma() {
}
const ee = Object.assign, ze = typeof window < "u", vt = (e) => e !== null && typeof e == "object", ne = (e) => e != null, Qe = (e) => typeof e == "function", Vt = (e) => vt(e) && Qe(e.then) && Qe(e.catch), Xt = (e) => Object.prototype.toString.call(e) === "[object Date]" && !Number.isNaN(e.getTime()), wn = (e) => typeof e == "number" || /^\d+(\.\d+)?$/.test(e), ga = () => ze ? /ios|iphone|ipad|ipod/.test(navigator.userAgent.toLowerCase()) : false;
function Zt(e, t) {
  const n = t.split(".");
  let a = e;
  return n.forEach((l) => {
    var o;
    a = vt(a) && (o = a[l]) != null ? o : "";
  }), a;
}
function ge(e, t, n) {
  return t.reduce((a, l) => ((!n || e[l] !== void 0) && (a[l] = e[l]), a), {});
}
const Ne = (e, t) => JSON.stringify(e) === JSON.stringify(t), ct = (e) => Array.isArray(e) ? e : [e], be = null, N = [Number, String], F = { type: Boolean, default: true }, he = (e) => ({ type: e, required: true }), Oe = () => ({ type: Array, default: () => [] }), q = (e) => ({ type: N, default: e }), p = (e) => ({ type: String, default: e });
function mt(e) {
  const t = "scrollTop" in e ? e.scrollTop : e.pageYOffset;
  return Math.max(t, 0);
}
function It(e, t) {
  "scrollTop" in e ? e.scrollTop = t : e.scrollTo(e.scrollX, t);
}
function Lt() {
  return window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
}
function Mt(e) {
  It(window, e), It(document.body, e);
}
function pt(e, t) {
  if (e === window)
    return 0;
  const n = t ? mt(t) : Lt();
  return me(e).top + n;
}
const ha = ga();
function ba() {
  ha && Mt(Lt());
}
const Cn = (e) => e.stopPropagation();
function ye(e, t) {
  (typeof e.cancelable != "boolean" || e.cancelable) && e.preventDefault(), t && Cn(e);
}
function He(e) {
  const t = Qn(e);
  if (!t)
    return false;
  const n = window.getComputedStyle(t), a = n.display === "none", l = t.offsetParent === null && n.position !== "fixed";
  return a || l;
}
const { width: tt, height: gt } = ca();
function le(e) {
  if (ne(e))
    return wn(e) ? "".concat(e, "px") : String(e);
}
function Ft(e) {
  if (ne(e)) {
    if (Array.isArray(e))
      return { width: le(e[0]), height: le(e[1]) };
    const t = le(e);
    return { width: t, height: t };
  }
}
function Nt(e) {
  const t = {};
  return e !== void 0 && (t.zIndex = +e), t;
}
let xt;
function ya() {
  if (!xt) {
    const e = document.documentElement, t = e.style.fontSize || window.getComputedStyle(e).fontSize;
    xt = parseFloat(t);
  }
  return xt;
}
function xa(e) {
  return e = e.replace(/rem/g, ""), +e * ya();
}
function wa(e) {
  return e = e.replace(/vw/g, ""), +e * tt.value / 100;
}
function Ca(e) {
  return e = e.replace(/vh/g, ""), +e * gt.value / 100;
}
function Ht(e) {
  if (typeof e == "number")
    return e;
  if (ze) {
    if (e.includes("rem"))
      return xa(e);
    if (e.includes("vw"))
      return wa(e);
    if (e.includes("vh"))
      return Ca(e);
  }
  return parseFloat(e);
}
const Sa = /-(\w)/g, Sn = (e) => e.replace(Sa, (t, n) => n.toUpperCase());
function Tn(e, t = 2) {
  let n = e + "";
  for (; n.length < t; )
    n = "0" + n;
  return n;
}
const ve = (e, t, n) => Math.min(Math.max(e, t), n);
function Gt(e, t, n) {
  const a = e.indexOf(t);
  return a === -1 ? e : t === "-" && a !== 0 ? e.slice(0, a) : e.slice(0, a + 1) + e.slice(a).replace(n, "");
}
function Ta(e, t = true, n = true) {
  t ? e = Gt(e, ".", /\./g) : e = e.split(".")[0], n ? e = Gt(e, "-", /-/g) : e = e.replace(/-/, "");
  const a = t ? /[^-0-9.]/g : /[^-0-9]/g;
  return e.replace(a, "");
}
const { hasOwnProperty: ka } = Object.prototype;
function $a(e, t, n) {
  const a = t[n];
  ne(a) && (!ka.call(e, n) || !vt(a) ? e[n] = a : e[n] = kn(Object(e[n]), a));
}
function kn(e, t) {
  return Object.keys(t).forEach((n) => {
    $a(e, t, n);
  }), e;
}
var Ia = { name: "\u59D3\u540D", tel: "\u7535\u8BDD", save: "\u4FDD\u5B58", clear: "\u6E05\u7A7A", undo: "\u64A4\u9500", cancel: "\u53D6\u6D88", confirm: "\u786E\u8BA4", delete: "\u5220\u9664", loading: "\u52A0\u8F7D\u4E2D...", noCoupon: "\u6682\u65E0\u4F18\u60E0\u5238", nameEmpty: "\u8BF7\u586B\u5199\u59D3\u540D", addContact: "\u6DFB\u52A0\u8054\u7CFB\u4EBA", telInvalid: "\u8BF7\u586B\u5199\u6B63\u786E\u7684\u7535\u8BDD", vanCalendar: { end: "\u7ED3\u675F", start: "\u5F00\u59CB", title: "\u65E5\u671F\u9009\u62E9", weekdays: ["\u65E5", "\u4E00", "\u4E8C", "\u4E09", "\u56DB", "\u4E94", "\u516D"], monthTitle: (e, t) => "".concat(e, "\u5E74").concat(t, "\u6708"), rangePrompt: (e) => "\u6700\u591A\u9009\u62E9 ".concat(e, " \u5929") }, vanCascader: { select: "\u8BF7\u9009\u62E9" }, vanPagination: { prev: "\u4E0A\u4E00\u9875", next: "\u4E0B\u4E00\u9875" }, vanPullRefresh: { pulling: "\u4E0B\u62C9\u5373\u53EF\u5237\u65B0...", loosing: "\u91CA\u653E\u5373\u53EF\u5237\u65B0..." }, vanSubmitBar: { label: "\u5408\u8BA1:" }, vanCoupon: { unlimited: "\u65E0\u95E8\u69DB", discount: (e) => "".concat(e, "\u6298"), condition: (e) => "\u6EE1".concat(e, "\u5143\u53EF\u7528") }, vanCouponCell: { title: "\u4F18\u60E0\u5238", count: (e) => "".concat(e, "\u5F20\u53EF\u7528") }, vanCouponList: { exchange: "\u5151\u6362", close: "\u4E0D\u4F7F\u7528", enable: "\u53EF\u7528", disabled: "\u4E0D\u53EF\u7528", placeholder: "\u8F93\u5165\u4F18\u60E0\u7801" }, vanAddressEdit: { area: "\u5730\u533A", areaEmpty: "\u8BF7\u9009\u62E9\u5730\u533A", addressEmpty: "\u8BF7\u586B\u5199\u8BE6\u7EC6\u5730\u5740", addressDetail: "\u8BE6\u7EC6\u5730\u5740", defaultAddress: "\u8BBE\u4E3A\u9ED8\u8BA4\u6536\u8D27\u5730\u5740" }, vanAddressList: { add: "\u65B0\u589E\u5730\u5740" } };
const qt = O("zh-CN"), Jt = Ce({ "zh-CN": Ia }), Ea = { messages() {
  return Jt[qt.value];
}, use(e, t) {
  qt.value = e, this.add({ [e]: t });
}, add(e = {}) {
  kn(Jt, e);
} };
var Pa = Ea;
function Oa(e) {
  const t = Sn(e) + ".";
  return (n, ...a) => {
    const l = Pa.messages(), o = Zt(l, t + n) || Zt(l, n);
    return Qe(o) ? o(...a) : o;
  };
}
function Et(e, t) {
  return t ? typeof t == "string" ? " ".concat(e, "--").concat(t) : Array.isArray(t) ? t.reduce((n, a) => n + Et(e, a), "") : Object.keys(t).reduce((n, a) => n + (t[a] ? Et(e, a) : ""), "") : "";
}
function Ba(e) {
  return (t, n) => (t && typeof t != "string" && (n = t, t = ""), t = t ? "".concat(e, "__").concat(t) : e, "".concat(t).concat(Et(t, n)));
}
function W(e) {
  const t = "van-".concat(e);
  return [t, Ba(t), Oa(t)];
}
const ht = "van-hairline", Aa = "".concat(ht, "--right"), Da = "".concat(ht, "--bottom"), Ra = "".concat(ht, "--top-bottom"), za = "".concat(ht, "-unset--top-bottom"), et = "van-haptics-feedback", _a = Symbol("van-form"), Va = 500, Qt = 5;
function bt(e, { args: t = [], done: n, canceled: a, error: l }) {
  if (e) {
    const o = e.apply(null, t);
    Vt(o) ? o.then((d) => {
      d ? n() : a && a();
    }).catch(l || ma) : o ? n() : a && a();
  } else
    n();
}
function te(e) {
  return e.install = (t) => {
    const { name: n } = e;
    n && (t.component(n, e), t.component(Sn("-".concat(n)), e));
  }, e;
}
const $n = Symbol();
function Yt(e) {
  const t = Bt($n, null);
  t && Y(t, (n) => {
    n && e();
  });
}
function ue(e) {
  const t = Ye();
  t && ee(t.proxy, e);
}
const In = { to: [String, Object], url: String, replace: Boolean };
function En({ to: e, url: t, replace: n, $router: a }) {
  e && a ? a[n ? "replace" : "push"](e) : t && (n ? location.replace(t) : location.href = t);
}
function La() {
  const e = Ye().proxy;
  return () => En(e);
}
const [Ma, en] = W("badge"), Fa = { dot: Boolean, max: N, tag: p("div"), color: String, offset: Array, content: N, showZero: F, position: p("top-right") };
var Na = X({ name: Ma, props: Fa, setup(e, { slots: t }) {
  const n = () => {
    if (t.content)
      return true;
    const { content: i, showZero: r } = e;
    return ne(i) && i !== "" && (r || i !== 0 && i !== "0");
  }, a = () => {
    const { dot: i, max: r, content: v } = e;
    if (!i && n())
      return t.content ? t.content() : ne(r) && wn(v) && +v > +r ? "".concat(r, "+") : v;
  }, l = (i) => i.startsWith("-") ? i.replace("-", "") : "-".concat(i), o = z(() => {
    const i = { background: e.color };
    if (e.offset) {
      const [r, v] = e.offset, { position: u } = e, [g, m] = u.split("-");
      t.default ? (typeof v == "number" ? i[g] = le(g === "top" ? v : -v) : i[g] = g === "top" ? le(v) : l(v), typeof r == "number" ? i[m] = le(m === "left" ? r : -r) : i[m] = m === "left" ? le(r) : l(r)) : (i.marginTop = le(v), i.marginLeft = le(r));
    }
    return i;
  }), d = () => {
    if (n() || e.dot)
      return c("div", { class: en([e.position, { dot: e.dot, fixed: !!t.default }]), style: o.value }, [a()]);
  };
  return () => {
    if (t.default) {
      const { tag: i } = e;
      return c(i, { class: en("wrapper") }, { default: () => [t.default(), d()] });
    }
    return d();
  };
} });
const Pn = te(Na);
let Ha = 2e3;
const Ya = () => ++Ha, [ja, Ei] = W("config-provider"), Ua = Symbol(ja), [Ka, tn] = W("icon"), Wa = (e) => e == null ? void 0 : e.includes("/"), Xa = { dot: Boolean, tag: p("i"), name: String, size: N, badge: N, color: String, badgeProps: Object, classPrefix: String };
var Za = X({ name: Ka, props: Xa, setup(e, { slots: t }) {
  const n = Bt(Ua, null), a = z(() => e.classPrefix || (n == null ? void 0 : n.iconPrefix) || tn());
  return () => {
    const { tag: l, dot: o, name: d, size: i, badge: r, color: v } = e, u = Wa(d);
    return c(Pn, re({ dot: o, tag: l, class: [a.value, u ? "" : "".concat(a.value, "-").concat(d)], style: { color: v, fontSize: le(i) }, content: r }, e.badgeProps), { default: () => {
      var g;
      return [(g = t.default) == null ? void 0 : g.call(t), u && c("img", { class: tn("image"), src: d }, null)];
    } });
  };
} });
const fe = te(Za), [pa, Ge] = W("loading"), Ga = Array(12).fill(null).map((e, t) => c("i", { class: Ge("line", String(t + 1)) }, null)), qa = c("svg", { class: Ge("circular"), viewBox: "25 25 50 50" }, [c("circle", { cx: "50", cy: "50", r: "20", fill: "none" }, null)]), Ja = { size: N, type: p("circular"), color: String, vertical: Boolean, textSize: N, textColor: String };
var Qa = X({ name: pa, props: Ja, setup(e, { slots: t }) {
  const n = z(() => ee({ color: e.color }, Ft(e.size))), a = () => {
    const o = e.type === "spinner" ? Ga : qa;
    return c("span", { class: Ge("spinner", e.type), style: n.value }, [t.icon ? t.icon() : o]);
  }, l = () => {
    var o;
    if (t.default)
      return c("span", { class: Ge("text"), style: { fontSize: le(e.textSize), color: (o = e.textColor) != null ? o : e.color } }, [t.default()]);
  };
  return () => {
    const { type: o, vertical: d } = e;
    return c("div", { class: Ge([o, { vertical: d }]), "aria-live": "polite", "aria-busy": true }, [a(), l()]);
  };
} });
const Ue = te(Qa), eo = { show: Boolean, zIndex: N, overlay: F, duration: N, teleport: [String, Object], lockScroll: F, lazyRender: F, beforeClose: Function, overlayProps: Object, overlayStyle: Object, overlayClass: be, transitionAppear: Boolean, closeOnClickOverlay: F };
function to(e, t) {
  return e > t ? "horizontal" : t > e ? "vertical" : "";
}
function Ke() {
  const e = O(0), t = O(0), n = O(0), a = O(0), l = O(0), o = O(0), d = O(""), i = O(true), r = () => d.value === "vertical", v = () => d.value === "horizontal", u = () => {
    n.value = 0, a.value = 0, l.value = 0, o.value = 0, d.value = "", i.value = true;
  };
  return { move: (x) => {
    const y = x.touches[0];
    n.value = (y.clientX < 0 ? 0 : y.clientX) - e.value, a.value = y.clientY - t.value, l.value = Math.abs(n.value), o.value = Math.abs(a.value);
    const C = 10;
    (!d.value || l.value < C && o.value < C) && (d.value = to(l.value, o.value)), i.value && (l.value > Qt || o.value > Qt) && (i.value = false);
  }, start: (x) => {
    u(), e.value = x.touches[0].clientX, t.value = x.touches[0].clientY;
  }, reset: u, startX: e, startY: t, deltaX: n, deltaY: a, offsetX: l, offsetY: o, direction: d, isVertical: r, isHorizontal: v, isTap: i };
}
let We = 0;
const nn = "van-overflow-hidden";
function no(e, t) {
  const n = Ke(), a = "01", l = "10", o = (u) => {
    n.move(u);
    const g = n.deltaY.value > 0 ? l : a, m = sa(u.target, e.value), { scrollHeight: x, offsetHeight: y, scrollTop: C } = m;
    let s = "11";
    C === 0 ? s = y >= x ? "00" : "01" : C + y >= x && (s = "10"), s !== "11" && n.isVertical() && !(parseInt(s, 2) & parseInt(g, 2)) && ye(u, true);
  }, d = () => {
    document.addEventListener("touchstart", n.start), document.addEventListener("touchmove", o, { passive: false }), We || document.body.classList.add(nn), We++;
  }, i = () => {
    We && (document.removeEventListener("touchstart", n.start), document.removeEventListener("touchmove", o), We--, We || document.body.classList.remove(nn));
  }, r = () => t() && d(), v = () => t() && i();
  ut(r), st(v), je(v), Y(t, (u) => {
    u ? d() : i();
  });
}
function On(e) {
  const t = O(false);
  return Y(e, (n) => {
    n && (t.value = n);
  }, { immediate: true }), (n) => () => t.value ? n() : null;
}
const Pt = () => {
  var e;
  const { scopeId: t } = ((e = Ye()) == null ? void 0 : e.vnode) || {};
  return t ? { [t]: "" } : null;
}, [ao, oo] = W("overlay"), lo = { show: Boolean, zIndex: N, duration: N, className: be, lockScroll: F, lazyRender: F, customStyle: Object, teleport: [String, Object] };
var io = X({ name: ao, inheritAttrs: false, props: lo, setup(e, { attrs: t, slots: n }) {
  const a = O(), l = On(() => e.show || !e.lazyRender), o = (i) => {
    e.lockScroll && ye(i, true);
  }, d = l(() => {
    var i;
    const r = ee(Nt(e.zIndex), e.customStyle);
    return ne(e.duration) && (r.animationDuration = "".concat(e.duration, "s")), Pe(c("div", re({ ref: a, style: r, class: [oo(), e.className] }, t), [(i = n.default) == null ? void 0 : i.call(n)]), [[Re, e.show]]);
  });
  return Se("touchmove", o, { target: a }), () => {
    const i = c(At, { name: "van-fade", appear: true }, { default: d });
    return e.teleport ? c(Dt, { to: e.teleport }, { default: () => [i] }) : i;
  };
} });
const ro = te(io), co = ee({}, eo, { round: Boolean, position: p("center"), closeIcon: p("cross"), closeable: Boolean, transition: String, iconPrefix: String, closeOnPopstate: Boolean, closeIconPosition: p("top-right"), destroyOnClose: Boolean, safeAreaInsetTop: Boolean, safeAreaInsetBottom: Boolean }), [so, an] = W("popup");
var uo = X({ name: so, inheritAttrs: false, props: co, emits: ["open", "close", "opened", "closed", "keydown", "update:show", "clickOverlay", "clickCloseIcon"], setup(e, { emit: t, attrs: n, slots: a }) {
  let l, o;
  const d = O(), i = O(), r = On(() => e.show || !e.lazyRender), v = z(() => {
    const $ = { zIndex: d.value };
    if (ne(e.duration)) {
      const U = e.position === "center" ? "animationDuration" : "transitionDuration";
      $[U] = "".concat(e.duration, "s");
    }
    return $;
  }), u = () => {
    l || (l = true, d.value = e.zIndex !== void 0 ? +e.zIndex : Ya(), t("open"));
  }, g = () => {
    l && bt(e.beforeClose, { done() {
      l = false, t("close"), t("update:show", false);
    } });
  }, m = ($) => {
    t("clickOverlay", $), e.closeOnClickOverlay && g();
  }, x = () => {
    if (e.overlay) {
      const $ = ee({ show: e.show, class: e.overlayClass, zIndex: d.value, duration: e.duration, customStyle: e.overlayStyle, role: e.closeOnClickOverlay ? "button" : void 0, tabindex: e.closeOnClickOverlay ? 0 : void 0 }, e.overlayProps);
      return c(ro, re($, Pt(), { onClick: m }), { default: a["overlay-content"] });
    }
  }, y = ($) => {
    t("clickCloseIcon", $), g();
  }, C = () => {
    if (e.closeable)
      return c(fe, { role: "button", tabindex: 0, name: e.closeIcon, class: [an("close-icon", e.closeIconPosition), et], classPrefix: e.iconPrefix, onClick: y }, null);
  };
  let s;
  const S = () => {
    s && clearTimeout(s), s = setTimeout(() => {
      t("opened");
    });
  }, h = () => t("closed"), A = ($) => t("keydown", $), T = r(() => {
    var $;
    const { destroyOnClose: U, round: k, position: _, safeAreaInsetTop: P, safeAreaInsetBottom: D, show: w } = e;
    if (!(!w && U))
      return Pe(c("div", re({ ref: i, style: v.value, role: "dialog", tabindex: 0, class: [an({ round: k, [_]: _ }), { "van-safe-area-top": P, "van-safe-area-bottom": D }], onKeydown: A }, n, Pt()), [($ = a.default) == null ? void 0 : $.call(a), C()]), [[Re, w]]);
  }), b = () => {
    const { position: $, transition: U, transitionAppear: k } = e, _ = $ === "center" ? "van-fade" : "van-popup-slide-".concat($);
    return c(At, { name: U || _, appear: k, onAfterEnter: S, onAfterLeave: h }, { default: T });
  };
  return Y(() => e.show, ($) => {
    $ && !l && (u(), n.tabindex === 0 && ae(() => {
      var U;
      (U = i.value) == null || U.focus();
    })), !$ && l && (l = false, t("close"));
  }), ue({ popupRef: i }), no(i, () => e.show && e.lockScroll), Se("popstate", () => {
    e.closeOnPopstate && (g(), o = false);
  }), Ie(() => {
    e.show && u();
  }), Rt(() => {
    o && (t("update:show", true), o = false);
  }), st(() => {
    e.show && e.teleport && (g(), o = true);
  }), rt($n, () => e.show), () => e.teleport ? c(Dt, { to: e.teleport }, { default: () => [x(), b()] }) : c(bn, null, [x(), b()]);
} });
const Bn = te(uo), [fo, $e, on] = W("picker"), An = (e) => e.find((t) => !t.disabled) || e[0];
function vo(e, t) {
  const n = e[0];
  if (n) {
    if (Array.isArray(n))
      return "multiple";
    if (t.children in n)
      return "cascade";
  }
  return "default";
}
function lt(e, t) {
  t = ve(t, 0, e.length);
  for (let n = t; n < e.length; n++)
    if (!e[n].disabled)
      return n;
  for (let n = t - 1; n >= 0; n--)
    if (!e[n].disabled)
      return n;
  return 0;
}
const ln = (e, t, n) => t !== void 0 && e.some((a) => a[n.value] === t);
function Ot(e, t, n) {
  const a = e.findIndex((o) => o[n.value] === t), l = lt(e, a);
  return e[l];
}
function mo(e, t, n) {
  const a = [];
  let l = { [t.children]: e }, o = 0;
  for (; l && l[t.children]; ) {
    const d = l[t.children], i = n.value[o];
    if (l = ne(i) ? Ot(d, i, t) : void 0, !l && d.length) {
      const r = An(d)[t.value];
      l = Ot(d, r, t);
    }
    o++, a.push(d);
  }
  return a;
}
function go(e) {
  const { transform: t } = window.getComputedStyle(e), n = t.slice(7, t.length - 1).split(", ")[5];
  return Number(n);
}
function ho(e) {
  return ee({ text: "text", value: "value", children: "children" }, e);
}
const rn = 200, cn = 300, bo = 15, [Dn, wt] = W("picker-column"), Rn = Symbol(Dn);
var yo = X({ name: Dn, props: { value: N, fields: he(Object), options: Oe(), readonly: Boolean, allowHtml: Boolean, optionHeight: he(Number), swipeDuration: he(N), visibleOptionNum: he(N) }, emits: ["change", "clickOption", "scrollInto"], setup(e, { emit: t, slots: n }) {
  let a, l, o, d, i;
  const r = O(), v = O(), u = O(0), g = O(0), m = Ke(), x = () => e.options.length, y = () => e.optionHeight * (+e.visibleOptionNum - 1) / 2, C = (P) => {
    let D = lt(e.options, P);
    const w = -D * e.optionHeight, I = () => {
      D > x() - 1 && (D = lt(e.options, P));
      const j = e.options[D][e.fields.value];
      j !== e.value && t("change", j);
    };
    a && w !== u.value ? i = I : I(), u.value = w;
  }, s = () => e.readonly || !e.options.length, S = (P) => {
    a || s() || (i = null, g.value = rn, C(P), t("clickOption", e.options[P]));
  }, h = (P) => ve(Math.round(-P / e.optionHeight), 0, x() - 1), A = z(() => h(u.value)), T = (P, D) => {
    const w = Math.abs(P / D);
    P = u.value + w / 3e-3 * (P < 0 ? -1 : 1);
    const I = h(P);
    g.value = +e.swipeDuration, C(I);
  }, b = () => {
    a = false, g.value = 0, i && (i(), i = null);
  }, $ = (P) => {
    if (!s()) {
      if (m.start(P), a) {
        const D = go(v.value);
        u.value = Math.min(0, D - y());
      }
      g.value = 0, l = u.value, o = Date.now(), d = l, i = null;
    }
  }, U = (P) => {
    if (s())
      return;
    m.move(P), m.isVertical() && (a = true, ye(P, true));
    const D = ve(l + m.deltaY.value, -(x() * e.optionHeight), e.optionHeight), w = h(D);
    w !== A.value && t("scrollInto", e.options[w]), u.value = D;
    const I = Date.now();
    I - o > cn && (o = I, d = D);
  }, k = () => {
    if (s())
      return;
    const P = u.value - d, D = Date.now() - o;
    if (D < cn && Math.abs(P) > bo) {
      T(P, D);
      return;
    }
    const I = h(u.value);
    g.value = rn, C(I), setTimeout(() => {
      a = false;
    }, 0);
  }, _ = () => {
    const P = { height: "".concat(e.optionHeight, "px") };
    return e.options.map((D, w) => {
      const I = D[e.fields.text], { disabled: j } = D, ce = D[e.fields.value], B = { role: "button", style: P, tabindex: j ? -1 : 0, class: [wt("item", { disabled: j, selected: ce === e.value }), D.className], onClick: () => S(w) }, M = { class: "van-ellipsis", [e.allowHtml ? "innerHTML" : "textContent"]: I };
      return c("li", B, [n.option ? n.option(D, w) : c("div", M, null)]);
    });
  };
  return _e(Rn), ue({ stopMomentum: b }), zt(() => {
    const P = a ? Math.floor(-u.value / e.optionHeight) : e.options.findIndex((I) => I[e.fields.value] === e.value), D = lt(e.options, P), w = -D * e.optionHeight;
    a && D < P && b(), u.value = w;
  }), Se("touchmove", U, { target: r }), () => c("div", { ref: r, class: wt(), onTouchstartPassive: $, onTouchend: k, onTouchcancel: k }, [c("ul", { ref: v, style: { transform: "translate3d(0, ".concat(u.value + y(), "px, 0)"), transitionDuration: "".concat(g.value, "ms"), transitionProperty: g.value ? "all" : "none" }, class: wt("wrapper"), onTransitionend: b }, [_()])]);
} });
const [xo] = W("picker-toolbar"), yt = { title: String, cancelButtonText: String, confirmButtonText: String }, wo = ["cancel", "confirm", "title", "toolbar"], Co = Object.keys(yt);
var So = X({ name: xo, props: yt, emits: ["confirm", "cancel"], setup(e, { emit: t, slots: n }) {
  const a = () => {
    if (n.title)
      return n.title();
    if (e.title)
      return c("div", { class: [$e("title"), "van-ellipsis"] }, [e.title]);
  }, l = () => t("cancel"), o = () => t("confirm"), d = () => {
    var r;
    const v = (r = e.cancelButtonText) != null ? r : on("cancel");
    if (!(!n.cancel && !v))
      return c("button", { type: "button", class: [$e("cancel"), et], onClick: l }, [n.cancel ? n.cancel() : v]);
  }, i = () => {
    var r;
    const v = (r = e.confirmButtonText) != null ? r : on("confirm");
    if (!(!n.confirm && !v))
      return c("button", { type: "button", class: [$e("confirm"), et], onClick: o }, [n.confirm ? n.confirm() : v]);
  };
  return () => c("div", { class: $e("toolbar") }, [n.toolbar ? n.toolbar() : [d(), a(), i()]]);
} });
const To = (e, t) => {
  const n = O(e());
  return Y(e, (a) => {
    a !== n.value && (n.value = a);
  }), Y(n, (a) => {
    a !== e() && t(a);
  }), n;
};
function ko(e, t, n) {
  let a, l = 0;
  const o = e.scrollLeft, d = n === 0 ? 1 : Math.round(n * 1e3 / 16);
  let i = o;
  function r() {
    yn(a);
  }
  function v() {
    i += (t - o) / d, e.scrollLeft = i, ++l < d && (a = Je(v));
  }
  return v(), r;
}
function $o(e, t, n, a) {
  let l, o = mt(e);
  const d = o < t, i = n === 0 ? 1 : Math.round(n * 1e3 / 16), r = (t - o) / i;
  function v() {
    yn(l);
  }
  function u() {
    o += r, (d && o > t || !d && o < t) && (o = t), It(e, o), d && o < t || !d && o > t ? l = Je(u) : a && (l = Je(a));
  }
  return u(), v;
}
let Io = 0;
function jt() {
  const e = Ye(), { name: t = "unknown" } = (e == null ? void 0 : e.type) || {};
  return "".concat(t, "-").concat(++Io);
}
function Eo() {
  const e = O([]), t = [];
  return ea(() => {
    e.value = [];
  }), [e, (a) => (t[a] || (t[a] = (l) => {
    e.value[a] = l;
  }), t[a])];
}
function zn(e, t) {
  if (!ze || !window.IntersectionObserver)
    return;
  const n = new IntersectionObserver((o) => {
    t(o[0].intersectionRatio > 0);
  }, { root: document.body }), a = () => {
    e.value && n.observe(e.value);
  }, l = () => {
    e.value && n.unobserve(e.value);
  };
  st(l), je(l), ut(a);
}
const [Po, Oo] = W("sticky"), Bo = { zIndex: N, position: p("top"), container: Object, offsetTop: q(0), offsetBottom: q(0) };
var Ao = X({ name: Po, props: Bo, emits: ["scroll", "change"], setup(e, { emit: t, slots: n }) {
  const a = O(), l = dt(a), o = Ce({ fixed: false, width: 0, height: 0, transform: 0 }), d = O(false), i = z(() => Ht(e.position === "top" ? e.offsetTop : e.offsetBottom)), r = z(() => {
    if (d.value)
      return;
    const { fixed: m, height: x, width: y } = o;
    if (m)
      return { width: "".concat(y, "px"), height: "".concat(x, "px") };
  }), v = z(() => {
    if (!o.fixed || d.value)
      return;
    const m = ee(Nt(e.zIndex), { width: "".concat(o.width, "px"), height: "".concat(o.height, "px"), [e.position]: "".concat(i.value, "px") });
    return o.transform && (m.transform = "translate3d(0, ".concat(o.transform, "px, 0)")), m;
  }), u = (m) => t("scroll", { scrollTop: m, isFixed: o.fixed }), g = () => {
    if (!a.value || He(a))
      return;
    const { container: m, position: x } = e, y = me(a), C = mt(window);
    if (o.width = y.width, o.height = y.height, x === "top")
      if (m) {
        const s = me(m), S = s.bottom - i.value - o.height;
        o.fixed = i.value > y.top && s.bottom > 0, o.transform = S < 0 ? S : 0;
      } else
        o.fixed = i.value > y.top;
    else {
      const { clientHeight: s } = document.documentElement;
      if (m) {
        const S = me(m), h = s - S.top - i.value - o.height;
        o.fixed = s - i.value < y.bottom && s > S.top, o.transform = h < 0 ? -h : 0;
      } else
        o.fixed = s - i.value < y.bottom;
    }
    u(C);
  };
  return Y(() => o.fixed, (m) => t("change", m)), Se("scroll", g, { target: l, passive: true }), zn(a, g), Y([tt, gt], () => {
    !a.value || He(a) || !o.fixed || (d.value = true, ae(() => {
      const m = me(a);
      o.width = m.width, o.height = m.height, d.value = false;
    }));
  }), () => {
    var m;
    return c("div", { ref: a, style: r.value }, [c("div", { class: Oo({ fixed: o.fixed && !d.value }), style: v.value }, [(m = n.default) == null ? void 0 : m.call(n)])]);
  };
} });
const Do = te(Ao), [_n, at] = W("swipe"), Ro = { loop: F, width: N, height: N, vertical: Boolean, autoplay: q(0), duration: q(500), touchable: F, lazyRender: Boolean, initialSwipe: q(0), indicatorColor: String, showIndicators: F, stopPropagation: F }, Vn = Symbol(_n);
var zo = X({ name: _n, props: Ro, emits: ["change", "dragStart", "dragEnd"], setup(e, { emit: t, slots: n }) {
  const a = O(), l = O(), o = Ce({ rect: null, width: 0, height: 0, offset: 0, active: 0, swiping: false });
  let d = false;
  const i = Ke(), { children: r, linkChildren: v } = ft(Vn), u = z(() => r.length), g = z(() => o[e.vertical ? "height" : "width"]), m = z(() => e.vertical ? i.deltaY.value : i.deltaX.value), x = z(() => o.rect ? (e.vertical ? o.rect.height : o.rect.width) - g.value * u.value : 0), y = z(() => g.value ? Math.ceil(Math.abs(x.value) / g.value) : u.value), C = z(() => u.value * g.value), s = z(() => (o.active + u.value) % u.value), S = z(() => {
    const R = e.vertical ? "vertical" : "horizontal";
    return i.direction.value === R;
  }), h = z(() => {
    const R = { transitionDuration: "".concat(o.swiping ? 0 : e.duration, "ms"), transform: "translate".concat(e.vertical ? "Y" : "X", "(").concat(+o.offset.toFixed(2), "px)") };
    if (g.value) {
      const G = e.vertical ? "height" : "width", J = e.vertical ? "width" : "height";
      R[G] = "".concat(C.value, "px"), R[J] = e[J] ? "".concat(e[J], "px") : "";
    }
    return R;
  }), A = (R) => {
    const { active: G } = o;
    return R ? e.loop ? ve(G + R, -1, u.value) : ve(G + R, 0, y.value) : G;
  }, T = (R, G = 0) => {
    let J = R * g.value;
    e.loop || (J = Math.min(J, -x.value));
    let de = G - J;
    return e.loop || (de = ve(de, x.value, 0)), de;
  }, b = ({ pace: R = 0, offset: G = 0, emitChange: J }) => {
    if (u.value <= 1)
      return;
    const { active: de } = o, E = A(R), H = T(E, G);
    if (e.loop) {
      if (r[0] && H !== x.value) {
        const f = H < x.value;
        r[0].setOffset(f ? C.value : 0);
      }
      if (r[u.value - 1] && H !== 0) {
        const f = H > 0;
        r[u.value - 1].setOffset(f ? -C.value : 0);
      }
    }
    o.active = E, o.offset = H, J && E !== de && t("change", s.value);
  }, $ = () => {
    o.swiping = true, o.active <= -1 ? b({ pace: u.value }) : o.active >= u.value && b({ pace: -u.value });
  }, U = () => {
    $(), i.reset(), De(() => {
      o.swiping = false, b({ pace: -1, emitChange: true });
    });
  }, k = () => {
    $(), i.reset(), De(() => {
      o.swiping = false, b({ pace: 1, emitChange: true });
    });
  };
  let _;
  const P = () => clearTimeout(_), D = () => {
    P(), +e.autoplay > 0 && u.value > 1 && (_ = setTimeout(() => {
      k(), D();
    }, +e.autoplay));
  }, w = (R = +e.initialSwipe) => {
    if (!a.value)
      return;
    const G = () => {
      var J, de;
      if (!He(a)) {
        const E = { width: a.value.offsetWidth, height: a.value.offsetHeight };
        o.rect = E, o.width = +((J = e.width) != null ? J : E.width), o.height = +((de = e.height) != null ? de : E.height);
      }
      u.value && (R = Math.min(u.value - 1, R), R === -1 && (R = u.value - 1)), o.active = R, o.swiping = true, o.offset = T(R), r.forEach((E) => {
        E.setOffset(0);
      }), D();
    };
    He(a) ? ae().then(G) : G();
  }, I = () => w(o.active);
  let j;
  const ce = (R) => {
    !e.touchable || R.touches.length > 1 || (i.start(R), d = false, j = Date.now(), P(), $());
  }, B = (R) => {
    e.touchable && o.swiping && (i.move(R), S.value && (!e.loop && (o.active === 0 && m.value > 0 || o.active === u.value - 1 && m.value < 0) || (ye(R, e.stopPropagation), b({ offset: m.value }), d || (t("dragStart", { index: s.value }), d = true))));
  }, M = () => {
    if (!e.touchable || !o.swiping)
      return;
    const R = Date.now() - j, G = m.value / R;
    if ((Math.abs(G) > 0.25 || Math.abs(m.value) > g.value / 2) && S.value) {
      const de = e.vertical ? i.offsetY.value : i.offsetX.value;
      let E = 0;
      e.loop ? E = de > 0 ? m.value > 0 ? -1 : 1 : 0 : E = -Math[m.value > 0 ? "ceil" : "floor"](m.value / g.value), b({ pace: E, emitChange: true });
    } else
      m.value && b({ pace: 0 });
    d = false, o.swiping = false, t("dragEnd", { index: s.value }), D();
  }, K = (R, G = {}) => {
    $(), i.reset(), De(() => {
      let J;
      e.loop && R === u.value ? J = o.active === 0 ? 0 : R : J = R % u.value, G.immediate ? De(() => {
        o.swiping = false;
      }) : o.swiping = false, b({ pace: J - o.active, emitChange: true });
    });
  }, oe = (R, G) => {
    const J = G === s.value, de = J ? { backgroundColor: e.indicatorColor } : void 0;
    return c("i", { style: de, class: at("indicator", { active: J }) }, null);
  }, se = () => {
    if (n.indicator)
      return n.indicator({ active: s.value, total: u.value });
    if (e.showIndicators && u.value > 1)
      return c("div", { class: at("indicators", { vertical: e.vertical }) }, [Array(u.value).fill("").map(oe)]);
  };
  return ue({ prev: U, next: k, state: o, resize: I, swipeTo: K }), v({ size: g, props: e, count: u, activeIndicator: s }), Y(() => e.initialSwipe, (R) => w(+R)), Y(u, () => w(o.active)), Y(() => e.autoplay, D), Y([tt, gt, () => e.width, () => e.height], I), Y(ua(), (R) => {
    R === "visible" ? D() : P();
  }), Ie(w), Rt(() => w(o.active)), Yt(() => w(o.active)), st(P), je(P), Se("touchmove", B, { target: l }), () => {
    var R;
    return c("div", { ref: a, class: at() }, [c("div", { ref: l, style: h.value, class: at("track", { vertical: e.vertical }), onTouchstartPassive: ce, onTouchend: M, onTouchcancel: M }, [(R = n.default) == null ? void 0 : R.call(n)]), se()]);
  };
} });
const Ln = te(zo), [_o, sn] = W("tabs");
var Vo = X({ name: _o, props: { count: he(Number), inited: Boolean, animated: Boolean, duration: he(N), swipeable: Boolean, lazyRender: Boolean, currentIndex: he(Number) }, emits: ["change"], setup(e, { emit: t, slots: n }) {
  const a = O(), l = (i) => t("change", i), o = () => {
    var i;
    const r = (i = n.default) == null ? void 0 : i.call(n);
    return e.animated || e.swipeable ? c(Ln, { ref: a, loop: false, class: sn("track"), duration: +e.duration * 1e3, touchable: e.swipeable, lazyRender: e.lazyRender, showIndicators: false, onChange: l }, { default: () => [r] }) : r;
  }, d = (i) => {
    const r = a.value;
    r && r.state.active !== i && r.swipeTo(i, { immediate: !e.inited });
  };
  return Y(() => e.currentIndex, d), Ie(() => {
    d(e.currentIndex);
  }), ue({ swipeRef: a }), () => c("div", { class: sn("content", { animated: e.animated || e.swipeable }) }, [o()]);
} });
const [Mn, ot] = W("tabs"), Lo = { type: p("line"), color: String, border: Boolean, sticky: Boolean, shrink: Boolean, active: q(0), duration: q(0.3), animated: Boolean, ellipsis: F, swipeable: Boolean, scrollspy: Boolean, offsetTop: q(0), background: String, lazyRender: F, showHeader: F, lineWidth: N, lineHeight: N, beforeChange: Function, swipeThreshold: q(5), titleActiveColor: String, titleInactiveColor: String }, Fn = Symbol(Mn);
var Mo = X({ name: Mn, props: Lo, emits: ["change", "scroll", "rendered", "clickTab", "update:active"], setup(e, { emit: t, slots: n }) {
  let a, l, o, d, i;
  const r = O(), v = O(), u = O(), g = O(), m = jt(), x = dt(r), [y, C] = Eo(), { children: s, linkChildren: S } = ft(Fn), h = Ce({ inited: false, position: "", lineStyle: {}, currentIndex: -1 }), A = z(() => s.length > +e.swipeThreshold || !e.ellipsis || e.shrink), T = z(() => ({ borderColor: e.color, background: e.background })), b = (E, H) => {
    var f;
    return (f = E.name) != null ? f : H;
  }, $ = z(() => {
    const E = s[h.currentIndex];
    if (E)
      return b(E, h.currentIndex);
  }), U = z(() => Ht(e.offsetTop)), k = z(() => e.sticky ? U.value + a : 0), _ = (E) => {
    const H = v.value, f = y.value;
    if (!A.value || !H || !f || !f[h.currentIndex])
      return;
    const V = f[h.currentIndex].$el, L = V.offsetLeft - (H.offsetWidth - V.offsetWidth) / 2;
    d && d(), d = ko(H, L, E ? 0 : +e.duration);
  }, P = () => {
    const E = h.inited;
    ae(() => {
      const H = y.value;
      if (!H || !H[h.currentIndex] || e.type !== "line" || He(r.value))
        return;
      const f = H[h.currentIndex].$el, { lineWidth: V, lineHeight: L } = e, Z = f.offsetLeft + f.offsetWidth / 2, Q = { width: le(V), backgroundColor: e.color, transform: "translateX(".concat(Z, "px) translateX(-50%)") };
      if (E && (Q.transitionDuration = "".concat(e.duration, "s")), ne(L)) {
        const xe = le(L);
        Q.height = xe, Q.borderRadius = xe;
      }
      h.lineStyle = Q;
    });
  }, D = (E) => {
    const H = E < h.currentIndex ? -1 : 1;
    for (; E >= 0 && E < s.length; ) {
      if (!s[E].disabled)
        return E;
      E += H;
    }
  }, w = (E, H) => {
    const f = D(E);
    if (!ne(f))
      return;
    const V = s[f], L = b(V, f), Z = h.currentIndex !== null;
    h.currentIndex !== f && (h.currentIndex = f, H || _(), P()), L !== e.active && (t("update:active", L), Z && t("change", L, V.title)), o && !e.scrollspy && Mt(Math.ceil(pt(r.value) - U.value));
  }, I = (E, H) => {
    const f = s.findIndex((V, L) => b(V, L) === E);
    w(f === -1 ? 0 : f, H);
  }, j = (E = false) => {
    if (e.scrollspy) {
      const H = s[h.currentIndex].$el;
      if (H && x.value) {
        const f = pt(H, x.value) - k.value;
        l = true, i && i(), i = $o(x.value, f, E ? 0 : +e.duration, () => {
          l = false;
        });
      }
    }
  }, ce = (E, H, f) => {
    const { title: V, disabled: L } = s[H], Z = b(s[H], H);
    L || (bt(e.beforeChange, { args: [Z], done: () => {
      w(H), j();
    } }), En(E)), t("clickTab", { name: Z, title: V, event: f, disabled: L });
  }, B = (E) => {
    o = E.isFixed, t("scroll", E);
  }, M = (E) => {
    ae(() => {
      I(E), j(true);
    });
  }, K = () => {
    for (let E = 0; E < s.length; E++) {
      const { top: H } = me(s[E].$el);
      if (H > k.value)
        return E === 0 ? 0 : E - 1;
    }
    return s.length - 1;
  }, oe = () => {
    if (e.scrollspy && !l) {
      const E = K();
      w(E);
    }
  }, se = () => {
    if (e.type === "line" && s.length)
      return c("div", { class: ot("line"), style: h.lineStyle }, null);
  }, R = () => {
    var E, H, f;
    const { type: V, border: L, sticky: Z } = e, Q = [c("div", { ref: Z ? void 0 : u, class: [ot("wrap"), { [Ra]: V === "line" && L }] }, [c("div", { ref: v, role: "tablist", class: ot("nav", [V, { shrink: e.shrink, complete: A.value }]), style: T.value, "aria-orientation": "horizontal" }, [(E = n["nav-left"]) == null ? void 0 : E.call(n), s.map((xe) => xe.renderTitle(ce)), se(), (H = n["nav-right"]) == null ? void 0 : H.call(n)])]), (f = n["nav-bottom"]) == null ? void 0 : f.call(n)];
    return Z ? c("div", { ref: u }, [Q]) : Q;
  }, G = () => {
    P(), ae(() => {
      var E, H;
      _(true), (H = (E = g.value) == null ? void 0 : E.swipeRef.value) == null || H.resize();
    });
  };
  Y(() => [e.color, e.duration, e.lineWidth, e.lineHeight], P), Y(tt, G), Y(() => e.active, (E) => {
    E !== $.value && I(E);
  }), Y(() => s.length, () => {
    h.inited && (I(e.active), P(), ae(() => {
      _(true);
    }));
  });
  const J = () => {
    I(e.active, true), ae(() => {
      h.inited = true, u.value && (a = me(u.value).height), _(true);
    });
  }, de = (E, H) => t("rendered", E, H);
  return ue({ resize: G, scrollTo: M }), Rt(P), Yt(P), ut(J), zn(r, P), Se("scroll", oe, { target: x, passive: true }), S({ id: m, props: e, setLine: P, scrollable: A, onRendered: de, currentName: $, setTitleRefs: C, scrollIntoView: _ }), () => c("div", { ref: r, class: ot([e.type]) }, [e.showHeader ? e.sticky ? c(Do, { container: r.value, offsetTop: U.value, onScroll: B }, { default: () => [R()] }) : R() : null, c(Vo, { ref: g, count: s.length, inited: h.inited, animated: e.animated, duration: e.duration, swipeable: e.swipeable, lazyRender: e.lazyRender, currentIndex: h.currentIndex, onChange: w }, { default: () => {
    var E;
    return [(E = n.default) == null ? void 0 : E.call(n)];
  } })]);
} });
const Fo = Symbol(), Nn = Symbol(), Hn = () => Bt(Nn, null), No = (e) => {
  const t = Hn();
  rt(Fo, e), rt(Nn, z(() => (t == null || t.value) && e.value));
}, [Ho, un] = W("tab"), Yo = X({ name: Ho, props: { id: String, dot: Boolean, type: String, color: String, title: String, badge: N, shrink: Boolean, isActive: Boolean, disabled: Boolean, controls: String, scrollable: Boolean, activeColor: String, inactiveColor: String, showZeroBadge: F }, setup(e, { slots: t }) {
  const n = z(() => {
    const l = {}, { type: o, color: d, disabled: i, isActive: r, activeColor: v, inactiveColor: u } = e;
    d && o === "card" && (l.borderColor = d, i || (r ? l.backgroundColor = d : l.color = d));
    const m = r ? v : u;
    return m && (l.color = m), l;
  }), a = () => {
    const l = c("span", { class: un("text", { ellipsis: !e.scrollable }) }, [t.title ? t.title() : e.title]);
    return e.dot || ne(e.badge) && e.badge !== "" ? c(Pn, { dot: e.dot, content: e.badge, showZero: e.showZeroBadge }, { default: () => [l] }) : l;
  };
  return () => c("div", { id: e.id, role: "tab", class: [un([e.type, { grow: e.scrollable && !e.shrink, shrink: e.shrink, active: e.isActive, disabled: e.disabled }])], style: n.value, tabindex: e.disabled ? void 0 : e.isActive ? 0 : -1, "aria-selected": e.isActive, "aria-disabled": e.disabled || void 0, "aria-controls": e.controls, "data-allow-mismatch": "attribute" }, [a()]);
} }), [jo, Uo] = W("swipe-item");
var Ko = X({ name: jo, setup(e, { slots: t }) {
  let n;
  const a = Ce({ offset: 0, inited: false, mounted: false }), { parent: l, index: o } = _e(Vn);
  if (!l)
    return;
  const d = z(() => {
    const v = {}, { vertical: u } = l.props;
    return l.size.value && (v[u ? "height" : "width"] = "".concat(l.size.value, "px")), a.offset && (v.transform = "translate".concat(u ? "Y" : "X", "(").concat(a.offset, "px)")), v;
  }), i = z(() => {
    const { loop: v, lazyRender: u } = l.props;
    if (!u || n)
      return true;
    if (!a.mounted)
      return false;
    const g = l.activeIndicator.value, m = l.count.value - 1, x = g === 0 && v ? m : g - 1, y = g === m && v ? 0 : g + 1;
    return n = o.value === g || o.value === x || o.value === y, n;
  }), r = (v) => {
    a.offset = v;
  };
  return Ie(() => {
    ae(() => {
      a.mounted = true;
    });
  }), ue({ setOffset: r }), () => {
    var v;
    return c("div", { class: Uo(), style: d.value }, [i.value ? (v = t.default) == null ? void 0 : v.call(t) : null]);
  };
} });
const Yn = te(Ko), [Wo, Ct] = W("tab"), Xo = ee({}, In, { dot: Boolean, name: N, badge: N, title: String, disabled: Boolean, titleClass: be, titleStyle: [String, Object], showZeroBadge: F });
var Zo = X({ name: Wo, props: Xo, setup(e, { slots: t }) {
  const n = jt(), a = O(false), l = Ye(), { parent: o, index: d } = _e(Fn);
  if (!o)
    return;
  const i = () => {
    var y;
    return (y = e.name) != null ? y : d.value;
  }, r = () => {
    a.value = true, o.props.lazyRender && ae(() => {
      o.onRendered(i(), e.title);
    });
  }, v = z(() => {
    const y = i() === o.currentName.value;
    return y && !a.value && r(), y;
  }), u = O(""), g = O("");
  zt(() => {
    const { titleClass: y, titleStyle: C } = e;
    u.value = y ? ta(y) : "", g.value = C && typeof C != "string" ? na(aa(C)) : C;
  });
  const m = (y) => c(Yo, re({ key: n, id: "".concat(o.id, "-").concat(d.value), ref: o.setTitleRefs(d.value), style: g.value, class: u.value, isActive: v.value, controls: n, scrollable: o.scrollable.value, activeColor: o.props.titleActiveColor, inactiveColor: o.props.titleInactiveColor, onClick: (C) => y(l.proxy, d.value, C) }, ge(o.props, ["type", "color", "shrink"]), ge(e, ["dot", "badge", "title", "disabled", "showZeroBadge"])), { title: t.title }), x = O(!v.value);
  return Y(v, (y) => {
    y ? x.value = false : De(() => {
      x.value = true;
    });
  }), Y(() => e.title, () => {
    o.setLine(), o.scrollIntoView();
  }), No(v), ue({ id: n, renderTitle: m }), () => {
    var y;
    const C = "".concat(o.id, "-").concat(d.value), { animated: s, swipeable: S, scrollspy: h, lazyRender: A } = o.props;
    if (!t.default && !s)
      return;
    const T = h || v.value;
    if (s || S)
      return c(Yn, { id: n, role: "tabpanel", class: Ct("panel-wrapper", { inactive: x.value }), tabindex: v.value ? 0 : -1, "aria-hidden": !v.value, "aria-labelledby": C, "data-allow-mismatch": "attribute" }, { default: () => {
        var U;
        return [c("div", { class: Ct("panel") }, [(U = t.default) == null ? void 0 : U.call(t)])];
      } });
    const $ = a.value || h || !A ? (y = t.default) == null ? void 0 : y.call(t) : null;
    return Pe(c("div", { id: n, role: "tabpanel", class: Ct("panel"), tabindex: T ? 0 : -1, "aria-labelledby": C, "data-allow-mismatch": "attribute" }, [$]), [[Re, T]]);
  };
} });
const Pi = te(Zo), Oi = te(Mo), [po, Bi] = W("picker-group"), Go = Symbol(po);
ee({ tabs: Oe(), activeTab: q(0), nextStepText: String, showToolbar: F }, yt);
const Ut = ee({ loading: Boolean, readonly: Boolean, allowHtml: Boolean, optionHeight: q(44), showToolbar: F, swipeDuration: q(1e3), visibleOptionNum: q(6) }, yt), qo = ee({}, Ut, { columns: Oe(), modelValue: Oe(), toolbarPosition: p("top"), columnsFieldNames: Object });
var Jo = X({ name: fo, props: qo, emits: ["confirm", "cancel", "change", "scrollInto", "clickOption", "update:modelValue"], setup(e, { emit: t, slots: n }) {
  const a = O(), l = O(e.modelValue.slice(0)), { parent: o } = _e(Go), { children: d, linkChildren: i } = ft(Rn);
  i();
  const r = z(() => ho(e.columnsFieldNames)), v = z(() => Ht(e.optionHeight)), u = z(() => vo(e.columns, r.value)), g = z(() => {
    const { columns: w } = e;
    switch (u.value) {
      case "multiple":
        return w;
      case "cascade":
        return mo(w, r.value, l);
      default:
        return [w];
    }
  }), m = z(() => g.value.some((w) => w.length)), x = z(() => g.value.map((w, I) => Ot(w, l.value[I], r.value))), y = z(() => g.value.map((w, I) => w.findIndex((j) => j[r.value.value] === l.value[I]))), C = (w, I) => {
    if (l.value[w] !== I) {
      const j = l.value.slice(0);
      j[w] = I, l.value = j;
    }
  }, s = () => ({ selectedValues: l.value.slice(0), selectedOptions: x.value, selectedIndexes: y.value }), S = (w, I) => {
    C(I, w), u.value === "cascade" && l.value.forEach((j, ce) => {
      const B = g.value[ce];
      ln(B, j, r.value) || C(ce, B.length ? B[0][r.value.value] : void 0);
    }), ae(() => {
      t("change", ee({ columnIndex: I }, s()));
    });
  }, h = (w, I) => {
    const j = { columnIndex: I, currentOption: w };
    t("clickOption", ee(s(), j)), t("scrollInto", j);
  }, A = () => {
    d.forEach((I) => I.stopMomentum());
    const w = s();
    return ae(() => {
      const I = s();
      t("confirm", I);
    }), w;
  }, T = () => t("cancel", s()), b = () => g.value.map((w, I) => c(yo, { value: l.value[I], fields: r.value, options: w, readonly: e.readonly, allowHtml: e.allowHtml, optionHeight: v.value, swipeDuration: e.swipeDuration, visibleOptionNum: e.visibleOptionNum, onChange: (j) => S(j, I), onClickOption: (j) => h(j, I), onScrollInto: (j) => {
    t("scrollInto", { currentOption: j, columnIndex: I });
  } }, { option: n.option })), $ = (w) => {
    if (m.value) {
      const I = { height: "".concat(v.value, "px") }, j = { backgroundSize: "100% ".concat((w - v.value) / 2, "px") };
      return [c("div", { class: $e("mask"), style: j }, null), c("div", { class: [za, $e("frame")], style: I }, null)];
    }
  }, U = () => {
    const w = v.value * +e.visibleOptionNum, I = { height: "".concat(w, "px") };
    return !e.loading && !m.value && n.empty ? n.empty() : c("div", { ref: a, class: $e("columns"), style: I }, [b(), $(w)]);
  }, k = () => {
    if (e.showToolbar && !o)
      return c(So, re(ge(e, Co), { onConfirm: A, onCancel: T }), ge(n, wo));
  }, _ = (w) => {
    w.forEach((I, j) => {
      I.length && !ln(I, l.value[j], r.value) && C(j, An(I)[r.value.value]);
    });
  };
  Y(g, (w) => _(w), { immediate: true });
  let P;
  return Y(() => e.modelValue, (w) => {
    !Ne(w, l.value) && !Ne(w, P) && (l.value = w.slice(0), P = w.slice(0)), e.modelValue.length === 0 && _(g.value);
  }, { deep: true }), Y(l, (w) => {
    Ne(w, e.modelValue) || (P = w.slice(0), t("update:modelValue", P));
  }, { immediate: true }), Se("touchmove", ye, { target: a }), ue({ confirm: A, getSelectedOptions: () => x.value }), () => {
    var w, I;
    return c("div", { class: $e() }, [e.toolbarPosition === "top" ? k() : null, e.loading ? c(Ue, { class: $e("loading") }, null) : null, (w = n["columns-top"]) == null ? void 0 : w.call(n), U(), (I = n["columns-bottom"]) == null ? void 0 : I.call(n), e.toolbarPosition === "bottom" ? k() : null]);
  };
} });
const Qo = te(Jo), [el, Ve] = W("cell"), jn = { tag: p("div"), icon: String, size: String, title: N, value: N, label: N, center: Boolean, isLink: Boolean, border: F, iconPrefix: String, valueClass: be, labelClass: be, titleClass: be, titleStyle: null, arrowDirection: String, required: { type: [Boolean, String], default: null }, clickable: { type: Boolean, default: null } }, tl = ee({}, jn, In);
var nl = X({ name: el, props: tl, setup(e, { slots: t }) {
  const n = La(), a = () => {
    if (t.label || ne(e.label))
      return c("div", { class: [Ve("label"), e.labelClass] }, [t.label ? t.label() : e.label]);
  }, l = () => {
    var r;
    if (t.title || ne(e.title)) {
      const v = (r = t.title) == null ? void 0 : r.call(t);
      return Array.isArray(v) && v.length === 0 ? void 0 : c("div", { class: [Ve("title"), e.titleClass], style: e.titleStyle }, [v || c("span", null, [e.title]), a()]);
    }
  }, o = () => {
    const r = t.value || t.default;
    if (r || ne(e.value))
      return c("div", { class: [Ve("value"), e.valueClass] }, [r ? r() : c("span", null, [e.value])]);
  }, d = () => {
    if (t.icon)
      return t.icon();
    if (e.icon)
      return c(fe, { name: e.icon, class: Ve("left-icon"), classPrefix: e.iconPrefix }, null);
  }, i = () => {
    if (t["right-icon"])
      return t["right-icon"]();
    if (e.isLink) {
      const r = e.arrowDirection && e.arrowDirection !== "right" ? "arrow-".concat(e.arrowDirection) : "arrow";
      return c(fe, { name: r, class: Ve("right-icon") }, null);
    }
  };
  return () => {
    var r;
    const { tag: v, size: u, center: g, border: m, isLink: x, required: y } = e, C = (r = e.clickable) != null ? r : x, s = { center: g, required: !!y, clickable: C, borderless: !m };
    return u && (s[u] = !!u), c(v, { class: Ve(s), role: C ? "button" : void 0, tabindex: C ? 0 : void 0, onClick: n }, { default: () => {
      var S;
      return [d(), l(), o(), i(), (S = t.extra) == null ? void 0 : S.call(t)];
    } });
  };
} });
const al = te(nl);
function Un(e) {
  return Array.isArray(e) ? !e.length : e === 0 ? false : !e;
}
function ol(e, t) {
  if (Un(e)) {
    if (t.required)
      return false;
    if (t.validateEmpty === false)
      return true;
  }
  return !(t.pattern && !t.pattern.test(String(e)));
}
function ll(e, t) {
  return new Promise((n) => {
    const a = t.validator(e, t);
    if (Vt(a)) {
      a.then(n);
      return;
    }
    n(a);
  });
}
function dn(e, t) {
  const { message: n } = t;
  return Qe(n) ? n(e, t) : n || "";
}
function il({ target: e }) {
  e.composing = true;
}
function fn({ target: e }) {
  e.composing && (e.composing = false, e.dispatchEvent(new Event("input")));
}
function rl(e, t) {
  const n = Lt();
  e.style.height = "auto";
  let a = e.scrollHeight;
  if (vt(t)) {
    const { maxHeight: l, minHeight: o } = t;
    l !== void 0 && (a = Math.min(a, l)), o !== void 0 && (a = Math.max(a, o));
  }
  a && (e.style.height = "".concat(a, "px"), Mt(n));
}
function cl(e, t) {
  return e === "number" && (e = "text", t != null ? t : t = "decimal"), e === "digit" && (e = "tel", t != null ? t : t = "numeric"), { type: e, inputmode: t };
}
function Xe(e) {
  return [...e].length;
}
function St(e, t) {
  return [...e].slice(0, t).join("");
}
const [sl, we] = W("field"), ul = { id: String, name: String, leftIcon: String, rightIcon: String, autofocus: Boolean, clearable: Boolean, maxlength: N, max: Number, min: Number, formatter: Function, clearIcon: p("clear"), modelValue: q(""), inputAlign: String, placeholder: String, autocomplete: String, autocapitalize: String, autocorrect: String, errorMessage: String, enterkeyhint: String, clearTrigger: p("focus"), formatTrigger: p("onChange"), spellcheck: { type: Boolean, default: null }, error: { type: Boolean, default: null }, disabled: { type: Boolean, default: null }, readonly: { type: Boolean, default: null }, inputmode: String }, dl = ee({}, jn, ul, { rows: N, type: p("text"), rules: Array, autosize: [Boolean, Object], labelWidth: N, labelClass: be, labelAlign: String, showWordLimit: Boolean, errorMessageAlign: String, colon: { type: Boolean, default: null } });
var fl = X({ name: sl, props: dl, emits: ["blur", "focus", "clear", "keypress", "clickInput", "endValidate", "startValidate", "clickLeftIcon", "clickRightIcon", "update:modelValue"], setup(e, { emit: t, slots: n }) {
  const a = jt(), l = Ce({ status: "unvalidated", focused: false, validateMessage: "" }), o = O(), d = O(), i = O(), { parent: r } = _e(_a), v = () => {
    var f;
    return String((f = e.modelValue) != null ? f : "");
  }, u = (f) => {
    if (ne(e[f]))
      return e[f];
    if (r && ne(r.props[f]))
      return r.props[f];
  }, g = z(() => {
    const f = u("readonly");
    if (e.clearable && !f) {
      const V = v() !== "", L = e.clearTrigger === "always" || e.clearTrigger === "focus" && l.focused;
      return V && L;
    }
    return false;
  }), m = z(() => i.value && n.input ? i.value() : e.modelValue), x = z(() => {
    var f;
    const V = u("required");
    return V === "auto" ? (f = e.rules) == null ? void 0 : f.some((L) => L.required) : V;
  }), y = (f) => f.reduce((V, L) => V.then(() => {
    if (l.status === "failed")
      return;
    let { value: Z } = m;
    if (L.formatter && (Z = L.formatter(Z, L)), !ol(Z, L)) {
      l.status = "failed", l.validateMessage = dn(Z, L);
      return;
    }
    if (L.validator)
      return Un(Z) && L.validateEmpty === false ? void 0 : ll(Z, L).then((Q) => {
        Q && typeof Q == "string" ? (l.status = "failed", l.validateMessage = Q) : Q === false && (l.status = "failed", l.validateMessage = dn(Z, L));
      });
  }), Promise.resolve()), C = () => {
    l.status = "unvalidated", l.validateMessage = "";
  }, s = () => t("endValidate", { status: l.status, message: l.validateMessage }), S = (f = e.rules) => new Promise((V) => {
    C(), f ? (t("startValidate"), y(f).then(() => {
      l.status === "failed" ? (V({ name: e.name, message: l.validateMessage }), s()) : (l.status = "passed", V(), s());
    })) : V();
  }), h = (f) => {
    if (r && e.rules) {
      const { validateTrigger: V } = r.props, L = ct(V).includes(f), Z = e.rules.filter((Q) => Q.trigger ? ct(Q.trigger).includes(f) : L);
      Z.length && S(Z);
    }
  }, A = (f) => {
    var V;
    const { maxlength: L } = e;
    if (ne(L) && Xe(f) > +L) {
      const Z = v();
      if (Z && Xe(Z) === +L)
        return Z;
      let Q = (V = o.value) == null ? void 0 : V.selectionEnd;
      if (l.focused && Q) {
        const xe = [...f], Be = xe.length - +L;
        return Q = Xe(f.slice(0, Q)), xe.splice(Q - Be, Be), xe.join("");
      }
      return St(f, +L);
    }
    return f;
  }, T = (f, V = "onChange") => {
    var L, Z;
    const Q = f;
    f = A(f);
    const xe = Q.length - f.length;
    if (e.type === "number" || e.type === "digit") {
      const ke = e.type === "number";
      if (f = Ta(f, ke, ke), V === "onBlur" && f !== "" && (e.min !== void 0 || e.max !== void 0)) {
        const Te = ve(+f, (L = e.min) != null ? L : -1 / 0, (Z = e.max) != null ? Z : 1 / 0);
        +f !== Te && (f = Te.toString());
      }
    }
    let Be = 0;
    if (e.formatter && V === e.formatTrigger) {
      const { formatter: ke, maxlength: Te } = e;
      if (f = ke(f), ne(Te) && Xe(f) > +Te && (f = St(f, +Te)), o.value && l.focused) {
        const { selectionEnd: nt } = o.value, Wt = St(Q, nt);
        Be = ke(Wt).length - Wt.length;
      }
    }
    if (o.value && o.value.value !== f)
      if (l.focused) {
        let { selectionStart: ke, selectionEnd: Te } = o.value;
        if (o.value.value = f, ne(ke) && ne(Te)) {
          const nt = f.length;
          xe ? (ke -= xe, Te -= xe) : Be && (ke += Be, Te += Be), o.value.setSelectionRange(Math.min(ke, nt), Math.min(Te, nt));
        }
      } else
        o.value.value = f;
    f !== e.modelValue && t("update:modelValue", f);
  }, b = (f) => {
    f.target.composing || T(f.target.value);
  }, $ = () => {
    var f;
    return (f = o.value) == null ? void 0 : f.blur();
  }, U = () => {
    var f;
    return (f = o.value) == null ? void 0 : f.focus();
  }, k = () => {
    const f = o.value;
    e.type === "textarea" && e.autosize && f && rl(f, e.autosize);
  }, _ = (f) => {
    l.focused = true, t("focus", f), ae(k), u("readonly") && $();
  }, P = (f) => {
    l.focused = false, T(v(), "onBlur"), t("blur", f), !u("readonly") && (h("onBlur"), ae(k), ba());
  }, D = (f) => t("clickInput", f), w = (f) => t("clickLeftIcon", f), I = (f) => t("clickRightIcon", f), j = (f) => {
    ye(f), t("update:modelValue", ""), t("clear", f);
  }, ce = z(() => {
    if (typeof e.error == "boolean")
      return e.error;
    if (r && r.props.showError && l.status === "failed")
      return true;
  }), B = z(() => {
    const f = u("labelWidth"), V = u("labelAlign");
    if (f && V !== "top")
      return { width: le(f) };
  }), M = (f) => {
    f.keyCode === 13 && (!(r && r.props.submitOnEnter) && e.type !== "textarea" && ye(f), e.type === "search" && $()), t("keypress", f);
  }, K = () => e.id || "".concat(a, "-input"), oe = () => l.status, se = () => {
    const f = we("control", [u("inputAlign"), { error: ce.value, custom: !!n.input, "min-height": e.type === "textarea" && !e.autosize }]);
    if (n.input)
      return c("div", { class: f, onClick: D }, [n.input()]);
    const V = { id: K(), ref: o, name: e.name, rows: e.rows !== void 0 ? +e.rows : void 0, class: f, disabled: u("disabled"), readonly: u("readonly"), autofocus: e.autofocus, placeholder: e.placeholder, autocomplete: e.autocomplete, autocapitalize: e.autocapitalize, autocorrect: e.autocorrect, enterkeyhint: e.enterkeyhint, spellcheck: e.spellcheck, "aria-labelledby": e.label ? "".concat(a, "-label") : void 0, "data-allow-mismatch": "attribute", onBlur: P, onFocus: _, onInput: b, onClick: D, onChange: fn, onKeypress: M, onCompositionend: fn, onCompositionstart: il };
    return e.type === "textarea" ? c("textarea", re(V, { inputmode: e.inputmode }), null) : c("input", re(cl(e.type, e.inputmode), V), null);
  }, R = () => {
    const f = n["left-icon"];
    if (e.leftIcon || f)
      return c("div", { class: we("left-icon"), onClick: w }, [f ? f() : c(fe, { name: e.leftIcon, classPrefix: e.iconPrefix }, null)]);
  }, G = () => {
    const f = n["right-icon"];
    if (e.rightIcon || f)
      return c("div", { class: we("right-icon"), onClick: I }, [f ? f() : c(fe, { name: e.rightIcon, classPrefix: e.iconPrefix }, null)]);
  }, J = () => {
    if (e.showWordLimit && e.maxlength) {
      const f = Xe(v());
      return c("div", { class: we("word-limit") }, [c("span", { class: we("word-num") }, [f]), oa("/"), e.maxlength]);
    }
  }, de = () => {
    if (r && r.props.showErrorMessage === false)
      return;
    const f = e.errorMessage || l.validateMessage;
    if (f) {
      const V = n["error-message"], L = u("errorMessageAlign");
      return c("div", { class: we("error-message", L) }, [V ? V({ message: f }) : f]);
    }
  }, E = () => {
    const f = u("labelWidth"), V = u("labelAlign"), L = u("colon") ? ":" : "";
    if (n.label)
      return [n.label(), L];
    if (e.label)
      return c("label", { id: "".concat(a, "-label"), for: n.input ? void 0 : K(), "data-allow-mismatch": "attribute", onClick: (Z) => {
        ye(Z), U();
      }, style: V === "top" && f ? { width: le(f) } : void 0 }, [e.label + L]);
  }, H = () => [c("div", { class: we("body") }, [se(), g.value && c(fe, { ref: d, name: e.clearIcon, class: we("clear") }, null), G(), n.button && c("div", { class: we("button") }, [n.button()])]), J(), de()];
  return ue({ blur: $, focus: U, validate: S, formValue: m, resetValidation: C, getValidationStatus: oe }), rt(da, { customValue: i, resetValidation: C, validateWithTrigger: h }), Y(() => e.modelValue, () => {
    T(v()), C(), h("onChange"), ae(k);
  }), Ie(() => {
    T(v(), e.formatTrigger), ae(k);
  }), Se("touchstart", j, { target: z(() => {
    var f;
    return (f = d.value) == null ? void 0 : f.$el;
  }) }), () => {
    const f = u("disabled"), V = u("labelAlign"), L = R(), Z = () => {
      const Q = E();
      return V === "top" ? [L, Q].filter(Boolean) : Q || [];
    };
    return c(al, { size: e.size, class: we({ error: ce.value, disabled: f, ["label-".concat(V)]: V }), center: e.center, border: e.border, isLink: e.isLink, clickable: e.clickable, titleStyle: B.value, valueClass: we("value"), titleClass: [we("label", [V, { required: x.value }]), e.labelClass], arrowDirection: e.arrowDirection }, { icon: L && V !== "top" ? () => L : null, title: Z, value: H, extra: n.extra });
  };
} });
const Ai = te(fl);
function vl() {
  const e = Ce({ show: false }), t = (l) => {
    e.show = l;
  }, n = (l) => {
    ee(e, l, { transitionAppear: true }), t(true);
  }, a = () => t(false);
  return ue({ open: n, close: a, toggle: t }), { open: n, close: a, state: e, toggle: t };
}
function ml(e) {
  const t = la(e), n = document.createElement("div");
  return document.body.appendChild(n), { instance: t.mount(n), unmount() {
    t.unmount(), document.body.removeChild(n);
  } };
}
const [Kn, gl] = W("radio-group"), hl = { shape: String, disabled: Boolean, iconSize: N, direction: String, modelValue: be, checkedColor: String }, Wn = Symbol(Kn);
var bl = X({ name: Kn, props: hl, emits: ["change", "update:modelValue"], setup(e, { emit: t, slots: n }) {
  const { linkChildren: a } = ft(Wn), l = (o) => t("update:modelValue", o);
  return Y(() => e.modelValue, (o) => t("change", o)), a({ props: e, updateValue: l }), _t(() => e.modelValue), () => {
    var o;
    return c("div", { class: gl([e.direction]), role: "radiogroup" }, [(o = n.default) == null ? void 0 : o.call(n)]);
  };
} });
const Di = te(bl), [yl, Ri] = W("checkbox-group"), xl = Symbol(yl), Kt = { name: be, disabled: Boolean, iconSize: N, modelValue: be, checkedColor: String, labelPosition: String, labelDisabled: Boolean };
var Xn = X({ props: ee({}, Kt, { bem: he(Function), role: String, shape: String, parent: Object, checked: Boolean, bindGroup: F, indeterminate: { type: Boolean, default: null } }), emits: ["click", "toggle"], setup(e, { emit: t, slots: n }) {
  const a = O(), l = (m) => {
    if (e.parent && e.bindGroup)
      return e.parent.props[m];
  }, o = z(() => {
    if (e.parent && e.bindGroup) {
      const m = l("disabled") || e.disabled;
      if (e.role === "checkbox") {
        const x = l("modelValue").length, y = l("max"), C = y && x >= +y;
        return m || C && !e.checked;
      }
      return m;
    }
    return e.disabled;
  }), d = z(() => l("direction")), i = z(() => {
    const m = e.checkedColor || l("checkedColor");
    if (m && (e.checked || e.indeterminate) && !o.value)
      return { borderColor: m, backgroundColor: m };
  }), r = z(() => e.shape || l("shape") || "round"), v = (m) => {
    const { target: x } = m, y = a.value, C = y === x || (y == null ? void 0 : y.contains(x));
    !o.value && (C || !e.labelDisabled) && t("toggle"), t("click", m);
  }, u = () => {
    var m, x;
    const { bem: y, checked: C, indeterminate: s } = e, S = e.iconSize || l("iconSize");
    return c("div", { ref: a, class: y("icon", [r.value, { disabled: o.value, checked: C, indeterminate: s }]), style: r.value !== "dot" ? { fontSize: le(S) } : { width: le(S), height: le(S), borderColor: (m = i.value) == null ? void 0 : m.borderColor } }, [n.icon ? n.icon({ checked: C, disabled: o.value }) : r.value !== "dot" ? c(fe, { name: s ? "minus" : "success", style: i.value }, null) : c("div", { class: y("icon--dot__icon"), style: { backgroundColor: (x = i.value) == null ? void 0 : x.backgroundColor } }, null)]);
  }, g = () => {
    const { checked: m } = e;
    if (n.default)
      return c("span", { class: e.bem("label", [e.labelPosition, { disabled: o.value }]) }, [n.default({ checked: m, disabled: o.value })]);
  };
  return () => {
    const m = e.labelPosition === "left" ? [g(), u()] : [u(), g()];
    return c("div", { role: e.role, class: e.bem([{ disabled: o.value, "label-disabled": e.labelDisabled }, d.value]), tabindex: o.value ? void 0 : 0, "aria-checked": e.checked, onClick: v }, [m]);
  };
} });
const wl = ee({}, Kt, { shape: String }), [Cl, Sl] = W("radio");
var Tl = X({ name: Cl, props: wl, emits: ["update:modelValue"], setup(e, { emit: t, slots: n }) {
  const { parent: a } = _e(Wn), l = () => (a ? a.props.modelValue : e.modelValue) === e.name, o = () => {
    a ? a.updateValue(e.name) : t("update:modelValue", e.name);
  };
  return () => c(Xn, re({ bem: Sl, role: "radio", parent: a, checked: l(), onToggle: o }, e), ge(n, ["default", "icon"]));
} });
const zi = te(Tl), [kl, $l] = W("checkbox"), Il = ee({}, Kt, { shape: String, bindGroup: F, indeterminate: { type: Boolean, default: null } });
var El = X({ name: kl, props: Il, emits: ["change", "update:modelValue"], setup(e, { emit: t, slots: n }) {
  const { parent: a } = _e(xl), l = (i) => {
    const { name: r } = e, { max: v, modelValue: u } = a.props, g = u.slice();
    if (i)
      !(v && g.length >= +v) && !g.includes(r) && (g.push(r), e.bindGroup && a.updateValue(g));
    else {
      const m = g.indexOf(r);
      m !== -1 && (g.splice(m, 1), e.bindGroup && a.updateValue(g));
    }
  }, o = z(() => a && e.bindGroup ? a.props.modelValue.indexOf(e.name) !== -1 : !!e.modelValue), d = (i = !o.value) => {
    a && e.bindGroup ? l(i) : t("update:modelValue", i), e.indeterminate !== null && t("change", i);
  };
  return Y(() => e.modelValue, (i) => {
    e.indeterminate === null && t("change", i);
  }), ue({ toggle: d, props: e, checked: o }), _t(() => e.modelValue), () => c(Xn, re({ bem: $l, role: "checkbox", parent: a, checked: o.value, onToggle: d }, e), ge(n, ["default", "icon"]));
} });
const _i = te(El), Pl = ee({}, Ut, { modelValue: Oe(), filter: Function, formatter: { type: Function, default: (e, t) => t } }), Ol = Object.keys(Ut);
function Bl(e, t) {
  if (e < 0)
    return [];
  const n = Array(e);
  let a = -1;
  for (; ++a < e; )
    n[a] = t(a);
  return n;
}
const Al = (e, t) => 32 - new Date(e, t - 1, 32).getDate(), Tt = (e, t, n, a, l, o) => {
  const d = Bl(t - e + 1, (i) => {
    const r = Tn(e + i);
    return a(n, { text: r, value: r });
  });
  return l ? l(n, d, o) : d;
}, Dl = (e, t) => e.map((n, a) => {
  const l = t[a];
  if (l.length) {
    const o = +l[0].value, d = +l[l.length - 1].value;
    return Tn(ve(+n, o, d));
  }
  return n;
}), [Rl, Le] = W("image"), zl = { src: String, alt: String, fit: String, position: String, round: Boolean, block: Boolean, width: N, height: N, radius: N, lazyLoad: Boolean, iconSize: N, showError: F, errorIcon: p("photo-fail"), iconPrefix: String, showLoading: F, loadingIcon: p("photo"), crossorigin: String, referrerpolicy: String, decoding: String };
var _l = X({ name: Rl, props: zl, emits: ["load", "error"], setup(e, { emit: t, slots: n }) {
  const a = O(false), l = O(true), o = O(), { $Lazyload: d } = Ye().proxy, i = z(() => {
    const s = { width: le(e.width), height: le(e.height) };
    return ne(e.radius) && (s.overflow = "hidden", s.borderRadius = le(e.radius)), s;
  });
  Y(() => e.src, () => {
    a.value = false, l.value = true;
  });
  const r = (s) => {
    l.value && (l.value = false, t("load", s));
  }, v = () => {
    const s = new Event("load");
    Object.defineProperty(s, "target", { value: o.value, enumerable: true }), r(s);
  }, u = (s) => {
    a.value = true, l.value = false, t("error", s);
  }, g = (s, S, h) => h ? h() : c(fe, { name: s, size: e.iconSize, class: S, classPrefix: e.iconPrefix }, null), m = () => {
    if (l.value && e.showLoading)
      return c("div", { class: Le("loading") }, [g(e.loadingIcon, Le("loading-icon"), n.loading)]);
    if (a.value && e.showError)
      return c("div", { class: Le("error") }, [g(e.errorIcon, Le("error-icon"), n.error)]);
  }, x = () => {
    if (a.value || !e.src)
      return;
    const s = { alt: e.alt, class: Le("img"), decoding: e.decoding, style: { objectFit: e.fit, objectPosition: e.position }, crossorigin: e.crossorigin, referrerpolicy: e.referrerpolicy };
    return e.lazyLoad ? Pe(c("img", re({ ref: o }, s), null), [[ia("lazy"), e.src]]) : c("img", re({ ref: o, src: e.src, onLoad: r, onError: u }, s), null);
  }, y = ({ el: s }) => {
    const S = () => {
      s === o.value && l.value && v();
    };
    o.value ? S() : ae(S);
  }, C = ({ el: s }) => {
    s === o.value && !a.value && u();
  };
  return d && ze && (d.$on("loaded", y), d.$on("error", C), je(() => {
    d.$off("loaded", y), d.$off("error", C);
  })), Ie(() => {
    ae(() => {
      var s;
      (s = o.value) != null && s.complete && !e.lazyLoad && v();
    });
  }), () => {
    var s;
    return c("div", { class: Le({ round: e.round, block: e.block }), style: i.value }, [x(), m(), (s = n.default) == null ? void 0 : s.call(n)]);
  };
} });
const Zn = te(_l), vn = (/* @__PURE__ */ new Date()).getFullYear(), [Vl] = W("date-picker"), Ll = ee({}, Pl, { columnsType: { type: Array, default: () => ["year", "month", "day"] }, minDate: { type: Date, default: () => new Date(vn - 10, 0, 1), validator: Xt }, maxDate: { type: Date, default: () => new Date(vn + 10, 11, 31), validator: Xt } });
var Ml = X({ name: Vl, props: Ll, emits: ["confirm", "cancel", "change", "update:modelValue"], setup(e, { emit: t, slots: n }) {
  const a = O(e.modelValue), l = O(false), o = O(), d = z(() => l.value ? e.modelValue : a.value), i = (b) => b === e.minDate.getFullYear(), r = (b) => b === e.maxDate.getFullYear(), v = (b) => b === e.minDate.getMonth() + 1, u = (b) => b === e.maxDate.getMonth() + 1, g = (b) => {
    const { minDate: $, columnsType: U } = e, k = U.indexOf(b), _ = d.value[k];
    if (_)
      return +_;
    switch (b) {
      case "year":
        return $.getFullYear();
      case "month":
        return $.getMonth() + 1;
      case "day":
        return $.getDate();
    }
  }, m = () => {
    const b = e.minDate.getFullYear(), $ = e.maxDate.getFullYear();
    return Tt(b, $, "year", e.formatter, e.filter, d.value);
  }, x = () => {
    const b = g("year"), $ = i(b) ? e.minDate.getMonth() + 1 : 1, U = r(b) ? e.maxDate.getMonth() + 1 : 12;
    return Tt($, U, "month", e.formatter, e.filter, d.value);
  }, y = () => {
    const b = g("year"), $ = g("month"), U = i(b) && v($) ? e.minDate.getDate() : 1, k = r(b) && u($) ? e.maxDate.getDate() : Al(b, $);
    return Tt(U, k, "day", e.formatter, e.filter, d.value);
  }, C = () => {
    var b;
    return (b = o.value) == null ? void 0 : b.confirm();
  }, s = () => a.value, S = z(() => e.columnsType.map((b) => {
    switch (b) {
      case "year":
        return m();
      case "month":
        return x();
      case "day":
        return y();
      default:
        return [];
    }
  }));
  Y(a, (b) => {
    Ne(b, e.modelValue) || t("update:modelValue", b);
  }), Y(() => e.modelValue, (b, $) => {
    l.value = Ne($, a.value), b = Dl(b, S.value), Ne(b, a.value) || (a.value = b), l.value = false;
  }, { immediate: true });
  const h = (...b) => t("change", ...b), A = (...b) => t("cancel", ...b), T = (...b) => t("confirm", ...b);
  return ue({ confirm: C, getSelectedDate: s }), () => c(Qo, re({ ref: o, modelValue: a.value, "onUpdate:modelValue": (b) => a.value = b, columns: S.value, onChange: h, onCancel: A, onConfirm: T }, ge(e, Ol)), n);
} });
const Vi = te(Ml), mn = (e) => Math.sqrt((e[0].clientX - e[1].clientX) ** 2 + (e[0].clientY - e[1].clientY) ** 2), Fl = (e) => ({ x: (e[0].clientX + e[1].clientX) / 2, y: (e[0].clientY + e[1].clientY) / 2 }), kt = W("image-preview")[1], gn = 2.6, Nl = { src: String, show: Boolean, active: Number, minZoom: he(N), maxZoom: he(N), rootWidth: he(Number), rootHeight: he(Number), disableZoom: Boolean, doubleScale: Boolean, closeOnClickImage: Boolean, closeOnClickOverlay: Boolean, vertical: Boolean };
var Hl = X({ props: Nl, emits: ["scale", "close", "longPress"], setup(e, { emit: t, slots: n }) {
  const a = Ce({ scale: 1, moveX: 0, moveY: 0, moving: false, zooming: false, initializing: false, imageRatio: 0 }), l = Ke(), o = O(), d = O(), i = O(false), r = O(false);
  let v = 0;
  const u = z(() => {
    const { scale: B, moveX: M, moveY: K, moving: oe, zooming: se, initializing: R } = a, G = { transitionDuration: se || oe || R ? "0s" : ".3s" };
    return (B !== 1 || r.value) && (G.transform = "matrix(".concat(B, ", 0, 0, ").concat(B, ", ").concat(M, ", ").concat(K, ")")), G;
  }), g = z(() => {
    if (a.imageRatio) {
      const { rootWidth: B, rootHeight: M } = e, K = i.value ? M / a.imageRatio : B;
      return Math.max(0, (a.scale * K - B) / 2);
    }
    return 0;
  }), m = z(() => {
    if (a.imageRatio) {
      const { rootWidth: B, rootHeight: M } = e, K = i.value ? M : B * a.imageRatio;
      return Math.max(0, (a.scale * K - M) / 2);
    }
    return 0;
  }), x = (B, M) => {
    var K;
    if (B = ve(B, +e.minZoom, +e.maxZoom + 1), B !== a.scale) {
      const oe = B / a.scale;
      if (a.scale = B, M) {
        const se = me((K = o.value) == null ? void 0 : K.$el), R = { x: se.width * 0.5, y: se.height * 0.5 }, G = a.moveX - (M.x - se.left - R.x) * (oe - 1), J = a.moveY - (M.y - se.top - R.y) * (oe - 1);
        a.moveX = ve(G, -g.value, g.value), a.moveY = ve(J, -m.value, m.value);
      } else
        a.moveX = 0, a.moveY = r.value ? v : 0;
      t("scale", { scale: B, index: e.active });
    }
  }, y = () => {
    x(1);
  }, C = () => {
    const B = a.scale > 1 ? 1 : 2;
    x(B, B === 2 || r.value ? { x: l.startX.value, y: l.startY.value } : void 0);
  };
  let s, S, h, A, T, b, $, U, k = false;
  const _ = (B) => {
    const { touches: M } = B;
    if (s = M.length, s === 2 && e.disableZoom)
      return;
    const { offsetX: K } = l;
    l.start(B), S = a.moveX, h = a.moveY, U = Date.now(), k = false, a.moving = s === 1 && (a.scale !== 1 || r.value), a.zooming = s === 2 && !K.value, a.zooming && (A = a.scale, T = mn(M));
  }, P = (B) => {
    const { touches: M } = B;
    if (l.move(B), a.moving) {
      const { deltaX: K, deltaY: oe } = l, se = K.value + S, R = oe.value + h;
      if ((e.vertical ? l.isVertical() && Math.abs(R) > m.value : l.isHorizontal() && Math.abs(se) > g.value) && !k) {
        a.moving = false;
        return;
      }
      k = true, ye(B, true), a.moveX = ve(se, -g.value, g.value), a.moveY = ve(R, -m.value, m.value);
    }
    if (a.zooming && (ye(B, true), M.length === 2)) {
      const K = mn(M), oe = A * K / T;
      b = Fl(M), x(oe, b);
    }
  }, D = (B) => {
    var M;
    const K = (M = d.value) == null ? void 0 : M.$el;
    if (!K)
      return;
    const oe = K.firstElementChild, se = B.target === K, R = oe == null ? void 0 : oe.contains(B.target);
    !e.closeOnClickImage && R || !e.closeOnClickOverlay && se || t("close");
  }, w = (B) => {
    if (s > 1)
      return;
    const M = Date.now() - U, K = 250;
    l.isTap.value && (M < K ? e.doubleScale ? $ ? (clearTimeout($), $ = null, C()) : $ = setTimeout(() => {
      D(B), $ = null;
    }, K) : D(B) : M > Va && t("longPress"));
  }, I = (B) => {
    let M = false;
    if ((a.moving || a.zooming) && (M = true, a.moving && S === a.moveX && h === a.moveY && (M = false), !B.touches.length)) {
      a.zooming && (a.moveX = ve(a.moveX, -g.value, g.value), a.moveY = ve(a.moveY, -m.value, m.value), a.zooming = false), a.moving = false, S = 0, h = 0, A = 1, a.scale < 1 && y();
      const K = +e.maxZoom;
      a.scale > K && x(K, b);
    }
    ye(B, M), w(B), l.reset();
  }, j = () => {
    const { rootWidth: B, rootHeight: M } = e, K = M / B, { imageRatio: oe } = a;
    i.value = a.imageRatio > K && oe < gn, r.value = a.imageRatio > K && oe >= gn, r.value && (v = (oe * B - M) / 2, a.moveY = v, a.initializing = true, Je(() => {
      a.initializing = false;
    })), y();
  }, ce = (B) => {
    const { naturalWidth: M, naturalHeight: K } = B.target;
    a.imageRatio = K / M, j();
  };
  return Y(() => e.active, y), Y(() => e.show, (B) => {
    B || y();
  }), Y(() => [e.rootWidth, e.rootHeight], j), Se("touchmove", P, { target: z(() => {
    var B;
    return (B = d.value) == null ? void 0 : B.$el;
  }) }), ue({ resetScale: y }), () => {
    const B = { loading: () => c(Ue, { type: "spinner" }, null) };
    return c(Yn, { ref: d, class: kt("swipe-item"), onTouchstartPassive: _, onTouchend: I, onTouchcancel: I }, { default: () => [n.image ? c("div", { class: kt("image-wrap") }, [n.image({ src: e.src, onLoad: ce, style: u.value })]) : c(Zn, { ref: o, src: e.src, fit: "contain", class: kt("image", { vertical: i.value }), style: u.value, onLoad: ce }, B)] });
  };
} });
const [Yl, Me] = W("image-preview"), jl = ["show", "teleport", "transition", "overlayStyle", "closeOnPopstate"], Ul = { show: Boolean, loop: F, images: Oe(), minZoom: q(1 / 3), maxZoom: q(3), overlay: F, vertical: Boolean, closeable: Boolean, showIndex: F, className: be, closeIcon: p("clear"), transition: String, beforeClose: Function, doubleScale: F, overlayClass: be, overlayStyle: Object, swipeDuration: q(300), startPosition: q(0), showIndicators: Boolean, closeOnPopstate: F, closeOnClickImage: F, closeOnClickOverlay: F, closeIconPosition: p("top-right"), teleport: [String, Object] };
var pn = X({ name: Yl, props: Ul, emits: ["scale", "close", "closed", "change", "longPress", "update:show"], setup(e, { emit: t, slots: n }) {
  const a = O(), l = O(), o = Ce({ active: 0, rootWidth: 0, rootHeight: 0, disableZoom: false }), d = () => {
    if (a.value) {
      const A = me(a.value.$el);
      o.rootWidth = A.width, o.rootHeight = A.height, a.value.resize();
    }
  }, i = (A) => t("scale", A), r = (A) => t("update:show", A), v = () => {
    bt(e.beforeClose, { args: [o.active], done: () => r(false) });
  }, u = (A) => {
    A !== o.active && (o.active = A, t("change", A));
  }, g = () => {
    if (e.showIndex)
      return c("div", { class: Me("index") }, [n.index ? n.index({ index: o.active }) : "".concat(o.active + 1, " / ").concat(e.images.length)]);
  }, m = () => {
    if (n.cover)
      return c("div", { class: Me("cover") }, [n.cover()]);
  }, x = () => {
    o.disableZoom = true;
  }, y = () => {
    o.disableZoom = false;
  }, C = () => c(Ln, { ref: a, lazyRender: true, loop: e.loop, class: Me("swipe"), vertical: e.vertical, duration: e.swipeDuration, initialSwipe: e.startPosition, showIndicators: e.showIndicators, indicatorColor: "white", onChange: u, onDragEnd: y, onDragStart: x }, { default: () => [e.images.map((A, T) => c(Hl, { ref: (b) => {
    T === o.active && (l.value = b);
  }, src: A, show: e.show, active: o.active, maxZoom: e.maxZoom, minZoom: e.minZoom, rootWidth: o.rootWidth, rootHeight: o.rootHeight, disableZoom: o.disableZoom, doubleScale: e.doubleScale, closeOnClickImage: e.closeOnClickImage, closeOnClickOverlay: e.closeOnClickOverlay, vertical: e.vertical, onScale: i, onClose: v, onLongPress: () => t("longPress", { index: T }) }, { image: n.image }))] }), s = () => {
    if (e.closeable)
      return c(fe, { role: "button", name: e.closeIcon, class: [Me("close-icon", e.closeIconPosition), et], onClick: v }, null);
  }, S = () => t("closed"), h = (A, T) => {
    var b;
    return (b = a.value) == null ? void 0 : b.swipeTo(A, T);
  };
  return ue({ resetScale: () => {
    var A;
    (A = l.value) == null || A.resetScale();
  }, swipeTo: h }), Ie(d), Y([tt, gt], d), Y(() => e.startPosition, (A) => u(+A)), Y(() => e.show, (A) => {
    const { images: T, startPosition: b } = e;
    A ? (u(+b), ae(() => {
      d(), h(+b, { immediate: true });
    })) : t("close", { index: o.active, url: T[o.active] });
  }), () => c(Bn, re({ class: [Me(), e.className], overlayClass: [Me("overlay"), e.overlayClass], onClosed: S, "onUpdate:show": r }, ge(e, jl)), { default: () => [s(), C(), g(), m()] });
} });
let it;
const Kl = { loop: true, images: [], maxZoom: 3, minZoom: 1 / 3, onScale: void 0, onClose: void 0, onChange: void 0, vertical: false, teleport: "body", className: "", showIndex: true, closeable: false, closeIcon: "clear", transition: void 0, beforeClose: void 0, doubleScale: true, overlayStyle: void 0, overlayClass: void 0, startPosition: 0, swipeDuration: 300, showIndicators: false, closeOnPopstate: true, closeOnClickOverlay: true, closeIconPosition: "top-right" };
function Wl() {
  ({ instance: it } = ml({ setup() {
    const { state: e, toggle: t } = vl(), n = () => {
      e.images = [];
    };
    return () => c(pn, re(e, { onClosed: n, "onUpdate:show": t }), null);
  } }));
}
const Xl = (e, t = 0) => {
  if (ze)
    return it || Wl(), e = Array.isArray(e) ? { images: e, startPosition: t } : e, it.open(ee({}, Kl, e)), it;
};
te(pn);
const [Zl, Fe, pl] = W("list"), Gl = { error: Boolean, offset: q(300), loading: Boolean, disabled: Boolean, finished: Boolean, scroller: Object, errorText: String, direction: p("down"), loadingText: { type: String, default: "" }, finishedText: String, immediateCheck: F };
var ql = X({ name: Zl, props: Gl, emits: ["load", "update:error", "update:loading"], setup(e, { emit: t, slots: n }) {
  const a = O(e.loading), l = O(), o = O(), d = Hn(), i = dt(l), r = z(() => e.scroller || i.value), v = () => {
    ae(() => {
      if (a.value || e.finished || e.disabled || e.error || (d == null ? void 0 : d.value) === false)
        return;
      const { direction: y } = e, C = +e.offset, s = me(r);
      if (!s.height || He(l))
        return;
      let S = false;
      const h = me(o);
      y === "up" ? S = s.top - h.top <= C : S = h.bottom - s.bottom <= C, S && (a.value = true, t("update:loading", true), t("load"));
    });
  }, u = () => {
    if (e.finished) {
      const y = n.finished ? n.finished() : e.finishedText;
      if (y)
        return c("div", { class: Fe("finished-text") }, [y]);
    }
  }, g = () => {
    t("update:error", false), v();
  }, m = () => {
    if (e.error) {
      const y = n.error ? n.error() : e.errorText;
      if (y)
        return c("div", { role: "button", class: Fe("error-text"), tabindex: 0, onClick: g }, [y]);
    }
  }, x = () => {
    if (a.value && !e.finished && !e.disabled)
      return c("div", { class: Fe("loading") }, [n.loading ? n.loading() : e.loadingText != null && c(Ue, { class: Fe("loading-icon") }, { default: () => [e.loadingText || pl("loading")] })]);
  };
  return Y(() => [e.loading, e.finished, e.error], v), d && Y(d, (y) => {
    y && v();
  }), ra(() => {
    a.value = e.loading;
  }), Ie(() => {
    e.immediateCheck && v();
  }), ue({ check: v }), Se("scroll", v, { target: r, passive: true }), () => {
    var y;
    const C = (y = n.default) == null ? void 0 : y.call(n), s = c("div", { ref: o, class: Fe("placeholder") }, null);
    return c("div", { ref: l, role: "feed", class: Fe(), "aria-busy": a.value }, [e.direction === "down" ? C : s, x(), u(), m(), e.direction === "up" ? C : s]);
  };
} });
const Li = te(ql), [Jl, Ze] = W("notice-bar"), Ql = { text: String, mode: String, color: String, delay: q(1), speed: q(60), leftIcon: String, wrapable: Boolean, background: String, scrollable: { type: Boolean, default: null } };
var ei = X({ name: Jl, props: Ql, emits: ["close", "replay"], setup(e, { emit: t, slots: n }) {
  let a = 0, l = 0, o;
  const d = O(), i = O(), r = Ce({ show: true, offset: 0, duration: 0 }), v = () => {
    if (n["left-icon"])
      return n["left-icon"]();
    if (e.leftIcon)
      return c(fe, { class: Ze("left-icon"), name: e.leftIcon }, null);
  }, u = () => {
    if (e.mode === "closeable")
      return "cross";
    if (e.mode === "link")
      return "arrow";
  }, g = (s) => {
    e.mode === "closeable" && (r.show = false, t("close", s));
  }, m = () => {
    if (n["right-icon"])
      return n["right-icon"]();
    const s = u();
    if (s)
      return c(fe, { name: s, class: Ze("right-icon"), onClick: g }, null);
  }, x = () => {
    r.offset = a, r.duration = 0, Je(() => {
      De(() => {
        r.offset = -l, r.duration = (l + a) / +e.speed, t("replay");
      });
    });
  }, y = () => {
    const s = e.scrollable === false && !e.wrapable, S = { transform: r.offset ? "translateX(".concat(r.offset, "px)") : "", transitionDuration: "".concat(r.duration, "s") };
    return c("div", { ref: d, role: "marquee", class: Ze("wrap") }, [c("div", { ref: i, style: S, class: [Ze("content"), { "van-ellipsis": s }], onTransitionend: x }, [n.default ? n.default() : e.text])]);
  }, C = () => {
    const { delay: s, speed: S, scrollable: h } = e, A = ne(s) ? +s * 1e3 : 0;
    a = 0, l = 0, r.offset = 0, r.duration = 0, clearTimeout(o), o = setTimeout(() => {
      if (!d.value || !i.value || h === false)
        return;
      const T = me(d).width, b = me(i).width;
      (h || b > T) && De(() => {
        a = T, l = b, r.offset = -l, r.duration = l / +S;
      });
    }, A);
  };
  return Yt(C), ut(C), Se("pageshow", C), ue({ reset: C }), Y(() => [e.text, e.scrollable], C), () => {
    const { color: s, wrapable: S, background: h } = e;
    return Pe(c("div", { role: "alert", class: Ze({ wrapable: S }), style: { color: s, background: h } }, [v(), y(), m()]), [[Re, r.show]]);
  };
} });
const Mi = te(ei), [ti, qe] = W("key"), ni = c("svg", { class: qe("collapse-icon"), viewBox: "0 0 30 24" }, [c("path", { d: "M26 13h-2v2h2v-2zm-8-3h2V8h-2v2zm2-4h2V4h-2v2zm2 4h4V4h-2v4h-2v2zm-7 14 3-3h-6l3 3zM6 13H4v2h2v-2zm16 0H8v2h14v-2zm-12-3h2V8h-2v2zM28 0l1 1 1 1v15l-1 2H1l-1-2V2l1-1 1-1zm0 2H2v15h26V2zM6 4v2H4V4zm10 2h2V4h-2v2zM8 9v1H4V8zm8 0v1h-2V8zm-6-5v2H8V4zm4 0v2h-2V4z", fill: "currentColor" }, null)]), ai = c("svg", { class: qe("delete-icon"), viewBox: "0 0 32 22" }, [c("path", { d: "M28 0a4 4 0 0 1 4 4v14a4 4 0 0 1-4 4H10.4a2 2 0 0 1-1.4-.6L1 13.1c-.6-.5-.9-1.3-.9-2 0-1 .3-1.7.9-2.2L9 .6a2 2 0 0 1 1.4-.6zm0 2H10.4l-8.2 8.3a1 1 0 0 0-.3.7c0 .3.1.5.3.7l8.2 8.4H28a2 2 0 0 0 2-2V4c0-1.1-.9-2-2-2zm-5 4a1 1 0 0 1 .7.3 1 1 0 0 1 0 1.4L20.4 11l3.3 3.3c.2.2.3.5.3.7 0 .3-.1.5-.3.7a1 1 0 0 1-.7.3 1 1 0 0 1-.7-.3L19 12.4l-3.4 3.3a1 1 0 0 1-.6.3 1 1 0 0 1-.7-.3 1 1 0 0 1-.3-.7c0-.2.1-.5.3-.7l3.3-3.3-3.3-3.3A1 1 0 0 1 14 7c0-.3.1-.5.3-.7A1 1 0 0 1 15 6a1 1 0 0 1 .6.3L19 9.6l3.3-3.3A1 1 0 0 1 23 6z", fill: "currentColor" }, null)]);
var $t = X({ name: ti, props: { type: String, text: N, color: String, wider: Boolean, large: Boolean, loading: Boolean }, emits: ["press"], setup(e, { emit: t, slots: n }) {
  const a = O(false), l = Ke(), o = (v) => {
    l.start(v), a.value = true;
  }, d = (v) => {
    l.move(v), l.direction.value && (a.value = false);
  }, i = (v) => {
    a.value && (n.default || ye(v), a.value = false, t("press", e.text, e.type));
  }, r = () => {
    if (e.loading)
      return c(Ue, { class: qe("loading-icon") }, null);
    const v = n.default ? n.default() : e.text;
    switch (e.type) {
      case "delete":
        return v || ai;
      case "extra":
        return v || ni;
      default:
        return v;
    }
  };
  return () => c("div", { class: qe("wrapper", { wider: e.wider }), onTouchstartPassive: o, onTouchmovePassive: d, onTouchend: i, onTouchcancel: i }, [c("div", { role: "button", tabindex: 0, class: qe([e.color, { large: e.large, active: a.value, delete: e.type === "delete" }]) }, [r()])]);
} });
const [oi, Ee] = W("number-keyboard"), li = { show: Boolean, title: String, theme: p("default"), zIndex: N, teleport: [String, Object], maxlength: q(1 / 0), modelValue: p(""), transition: F, blurOnClose: F, showDeleteKey: F, randomKeyOrder: Boolean, closeButtonText: String, deleteButtonText: String, closeButtonLoading: Boolean, hideOnClickOutside: F, safeAreaInsetBottom: F, extraKey: { type: [String, Array], default: "" } };
function ii(e) {
  for (let t = e.length - 1; t > 0; t--) {
    const n = Math.floor(Math.random() * (t + 1)), a = e[t];
    e[t] = e[n], e[n] = a;
  }
  return e;
}
var ri = X({ name: oi, inheritAttrs: false, props: li, emits: ["show", "hide", "blur", "input", "close", "delete", "update:modelValue"], setup(e, { emit: t, slots: n, attrs: a }) {
  const l = O(), o = () => {
    const s = Array(9).fill("").map((S, h) => ({ text: h + 1 }));
    return e.randomKeyOrder && ii(s), s;
  }, d = () => [...o(), { text: e.extraKey, type: "extra" }, { text: 0 }, { text: e.showDeleteKey ? e.deleteButtonText : "", type: e.showDeleteKey ? "delete" : "" }], i = () => {
    const s = o(), { extraKey: S } = e, h = Array.isArray(S) ? S : [S];
    return h.length === 0 ? s.push({ text: 0, wider: true }) : h.length === 1 ? s.push({ text: 0, wider: true }, { text: h[0], type: "extra" }) : h.length === 2 && s.push({ text: h[0], type: "extra" }, { text: 0 }, { text: h[1], type: "extra" }), s;
  }, r = z(() => e.theme === "custom" ? i() : d()), v = () => {
    e.show && t("blur");
  }, u = () => {
    t("close"), e.blurOnClose && v();
  }, g = () => t(e.show ? "show" : "hide"), m = (s, S) => {
    if (s === "") {
      S === "extra" && v();
      return;
    }
    const h = e.modelValue;
    S === "delete" ? (t("delete"), t("update:modelValue", h.slice(0, h.length - 1))) : S === "close" ? u() : h.length < +e.maxlength && (t("input", s), t("update:modelValue", h + s));
  }, x = () => {
    const { title: s, theme: S, closeButtonText: h } = e, A = n["title-left"], T = h && S === "default";
    if (s || T || A)
      return c("div", { class: Ee("header") }, [A && c("span", { class: Ee("title-left") }, [A()]), s && c("h2", { class: Ee("title") }, [s]), T && c("button", { type: "button", class: [Ee("close"), et], onClick: u }, [h])]);
  }, y = () => r.value.map((s) => {
    const S = {};
    return s.type === "delete" && (S.default = n.delete), s.type === "extra" && (S.default = n["extra-key"]), c($t, { key: s.text, text: s.text, type: s.type, wider: s.wider, color: s.color, onPress: m }, S);
  }), C = () => {
    if (e.theme === "custom")
      return c("div", { class: Ee("sidebar") }, [e.showDeleteKey && c($t, { large: true, text: e.deleteButtonText, type: "delete", onPress: m }, { default: n.delete }), c($t, { large: true, text: e.closeButtonText, type: "close", color: "blue", loading: e.closeButtonLoading, onPress: m }, null)]);
  };
  return Y(() => e.show, (s) => {
    e.transition || t(s ? "show" : "hide");
  }), e.hideOnClickOutside && xn(l, v, { eventName: "touchstart" }), () => {
    const s = x(), S = c(At, { name: e.transition ? "van-slide-up" : "" }, { default: () => [Pe(c("div", re({ ref: l, style: Nt(e.zIndex), class: Ee({ unfit: !e.safeAreaInsetBottom, "with-title": !!s }), onAnimationend: g, onTouchstartPassive: Cn }, a), [s, c("div", { class: Ee("body") }, [c("div", { class: Ee("keys") }, [y()]), C()])]), [[Re, e.show]])] });
    return e.teleport ? c(Dt, { to: e.teleport }, { default: () => [S] }) : S;
  };
} });
const Fi = te(ri), [ci, Ae] = W("popover"), si = ["overlay", "duration", "teleport", "overlayStyle", "overlayClass", "closeOnClickOverlay"], ui = { show: Boolean, theme: p("light"), overlay: Boolean, actions: Oe(), actionsDirection: p("vertical"), trigger: p("click"), duration: N, showArrow: F, placement: p("bottom"), iconPrefix: String, overlayClass: be, overlayStyle: Object, closeOnClickAction: F, closeOnClickOverlay: F, closeOnClickOutside: F, offset: { type: Array, default: () => [0, 8] }, teleport: { type: [String, Object], default: "body" } };
var di = X({ name: ci, props: ui, emits: ["select", "touchstart", "update:show"], setup(e, { emit: t, slots: n, attrs: a }) {
  let l;
  const o = O(), d = O(), i = O(), r = To(() => e.show, (h) => t("update:show", h)), v = () => ({ placement: e.placement, modifiers: [{ name: "computeStyles", options: { adaptive: false, gpuAcceleration: false } }, ee({}, fa, { options: { offset: e.offset } })] }), u = () => d.value && i.value ? va(d.value, i.value.popupRef.value, v()) : null, g = () => {
    ae(() => {
      r.value && (l ? l.setOptions(v()) : (l = u(), ze && (window.addEventListener("animationend", g), window.addEventListener("transitionend", g))));
    });
  }, m = (h) => {
    r.value = h;
  }, x = () => {
    e.trigger === "click" && (r.value = !r.value);
  }, y = (h, A) => {
    h.disabled || (t("select", h, A), e.closeOnClickAction && (r.value = false));
  }, C = () => {
    r.value && e.closeOnClickOutside && (!e.overlay || e.closeOnClickOverlay) && (r.value = false);
  }, s = (h, A) => n.action ? n.action({ action: h, index: A }) : [h.icon && c(fe, { name: h.icon, classPrefix: e.iconPrefix, class: Ae("action-icon") }, null), c("div", { class: [Ae("action-text"), { [Da]: e.actionsDirection === "vertical" }] }, [h.text])], S = (h, A) => {
    const { icon: T, color: b, disabled: $, className: U } = h;
    return c("div", { role: "menuitem", class: [Ae("action", { disabled: $, "with-icon": T }), { [Aa]: e.actionsDirection === "horizontal" }, U], style: { color: b }, tabindex: $ ? void 0 : 0, "aria-disabled": $ || void 0, onClick: () => y(h, A) }, [s(h, A)]);
  };
  return Ie(() => {
    g(), zt(() => {
      var h;
      o.value = (h = i.value) == null ? void 0 : h.popupRef.value;
    });
  }), je(() => {
    l && (ze && (window.removeEventListener("animationend", g), window.removeEventListener("transitionend", g)), l.destroy(), l = null);
  }), Y(() => [r.value, e.offset, e.placement], g), xn([d, o], C, { eventName: "touchstart" }), () => {
    var h;
    return c(bn, null, [c("span", { ref: d, class: Ae("wrapper"), onClick: x }, [(h = n.reference) == null ? void 0 : h.call(n)]), c(Bn, re({ ref: i, show: r.value, class: Ae([e.theme]), position: "", transition: "van-popover-zoom", lockScroll: false, "onUpdate:show": m }, a, Pt(), ge(e, si)), { default: () => [e.showArrow && c("div", { class: Ae("arrow") }, null), c("div", { role: "menu", class: Ae("content", e.actionsDirection) }, [n.default ? n.default() : e.actions.map(S)])] })]);
  };
} });
const Ni = te(di), [fi, pe, vi] = W("pull-refresh"), Gn = 50, mi = ["pulling", "loosing", "success"], gi = { disabled: Boolean, modelValue: Boolean, headHeight: q(Gn), successText: String, pullingText: String, loosingText: String, loadingText: String, pullDistance: N, successDuration: q(500), animationDuration: q(300) };
var hi = X({ name: fi, props: gi, emits: ["change", "refresh", "update:modelValue"], setup(e, { emit: t, slots: n }) {
  let a;
  const l = O(), o = O(), d = dt(l), i = Ce({ status: "normal", distance: 0, duration: 0 }), r = Ke(), v = () => {
    if (e.headHeight !== Gn)
      return { height: "".concat(e.headHeight, "px") };
  }, u = () => i.status !== "loading" && i.status !== "success" && !e.disabled, g = (T) => {
    const b = +(e.pullDistance || e.headHeight);
    return T > b && (T < b * 2 ? T = b + (T - b) / 2 : T = b * 1.5 + (T - b * 2) / 4), Math.round(T);
  }, m = (T, b) => {
    const $ = +(e.pullDistance || e.headHeight);
    i.distance = T, b ? i.status = "loading" : T === 0 ? i.status = "normal" : T < $ ? i.status = "pulling" : i.status = "loosing", t("change", { status: i.status, distance: T });
  }, x = () => {
    const { status: T } = i;
    return T === "normal" ? "" : e["".concat(T, "Text")] || vi(T);
  }, y = () => {
    const { status: T, distance: b } = i;
    if (n[T])
      return n[T]({ distance: b });
    const $ = [];
    return mi.includes(T) && $.push(c("div", { class: pe("text") }, [x()])), T === "loading" && $.push(c(Ue, { class: pe("loading") }, { default: x })), $;
  }, C = () => {
    i.status = "success", setTimeout(() => {
      m(0);
    }, +e.successDuration);
  }, s = (T) => {
    a = mt(d.value) === 0, a && (i.duration = 0, r.start(T));
  }, S = (T) => {
    u() && s(T);
  }, h = (T) => {
    if (u()) {
      a || s(T);
      const { deltaY: b } = r;
      r.move(T), a && b.value >= 0 && r.isVertical() && (ye(T), m(g(b.value)));
    }
  }, A = () => {
    a && r.deltaY.value && u() && (i.duration = +e.animationDuration, i.status === "loosing" ? (m(+e.headHeight, true), t("update:modelValue", true), ae(() => t("refresh"))) : m(0));
  };
  return Y(() => e.modelValue, (T) => {
    i.duration = +e.animationDuration, T ? m(+e.headHeight, true) : n.success || e.successText ? C() : m(0, false);
  }), Se("touchmove", h, { target: o }), () => {
    var T;
    const b = { transitionDuration: "".concat(i.duration, "ms"), transform: i.distance ? "translate3d(0,".concat(i.distance, "px, 0)") : "" };
    return c("div", { ref: l, class: pe() }, [c("div", { ref: o, class: pe("track"), style: b, onTouchstartPassive: S, onTouchend: A, onTouchcancel: A }, [c("div", { class: pe("head"), style: v() }, [y()]), (T = n.default) == null ? void 0 : T.call(n)])]);
  };
} });
const Hi = te(hi), [bi, ie, yi] = W("uploader");
function hn(e, t) {
  return new Promise((n) => {
    if (t === "file") {
      n();
      return;
    }
    const a = new FileReader();
    a.onload = (l) => {
      n(l.target.result);
    }, t === "dataUrl" ? a.readAsDataURL(e) : t === "text" && a.readAsText(e);
  });
}
function qn(e, t) {
  return ct(e).some((n) => n.file ? Qe(t) ? t(n.file) : n.file.size > +t : false);
}
function xi(e, t) {
  const n = [], a = [];
  return e.forEach((l) => {
    qn(l, t) ? a.push(l) : n.push(l);
  }), { valid: n, invalid: a };
}
const wi = /\.(jpeg|jpg|gif|png|svg|webp|jfif|bmp|dpg|avif)/i, Ci = (e) => wi.test(e);
function Jn(e) {
  return e.isImage ? true : e.file && e.file.type ? e.file.type.indexOf("image") === 0 : e.url ? Ci(e.url) : typeof e.content == "string" ? e.content.indexOf("data:image") === 0 : false;
}
var Si = X({ props: { name: N, item: he(Object), index: Number, imageFit: String, lazyLoad: Boolean, deletable: Boolean, reupload: Boolean, previewSize: [Number, String, Array], beforeDelete: Function }, emits: ["delete", "preview", "reupload"], setup(e, { emit: t, slots: n }) {
  const a = () => {
    const { status: u, message: g } = e.item;
    if (u === "uploading" || u === "failed") {
      const m = u === "failed" ? c(fe, { name: "close", class: ie("mask-icon") }, null) : c(Ue, { class: ie("loading") }, null), x = ne(g) && g !== "";
      return c("div", { class: ie("mask") }, [m, x && c("div", { class: ie("mask-message") }, [g])]);
    }
  }, l = (u) => {
    const { name: g, item: m, index: x, beforeDelete: y } = e;
    u.stopPropagation(), bt(y, { args: [m, { name: g, index: x }], done: () => t("delete") });
  }, o = () => t("preview"), d = () => t("reupload"), i = () => {
    if (e.deletable && e.item.status !== "uploading") {
      const u = n["preview-delete"];
      return c("div", { role: "button", class: ie("preview-delete", { shadow: !u }), tabindex: 0, "aria-label": yi("delete"), onClick: l }, [u ? u() : c(fe, { name: "cross", class: ie("preview-delete-icon") }, null)]);
    }
  }, r = () => {
    if (n["preview-cover"]) {
      const { index: u, item: g } = e;
      return c("div", { class: ie("preview-cover") }, [n["preview-cover"](ee({ index: u }, g))]);
    }
  }, v = () => {
    const { item: u, lazyLoad: g, imageFit: m, previewSize: x, reupload: y } = e;
    return Jn(u) ? c(Zn, { fit: m, src: u.objectUrl || u.content || u.url, class: ie("preview-image"), width: Array.isArray(x) ? x[0] : x, height: Array.isArray(x) ? x[1] : x, lazyLoad: g, onClick: y ? d : o }, { default: r }) : c("div", { class: ie("file"), style: Ft(e.previewSize) }, [c(fe, { class: ie("file-icon"), name: "description" }, null), c("div", { class: [ie("file-name"), "van-ellipsis"] }, [u.file ? u.file.name : u.url]), r()]);
  };
  return () => c("div", { class: ie("preview") }, [v(), a(), i()]);
} });
const Ti = { name: q(""), accept: p("image/*"), capture: String, multiple: Boolean, disabled: Boolean, readonly: Boolean, lazyLoad: Boolean, maxCount: q(1 / 0), imageFit: p("cover"), resultType: p("dataUrl"), uploadIcon: p("photograph"), uploadText: String, deletable: F, reupload: Boolean, afterRead: Function, showUpload: F, modelValue: Oe(), beforeRead: Function, beforeDelete: Function, previewSize: [Number, String, Array], previewImage: F, previewOptions: Object, previewFullImage: F, maxSize: { type: [Number, String, Function], default: 1 / 0 } };
var ki = X({ name: bi, props: Ti, emits: ["delete", "oversize", "clickUpload", "closePreview", "clickPreview", "clickReupload", "update:modelValue"], setup(e, { emit: t, slots: n }) {
  const a = O(), l = [], o = O(-1), d = O(false), i = (k = e.modelValue.length) => ({ name: e.name, index: k }), r = () => {
    a.value && (a.value.value = "");
  }, v = (k) => {
    if (r(), qn(k, e.maxSize))
      if (Array.isArray(k)) {
        const _ = xi(k, e.maxSize);
        if (k = _.valid, t("oversize", _.invalid, i()), !k.length)
          return;
      } else {
        t("oversize", k, i());
        return;
      }
    if (k = Ce(k), o.value > -1) {
      const _ = [...e.modelValue];
      _.splice(o.value, 1, k), t("update:modelValue", _), o.value = -1;
    } else
      t("update:modelValue", [...e.modelValue, ...ct(k)]);
    e.afterRead && e.afterRead(k, i());
  }, u = (k) => {
    const { maxCount: _, modelValue: P, resultType: D } = e;
    if (Array.isArray(k)) {
      const w = +_ - P.length;
      k.length > w && (k = k.slice(0, w)), Promise.all(k.map((I) => hn(I, D))).then((I) => {
        const j = k.map((ce, B) => {
          const M = { file: ce, status: "", message: "", objectUrl: URL.createObjectURL(ce) };
          return I[B] && (M.content = I[B]), M;
        });
        v(j);
      });
    } else
      hn(k, D).then((w) => {
        const I = { file: k, status: "", message: "", objectUrl: URL.createObjectURL(k) };
        w && (I.content = w), v(I);
      });
  }, g = (k) => {
    const { files: _ } = k.target;
    if (e.disabled || !_ || !_.length)
      return;
    const P = _.length === 1 ? _[0] : [].slice.call(_);
    if (e.beforeRead) {
      const D = e.beforeRead(P, i());
      if (!D) {
        r();
        return;
      }
      if (Vt(D)) {
        D.then((w) => {
          u(w || P);
        }).catch(r);
        return;
      }
    }
    u(P);
  };
  let m;
  const x = () => t("closePreview"), y = (k) => {
    if (e.previewFullImage) {
      const _ = e.modelValue.filter(Jn), P = _.map((D) => (D.objectUrl && !D.url && D.status !== "failed" && (D.url = D.objectUrl, l.push(D.url)), D.url)).filter(Boolean);
      m = Xl(ee({ images: P, startPosition: _.indexOf(k), onClose: x }, e.previewOptions));
    }
  }, C = () => {
    m && m.close();
  }, s = (k, _) => {
    const P = e.modelValue.slice(0);
    P.splice(_, 1), t("update:modelValue", P), t("delete", k, i(_));
  }, S = (k) => {
    d.value = true, o.value = k, ae(() => U());
  }, h = () => {
    d.value || (o.value = -1), d.value = false;
  }, A = (k, _) => {
    const P = ["imageFit", "deletable", "reupload", "previewSize", "beforeDelete"], D = ee(ge(e, P), ge(k, P, true));
    return c(Si, re({ item: k, index: _, onClick: () => t(e.reupload ? "clickReupload" : "clickPreview", k, i(_)), onDelete: () => s(k, _), onPreview: () => y(k), onReupload: () => S(_) }, ge(e, ["name", "lazyLoad"]), D), ge(n, ["preview-cover", "preview-delete"]));
  }, T = () => {
    if (e.previewImage)
      return e.modelValue.map(A);
  }, b = (k) => t("clickUpload", k), $ = () => {
    const k = e.modelValue.length < +e.maxCount, _ = e.readonly ? null : c("input", { ref: a, type: "file", class: ie("input"), accept: e.accept, capture: e.capture, multiple: e.multiple && o.value === -1, disabled: e.disabled, onChange: g, onClick: h }, null);
    return n.default ? Pe(c("div", { class: ie("input-wrapper"), onClick: b }, [n.default(), _]), [[Re, k]]) : Pe(c("div", { class: ie("upload", { readonly: e.readonly }), style: Ft(e.previewSize), onClick: b }, [c(fe, { name: e.uploadIcon, class: ie("upload-icon") }, null), e.uploadText && c("span", { class: ie("upload-text") }, [e.uploadText]), _]), [[Re, e.showUpload && k]]);
  }, U = () => {
    a.value && !e.disabled && a.value.click();
  };
  return je(() => {
    l.forEach((k) => URL.revokeObjectURL(k));
  }), ue({ chooseFile: U, reuploadFile: S, closeImagePreview: C }), _t(() => e.modelValue), () => c("div", { class: ie() }, [c("div", { class: ie("wrapper", { disabled: e.disabled }) }, [T(), $()])]);
} });
const Yi = te(ki);
var ji = { name: "Name", tel: "Phone", save: "Save", clear: "Clear", undo: "Undo", cancel: "Cancel", confirm: "Confirm", delete: "Delete", loading: "Loading...", noCoupon: "No coupons", nameEmpty: "Please fill in the name", addContact: "Add contact", telInvalid: "Malformed phone number", vanCalendar: { end: "End", start: "Start", title: "Calendar", weekdays: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"], monthTitle: (e, t) => "".concat(e, "/").concat(t), rangePrompt: (e) => "Choose no more than ".concat(e, " days") }, vanCascader: { select: "Select" }, vanPagination: { prev: "Previous", next: "Next" }, vanPullRefresh: { pulling: "Pull to refresh...", loosing: "Loose to refresh..." }, vanSubmitBar: { label: "Total:" }, vanCoupon: { unlimited: "Unlimited", discount: (e) => "".concat(e * 10, "% off"), condition: (e) => "At least ".concat(e) }, vanCouponCell: { title: "Coupon", count: (e) => "You have ".concat(e, " coupons") }, vanCouponList: { exchange: "Exchange", close: "Close", enable: "Available", disabled: "Unavailable", placeholder: "Coupon code" }, vanAddressEdit: { area: "Area", areaEmpty: "Please select a receiving area", addressEmpty: "Address can not be empty", addressDetail: "Address", defaultAddress: "Set as the default address" }, vanAddressList: { add: "Add new address" } }, Ui = { name: "Nome", tel: "Fone", save: "Salvar", clear: "Claro", undo: "Desfazer", cancel: "Cancelar", confirm: "Confirmar", delete: "Excluir", loading: "Carregando...", noCoupon: "Nenhum cupom", nameEmpty: "Por favor, preencha o nome", addContact: "Adicionar novo contato", telInvalid: "Telefone em formato inv\xE1lido", vanCalendar: { end: "Fim", start: "In\xEDcio", title: "Calend\xE1rio", weekdays: ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "S\xE1b"], monthTitle: (e, t) => "".concat(t, "/").concat(e), rangePrompt: (e) => "Escolha no m\xE1ximo ".concat(e, " dias") }, vanCascader: { select: "Selecione" }, vanPagination: { prev: "Anterior", next: "Pr\xF3ximo" }, vanPullRefresh: { pulling: "Puxe para atualizar...", loosing: "Solte para atualizar..." }, vanSubmitBar: { label: "Total:" }, vanCoupon: { unlimited: "Ilimitado", discount: (e) => "".concat(e * 10, "% de desconto"), condition: (e) => "Pelo menos ".concat(e) }, vanCouponCell: { title: "Cupom", count: (e) => "Voc\xEA possui ".concat(e, " cupom(ns)") }, vanCouponList: { exchange: "Usar", close: "Fechar", enable: "Dispon\xEDvel", disabled: "Indispon\xEDvel", placeholder: "C\xF3digo do cupom" }, vanAddressEdit: { area: "\xC1rea", areaEmpty: "Por favor, selecione uma \xE1rea de recebimento", addressEmpty: "Endere\xE7o n\xE3o pode ser vazio", addressDetail: "Endere\xE7o", defaultAddress: "Usar como endere\xE7o padr\xE3o" }, vanAddressList: { add: "Adicionar novo endere\xE7o" } }, Ki = { name: "Nama", tel: "Telepon", save: "Simpan", clear: "Jernih", undo: "Batalkan", cancel: "Batal", confirm: "Konfirmasi", delete: "Hapus", loading: "Memuat...", noCoupon: "Tidak ada kupon", nameEmpty: "Silakan isi nama", addContact: "Tambahkan kontak", telInvalid: "Nomor telepon salah format", vanCalendar: { end: "Akhir", start: "Mulai", title: "Kalender", weekdays: ["minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"], monthTitle: (e, t) => "".concat(e, "/").concat(t), rangePrompt: (e) => "Pilih tidak lebih dari ".concat(e, " hari") }, vanCascader: { select: "Pilih" }, vanPagination: { prev: "Sebelumnya", next: "Selanjutnya" }, vanPullRefresh: { pulling: "Tarik untuk menyegarkan...", loosing: "Loose untuk menyegarkan..." }, vanSubmitBar: { label: "Jumlah:" }, vanCoupon: { unlimited: "Tidak terbatas", discount: (e) => "".concat(e * 10, "% off"), condition: (e) => "Setidaknya ".concat(e) }, vanCouponCell: { title: "Kupon", count: (e) => "Anda memiliki kupon ".concat(e) }, vanCouponList: { exchange: "Pertukaran", close: "Tutup", enable: "Tersedia", disabled: "Tidak tersedia", placeholder: "Kode kupon" }, vanAddressEdit: { area: "Daerah", areaEmpty: "Silakan pilih area penerima", addressEmpty: "Alamat tidak boleh kosong", addressDetail: "Alamat", defaultAddress: "Tetapkan sebagai alamat default" }, vanAddressList: { add: "Tambahkan alamat baru" } }, Wi = { name: "Nombre", tel: "Tel\xE9fono", save: "Guardar", clear: "Claro", undo: "Deshacer", cancel: "Cancelar", confirm: "Confirmar", delete: "Eliminar", loading: "Cargando...", noCoupon: "Sin cupones", nameEmpty: "Por favor rellena el nombre", addContact: "A\xF1adi contacto", telInvalid: "Tel\xE9fono inv\xE1lido", vanCalendar: { end: "Fin", start: "Inicio", title: "Calendario", weekdays: ["Dom", "Lun", "Mar", "Mi\xE9", "Jue", "Vie", "S\xE1b"], monthTitle: (e, t) => "".concat(e, "/").concat(t), rangePrompt: (e) => "Elija no m\xE1s de ".concat(e, " d\xEDas") }, vanCascader: { select: "Seleccione" }, vanPagination: { prev: "Anterior", next: "Siguiente" }, vanPullRefresh: { pulling: "Tira para recargar...", loosing: "Suelta para recargar..." }, vanSubmitBar: { label: "Total:" }, vanCoupon: { unlimited: "Ilimitado", discount: (e) => "".concat(e * 10, "% de descuento"), condition: (e) => "Al menos ".concat(e) }, vanCouponCell: { title: "Cup\xF3n", count: (e) => "You have ".concat(e, " coupons") }, vanCouponList: { exchange: "Intercambio", close: "Cerrar", enable: "Disponible", disabled: "No disponible", placeholder: "C\xF3digo del cup\xF3n" }, vanAddressEdit: { area: "\xC1rea", areaEmpty: "Por favor selecciona una \xE1rea de recogida", addressEmpty: "La direcci\xF3n no puede estar vacia", addressDetail: "Direcci\xF3n", defaultAddress: "Establecer como direcci\xF3n por defecto" }, vanAddressList: { add: "Anadir direcci\xF3n" } };
export {
  _i as C,
  Vi as D,
  Ai as F,
  Ea as L,
  Mi as N,
  Bn as P,
  zi as R,
  Yn as S,
  Pi as T,
  Yi as U,
  ji as a,
  Ki as b,
  Wi as c,
  Oi as d,
  Qo as e,
  Li as f,
  Hi as g,
  Ln as h,
  Ni as i,
  Di as j,
  Fi as k,
  Ui as s
};
