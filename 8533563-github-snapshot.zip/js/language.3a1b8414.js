import { s as r, __tla as __tla_0 } from "./index.bb04cb73.js";
import "./@vue.b00de3e9.js";
import "./vue-router.c227d4ba.js";
import "./axios.853f16bf.js";
import "./element-plus.53baa8a9.js";
import "./@element-plus.e21ea623.js";
import "./@ctrl.11979b50.js";
import "./dayjs.9abdbee1.js";
import "./clipboard.aaae98d3.js";
import "./@vueuse.eccd744a.js";
import "./lodash-es.e1022fb5.js";
import "./@popperjs.da591b4f.js";
import "./vant.f7b4805b.js";
import "./@vant.f52f09a9.js";
import "./vue-i18n.07fcbeea.js";
import "./@intlify.928cb664.js";
import "./vuex.33ea5d58.js";
import "./xe-utils.a532b55a.js";
import "./crypto-js.c184c643.js";
import "./decimal.js.2def1975.js";
import "./nprogress.9fc41f77.js";
import "./vconsole.0cfb1d33.js";
import "./perfect-scrollbar.19f80865.js";
let A;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e) {
    }
  })()
]).then(async () => {
  A = async function() {
    var _a;
    const { language: i, country: e } = r.state.metaConfig;
    let o = i;
    if (!i)
      return;
    let l = localStorage.getItem("language"), t;
    try {
      l && (t = o.find((a) => a.value === l).value);
    } catch (e2) {
    }
    t ? r.state.language = t : (t = o.find((a) => a.value === navigator.language), t || (t = ((_a = o.find((a) => a.value === navigator.language.split("-")[0])) == null ? void 0 : _a.value) || o[0].value), t ? localStorage.setItem("language", t) : localStorage.setItem("language", "en"), r.state.language = localStorage.getItem("language")), localStorage.setItem("country", e && e[0].value), r.state.area = e && e[0].label.split("/")[1].replace("+", "");
  };
});
export {
  __tla,
  A as checkLanguage
};
