import { $ as N, a4 as ke, aQ as z, _ as u, c as ye, b as we, T as M, __tla as __tla_0 } from "./index.bb04cb73.js";
import { _ as Ce } from "./google.32be915d.js";
import { _ as xe } from "./facebook.9a3c493d.js";
import { u as $e } from "./vuex.33ea5d58.js";
import { b as Ie, u as Ee } from "./vue-router.c227d4ba.js";
import { u as Re } from "./vue-i18n.07fcbeea.js";
import { u as Le, __tla as __tla_1 } from "./index.e72a0941.js";
import { w as K, e as Te, a9 as Se, o as l, c, a as e, u as t, L as k, _ as d, U as r, M as L, R as Ve, ab as Ae, J as v, W as n, a5 as b, ao as m, r as p, n as Be, l as Pe } from "./@vue.b00de3e9.js";
import "./axios.853f16bf.js";
import "./element-plus.53baa8a9.js";
import "./@element-plus.e21ea623.js";
import "./@ctrl.11979b50.js";
import "./dayjs.9abdbee1.js";
import "./clipboard.aaae98d3.js";
import "./@vueuse.eccd744a.js";
import "./lodash-es.e1022fb5.js";
import "./@popperjs.da591b4f.js";
import "./vant.f7b4805b.js";
import "./@vant.f52f09a9.js";
import "./xe-utils.a532b55a.js";
import "./crypto-js.c184c643.js";
import "./decimal.js.2def1975.js";
import "./nprogress.9fc41f77.js";
import "./vconsole.0cfb1d33.js";
import "./perfect-scrollbar.19f80865.js";
import "./@intlify.928cb664.js";
let Is;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e2) {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch (e2) {
    }
  })()
]).then(async () => {
  let De, Oe, qe, He, Xe, Ge, Fe, Ne, ze, Me, Ke, Ue, Je, Qe, We, Ye, je, Ze, et, tt, st, it, ot, at, lt, nt, ct, dt, rt, _t, ut, mt, pt, gt, vt, ft, ht, bt, kt, yt, wt, Ct, xt, $t, It, Et, Rt, Lt, Tt, St, Vt, At, Bt, Pt, Dt, Ot, qt, Ht, Xt, Gt, Ft, Nt, zt, Mt, Kt, Ut, Jt, Qt, Wt, Yt;
  De = {
    class: "ui-collapse"
  };
  Oe = {
    class: "title"
  };
  qe = {
    class: "label"
  };
  He = {
    class: "ui-collapse-item__content"
  };
  Xe = {
    class: "game-menu"
  };
  Ge = [
    "onClick"
  ];
  Fe = {
    class: "img"
  };
  Ne = {
    class: "icon"
  };
  ze = [
    "src"
  ];
  Me = {
    class: "text"
  };
  Ke = {
    class: "ui-collapse-item"
  };
  Ue = {
    class: "title"
  };
  Je = {
    class: "label"
  };
  Qe = {
    class: "ui-collapse-item__content"
  };
  We = {
    class: "game-menu"
  };
  Ye = {
    class: "img"
  };
  je = {
    class: "icon"
  };
  Ze = {
    class: "text"
  };
  et = {
    class: "img"
  };
  tt = {
    class: "icon"
  };
  st = {
    class: "text"
  };
  it = {
    class: "img"
  };
  ot = {
    class: "icon"
  };
  at = {
    class: "text"
  };
  lt = {
    class: "img"
  };
  nt = {
    class: "icon"
  };
  ct = {
    class: "text"
  };
  dt = {
    class: "img"
  };
  rt = {
    class: "icon"
  };
  _t = {
    class: "text"
  };
  ut = {
    class: "img"
  };
  mt = {
    class: "icon"
  };
  pt = {
    class: "text"
  };
  gt = {
    class: "img"
  };
  vt = {
    class: "icon"
  };
  ft = {
    class: "text"
  };
  ht = {
    class: "img"
  };
  bt = {
    class: "icon"
  };
  kt = {
    class: "text"
  };
  yt = {
    class: "img"
  };
  wt = {
    class: "icon"
  };
  Ct = {
    class: "text"
  };
  xt = {
    class: "img"
  };
  $t = {
    class: "icon"
  };
  It = {
    class: "text"
  };
  Et = {
    class: "ui-collapse-item"
  };
  Rt = {
    class: "title"
  };
  Lt = {
    class: "label"
  };
  Tt = {
    class: "ui-collapse-item__content"
  };
  St = {
    class: "game-menu"
  };
  Vt = {
    class: "img"
  };
  At = {
    class: "icon"
  };
  Bt = {
    class: "text"
  };
  Pt = {
    class: "img"
  };
  Dt = {
    class: "icon"
  };
  Ot = {
    class: "text"
  };
  qt = {
    class: "img"
  };
  Ht = {
    class: "icon"
  };
  Xt = {
    class: "text"
  };
  Gt = {
    class: "img"
  };
  Ft = {
    class: "icon"
  };
  Nt = {
    class: "text"
  };
  zt = {
    class: "img"
  };
  Mt = {
    class: "icon"
  };
  Kt = {
    class: "text"
  };
  Ut = {
    key: 1,
    class: "ui-collapse-item"
  };
  Jt = {
    class: "title"
  };
  Qt = {
    class: "label"
  };
  Wt = {
    class: "ui-collapse-item__content"
  };
  Yt = {
    class: "game-menu"
  };
  Is = {
    __name: "side_bar_8",
    setup(jt) {
      const f = m(() => u(() => import("./index.829d73d9.js"), ["js/index.829d73d9.js","js/@vue.b00de3e9.js","js/img_xzapp_jl.d99abebb.js","js/vuex.33ea5d58.js","css/index.1e446410.css"])), U = m(() => u(() => import("./wg_side_share_page.062a3543.js"), ["js/wg_side_share_page.062a3543.js","js/@vue.b00de3e9.js"])), J = m(() => u(() => import("./wg_side_pink_agent.8e5c8f6b.js"), ["js/wg_side_pink_agent.8e5c8f6b.js","js/@vue.b00de3e9.js"])), Q = m(() => u(() => import("./wg_side_pink_events.108fa98f.js"), ["js/wg_side_pink_events.108fa98f.js","js/@vue.b00de3e9.js"])), W = m(() => u(() => import("./wg_side_pink_mission.bb6c101a.js"), ["js/wg_side_pink_mission.bb6c101a.js","js/@vue.b00de3e9.js"])), Y = m(() => u(() => import("./wg_side_pink_rebate.1e158c12.js"), ["js/wg_side_pink_rebate.1e158c12.js","js/@vue.b00de3e9.js"])), j = m(() => u(() => import("./wg_side_pink_interest.0ae0d086.js"), ["js/wg_side_pink_interest.0ae0d086.js","js/@vue.b00de3e9.js"])), Z = m(() => u(() => import("./wg_side_pink_fund.36f9a37c.js"), ["js/wg_side_pink_fund.36f9a37c.js","js/@vue.b00de3e9.js"])), ee = m(() => u(() => import("./wg_side_pink_vip.0c7d6ece.js"), ["js/wg_side_pink_vip.0c7d6ece.js","js/@vue.b00de3e9.js"])), te = m(() => u(() => import("./wg_side_pink_unClaim.f0895fae.js"), ["js/wg_side_pink_unClaim.f0895fae.js","js/@vue.b00de3e9.js"])), se = m(() => u(() => import("./wg_side_pink_history.0f196297.js"), ["js/wg_side_pink_history.0f196297.js","js/@vue.b00de3e9.js"])), ie = m(() => u(() => import("./wg_side_pink_download.853d0d30.js"), ["js/wg_side_pink_download.853d0d30.js","js/@vue.b00de3e9.js"])), oe = m(() => u(() => import("./wg_side_pink_customer.86038ab7.js"), ["js/wg_side_pink_customer.86038ab7.js","js/@vue.b00de3e9.js"])), ae = m(() => u(() => import("./wg_side_pink_faq.d29f17b5.js"), ["js/wg_side_pink_faq.d29f17b5.js","js/@vue.b00de3e9.js"])), le = m(() => u(() => import("./wg_side_pink_aboutus.33d2f8b1.js"), ["js/wg_side_pink_aboutus.33d2f8b1.js","js/@vue.b00de3e9.js"])), ne = m(() => u(() => import("./wg_side_pink_feedback.b4acdd5c.js"), ["js/wg_side_pink_feedback.b4acdd5c.js","js/@vue.b00de3e9.js"])), { locale: Zt, t: ce } = Re(), o = $e(), de = p(null), re = p(null), D = Ie();
      Ee();
      const y = p(true), T = p(null), O = p("auto"), w = p(false), S = p(null), q = p("auto"), C = p(false), V = p(null), H = p("auto"), x = p(false), A = p(null), X = p("auto"), { ggId: $, fbId: I } = o.state.loginConfig, { bindGoogle: _e, bindFacebook: ue, initFacebookSDK: me } = Le();
      me(I);
      const B = () => {
        Be(() => {
          T.value && (O.value = T.value.scrollHeight + "px"), S.value && (q.value = S.value.scrollHeight + "px"), V.value && (H.value = V.value.scrollHeight + "px"), A.value && (X.value = A.value.scrollHeight + "px");
        });
      }, pe = Pe(() => {
        var _a, _b, _c;
        return ye() ? !o.state.isApp && ((_a = o.state.downloadBar) == null ? void 0 : _a.systemGuideConfig.Android.guideStatus) : we() ? !o.state.isApp && ((_b = o.state.downloadBar) == null ? void 0 : _b.systemGuideConfig.IOS.guideStatus) : (_c = o.state.downloadBar) == null ? void 0 : _c.systemGuideConfig.PC.guideStatus;
      });
      K(() => o.state.tableList, () => {
        B();
      }, {
        deep: true
      }), K(() => o.state.showSideBar, (i) => {
        if (i && $) {
          const s = document.getElementById("google_btn");
          setTimeout(() => {
            s && s.hasChildNodes() && s.click();
          }, 1e3);
        }
      });
      const ge = () => {
        N.get("/user/media-management/list").then((i) => {
          i.status === "OK" && (o.state.mediaList.push(...i.data), console.log(123456, o.state.mediaList));
        });
      };
      Te(() => {
        fe(), ge(), B(), window.addEventListener("resize", () => {
          B();
        });
      });
      const ve = async () => {
        if (navigator.share)
          try {
            let i = o.state.accountInfo.id ? location.origin + "?dl=" + (o.state.accountInfo.id || "") : location.origin;
            await navigator.share({
              title: location.origin,
              text: location.host,
              url: i
            });
          } catch (i) {
            console.error("share error:", i.message);
          }
        else
          M("Your browser does not support sharing.");
      }, fe = () => {
        o.state.tableList.length || he();
      }, he = async () => {
        let i = [];
        await N.get("/game/game/typedVendors").then(async (s) => {
          if (s.code === 0) {
            i.push(...s.data.filter((_) => !!_.vendors.length || _.type === 0 || _.type === 98 || _.type === 99));
            let h = i.find((_) => _.type === 0), a = i.findIndex((_) => _.type === 0);
            a !== -1 && i.splice(a, 1);
            let R = i.find((_) => _.type === 98), P = i.findIndex((_) => _.type === 98);
            P !== -1 && i.splice(P, 1);
            let G = i.find((_) => _.type === 99), F = i.findIndex((_) => _.type === 99);
            F !== -1 && i.splice(F, 1), h && i.unshift(h), R && i.push(R), G && i.push(G), o.state.tableList = i;
          }
        });
      }, g = (i) => {
        if (!i)
          return M(ce("side_bar.closed"));
        o.state.showSideBar = false, D.push(i);
      }, be = (i, s) => {
        o.state.showSideBar = false, [
          "98",
          "99"
        ].includes(s.type) ? D.push("/sub-game?typeId=" + s.type) : globalVBus.$emit("changeActiveTab", i, s);
      }, E = (i) => {
        i === "game" ? y.value = !y.value : i === "offers" ? w.value = !w.value : i === "support" ? C.value = !C.value : x.value = !x.value;
      };
      return (i, s) => {
        var _a, _b, _c, _d, _e2, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t2, _u, _v;
        const h = Se("svg-icon");
        return l(), c("div", {
          class: "app-side-bar",
          ref_key: "appSideBarRef",
          ref: re
        }, [
          e("div", {
            class: k([
              {
                show: t(o).state.showSideBar
              },
              "side-bar"
            ]),
            ref_key: "sideBarRef",
            ref: de
          }, [
            e("div", De, [
              t(o).state.tableList.length ? (l(), c("div", {
                key: 0,
                class: k([
                  "ui-collapse-item",
                  {
                    "ui-collapse-item--expanded": y.value
                  }
                ])
              }, [
                e("div", {
                  class: "ui-collapse-title",
                  onClick: s[0] || (s[0] = (a) => E("game"))
                }, [
                  e("div", Oe, [
                    e("span", qe, d(i.$t("side_bar.casino")), 1),
                    e("i", {
                      class: k([
                        "icon",
                        {
                          rotate: !y.value
                        }
                      ])
                    }, [
                      r(h, {
                        iconClass: "wg_arrow_down"
                      })
                    ], 2)
                  ])
                ]),
                e("div", {
                  class: "ui-collapse-item__wrapper",
                  style: L({
                    height: y.value ? O.value : "0"
                  }),
                  ref_key: "gameRef",
                  ref: T
                }, [
                  e("div", He, [
                    e("ul", Xe, [
                      (l(true), c(Ve, null, Ae(t(o).state.tableList, (a, R) => (l(), c("li", {
                        class: "game-item",
                        onClick: (P) => be(R, a)
                      }, [
                        e("div", Fe, [
                          e("i", Ne, [
                            a.icon.indexOf("http") > -1 ? (l(), c("img", {
                              key: 0,
                              src: a.icon,
                              alt: ""
                            }, null, 8, ze)) : (l(), v(h, {
                              key: 1,
                              iconClass: t(ke)(a.type)
                            }, null, 8, [
                              "iconClass"
                            ]))
                          ])
                        ]),
                        e("div", Me, d(a.typeName), 1)
                      ], 8, Ge))), 256))
                    ])
                  ])
                ], 4)
              ], 2)) : n("", true),
              e("div", Ke, [
                e("div", {
                  class: "ui-collapse-title",
                  onClick: s[1] || (s[1] = (a) => E("offers"))
                }, [
                  e("div", Ue, [
                    e("span", Je, d(i.$t("side_bar.offers")), 1),
                    e("i", {
                      class: k([
                        "icon",
                        {
                          rotate: !w.value
                        }
                      ])
                    }, [
                      r(h, {
                        iconClass: "wg_arrow_down"
                      })
                    ], 2)
                  ])
                ]),
                e("div", {
                  class: "ui-collapse-item__wrapper",
                  style: L({
                    height: w.value ? q.value : "0"
                  }),
                  ref_key: "offersRef",
                  ref: S
                }, [
                  e("div", Qe, [
                    e("ul", We, [
                      e("li", {
                        class: "game-item",
                        onClick: ve
                      }, [
                        e("div", Ye, [
                          e("i", je, [
                            r(t(U), {
                              class: "svg-icon"
                            })
                          ])
                        ]),
                        e("div", Ze, d(i.$t("customize_activity_wg.share")), 1)
                      ]),
                      t(o).state.featureSwitch.agent ? (l(), c("li", {
                        key: 0,
                        class: "game-item",
                        onClick: s[2] || (s[2] = (a) => g("/home/promote"))
                      }, [
                        e("div", et, [
                          e("i", tt, [
                            r(t(J), {
                              class: "svg-icon"
                            })
                          ])
                        ]),
                        e("div", st, [
                          e("span", null, [
                            b(d(i.$t("side_bar.share_to_win")) + " ", 1),
                            t(o).state.badges && ((_a = t(o).state.badges.agent) == null ? void 0 : _a.badge) ? (l(), v(t(f), {
                              key: 0,
                              auto: true,
                              top: "-0.1rem",
                              style: {
                                transform: "translateX(100%)"
                              },
                              text: (_b = t(o).state.badges.agent) == null ? void 0 : _b.badge
                            }, null, 8, [
                              "text"
                            ])) : n("", true)
                          ])
                        ])
                      ])) : n("", true),
                      e("li", {
                        class: "game-item",
                        onClick: s[3] || (s[3] = (a) => g("/home/event"))
                      }, [
                        e("div", it, [
                          e("i", ot, [
                            r(t(Q), {
                              class: "svg-icon"
                            })
                          ])
                        ]),
                        e("div", at, [
                          e("span", null, [
                            b(d(i.$t("side_bar.event")) + " ", 1),
                            ((_d = (_c = t(o).state.badges) == null ? void 0 : _c.promotion) == null ? void 0 : _d.badge) ? (l(), v(t(f), {
                              key: 0,
                              auto: true,
                              top: "-0.1rem",
                              style: {
                                transform: "translateX(100%)"
                              },
                              text: (_e2 = t(o).state.badges.promotion) == null ? void 0 : _e2.badge
                            }, null, 8, [
                              "text"
                            ])) : n("", true)
                          ])
                        ])
                      ]),
                      t(o).state.featureSwitch.task ? (l(), c("li", {
                        key: 1,
                        class: "game-item",
                        onClick: s[4] || (s[4] = (a) => g("/home/task"))
                      }, [
                        e("div", lt, [
                          e("i", nt, [
                            r(t(W), {
                              class: "svg-icon"
                            })
                          ])
                        ]),
                        e("div", ct, [
                          e("span", null, [
                            b(d(i.$t("side_bar.task")) + " ", 1),
                            ((_g = (_f = t(o).state.badges) == null ? void 0 : _f.task) == null ? void 0 : _g.badge) ? (l(), v(t(f), {
                              key: 0,
                              auto: true,
                              top: "-0.1rem",
                              style: {
                                transform: "translateX(100%)"
                              },
                              text: t(o).state.badges.task.badge
                            }, null, 8, [
                              "text"
                            ])) : n("", true)
                          ])
                        ])
                      ])) : n("", true),
                      t(o).state.featureSwitch.rebate ? (l(), c("li", {
                        key: 2,
                        class: "game-item",
                        onClick: s[5] || (s[5] = (a) => g("/home/cashback"))
                      }, [
                        e("div", dt, [
                          e("i", rt, [
                            r(t(Y), {
                              class: "svg-icon"
                            })
                          ])
                        ]),
                        e("div", _t, [
                          e("span", null, [
                            b(d(i.$t("side_bar.rebate")) + " ", 1),
                            ((_i = (_h = t(o).state.badges) == null ? void 0 : _h.rebate) == null ? void 0 : _i.badge) ? (l(), v(t(f), {
                              key: 0,
                              auto: true,
                              top: "-0.1rem",
                              style: {
                                transform: "translateX(100%)"
                              },
                              text: (_j = t(o).state.badges.rebate) == null ? void 0 : _j.badge
                            }, null, 8, [
                              "text"
                            ])) : n("", true)
                          ])
                        ])
                      ])) : n("", true),
                      t(o).state.featureSwitch.incomeBox ? (l(), c("li", {
                        key: 3,
                        class: "game-item",
                        onClick: s[6] || (s[6] = (a) => g("/home/yuebao"))
                      }, [
                        e("div", ut, [
                          e("i", mt, [
                            r(t(j), {
                              class: "svg-icon"
                            })
                          ])
                        ]),
                        e("div", pt, [
                          e("span", null, [
                            b(d(i.$t("side_bar.fees")) + " ", 1),
                            ((_l = (_k = t(o).state.badges) == null ? void 0 : _k.incomeBox) == null ? void 0 : _l.badge) ? (l(), v(t(f), {
                              key: 0,
                              textColor: "rgb(255, 255, 0)",
                              auto: true,
                              top: "-0.1rem",
                              style: {
                                transform: "translateX(100%)"
                              },
                              text: (_m = t(o).state.badges.incomeBox) == null ? void 0 : _m.badge
                            }, null, 8, [
                              "text"
                            ])) : n("", true)
                          ])
                        ])
                      ])) : n("", true),
                      t(o).state.featureSwitch.depositPool ? (l(), c("li", {
                        key: 4,
                        class: "game-item",
                        onClick: s[7] || (s[7] = (a) => g("/home/rechargeFund"))
                      }, [
                        e("div", gt, [
                          e("i", vt, [
                            r(t(Z), {
                              class: "svg-icon"
                            })
                          ])
                        ]),
                        e("div", ft, [
                          e("span", null, [
                            b(d(i.$t("side_bar.fund")) + " ", 1),
                            ((_o = (_n = t(o).state.badges) == null ? void 0 : _n.depositPool) == null ? void 0 : _o.badge) ? (l(), v(t(f), {
                              key: 0,
                              auto: true,
                              top: "-0.1rem",
                              style: {
                                transform: "translateX(100%)"
                              },
                              textColor: "rgb(255, 255, 0)",
                              text: (_p = t(o).state.badges.depositPool) == null ? void 0 : _p.badge
                            }, null, 8, [
                              "text"
                            ])) : n("", true)
                          ])
                        ])
                      ])) : n("", true),
                      t(o).state.featureSwitch.vip ? (l(), c("li", {
                        key: 5,
                        class: "game-item",
                        onClick: s[8] || (s[8] = (a) => g("/home/vip"))
                      }, [
                        e("div", ht, [
                          e("i", bt, [
                            r(t(ee), {
                              class: "svg-icon"
                            })
                          ])
                        ]),
                        e("div", kt, [
                          e("span", null, [
                            s[21] || (s[21] = b(" VIP ", -1)),
                            ((_r = (_q = t(o).state.badges) == null ? void 0 : _q.vip) == null ? void 0 : _r.badge) ? (l(), v(t(f), {
                              key: 0,
                              auto: true,
                              top: "-0.1rem",
                              style: {
                                transform: "translateX(100%)"
                              },
                              text: (_s = t(o).state.badges.vip) == null ? void 0 : _s.badge
                            }, null, 8, [
                              "text"
                            ])) : n("", true)
                          ])
                        ])
                      ])) : n("", true),
                      e("li", {
                        class: "game-item",
                        onClick: s[9] || (s[9] = (a) => g("/home/canReceive"))
                      }, [
                        e("div", yt, [
                          e("i", wt, [
                            r(t(te), {
                              class: "svg-icon"
                            })
                          ])
                        ]),
                        e("div", Ct, [
                          e("span", null, [
                            b(d(i.$t("side_bar.reward")) + " ", 1),
                            ((_u = (_t2 = t(o).state.badges) == null ? void 0 : _t2.unclaimed) == null ? void 0 : _u.badge) ? (l(), v(t(f), {
                              key: 0,
                              auto: true,
                              top: "-0.1rem",
                              style: {
                                transform: "translateX(100%)"
                              },
                              text: (_v = t(o).state.badges.unclaimed) == null ? void 0 : _v.badge
                            }, null, 8, [
                              "text"
                            ])) : n("", true)
                          ])
                        ])
                      ]),
                      e("li", {
                        class: "game-item",
                        onClick: s[10] || (s[10] = (a) => g("/home/records"))
                      }, [
                        e("div", xt, [
                          e("i", $t, [
                            r(t(se), {
                              class: "svg-icon"
                            })
                          ])
                        ]),
                        e("div", It, d(i.$t("side_bar.history")), 1)
                      ])
                    ])
                  ])
                ], 4)
              ]),
              e("div", Et, [
                e("div", {
                  class: "ui-collapse-title",
                  onClick: s[11] || (s[11] = (a) => E("support"))
                }, [
                  e("div", Rt, [
                    e("span", Lt, d(i.$t("side_bar.support_center")), 1),
                    e("i", {
                      class: k([
                        "icon",
                        {
                          rotate: !C.value
                        }
                      ])
                    }, [
                      r(h, {
                        iconClass: "wg_arrow_down"
                      })
                    ], 2)
                  ])
                ]),
                e("div", {
                  class: "ui-collapse-item__wrapper",
                  style: L({
                    height: C.value ? H.value : "0"
                  }),
                  ref_key: "supportRef",
                  ref: V
                }, [
                  e("div", Tt, [
                    e("ul", St, [
                      pe.value ? (l(), c("li", {
                        key: 0,
                        class: "game-item",
                        onClick: s[12] || (s[12] = (...a) => t(z) && t(z)(...a))
                      }, [
                        e("div", Vt, [
                          e("i", At, [
                            r(t(ie), {
                              class: "svg-icon"
                            })
                          ])
                        ]),
                        e("div", Bt, d(i.$t("side_bar.download")), 1)
                      ])) : n("", true),
                      e("li", {
                        class: "game-item",
                        onClick: s[13] || (s[13] = (a) => g("/home/notice?noticeType=4"))
                      }, [
                        e("div", Pt, [
                          e("i", Dt, [
                            r(t(oe), {
                              class: "svg-icon"
                            })
                          ])
                        ]),
                        e("div", Ot, d(i.$t("side_bar.customer_service")), 1)
                      ]),
                      t(o).state.featureSwitch.faq ? (l(), c("li", {
                        key: 1,
                        class: "game-item",
                        onClick: s[14] || (s[14] = (a) => g("/home/notice?noticeType=4"))
                      }, [
                        e("div", qt, [
                          e("i", Ht, [
                            r(t(ae), {
                              class: "svg-icon"
                            })
                          ])
                        ]),
                        e("div", Xt, d(i.$t("side_bar.faq")), 1)
                      ])) : n("", true),
                      t(o).state.featureSwitch.aboutUs ? (l(), c("li", {
                        key: 2,
                        class: "game-item",
                        onClick: s[15] || (s[15] = (a) => g("/home/about"))
                      }, [
                        e("div", Gt, [
                          e("i", Ft, [
                            r(t(le), {
                              class: "svg-icon"
                            })
                          ])
                        ]),
                        e("div", Nt, d(i.$t("side_bar.about_us")), 1)
                      ])) : n("", true),
                      t(o).state.featureSwitch.feedback ? (l(), c("li", {
                        key: 3,
                        class: "game-item",
                        onClick: s[16] || (s[16] = (a) => g("/home/notice?noticeType=5"))
                      }, [
                        e("div", zt, [
                          e("i", Mt, [
                            r(t(ne), {
                              class: "svg-icon"
                            })
                          ])
                        ]),
                        e("div", Kt, d(i.$t("side_bar.feedback")), 1)
                      ])) : n("", true)
                    ])
                  ])
                ], 4)
              ]),
              !t(o).state.accountInfo.id && (t($) || t(I)) ? (l(), c("div", Ut, [
                e("div", {
                  class: "ui-collapse-title",
                  onClick: s[17] || (s[17] = (a) => E("quick"))
                }, [
                  e("div", Jt, [
                    e("span", Qt, d(i.$t("side_bar.quick_login")), 1),
                    e("i", {
                      class: k([
                        "icon",
                        {
                          rotate: !x.value
                        }
                      ])
                    }, [
                      r(h, {
                        iconClass: "wg_arrow_down"
                      })
                    ], 2)
                  ])
                ]),
                e("div", {
                  class: "ui-collapse-item__wrapper",
                  style: L({
                    height: x.value ? X.value : "0"
                  }),
                  ref_key: "quickRef",
                  ref: A
                }, [
                  e("div", Wt, [
                    e("ul", Yt, [
                      t($) ? (l(), c("li", {
                        key: 0,
                        class: "game-item",
                        onClick: s[18] || (s[18] = (a) => t(_e)(t($)))
                      }, [
                        ...s[22] || (s[22] = [
                          e("div", {
                            class: "third-party-button"
                          }, [
                            e("div", {
                              class: "real-google-btn",
                              id: "google_btn"
                            })
                          ], -1),
                          e("img", {
                            class: "login-icon",
                            src: Ce,
                            alt: "",
                            srcset: ""
                          }, null, -1),
                          e("div", {
                            class: "text one-line"
                          }, "Google Login", -1)
                        ])
                      ])) : n("", true),
                      t(I) ? (l(), c("li", {
                        key: 1,
                        class: "game-item",
                        id: "facebook_btn",
                        onClick: s[19] || (s[19] = (a) => t(ue)(t(I)))
                      }, [
                        ...s[23] || (s[23] = [
                          e("img", {
                            class: "login-icon",
                            src: xe,
                            alt: "",
                            srcset: ""
                          }, null, -1),
                          e("div", {
                            class: "text one-line"
                          }, "Facebook Login", -1)
                        ])
                      ])) : n("", true)
                    ])
                  ])
                ], 4)
              ])) : n("", true)
            ])
          ], 2),
          t(o).state.showSideBar && t(o).state.isMobile ? (l(), c("div", {
            key: 0,
            class: "side-overlay",
            onClick: s[20] || (s[20] = (a) => t(o).state.showSideBar = false)
          })) : n("", true)
        ], 512);
      };
    }
  };
});
export {
  __tla,
  Is as default
};
