import { O as gt, $ as st, T as ct, _ as yt, t as wt, u as bt, d as $t, __tla as __tla_0 } from "./index.bb04cb73.js";
import { F as dt, o as I, c as L, a as t, u as w, L as B, _ as x, O as Y, Z as J, d as nt, r as v, M as K, R as et, ab as _t, W as X, l as S, e as vt, n as mt, a5 as Ft, a3 as Tt, w as Dt, J as tt, V as ut, ao as xt } from "./@vue.b00de3e9.js";
import { b as It, u as kt } from "./vue-router.c227d4ba.js";
import { u as lt } from "./vuex.33ea5d58.js";
import { u as pt } from "./vue-i18n.07fcbeea.js";
import { u as ft } from "./useWinningToast.fa7f6a2b.js";
import "./axios.853f16bf.js";
import "./element-plus.53baa8a9.js";
import "./@element-plus.e21ea623.js";
import "./@ctrl.11979b50.js";
import "./dayjs.9abdbee1.js";
import "./clipboard.aaae98d3.js";
import "./@vueuse.eccd744a.js";
import "./lodash-es.e1022fb5.js";
import "./@popperjs.da591b4f.js";
import "./vant.f7b4805b.js";
import "./@vant.f52f09a9.js";
import "./xe-utils.a532b55a.js";
import "./crypto-js.c184c643.js";
import "./decimal.js.2def1975.js";
import "./nprogress.9fc41f77.js";
import "./vconsole.0cfb1d33.js";
import "./perfect-scrollbar.19f80865.js";
import "./@intlify.928cb664.js";
let Is;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e) {
    }
  })()
]).then(async () => {
  const St = "/png/glow.7ef47d3e.png", At = "/png/pedestal_clean.98d24b25.png", Ct = "/svg/rules_panel.a7dd8dff.svg", Et = "/svg/title_line_left.14ec1dc6.svg", Rt = "/svg/title_line_right.ba33c6c3.svg", Bt = "/png/chest_fill.83427e08.png", Ht = "/png/chest_fill_avtive.97113ba0.png", Mt = "/png/tap_hand.592b9dfe.png", Pt = "/svg/close.d8201995.svg";
  const Lt = {
    class: "registr-activity-style-1"
  }, Nt = {
    class: "page-wrap"
  }, zt = [
    "src"
  ], Ot = {
    class: "hero"
  }, jt = {
    class: "currency"
  }, Vt = {
    class: "value"
  }, Wt = [
    "src"
  ], qt = [
    "src"
  ], Gt = {
    class: "rule-panel"
  }, Ut = {
    class: "rule-title"
  }, Kt = {
    class: "rule-list"
  }, Xt = [
    "innerHTML"
  ], Yt = nt({
    name: "registrActivityStyle1"
  }), Jt = Object.assign(Yt, {
    props: {
      detail: {
        type: Object,
        required: true
      }
    },
    emits: [
      "close"
    ],
    setup(C, { emit: N }) {
      const b = C, H = N, g = lt();
      It();
      const { t: M } = pt(), i = v(false), d = v(false), $ = v(false), F = v(false);
      let f = null, c = null;
      const r = v({}), p = () => {
        $.value = true, F.value = true, c && clearTimeout(c), c = setTimeout(() => {
          F.value = false, c = null;
        }, 900);
      }, T = () => {
        d.value || i.value || (d.value = true, f = setTimeout(async () => {
          d.value = false, await D(), f = null;
        }, 280));
      }, D = async () => {
        await st.post("/user/promotion/claim", {
          type: b.detail.type,
          promotionId: b.detail.id
        }).then((_) => {
          _.code === 0 && (i.value = true, g.dispatch("refreshBalance"), r.value = _.data, p());
        });
      }, m = () => {
        H("close");
      };
      return dt(() => {
        f && (clearTimeout(f), f = null), c && (clearTimeout(c), c = null);
      }), (_, l) => {
        var _a, _b;
        return I(), L("div", Lt, [
          t("div", Nt, [
            t("button", {
              class: "close-btn",
              type: "button",
              onClick: m
            }, [
              t("img", {
                src: w(Pt),
                alt: "close"
              }, null, 8, zt)
            ]),
            t("div", Ot, [
              t("div", {
                class: B([
                  "amount",
                  {
                    show: $.value,
                    pop: F.value
                  }
                ])
              }, [
                t("div", jt, x(w(gt)()), 1),
                t("div", Vt, x((_b = (_a = r.value) == null ? void 0 : _a.reward) == null ? void 0 : _b.toString().replace(".", ",")), 1)
              ], 2),
              l[0] || (l[0] = t("img", {
                class: "hero-glow",
                src: St,
                alt: ""
              }, null, -1)),
              t("img", {
                class: B([
                  "hero-chest",
                  {
                    opening: d.value,
                    opened: i.value
                  }
                ]),
                src: i.value ? w(Ht) : w(Bt),
                alt: "chest",
                onClick: T
              }, null, 10, Wt),
              Y(t("img", {
                class: B([
                  "hero-hand",
                  {
                    pressing: d.value
                  }
                ]),
                src: w(Mt),
                alt: "tap hand"
              }, null, 10, qt), [
                [
                  J,
                  !i.value
                ]
              ]),
              Y(t("span", {
                class: B([
                  "hero-tap-ring",
                  {
                    pressing: d.value
                  }
                ])
              }, null, 2), [
                [
                  J,
                  !i.value
                ]
              ]),
              l[1] || (l[1] = t("img", {
                class: "hero-pedestal",
                src: At,
                alt: ""
              }, null, -1))
            ]),
            t("div", Gt, [
              l[4] || (l[4] = t("img", {
                class: "rule-bg",
                src: Ct,
                alt: ""
              }, null, -1)),
              t("div", Ut, [
                l[2] || (l[2] = t("img", {
                  class: "title-line left",
                  src: Et,
                  alt: ""
                }, null, -1)),
                t("span", null, x(w(M)("turntable.activity_description")), 1),
                l[3] || (l[3] = t("img", {
                  class: "title-line right",
                  src: Rt,
                  alt: ""
                }, null, -1))
              ]),
              t("ol", Kt, [
                t("li", {
                  innerHTML: C.detail.remark
                }, null, 8, Xt)
              ])
            ])
          ])
        ]);
      };
    }
  }), Zt = "/svg/close.cd370c94.svg", Qt = "/png/image_1669.a7acb67a.png", te = "/png/tiger.713a4927.png", ee = "/png/inner-circle.bede75b0.png", se = "/svg/inner_circle.cc5913a9.svg", ne = "/png/coin_badge.4d09fd19.png", le = "/png/wheel_ring.1fe945b0.png", ie = "/png/image_1676.3c44e49a.png", oe = "/png/coin_icon.7ef4118b.png", re = "/svg/rule_panel.d68de91f.svg", ae = "/svg/title_line_left.3bd05701.svg", ce = "/svg/title_line_right.b3bccc3f.svg", ue = "/png/center_highlight_4.3103c5b6.png", ge = "/png/center_highlight_6.03138e47.png", de = "/png/center_highlight_8.84cda91a.png", pe = "/png/center_highlight_10.8536b50d.png";
  const me = {
    class: "registr-activity-style-2"
  }, _e = {
    class: "page-wrap"
  }, ve = {
    class: "wheel-stage"
  }, fe = [
    "src"
  ], he = {
    class: "wheel-layer go-text"
  }, ye = {
    class: "rule-panel"
  }, we = {
    class: "rule-title"
  }, be = {
    class: "rule-list"
  }, $e = [
    "innerHTML"
  ], Fe = nt({
    name: "registrActivityStyle2"
  }), Te = Object.assign(Fe, {
    props: {
      detail: {
        type: Object,
        required: true
      }
    },
    emits: [
      "close"
    ],
    setup(C, { emit: N }) {
      const b = C, { show: H } = ft(), g = N, M = lt(), { t: i } = pt(), d = v(false), $ = 4600, F = 3, f = 220, c = [
        4,
        6,
        8,
        10
      ], r = {
        x: 3.75,
        y: 5.885
      }, p = {
        4: {
          textRadius: 1.46,
          coinRadius: 2.22,
          colors: [
            "#A8D5FE",
            "#FBF2D4",
            "#A8D5FE",
            "#FBF2D4"
          ]
        },
        6: {
          textRadius: 1.54,
          coinRadius: 2.29,
          colors: [
            "#A8D5FE",
            "#FBF2D4",
            "#E8D0FF",
            "#A8D5FE",
            "#FBF2D4",
            "#E8D0FF"
          ]
        },
        8: {
          textRadius: 1.56,
          coinRadius: 2.3,
          colors: [
            "#A8D5FE",
            "#FBF2D4",
            "#E8D0FF",
            "#FBF2D4",
            "#A8D5FE",
            "#FBF2D4",
            "#E8D0FF",
            "#FBF2D4"
          ]
        },
        10: {
          textRadius: 1.62,
          coinRadius: 2.28,
          colors: [
            "#A8D5FE",
            "#FBF2D4",
            "#E8D0FF",
            "#FBF2D4",
            "#A8D5FE",
            "#A8D5FE",
            "#FBF2D4",
            "#E8D0FF",
            "#FBF2D4",
            "#A8D5FE"
          ]
        }
      }, T = {
        4: {
          img: ue,
          left: 1.58,
          top: 3.03,
          width: 4.222,
          transform: "rotate(2deg)"
        },
        6: {
          img: ge,
          left: 2.189,
          top: 2.9034,
          width: 3.1532
        },
        8: {
          img: de,
          left: 2.5548,
          top: 3.0601,
          width: 2.4113
        },
        10: {
          img: pe,
          left: 2.7494,
          top: 3.0001,
          width: 2.0718
        }
      }, D = v(0), m = v(false), _ = v(false);
      let l = null, E = [];
      const O = () => {
        E.length && (E.forEach((s) => clearTimeout(s)), E = []);
      }, it = () => {
        O(), _.value = false;
        for (let s = 0; s < F * 2; s++)
          E.push(setTimeout(() => {
            _.value = s % 2 === 0;
          }, s * f));
        E.push(setTimeout(() => {
          _.value = true;
        }, F * 2 * f));
      }, z = S(() => {
        var _a;
        const s = (_a = b.detail) == null ? void 0 : _a.tiers;
        return Array.isArray(s) ? s.map((e) => e == null ? "" : String(e).trim()).filter((e) => e !== "") : [];
      }), j = S(() => {
        const s = z.value.length;
        return c.includes(s) ? s : 0;
      }), q = S(() => c.includes(j.value)), h = S(() => T[j.value] || T[6]), ot = S(() => h.value.img), rt = S(() => {
        const s = {
          left: "".concat(h.value.left, "rem"),
          top: "".concat(h.value.top, "rem"),
          width: "".concat(h.value.width, "rem")
        };
        return typeof h.value.height == "number" && (s.height = "".concat(h.value.height, "rem")), h.value.transform && (s.transform = h.value.transform), s;
      }), o = S(() => {
        const s = z.value;
        return c.includes(s.length) ? s : [];
      }), n = (s) => {
        const e = s == null ? "" : String(s).trim(), a = Number(e.replace(",", "."));
        return Number.isFinite(a) ? "num:".concat(a) : "text:".concat(e);
      }, y = (s, e) => {
        const a = n(e);
        return s.findIndex((R) => n(R) === a);
      }, k = S(() => {
        if (!q.value)
          return {};
        const s = j.value, e = p[s] || p[8], a = 360 / s, R = -(a / 2), W = Array.from({
          length: s
        }, (P, A) => e.colors[A % e.colors.length]).map((P, A) => {
          const U = A * a, at = (A + 1) * a;
          return "".concat(P, " ").concat(U, "deg ").concat(at, "deg");
        });
        return {
          "--segment-angle": "".concat(a, "deg"),
          "--segment-start-angle": "".concat(R, "deg"),
          "--segment-fill": "conic-gradient(from ".concat(R, "deg, ").concat(W.join(", "), ")")
        };
      }), u = S(() => {
        if (!q.value)
          return [];
        const s = o.value.length;
        if (!s)
          return [];
        const e = p[s] || p[8], a = 360 / s;
        return o.value.map((R, G) => {
          const W = -90 + G * a, P = W * Math.PI / 180, A = r.x + e.textRadius * Math.cos(P), U = r.y + e.textRadius * Math.sin(P), at = r.x + e.coinRadius * Math.cos(P), ht = r.y + e.coinRadius * Math.sin(P);
          return {
            index: G,
            label: R,
            prizeStyle: {
              left: "".concat(A, "rem"),
              top: "".concat(U, "rem"),
              transform: "translate(-50%, -50%) rotate(".concat(W + 90, "deg)")
            },
            coinStyle: {
              left: "".concat(at, "rem"),
              top: "".concat(ht, "rem"),
              transform: "translate(-50%, -50%)"
            }
          };
        });
      }), V = async () => {
        var _a;
        try {
          const s = await st.post("/user/promotion/claim", {
            type: b.detail.type,
            promotionId: b.detail.id
          });
          if (s.code !== 0)
            return s.msg && ct(s.msg), null;
          M.dispatch("refreshBalance");
          const e = (_a = s == null ? void 0 : s.data) == null ? void 0 : _a.reward;
          if (d.value || (d.value = true, m.value))
            return;
          O(), _.value = false;
          const a = o.value;
          if (!a.length)
            return;
          if (m.value = true, e == null || e === "") {
            m.value = false;
            return;
          }
          const R = y(a, e);
          if (R === -1) {
            m.value = false, ct(i("turntable.reward_mismatch_with_tiers"), "error");
            return;
          }
          const G = 360 / a.length, W = (D.value % 360 + 360) % 360;
          let A = (360 - R * G) % 360 - W;
          A <= 0 && (A += 360);
          const U = 6 + Math.floor(Math.random() * 3);
          D.value += U * 360 + A, l && clearTimeout(l), l = setTimeout(() => {
            m.value = false, it(), setTimeout(() => {
              H(i("lucky_wheel_wg.text6", {
                prize: e.toString().replace(".", ",")
              }), "success");
            }, 100);
          }, $);
        } catch (e) {
          return ct(i("leftMenu.failed"), "error"), null;
        }
      }, Z = S(() => ({
        transform: "rotate(".concat(D.value, "deg)"),
        transition: m.value ? "transform ".concat($, "ms cubic-bezier(0.16, 1, 0.3, 1)") : "none"
      })), Q = () => {
        g("close");
      };
      return dt(() => {
        l && (clearTimeout(l), l = null), O();
      }), (s, e) => (I(), L("div", me, [
        t("div", _e, [
          t("button", {
            class: "close-btn",
            type: "button",
            onClick: Q
          }, [
            ...e[0] || (e[0] = [
              t("img", {
                src: Zt,
                alt: "close"
              }, null, -1)
            ])
          ]),
          t("div", ve, [
            e[4] || (e[4] = t("div", {
              class: "wheel-layer image-1669"
            }, [
              t("img", {
                src: Qt,
                alt: ""
              })
            ], -1)),
            e[5] || (e[5] = t("div", {
              class: "wheel-layer tiger"
            }, [
              t("img", {
                src: te,
                alt: ""
              })
            ], -1)),
            t("div", {
              class: "wheel-rotator",
              style: K(Z.value)
            }, [
              e[2] || (e[2] = t("div", {
                class: "wheel-layer wheel-ring-box"
              }, [
                t("img", {
                  class: "wheel-ring",
                  src: ee,
                  alt: ""
                })
              ], -1)),
              e[3] || (e[3] = t("div", {
                class: "wheel-layer inner-circle"
              }, [
                t("img", {
                  src: se,
                  alt: ""
                })
              ], -1)),
              q.value ? (I(), L(et, {
                key: 0
              }, [
                t("div", {
                  class: "wheel-layer dynamic-sectors",
                  style: K(k.value)
                }, null, 4),
                (I(true), L(et, null, _t(u.value, (a) => (I(), L(et, {
                  key: "dynamic-".concat(a.index)
                }, [
                  t("span", {
                    class: "wheel-layer prize dynamic-prize",
                    style: K(a.prizeStyle)
                  }, x(a.label.toString().replace(".", ",")), 5),
                  t("div", {
                    class: "wheel-layer coin dynamic-coin",
                    style: K(a.coinStyle)
                  }, [
                    ...e[1] || (e[1] = [
                      t("img", {
                        src: ne,
                        alt: ""
                      }, null, -1)
                    ])
                  ], 4)
                ], 64))), 128))
              ], 64)) : X("", true)
            ], 4),
            Y(t("div", {
              class: "wheel-layer center-highlight",
              style: K(rt.value)
            }, [
              t("img", {
                src: ot.value,
                alt: ""
              }, null, 8, fe)
            ], 4), [
              [
                J,
                _.value
              ]
            ]),
            e[6] || (e[6] = t("div", {
              class: "wheel-layer wheel-pointer"
            }, [
              t("img", {
                class: "wheel-ring-2",
                src: le,
                alt: ""
              })
            ], -1)),
            t("div", {
              class: B([
                "wheel-layer go-button",
                {
                  spinning: m.value
                }
              ]),
              onClick: V
            }, null, 2),
            t("span", he, x(w(i)("turntable.registr_style_2_go")), 1),
            e[7] || (e[7] = t("div", {
              class: "wheel-layer image-1676"
            }, [
              t("img", {
                src: ie,
                alt: ""
              })
            ], -1)),
            e[8] || (e[8] = t("div", {
              class: "wheel-layer coin-stack"
            }, [
              t("img", {
                src: oe,
                alt: ""
              })
            ], -1))
          ]),
          t("div", ye, [
            e[11] || (e[11] = t("img", {
              class: "rule-bg",
              src: re,
              alt: ""
            }, null, -1)),
            t("div", we, [
              e[9] || (e[9] = t("img", {
                class: "title-line left",
                src: ae,
                alt: ""
              }, null, -1)),
              t("span", null, x(w(i)("turntable.activity_description")), 1),
              e[10] || (e[10] = t("img", {
                class: "title-line right",
                src: ce,
                alt: ""
              }, null, -1))
            ]),
            t("ol", be, [
              t("li", {
                innerHTML: C.detail.remark
              }, null, 8, $e)
            ])
          ])
        ])
      ]));
    }
  }), De = "/svg/close.cd370c94.svg", xe = "/png/sign_board.b9f16b36.png", Ie = "/svg/sign_plate.217b1b9f.svg", ke = "/png/glow.7ef47d3e.png", Se = "/png/wheel_scene.7606affb.png", Ae = "/png/new_badge.1c76f5f2.png", Ce = "/png/coin_icon.7ef4118b.png", Ee = "/png/btn_bg.3071a8fe.png", Re = "/svg/rules_bg.d5c6c50b.svg", Be = "/svg/title_line_left.3bd05701.svg", He = "/svg/title_line_right.b508f5bd.svg", Me = "/png/tap_hand.592b9dfe.png";
  let Pe, Le, Ne, ze, Oe, je, Ve, We, qe, Ge, Ue, Ke, Xe, Ye, Je, Ze, Qe, ts, es, ss;
  Pe = {
    class: "registr-activity-style-3"
  };
  Le = {
    class: "page-wrap"
  };
  Ne = {
    class: "activity-scene"
  };
  ze = {
    class: "sign-wrap"
  };
  Oe = {
    class: "title-wrap"
  };
  je = {
    class: "title-main"
  };
  Ve = {
    class: "title-sub"
  };
  We = {
    class: "wheel-wrap"
  };
  qe = {
    class: "spin-count"
  };
  Ge = {
    class: "slot-viewport"
  };
  Ue = {
    class: "slot-amount"
  };
  Ke = [
    "disabled"
  ];
  Xe = [
    "src"
  ];
  Ye = {
    class: "rule-panel"
  };
  Je = {
    class: "rule-title"
  };
  Ze = {
    class: "rule-list"
  };
  Qe = [
    "innerHTML"
  ];
  ts = nt({
    name: "registrActivityStyle3"
  });
  es = Object.assign(ts, {
    props: {
      detail: {
        type: Object,
        required: true
      }
    },
    emits: [
      "close"
    ],
    setup(C, { emit: N }) {
      var _a;
      const b = C, { show: H } = ft(), g = N, M = lt(), { t: i } = pt(), d = v(false), $ = v(false), F = v(null), f = 1.27, c = 4, r = v([]), p = v(false);
      let T = 0, D = true, m = false, _ = null;
      const l = ((_a = b.detail) == null ? void 0 : _a.tiers.map((o) => gt() + o)) || [];
      let E = 0;
      const O = () => {
        if (!l.length)
          return "";
        const o = l[E];
        return E = (E + 1) % l.length, o;
      }, it = () => Array.from({
        length: c
      }, () => O()), z = (o) => {
        const n = F.value;
        n && (n.style.transform = "translate3d(0, ".concat(o, "rem, 0)"));
      }, j = () => new Promise((o) => requestAnimationFrame(o)), q = (o, n) => new Promise((y) => {
        let k = false, u = null;
        const V = () => {
          k || (k = true, o.removeEventListener("transitionend", Z), u && (clearTimeout(u), u = null), y());
        }, Z = (Q) => {
          Q.target === o && Q.propertyName === "transform" && V();
        };
        u = setTimeout(V, n + 80), o.addEventListener("transitionend", Z);
      }), h = (o, n = "ease-out") => new Promise((y) => {
        const k = async () => {
          if (!D) {
            y();
            return;
          }
          if (m) {
            requestAnimationFrame(k);
            return;
          }
          m = true;
          const u = F.value;
          if (!u) {
            m = false, y();
            return;
          }
          if (u.style.transition = "none", z(-f), await j(), !D || !u.isConnected) {
            m = false, y();
            return;
          }
          if (u.style.transition = "transform ".concat(o, "ms ").concat(n), z(0), await q(u, o), !D || !u.isConnected) {
            m = false, y();
            return;
          }
          u.style.transition = "none";
          const V = O();
          if (r.value = [
            V,
            ...r.value.slice(0, c - 1)
          ], await mt(), !D || !u.isConnected) {
            m = false, y();
            return;
          }
          z(-f), await j(), m = false, y();
        };
        k();
      }), ot = async () => {
        await st.post("/user/promotion/claim", {
          type: b.detail.type,
          promotionId: b.detail.id
        }).then(async (o) => {
          if (o.code === 0) {
            if (M.dispatch("refreshBalance"), T = gt() + o.data.reward, p.value = true, d.value)
              return;
            $.value = true, _ && clearTimeout(_), _ = setTimeout(() => {
              $.value = false, _ = null;
            }, 280), d.value = true;
            const n = l.indexOf(T), y = l.length, k = l[(n - 1 + y) % y];
            for (let u = 0; u < 12 && D; u++)
              await h(80, "linear");
            await h(100, "ease-out"), await h(140, "ease-out"), await h(200, "ease-out"), r.value[0] = T, await h(300, "ease-out"), r.value[0] = k, await h(500, "cubic-bezier(0.16, 1, 0.3, 1)"), d.value = false, setTimeout(() => {
              H(i("lucky_wheel_wg.text6", {
                prize: T.toString().replace(".", ",")
              }), "success");
            }, 100);
          }
        });
      }, rt = () => {
        g("close");
      };
      return vt(async () => {
        D = true, r.value = it(), await mt(), z(-f);
      }), dt(() => {
        _ && (clearTimeout(_), _ = null), D = false;
      }), (o, n) => (I(), L("div", Pe, [
        t("div", Le, [
          t("button", {
            class: "close-btn",
            type: "button",
            onClick: rt
          }, [
            ...n[0] || (n[0] = [
              t("img", {
                src: De,
                alt: "close"
              }, null, -1)
            ])
          ]),
          t("div", Ne, [
            t("div", ze, [
              n[1] || (n[1] = t("img", {
                class: "sign-board",
                src: xe,
                alt: ""
              }, null, -1)),
              n[2] || (n[2] = t("img", {
                class: "sign-plate",
                src: Ie,
                alt: ""
              }, null, -1)),
              n[3] || (n[3] = t("div", {
                class: "sign-glow-wrap"
              }, [
                t("img", {
                  class: "sign-glow",
                  src: ke,
                  alt: ""
                })
              ], -1)),
              t("div", Oe, [
                t("p", je, x(w(i)("turntable.registr_style_3_title_main")), 1),
                t("p", Ve, x(w(i)("turntable.registr_style_3_title_sub")), 1)
              ])
            ]),
            t("div", We, [
              n[6] || (n[6] = t("img", {
                class: "wheel-scene",
                src: Se,
                alt: ""
              }, null, -1)),
              n[7] || (n[7] = t("div", {
                class: "new-badge"
              }, [
                t("img", {
                  src: Ae,
                  alt: "new"
                })
              ], -1)),
              t("p", qe, [
                Ft(x(w(i)("turntable.registr_style_3_spin_label")) + " ", 1),
                n[4] || (n[4] = t("span", null, "X1", -1))
              ]),
              t("div", Ge, [
                t("div", {
                  class: "slot-strip",
                  ref_key: "stripRef",
                  ref: F
                }, [
                  (I(true), L(et, null, _t(r.value, (y, k) => (I(), L("div", {
                    class: "slot-item",
                    key: k
                  }, [
                    n[5] || (n[5] = t("img", {
                      class: "slot-coin",
                      src: Ce,
                      alt: ""
                    }, null, -1)),
                    t("p", Ue, x(y.toString().replace(".", ",")), 1)
                  ]))), 128))
                ], 512)
              ]),
              t("button", {
                class: B([
                  "spin-btn",
                  {
                    pressing: $.value
                  }
                ]),
                type: "button",
                disabled: d.value,
                onClick: Tt(ot, [
                  "stop"
                ])
              }, [
                t("img", {
                  class: B([
                    "spin-btn-bg",
                    {
                      disabled: d.value
                    }
                  ]),
                  src: Ee,
                  alt: ""
                }, null, 2),
                t("span", null, x(w(i)("turntable.registr_style_3_spin_button")), 1)
              ], 10, Ke),
              Y(t("img", {
                class: B([
                  "tap-hand",
                  {
                    pressing: $.value
                  }
                ]),
                src: w(Me),
                alt: "tap hand"
              }, null, 10, Xe), [
                [
                  J,
                  !p.value
                ]
              ]),
              Y(t("span", {
                class: B([
                  "tap-ring",
                  {
                    pressing: $.value
                  }
                ])
              }, null, 2), [
                [
                  J,
                  !p.value
                ]
              ])
            ]),
            t("div", Ye, [
              n[10] || (n[10] = t("img", {
                class: "rule-bg",
                src: Re,
                alt: ""
              }, null, -1)),
              t("div", Je, [
                n[8] || (n[8] = t("img", {
                  class: "title-line left",
                  src: Be,
                  alt: ""
                }, null, -1)),
                t("span", null, x(w(i)("turntable.activity_description")), 1),
                n[9] || (n[9] = t("img", {
                  class: "title-line right",
                  src: He,
                  alt: ""
                }, null, -1))
              ]),
              t("ol", Ze, [
                t("li", {
                  innerHTML: C.detail.remark
                }, null, 8, Qe)
              ])
            ])
          ])
        ])
      ]));
    }
  });
  ss = nt({
    name: "registrActivityIndex"
  });
  Is = Object.assign(ss, {
    setup(C) {
      const N = xt(() => yt(() => import("./index.bb04cb73.js").then(async (m) => {
        await m.__tla;
        return m;
      }).then((r) => r.cg), ["js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css"])), b = lt(), H = kt(), g = v({}), M = v(false), i = v(null), d = {
        padding: 0,
        background: "transparent",
        border: "none",
        boxShadow: "none"
      }, $ = S(() => {
        var _a, _b;
        return H.name !== "game" && H.name !== "limit" && b.state.popDialogList[0] === "registrActivity" && !!((_a = g.value.ext) == null ? void 0 : _a.style) && !((_b = g.value.ext) == null ? void 0 : _b.received) && !b.state.showPreviewRegisterPage;
      }), F = async () => {
        !wt() || M.value || (M.value = true, await st.get("/user/promotion/promotionPop", {
          type: 33
        }).then((r) => {
          const { code: p, data: T } = r;
          p === 0 && T && T.length && (g.value = T[0], bt("registrActivity"));
        }));
      }, f = () => {
        g.value.ext && (g.value.ext.received = true), $t("registrActivity");
      }, c = () => {
        var _a;
        ((_a = i.value) == null ? void 0 : _a.visible) !== void 0 ? i.value.visible = false : f();
      };
      return Dt(() => b.state.accountInfo.id, (r) => {
        r && F();
      }), vt(() => {
        F();
      }), (r, p) => $.value ? (I(), tt(w(N), {
        key: 0,
        ref_key: "dialogRef",
        ref: i,
        class: "registr-activity-dialog",
        width: "7.5rem",
        title: " ",
        showClose: false,
        modalClose: false,
        customDialogPageBoxStyle: d,
        onInput: f
      }, {
        title: ut(() => [
          ...p[0] || (p[0] = [])
        ]),
        footer: ut(() => [
          ...p[1] || (p[1] = [])
        ]),
        default: ut(() => {
          var _a, _b, _c;
          return [
            ((_a = g.value.ext) == null ? void 0 : _a.style) == 1 ? (I(), tt(Jt, {
              key: 0,
              detail: g.value,
              onClose: c
            }, null, 8, [
              "detail"
            ])) : X("", true),
            ((_b = g.value.ext) == null ? void 0 : _b.style) == 2 ? (I(), tt(Te, {
              key: 1,
              detail: g.value,
              onClose: c
            }, null, 8, [
              "detail"
            ])) : X("", true),
            ((_c = g.value.ext) == null ? void 0 : _c.style) == 3 ? (I(), tt(es, {
              key: 2,
              detail: g.value,
              onClose: c
            }, null, 8, [
              "detail"
            ])) : X("", true)
          ];
        }),
        _: 1
      }, 512)) : X("", true);
    }
  });
});
export {
  __tla,
  Is as default
};
