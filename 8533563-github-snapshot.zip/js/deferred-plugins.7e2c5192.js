import { _ as t, __tla as __tla_0 } from "./index.bb04cb73.js";
import "./@vue.b00de3e9.js";
import "./vue-router.c227d4ba.js";
import "./axios.853f16bf.js";
import "./element-plus.53baa8a9.js";
import "./@element-plus.e21ea623.js";
import "./@ctrl.11979b50.js";
import "./dayjs.9abdbee1.js";
import "./clipboard.aaae98d3.js";
import "./@vueuse.eccd744a.js";
import "./lodash-es.e1022fb5.js";
import "./@popperjs.da591b4f.js";
import "./vant.f7b4805b.js";
import "./@vant.f52f09a9.js";
import "./vue-i18n.07fcbeea.js";
import "./@intlify.928cb664.js";
import "./vuex.33ea5d58.js";
import "./xe-utils.a532b55a.js";
import "./crypto-js.c184c643.js";
import "./decimal.js.2def1975.js";
import "./nprogress.9fc41f77.js";
import "./vconsole.0cfb1d33.js";
import "./perfect-scrollbar.19f80865.js";
let w;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e) {
    }
  })()
]).then(async () => {
  w = async function(r) {
    const [{ default: i }, { default: m }, { default: e }, { default: _ }] = await Promise.all([
      t(() => import("./vue-lazyload.60ea81ab.js"), ["js/vue-lazyload.60ea81ab.js","js/@vue.b00de3e9.js"]),
      t(() => import("./@lucky-canvas.9c5d641d.js"), ["js/@lucky-canvas.9c5d641d.js","js/@vue.b00de3e9.js"]),
      t(() => import("./vue-dragscroll.e39451dd.js"), []),
      t(() => import("./vh-check.67221602.js").then((o) => o.v), ["js/vh-check.67221602.js","js/clipboard.aaae98d3.js"])
    ]);
    await t(() => import("./@vant.f52f09a9.js").then((o) => o.n), ["js/@vant.f52f09a9.js","js/@vue.b00de3e9.js"]), r.use(m), r.use(e), r.use(i, {
      preLoad: 1.2,
      loadingClass: "lazy-loading",
      throttleWait: 100
    }), _("browser-address-bar");
  };
});
export {
  __tla,
  w as installDeferredPlugins
};
