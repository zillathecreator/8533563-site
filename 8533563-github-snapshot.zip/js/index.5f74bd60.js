import { u as m } from "./vuex.33ea5d58.js";
import { ai as s, am as l, __tla as __tla_0 } from "./index.bb04cb73.js";
import { w as A, e as f, f as b, r as c } from "./@vue.b00de3e9.js";
let h;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e) {
    }
  })()
]).then(async () => {
  h = function() {
    const e = c(0), o = c(null), t = m(), r = c();
    A(t.state, () => {
      r.value != t.state.balance.coinActiveAmount && u();
    });
    const u = () => {
      if (o.value && clearInterval(o.value), !t.state.balance.coinActiveAmount && t.state.balance.coinActiveAmount !== 0)
        return;
      r.value = t.state.balance.coinActiveAmount, e.value = 0;
      let a = 0, v = 0, n = 0, i = 0;
      o.value = setInterval(() => {
        a = s(t.state.balance.coinActiveAmount, e.value), n = parseInt(a).toString().length, v = Math.pow(10, n - 1), i = Number(v.toString().replace("1", "5").replace("0", "3")), a && (a > i ? e.value = l(e.value, i) : n === i.toString().length && n >= 2 && (a.toString()[0] !== "1" ? e.value = l(e.value, Math.pow(10, n - 1)) : e.value = l(e.value, Math.pow(10, n - 2))), a = s(t.state.balance.coinActiveAmount, e.value), a > 0.21 ? e.value = l(e.value, 0.11) : e.value = l(e.value, 0.01)), e.value == t.state.balance.coinActiveAmount && clearInterval(o.value);
      }, 20);
    };
    return f(() => {
      u();
    }), b(() => {
      u();
    }), {
      animationBalance: u,
      balanceAmount: e
    };
  };
});
export {
  __tla,
  h as u
};
