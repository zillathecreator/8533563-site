import { a as De, a4 as B, o as z, _ as L, i as ee, c as Ee, b as $e, $ as H, m as Ne, t as Be, __tla as __tla_0 } from "./index.bb04cb73.js";
import { w as te, f as ze, e as Ae, a9 as Re, aa as oe, o as n, c as r, a as d, J as g, u as l, W as m, U as k, a3 as ae, R as S, ab as x, _, L as f, M as qe, O as T, ao as I, r as G, m as Me, l as Ve, n as A } from "./@vue.b00de3e9.js";
import { _ as ne } from "./img_game_tj_1.e2fa3187.js";
import { _ as re } from "./collect_on.28ab0f00.js";
import { _ as ie } from "./collect_off.17e416b3.js";
import { _ as se } from "./maintenance.1b212141.js";
import { u as Pe } from "./vuex.33ea5d58.js";
import { b as He, u as Oe } from "./vue-router.c227d4ba.js";
import { X as le } from "./xe-utils.a532b55a.js";
import { u as We } from "./vue-i18n.07fcbeea.js";
import { H as je } from "./hammerjs.1014e407.js";
import { b as Fe } from "./bookmark_star_2.03c96bfe.js";
import "./axios.853f16bf.js";
import "./element-plus.53baa8a9.js";
import "./@element-plus.e21ea623.js";
import "./@ctrl.11979b50.js";
import "./dayjs.9abdbee1.js";
import "./clipboard.aaae98d3.js";
import "./@vueuse.eccd744a.js";
import "./lodash-es.e1022fb5.js";
import "./@popperjs.da591b4f.js";
import "./vant.f7b4805b.js";
import "./@vant.f52f09a9.js";
import "./crypto-js.c184c643.js";
import "./decimal.js.2def1975.js";
import "./nprogress.9fc41f77.js";
import "./vconsole.0cfb1d33.js";
import "./perfect-scrollbar.19f80865.js";
import "./@intlify.928cb664.js";
let Do;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e) {
    }
  })()
]).then(async () => {
  let Ue, Je, Qe, Xe, Ke, Ye, Ze, et, tt, ot, at, st, lt, nt, rt, it, ct, mt, ut, dt, yt, ht, pt, gt, _t, ft, kt, wt, Lt, It, vt, Tt, Gt, St, bt, Ct, xt, Dt, Et, $t, Nt, Bt, zt, At, Rt, qt, Mt, Vt, Pt, Ht, Ot, Wt, jt, Ft, Ut, Jt, Qt, Xt;
  Ue = {
    class: "container"
  };
  Je = {
    class: "home-page-scroll"
  };
  Qe = {
    class: "game-content"
  };
  Xe = {
    key: 0,
    class: "type-tabs"
  };
  Ke = {
    class: "iconBox"
  };
  Ye = [
    "onClick"
  ];
  Ze = {
    class: "item-title"
  };
  et = {
    class: "typeIcon"
  };
  tt = [
    "src"
  ];
  ot = {
    class: "typeText"
  };
  at = {
    class: "iconBox"
  };
  st = {
    key: 1,
    class: "type-tabs-8"
  };
  lt = [
    "onClick"
  ];
  nt = {
    class: "item-title"
  };
  rt = {
    class: "typeIcon"
  };
  it = [
    "src"
  ];
  ct = {
    class: "typeText"
  };
  mt = [
    "id"
  ];
  ut = {
    class: "item-title"
  };
  dt = {
    class: "item-title-left"
  };
  yt = [
    "src"
  ];
  ht = {
    key: 1,
    class: "icon"
  };
  pt = [
    "src"
  ];
  gt = [
    "onClick"
  ];
  _t = {
    key: 1,
    class: "gameHotHoliday"
  };
  ft = [
    "src"
  ];
  kt = {
    key: 2,
    class: "switch-pagination"
  };
  wt = {
    class: "switch-pagination-box"
  };
  Lt = [
    "onClick"
  ];
  It = [
    "onClick"
  ];
  vt = [
    "onClick"
  ];
  Tt = [
    "onClick"
  ];
  Gt = {
    key: 0,
    src: ne,
    class: "hotTag"
  };
  St = [
    "src"
  ];
  bt = [
    "src"
  ];
  Ct = {
    key: 3,
    src: re,
    class: "collectIcon"
  };
  xt = {
    key: 4,
    src: ie,
    class: "collectIcon"
  };
  Dt = {
    key: 5,
    class: "maintain"
  };
  Et = {
    key: 6,
    class: "vendor-logo"
  };
  $t = [
    "src"
  ];
  Nt = {
    key: 0,
    class: "game-name-normal"
  };
  Bt = {
    class: "name-inner"
  };
  zt = [
    "onClick"
  ];
  At = {
    key: 0,
    src: ne,
    class: "hotTag"
  };
  Rt = [
    "src"
  ];
  qt = [
    "src"
  ];
  Mt = {
    key: 3,
    src: re,
    class: "collectIcon"
  };
  Vt = {
    key: 4,
    src: ie,
    class: "collectIcon"
  };
  Pt = {
    key: 5,
    class: "maintain"
  };
  Ht = {
    key: 6,
    class: "vendor-logo"
  };
  Ot = [
    "src"
  ];
  Wt = {
    key: 0,
    class: "game-name-normal"
  };
  jt = {
    class: "name-inner"
  };
  Ft = [
    "onClick"
  ];
  Ut = {
    class: "item-tips-text"
  };
  Jt = {
    class: "item-tips-btn"
  };
  Qt = {
    key: 5,
    class: "item-tips"
  };
  Xt = {
    class: "item-tips-text"
  };
  Do = {
    __name: "dark",
    setup(Kt) {
      const ce = I(() => L(() => import("./notice.a8ebb779.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/notice.a8ebb779.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/swiper.e7c9d9a6.js","css/swiper.aa45c171.css","css/notice.701f4c1e.css"])), me = I(() => L(() => import("./index.2b4f50ab.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index.2b4f50ab.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/index.5412dd7f.css"])), ue = I(() => L(() => import("./index.8514f314.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index.8514f314.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css"])), de = I(() => L(() => import("./banner.7e7d603f.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/banner.7e7d603f.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/swiper.e7c9d9a6.js","css/swiper.aa45c171.css","css/banner.47a47090.css"])), D = I(() => L(() => import("./JackpotForHome.b4024f33.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/JackpotForHome.b4024f33.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/jackpot_home_9.c9bb2337.js","js/pool_arrow.22261be2.js","js/hourglass.f13eb720.js","js/jackpot_home_5.321480ad.js","js/useNumberAnimation.b686b495.js","js/useCountdown.d80d51b6.js","css/JackpotForHome.151bfcb6.css"])), E = I(() => L(() => import("./winner.62a24cd0.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/winner.62a24cd0.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/winner.f065f890.css"])), ye = I(() => L(() => import("./footer.ca312603.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/footer.ca312603.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/self_forbid.0de6beaf.js","css/footer.5cfccb7a.css"])), he = I(() => L(() => import("./quick_access.ebf1b67b.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/quick_access.ebf1b67b.js","js/vuex.33ea5d58.js","js/@vue.b00de3e9.js","js/index.bb04cb73.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/quick_access.8f8dc5c6.css"])), v = I(() => L(() => import("./index.0a0ffc46.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index.0a0ffc46.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css"]));
      We();
      const e = Pe(), $ = He();
      Oe();
      const N = G(true), O = G(true), u = Me([]), R = G(false), q = G(false), b = G(null), M = G([]), pe = G(""), ge = Ve(() => {
        var _a, _b, _c, _d, _e2, _f, _g, _h;
        const t = !e.state.isApp && !ee() && N.value && ((_a = e.state.downloadBar) == null ? void 0 : _a.guideStatus) && ((_b = e.state.downloadBar) == null ? void 0 : _b.topGuideStyle.includes("0")), s = !e.state.isApp && !ee() && N.value && ((_c = e.state.downloadBar) == null ? void 0 : _c.guideStatus) && ((_d = e.state.downloadBar) == null ? void 0 : _d.topGuideStyle.includes("0")) && ((_e2 = e.state.webmanifest) == null ? void 0 : _e2.icons);
        return Ee() ? t && ((_f = e.state.downloadBar) == null ? void 0 : _f.systemGuideConfig.Android.guideStatus) || s : $e() ? t && ((_g = e.state.downloadBar) == null ? void 0 : _g.systemGuideConfig.IOS.guideStatus) || s : t && ((_h = e.state.downloadBar) == null ? void 0 : _h.systemGuideConfig.PC.guideStatus) || s;
      });
      te(() => N.value, () => {
        e.state.haveRedEnvelop && Z();
      }), te(() => e.state.haveRedEnvelop, (t) => {
        t && setTimeout(() => {
          Z();
        }, 200);
      });
      const W = (t, s) => {
        let c = false;
        return t.type === 0 ? e.state.homeGameLayout.imageType === 0 && (s.hotType && s.imageIsSys && (c = true), !s.hotType && s.hotImageIsSys && (c = true)) : [
          0,
          3
        ].includes(e.state.homeGameLayout.vendorImageType) && s.sloganImageIsSys && (c = true), c && (t.type === 0 && e.state.homeGameLayout.showGameName || t.type !== 0 && e.state.homeGameLayout.showVendorName);
      }, _e = (t) => {
        let s = ".125";
        return t.type === 0 ? e.state.homeGameLayout.imageType == 0 ? e.state.homeGameLayout.imageStyle == 1 ? s = "0.125" : s = "0.0666" : e.state.homeGameLayout.imageStyle == 1 ? s = "0.1755" : s = "0.064935" : e.state.homeGameLayout.vendorImageType === 0 ? e.state.homeGameLayout.vendorImageStyle == 1 ? s = "0.125" : s = "0.0666" : e.state.homeGameLayout.vendorImageType === 1 ? e.state.homeGameLayout.vendorImageStyle == 1 ? s = "0.1755" : s = "0.064935" : e.state.homeGameLayout.vendorImageType === 2 || (s = "0.027"), s;
      }, fe = (t) => {
        let s = "";
        return t.type === 0 ? e.state.homeGameLayout.imageType === 0 ? s = "item-list" : s = "item-list item-list-square" : e.state.homeGameLayout.vendorImageType === 0 ? s = "item-list" : e.state.homeGameLayout.vendorImageType === 1 ? s = "item-list item-list-square" : e.state.homeGameLayout.vendorImageType === 2 ? s = "item-list half-horizontal" : e.state.homeGameLayout.vendorImageType === 3 && (s = "item-list full-horizontal"), s;
      }, ke = (t) => {
        let s = "item-list";
        return t.type === 0 ? e.state.homeGameLayout.imageType === 1 && (e.state.homeGameLayout.rowSize === 4 ? s += " item-list-square row4" : s += " item-list-square") : [
          0,
          1
        ].includes(e.state.homeGameLayout.vendorImageType) ? (e.state.homeGameLayout.rowSize === 4 && (s += " row4"), e.state.homeGameLayout.vendorImageType === 1 && (s += " item-list-vendor-square")) : e.state.homeGameLayout.vendorImageType === 2 ? s += " half-horizontal" : s += " full-horizontal", s;
      }, j = (t) => ({
        loading: pe,
        src: t
      }), we = async (t) => {
        let s = [], c = 0, p = {
          tag: t,
          _page: 1,
          _size: 1e3
        };
        return await H.get("/game/game/list", p).then((h) => {
          if (h.code === 0) {
            let { list: o, total: y } = h.data;
            s.push(...o), c = y;
          }
        }), {
          gameList: s,
          totalCount: c
        };
      }, F = async () => {
        u.length = 0, await H.get("/game/game/typedVendors").then(async (t) => {
          if (t.code === 0) {
            u.push(...t.data.filter((a) => !!a.vendors.length || a.type === 0 || a.type === 98 || a.type === 99)), u.forEach(async (a, w) => {
              if (a.type === 0) {
                a.vendors = (await we(1)).gameList, a.total = a.vendors.length, a.currentIndex = 0;
                let i = e.state.homeGameLayout.rowSize * e.state.homeGameLayout.hotGameLinesSize;
                a.showLength = i, a.currentShowLength = Math.min(i, a.total), a.carouselHeight = "auto", X(a, i);
              } else {
                a.total = a.vendors.length, a.currentIndex = 0;
                let i = [
                  0,
                  1
                ].includes(e.state.homeGameLayout.vendorImageType) ? e.state.homeGameLayout.rowSize * e.state.homeGameLayout.otherGameLinesSize : e.state.homeGameLayout.vendorImageType == 2 ? e.state.homeGameLayout.otherGameLinesSize * 2 : e.state.homeGameLayout.otherGameLinesSize;
                a.showLength = i, a.currentShowLength = Math.min(i, a.total), a.carouselHeight = "auto", X(a, i);
              }
              a.loadedIndex = 0;
            });
            let s = u.find((a) => a.type === 0), c = u.findIndex((a) => a.type === 0);
            c !== -1 && u.splice(c, 1);
            let p = u.find((a) => a.type === 98), h = u.findIndex((a) => a.type === 98);
            h !== -1 && u.splice(h, 1);
            let o = u.find((a) => a.type === 99), y = u.findIndex((a) => a.type === 99);
            y !== -1 && u.splice(y, 1), s && u.unshift(s), p && u.push(p), o && u.push(o), e.state.tableList = u, console.log("tableList", u), A(() => {
              let a = document.querySelector(".tab-scroll");
              a && Ne(a), a && V(), a && a.addEventListener("scroll", V), u.forEach((w, i) => {
                w.type != 0;
              }), setTimeout(() => {
                e.state.homeGameLayout.imageType == 1 && ve();
              }, 400);
            });
          }
        });
      }, Le = (t) => {
        let s;
        t.type === 0 ? s = e.state.homeGameLayout.rowSize * e.state.homeGameLayout.hotGameLinesSize : s = [
          0,
          1
        ].includes(e.state.homeGameLayout.vendorImageType) ? e.state.homeGameLayout.rowSize * e.state.homeGameLayout.otherGameLinesSize : e.state.homeGameLayout.vendorImageType == 2 ? e.state.homeGameLayout.otherGameLinesSize * 2 : e.state.homeGameLayout.otherGameLinesSize, t.currentShowLength += s;
      }, U = (t, s) => {
        t.maintain !== 1 && $.push({
          path: "/sub-game",
          query: {
            typeId: t.type || s,
            vendor: t.vendor
          }
        });
      }, J = G(/* @__PURE__ */ new Map()), Ie = (t, s) => {
        t ? (J.value.set(s, t), A(() => {
          Q(t, s);
        })) : J.value.delete(s);
      }, Q = (t, s) => {
        if (!t)
          return;
        t._hammer && t._hammer.destroy();
        const c = new je(t);
        c.on("swipeleft", () => {
          Y(s);
        }), c.on("swiperight", () => {
          K(s);
        }), t._hammer = c;
      }, X = (t, s) => {
        t.list = [], t.vendors.forEach((c, p) => {
          if (p % s === 0) {
            let h = [];
            h.push(c), t.list.push(h);
          } else
            t.list[t.list.length - 1].push(c);
        });
      }, ve = () => {
        A(() => {
          document.querySelectorAll(".carousel-container").forEach((s, c) => {
            s && !s._hammer && Q(s, c);
          });
        });
      }, K = le.throttle((t) => {
        console.log(u[t]), !(!u[t] || typeof u[t].currentIndex != "number" || u[t].currentIndex === 0) && u[t].currentIndex--;
      }, 500, {
        leading: true,
        trailing: false
      }), Y = le.throttle((t) => {
        u[t].loadedIndex < u[t].currentIndex + 1 && (u[t].loadedIndex = u[t].currentIndex + 1), !(!u[t] || !u[t].list || typeof u[t].currentIndex != "number" || u[t].currentIndex === u[t].list.length - 1) && u[t].currentIndex++;
      }, 500, {
        leading: true,
        trailing: false
      }), V = () => {
        let t = b.value, s = t.scrollWidth - t.clientWidth;
        s > 0 && t.scrollLeft < s ? q.value = true : q.value = false, t.scrollLeft > 0 ? R.value = true : R.value = false;
      }, Te = () => {
        b.value.scrollTo({
          left: 0,
          behavior: "smooth"
        });
      }, Ge = () => {
        let t = b.value, s = t.scrollWidth - t.clientWidth;
        t.scrollTo({
          left: s,
          behavior: "smooth"
        }), setTimeout(() => {
          t.scrollTo({
            left: s
          });
        }, 150);
      }, P = async (t, s) => {
        const c = b.value, p = M.value;
        if (!c || !p[t])
          return;
        await A(), Se(t, s);
        const h = c.clientWidth;
        if (c.scrollWidth <= h)
          return;
        const y = p[t], w = y.offsetLeft + y.offsetWidth / 2 - h / 2;
        c.scrollTo({
          left: w,
          behavior: "smooth"
        });
      }, Se = (t, s) => {
        const c = document.querySelector(".dark-home-page-wg .home-page-scroll"), p = document.querySelectorAll(".dark-home-page-wg .game-list .item"), h = document.querySelector(".dark-home-page-wg .dark-headerMenu");
        if (s.type === 98 || s.type === 99 || s.type === 100)
          $.push("/sub-game?typeId=".concat(s.type));
        else {
          const o = document.querySelector(".dark-home-page-wg .download-app-wg");
          let y;
          y = p[t].offsetTop - h.clientHeight, o && (y = y - o.clientHeight), c.scrollTo({
            top: y,
            behavior: "smooth"
          });
        }
      };
      ze(() => {
        O.value = false, V(), setTimeout(() => {
          O.value = true;
        }), e.dispatch("getJackpotDetail");
      });
      const be = () => {
        globalVBus.$emit("checkHomeFloat");
      };
      Ae(async () => {
        F();
        let t = document.querySelector(".dark-home-page-wg .home-page-scroll");
        t && t.addEventListener("scroll", be), globalVBus.$on("refreshGameTypeVendorList", F), globalVBus.$on("changeActiveTab", P), Ce();
      });
      const Ce = () => {
        var _a, _b, _c;
        let t = document.querySelector(".home-page-box .dark-home-page-wg"), s = new URL("/img/colors/" + De() + "/bg_pattern_tile.png", import.meta.url).href;
        if (((_a = e.state.festivalStyle) == null ? void 0 : _a.show) && ((_b = e.state.festivalStyle) == null ? void 0 : _b.bkgTexture) === 1) {
          const c = e.state.festivalStyle.style || 1, p = "/img_wg/festivalTheme/skin".concat((_c = e.state.festivalStyle) == null ? void 0 : _c.skin, "/theme").concat(c, "/bg_pattern_tile.png");
          s = new URL(p, import.meta.url).href;
        }
        t && (t.style.backgroundImage = "url('".concat(s, "')"));
      }, Z = () => {
        setTimeout(() => {
          const t = parseFloat(getComputedStyle(document.documentElement).fontSize);
          let s = document.querySelector(".home-page-box .download-app"), c = document.querySelector(".home-page-box .home-banner-box"), h = document.querySelector(".home-page-box .dark-headerMenu").clientHeight + (0.32 - 0.77) * t;
          s && (h += s.clientHeight), c && (h += c.clientHeight);
          let o = document.querySelector(".home-page-box .red-envelopes-float");
          o && (o.style.top = h + "px");
        });
      }, xe = () => {
        N.value = false;
      }, C = (t) => async () => {
        if (!Be()) {
          e.state.loginType = e.state.haveAccount ? "login" : "register", e.state.showLoginDialog = true;
          return;
        }
        await H.post("game/game/collect", {
          id: t.id,
          gameType: t.type,
          type: t.collect ? 0 : 1
        }).then((s) => {
          if (s.code === 0) {
            t.bookmark_star_2 = Fe + (/* @__PURE__ */ new Date()).getTime(), t.collect = !t.collect, t.collect && (t.clickCollect = true);
            let c = u.find((o) => o.type === 99);
            u.find((o) => o.type === 0).vendors.forEach((o) => {
              o.id === t.id && (o.collect = t.collect);
            });
            let h = c.vendors.findIndex((o) => o.id === t.id);
            h > -1 ? c.vendors.splice(h, 1) : c.vendors.unshift(t);
          }
        });
      };
      return (t, s) => {
        const c = Re("svg-icon"), p = oe("throttle"), h = oe("lazy");
        return n(), r("div", {
          class: f([
            "dark-home-page-wg",
            [
              "dark-home-page-wg-".concat(l(e).state.layoutMode)
            ]
          ])
        }, [
          d("div", Ue, [
            ge.value ? (n(), g(l(me), {
              key: 0,
              onClose: xe
            })) : m("", true),
            k(l(ue)),
            d("div", Je, [
              k(l(v), {
                position: 2
              }),
              l(e).state.winnerData && l(e).state.winnerData.ext && l(e).state.winnerData.ext.location === 0 && l(e).state.winnerData.data.length ? (n(), g(l(E), {
                key: 0,
                location: 0
              })) : m("", true),
              l(e).state.jackpotInfo.showPosition === 1 ? (n(), g(l(D), {
                key: 1
              })) : m("", true),
              k(l(de)),
              k(l(v), {
                position: 3
              }),
              l(e).state.shortcut.status ? (n(), g(l(he), {
                key: 2
              })) : m("", true),
              l(e).state.winnerData && l(e).state.winnerData.ext && l(e).state.winnerData.ext.location === 1 && l(e).state.winnerData.data.length ? (n(), g(l(E), {
                key: 3,
                location: 1
              })) : m("", true),
              k(l(ce)),
              k(l(v), {
                position: 4
              }),
              l(e).state.jackpotInfo.showPosition === 2 ? (n(), g(l(D), {
                key: 4
              })) : m("", true),
              l(e).state.winnerData && l(e).state.winnerData.ext && l(e).state.winnerData.ext.location === 2 && l(e).state.winnerData.data.length ? (n(), g(l(E), {
                key: 5,
                location: 2
              })) : m("", true),
              d("div", Qe, [
                l(e).state.layoutMode === 3 ? (n(), r("div", Xe, [
                  R.value ? (n(), r("div", {
                    key: 0,
                    class: "tab-prev",
                    onClick: ae(Te, [
                      "stop"
                    ])
                  }, [
                    d("div", Ke, [
                      k(c, {
                        iconClass: "wg_home_arrow"
                      })
                    ])
                  ])) : m("", true),
                  d("div", {
                    class: "tab-scroll",
                    ref_key: "tabScroll",
                    ref: b
                  }, [
                    (n(true), r(S, null, x(l(e).state.tableList, (o, y) => (n(), r("div", {
                      class: "tab-item",
                      ref_for: true,
                      ref_key: "tabItems",
                      ref: M,
                      onClick: (a) => P(y, o)
                    }, [
                      d("div", Ze, [
                        d("div", et, [
                          d("img", {
                            src: l(B)(o.type)
                          }, null, 8, tt)
                        ]),
                        d("div", ot, _(o.typeName), 1)
                      ])
                    ], 8, Ye))), 256))
                  ], 512),
                  q.value ? (n(), r("div", {
                    key: 1,
                    class: "tab-next",
                    onClick: ae(Ge, [
                      "stop"
                    ])
                  }, [
                    d("div", at, [
                      k(c, {
                        iconClass: "wg_home_arrow"
                      })
                    ])
                  ])) : m("", true)
                ])) : m("", true),
                l(e).state.layoutMode === 8 ? (n(), r("div", st, [
                  d("div", {
                    class: "tab-scroll",
                    ref_key: "tabScroll",
                    ref: b
                  }, [
                    (n(true), r(S, null, x(l(e).state.tableList, (o, y) => (n(), r("div", {
                      class: "tab-item",
                      ref_for: true,
                      ref_key: "tabItems",
                      ref: M,
                      onClick: (a) => P(y, o)
                    }, [
                      d("div", nt, [
                        d("div", rt, [
                          o.icon.indexOf("http") > -1 ? (n(), r("img", {
                            key: 0,
                            src: o.icon,
                            alt: ""
                          }, null, 8, it)) : (n(), g(c, {
                            key: 1,
                            iconClass: l(B)(o.type)
                          }, null, 8, [
                            "iconClass"
                          ]))
                        ]),
                        d("div", ct, _(o.typeName), 1)
                      ])
                    ], 8, lt))), 256))
                  ], 512)
                ])) : m("", true),
                l(e).state.jackpotInfo.showPosition === 4 ? (n(), g(l(D), {
                  key: 2,
                  style: {
                    "margin-top": ".3rem"
                  }
                })) : m("", true),
                d("div", {
                  class: f([
                    "game-list",
                    l(e).state.homeGameLayout.rowSize === 4 && l(e).state.homeGameLayout.imageType === 1 ? "game-list-square-4" : ""
                  ])
                }, [
                  (n(true), r(S, null, x(u, (o, y) => {
                    var _a, _b, _c;
                    return n(), r(S, {
                      key: y
                    }, [
                      o.type !== 98 && o.type !== 99 ? (n(), r("div", {
                        key: 0,
                        class: "item",
                        id: "item".concat(y + 1),
                        style: qe("--poster-image-border-base-radius:calc(var(--card-benchmark) * ".concat(_e(o), ")"))
                      }, [
                        d("a", ut, [
                          d("div", dt, [
                            l(e).state.layoutMode === 3 ? (n(), r("img", {
                              key: 0,
                              src: l(B)(o.type)
                            }, null, 8, yt)) : m("", true),
                            l(e).state.layoutMode === 8 ? (n(), r("i", ht, [
                              o.icon.indexOf("http") > -1 ? (n(), r("img", {
                                key: 0,
                                src: o.icon,
                                alt: ""
                              }, null, 8, pt)) : (n(), g(c, {
                                key: 1,
                                iconClass: l(B)(o.type)
                              }, null, 8, [
                                "iconClass"
                              ]))
                            ])) : m("", true),
                            d("span", null, _(o.typeName), 1)
                          ]),
                          !l(e).state.homeGameLayout.pageStyle && o.type !== 0 ? (n(), r("div", {
                            key: 0,
                            class: "item-title-right",
                            onClick: (a) => l($).push({
                              path: "/sub-game",
                              query: {
                                typeId: o.type
                              }
                            })
                          }, _(t.$t("home.all")), 9, gt)) : m("", true),
                          ((_a = l(e).state.festivalStyle) == null ? void 0 : _a.show) && o.type === 0 ? (n(), r("div", _t, [
                            d("img", {
                              src: "/img_wg/festivalTheme/skin".concat((_b = l(e).state.festivalStyle) == null ? void 0 : _b.skin, "/theme").concat(((_c = l(e).state.festivalStyle) == null ? void 0 : _c.style) || 1, "/apng_top_jr.png")
                            }, null, 8, ft)
                          ])) : m("", true),
                          l(e).state.homeGameLayout.pageStyle == 1 ? (n(), r("div", kt, [
                            d("div", wt, [
                              d("div", {
                                class: f([
                                  "leftIcon",
                                  {
                                    disabled: o.currentIndex === 0
                                  }
                                ]),
                                onClick: (a) => l(K)(y)
                              }, [
                                k(c, {
                                  iconClass: "wg_home_game_arrow"
                                })
                              ], 10, Lt),
                              d("div", {
                                class: "centerText",
                                onClick: (a) => l($).push({
                                  path: "/sub-game",
                                  query: {
                                    typeId: o.type
                                  }
                                })
                              }, _(t.$t("common.all")), 9, It),
                              d("div", {
                                class: f([
                                  "rightIcon",
                                  {
                                    disabled: o.list && o.currentIndex === o.list.length - 1
                                  }
                                ]),
                                onClick: (a) => l(Y)(y)
                              }, [
                                k(c, {
                                  iconClass: "wg_home_game_arrow"
                                })
                              ], 10, vt)
                            ])
                          ])) : m("", true)
                        ]),
                        y == 1 ? (n(), g(l(v), {
                          key: 0,
                          position: 5
                        })) : m("", true),
                        y == 0 ? (n(), g(l(v), {
                          key: 1,
                          position: 6
                        })) : m("", true),
                        l(e).state.homeGameLayout.pageStyle == 1 ? (n(), r("div", {
                          key: 2,
                          class: "carousel-container",
                          ref_for: true,
                          ref: (a) => Ie(a, y)
                        }, [
                          (n(true), r(S, null, x(o.list || [], (a, w) => (n(), r("div", {
                            class: f([
                              "carousel-page-slide",
                              {
                                "carousel-page-current": w === o.currentIndex,
                                "carousel-page-prev": w < o.currentIndex,
                                "carousel-page-next": w > o.currentIndex
                              }
                            ]),
                            key: w,
                            ref_for: true,
                            ref: "carouselPage".concat(y, "_").concat(w)
                          }, [
                            d("div", {
                              class: f(ke(o))
                            }, [
                              w <= o.loadedIndex ? (n(true), r(S, {
                                key: 0
                              }, x(a, (i, Yt) => (n(), r("div", {
                                key: i.id,
                                class: f(o.type === 0 ? "gameBox box" : "vendorBox box")
                              }, [
                                T((n(), r("div", {
                                  class: f([
                                    "innerBox",
                                    "innerBox".concat(i.id)
                                  ]),
                                  onClick: (Zt) => o.type === 0 && i.hotType === 1 ? l(z)(i) : o.type === 4 || o.type === 5 ? l(z)(i, 1) : U(i, o.type)
                                }, [
                                  i.recommend === 1 && i.hotType === 1 ? (n(), r("img", Gt)) : m("", true),
                                  o.type === 0 && i.maskImage && i.hotType === 1 ? (n(), r("img", {
                                    key: 1,
                                    src: i.maskImage,
                                    alt: "",
                                    class: "maskImage"
                                  }, null, 8, St)) : m("", true),
                                  i.collect && i.hotType === 1 && i.clickCollect ? T((n(), r("img", {
                                    key: 2,
                                    src: i.bookmark_star_2,
                                    class: "collectIcon collected",
                                    style: {
                                      transform: "scale(1.7)"
                                    }
                                  }, null, 8, bt)), [
                                    [
                                      p,
                                      C(i),
                                      void 0,
                                      {
                                        stop: true
                                      }
                                    ]
                                  ]) : i.collect && i.hotType === 1 && !i.clickCollect ? T((n(), r("img", Ct, null, 512)), [
                                    [
                                      p,
                                      C(i),
                                      void 0,
                                      {
                                        stop: true
                                      }
                                    ]
                                  ]) : i.hotType === 1 ? T((n(), r("img", xt, null, 512)), [
                                    [
                                      p,
                                      C(i),
                                      void 0,
                                      {
                                        stop: true
                                      }
                                    ]
                                  ]) : m("", true),
                                  i.maintain == 1 ? (n(), r("div", Dt, [
                                    ...s[0] || (s[0] = [
                                      d("img", {
                                        src: se,
                                        alt: ""
                                      }, null, -1)
                                    ])
                                  ])) : m("", true),
                                  [
                                    2,
                                    3
                                  ].includes(l(e).state.homeGameLayout.vendorImageType) && o.type != 0 && i.sloganImageIsSys ? (n(), r("div", Et, [
                                    d("img", {
                                      src: i.image,
                                      alt: ""
                                    }, null, 8, $t)
                                  ])) : m("", true),
                                  W(o, i) ? (n(), r("div", {
                                    key: 7,
                                    class: f([
                                      "names",
                                      {
                                        "gameName-4-hot": o.type != 0
                                      }
                                    ])
                                  }, [
                                    d("span", {
                                      class: f([
                                        "gameName",
                                        {
                                          "gameName-4": l(e).state.homeGameLayout.imageType == 1
                                        }
                                      ])
                                    }, _(i.name) + " " + _(o.type != 0 ? o.typeName : i.hotType == 0 ? i.type_ : ""), 3)
                                  ], 2)) : m("", true)
                                ], 10, Tt)), [
                                  [
                                    h,
                                    j(o.type === 0 && i.hotType === 1 ? i.image : o.type === 0 ? i.hotImage : i.sloganImage).src,
                                    "background-image"
                                  ]
                                ]),
                                (l(e).state.homeGameLayout.imageType == 1 && o.type === 0 || o.type !== 0 && [
                                  1,
                                  2
                                ].includes(l(e).state.homeGameLayout.vendorImageType)) && (o.type === 0 && l(e).state.homeGameLayout.showGameName || o.type !== 0 && l(e).state.homeGameLayout.showVendorName) ? (n(), r("div", Nt, [
                                  d("h4", Bt, _(i.name) + " " + _(i.hotType != 1 ? o.type != 0 ? o.typeName : i.type_ : ""), 1)
                                ])) : m("", true)
                              ], 2))), 128)) : m("", true)
                            ], 2)
                          ], 2))), 128))
                        ], 512)) : (n(), r("div", {
                          key: 3,
                          class: f(fe(o))
                        }, [
                          (n(true), r(S, null, x(o.vendors.slice(0, o.currentShowLength), (a, w) => (n(), r("div", {
                            key: a.id,
                            class: f(o.type === 0 ? "gameBox box" : "vendorBox box")
                          }, [
                            T((n(), r("div", {
                              class: f([
                                "innerBox",
                                "innerBox".concat(a.id)
                              ]),
                              onClick: (i) => o.type === 0 && a.hotType === 1 ? l(z)(a) : o.type === 4 || o.type === 5 ? l(z)(a, 1) : U(a, o.type)
                            }, [
                              a.recommend === 1 && a.hotType === 1 ? (n(), r("img", At)) : m("", true),
                              o.type === 0 && a.maskImage && a.hotType === 1 ? (n(), r("img", {
                                key: 1,
                                src: a.maskImage,
                                alt: "",
                                class: "maskImage"
                              }, null, 8, Rt)) : m("", true),
                              a.collect && a.hotType === 1 && a.clickCollect ? T((n(), r("img", {
                                key: 2,
                                src: a.bookmark_star_2,
                                class: "collectIcon collected",
                                style: {
                                  transform: "scale(1.7)"
                                }
                              }, null, 8, qt)), [
                                [
                                  p,
                                  C(a),
                                  void 0,
                                  {
                                    stop: true
                                  }
                                ]
                              ]) : a.collect && a.hotType === 1 && !a.clickCollect ? T((n(), r("img", Mt, null, 512)), [
                                [
                                  p,
                                  C(a),
                                  void 0,
                                  {
                                    stop: true
                                  }
                                ]
                              ]) : a.hotType === 1 ? T((n(), r("img", Vt, null, 512)), [
                                [
                                  p,
                                  C(a),
                                  void 0,
                                  {
                                    stop: true
                                  }
                                ]
                              ]) : m("", true),
                              a.maintain == 1 ? (n(), r("div", Pt, [
                                ...s[1] || (s[1] = [
                                  d("img", {
                                    src: se,
                                    alt: ""
                                  }, null, -1)
                                ])
                              ])) : m("", true),
                              [
                                2,
                                3
                              ].includes(l(e).state.homeGameLayout.vendorImageType) && o.type != 0 && a.sloganImageIsSys ? (n(), r("div", Ht, [
                                d("img", {
                                  src: a.image,
                                  alt: ""
                                }, null, 8, Ot)
                              ])) : m("", true),
                              W(o, a) ? (n(), r("div", {
                                key: 7,
                                class: f([
                                  "names",
                                  {
                                    "gameName-4-hot": o.type != 0
                                  }
                                ])
                              }, [
                                d("span", {
                                  class: f([
                                    "gameName",
                                    {
                                      "gameName-4": l(e).state.homeGameLayout.imageType == 1
                                    }
                                  ])
                                }, _(a.name) + " " + _(o.type != 0 ? o.typeName : a.hotType == 0 ? a.type_ : ""), 3)
                              ], 2)) : m("", true)
                            ], 10, zt)), [
                              [
                                h,
                                j(o.type === 0 && a.hotType === 1 ? a.image : o.type === 0 ? a.hotImage : a.sloganImage).src,
                                "background-image"
                              ]
                            ]),
                            (l(e).state.homeGameLayout.imageType == 1 && o.type === 0 || o.type !== 0 && [
                              1,
                              2
                            ].includes(l(e).state.homeGameLayout.vendorImageType)) && (o.type === 0 && l(e).state.homeGameLayout.showGameName || o.type !== 0 && l(e).state.homeGameLayout.showVendorName) ? (n(), r("div", Wt, [
                              d("h4", jt, _(a.name) + " " + _(o.type != 0 ? o.typeName ? o.typeName : o._type : ""), 1)
                            ])) : m("", true)
                          ], 2))), 128))
                        ], 2)),
                        !l(e).state.homeGameLayout.pageStyle && o.total > o.currentShowLength ? (n(), r("div", {
                          key: 4,
                          class: "item-tips",
                          onClick: (a) => Le(o)
                        }, [
                          d("div", Ut, _(t.$t("home.moreTipsText", {
                            current: o.currentShowLength,
                            total: o.total,
                            type: o.typeName
                          })), 1),
                          d("div", Jt, [
                            d("span", null, _(t.$t("home.loadMore")), 1),
                            k(c, {
                              iconClass: "wg_home_expand"
                            })
                          ])
                        ], 8, Ft)) : !l(e).state.homeGameLayout.pageStyle && o.total > o.showLength ? (n(), r("div", Qt, [
                          d("div", Xt, _(t.$t("home.loaded")), 1)
                        ])) : m("", true),
                        y == 0 ? (n(), g(l(v), {
                          key: 6,
                          position: 7
                        })) : m("", true)
                      ], 12, mt)) : m("", true),
                      o.type === 0 && l(e).state.jackpotInfo.showPosition === 3 ? (n(), g(l(D), {
                        key: 1
                      })) : m("", true)
                    ], 64);
                  }), 128)),
                  k(l(v), {
                    position: 8
                  })
                ], 2)
              ]),
              l(e).state.jackpotInfo.showPosition === 5 ? (n(), g(l(D), {
                key: 6
              })) : m("", true),
              k(l(v), {
                position: 9
              }),
              l(e).state.winnerData && l(e).state.winnerData.ext && l(e).state.winnerData.ext.location === 3 && l(e).state.winnerData.data.length ? (n(), g(l(E), {
                key: 7,
                location: 3
              })) : m("", true),
              k(l(ye))
            ])
          ])
        ], 2);
      };
    }
  };
});
export {
  __tla,
  Do as default
};
