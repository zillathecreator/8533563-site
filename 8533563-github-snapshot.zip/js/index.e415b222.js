import { r as m, w as k, e as B, o as a, J as g, c as i, U as c, V as d, W as r, Y as p, L as u, I as C, M as z, T as I } from "./@vue.b00de3e9.js";
import { u as _ } from "./vuex.33ea5d58.js";
import { k as w, __tla as __tla_0 } from "./index.bb04cb73.js";
import "./vue-router.c227d4ba.js";
import "./axios.853f16bf.js";
import "./element-plus.53baa8a9.js";
import "./@element-plus.e21ea623.js";
import "./@ctrl.11979b50.js";
import "./dayjs.9abdbee1.js";
import "./clipboard.aaae98d3.js";
import "./@vueuse.eccd744a.js";
import "./lodash-es.e1022fb5.js";
import "./@popperjs.da591b4f.js";
import "./vant.f7b4805b.js";
import "./@vant.f52f09a9.js";
import "./vue-i18n.07fcbeea.js";
import "./@intlify.928cb664.js";
import "./xe-utils.a532b55a.js";
import "./crypto-js.c184c643.js";
import "./decimal.js.2def1975.js";
import "./nprogress.9fc41f77.js";
import "./vconsole.0cfb1d33.js";
import "./perfect-scrollbar.19f80865.js";
let R;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e) {
    }
  })()
]).then(async () => {
  let O;
  O = {
    __name: "index",
    props: {
      showDialogOverlay: {
        type: Boolean,
        default: true
      },
      visible: Boolean,
      closeOnClickOverlay: {
        type: Boolean,
        default: true
      },
      zIndexBase: {
        type: Number,
        default: 1e3
      },
      customClass: String,
      btmPop: {
        type: Boolean,
        default: false
      },
      className: {
        type: String,
        default: ""
      }
    },
    emits: [
      "update:visible",
      "close"
    ],
    setup(e, { emit: f }) {
      const l = _(), t = e, n = f, o = m(false), v = m(t.zIndexBase + l.state.zIndex);
      k(() => t.visible, (s) => {
        s || (o.value = true);
      });
      const y = () => {
        t.closeOnClickOverlay && n("update:visible", false);
      }, x = () => {
        o.value = true;
      }, b = () => {
        o.value = false, n("close");
      };
      return B(() => {
        l.state.zIndex++;
      }), (s, h) => (a(), g(I, {
        to: "body"
      }, [
        e.visible || o.value ? (a(), i("div", {
          key: 0,
          class: u([
            "dialog-wrapper",
            [
              e.customClass
            ]
          ]),
          style: z({
            zIndex: v.value
          })
        }, [
          c(p, {
            name: "fade"
          }, {
            default: d(() => [
              e.visible && e.showDialogOverlay ? (a(), i("div", {
                key: 0,
                class: "dialog-overlay",
                onClick: y
              })) : r("", true)
            ]),
            _: 1
          }),
          c(p, {
            name: t.btmPop ? "btmPop" : "zoom",
            appear: "",
            onBeforeEnter: x,
            onAfterLeave: b
          }, {
            default: d(() => [
              e.visible ? (a(), i("div", {
                key: 0,
                class: u([
                  "dialog-content",
                  [
                    "".concat(e.className)
                  ]
                ])
              }, [
                C(s.$slots, "default", {}, void 0, true)
              ], 2)) : r("", true)
            ]),
            _: 3
          }, 8, [
            "name"
          ])
        ], 6)) : r("", true)
      ]));
    }
  };
  R = w(O, [
    [
      "__scopeId",
      "data-v-5163d555"
    ]
  ]);
});
export {
  __tla,
  R as default
};
