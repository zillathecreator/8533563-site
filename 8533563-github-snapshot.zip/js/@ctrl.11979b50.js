function u(r, e) {
  E(r) && (r = "100%");
  const t = I(r);
  return r = e === 360 ? r : Math.min(e, Math.max(0, parseFloat(r))), t && (r = parseInt(String(r * e), 10) / 100), Math.abs(r - e) < 1e-6 ? 1 : (e === 360 ? r = (r < 0 ? r % e + e : r % e) / parseFloat(String(e)) : r = r % e / parseFloat(String(e)), r);
}
function m(r) {
  return Math.min(1, Math.max(0, r));
}
function E(r) {
  return typeof r == "string" && r.indexOf(".") !== -1 && parseFloat(r) === 1;
}
function I(r) {
  return typeof r == "string" && r.indexOf("%") !== -1;
}
function F(r) {
  return r = parseFloat(r), (isNaN(r) || r < 0 || r > 1) && (r = 1), r;
}
function p(r) {
  return Number(r) <= 1 ? "".concat(Number(r) * 100, "%") : r;
}
function l(r) {
  return r.length === 1 ? "0" + r : String(r);
}
function B(r, e, t) {
  return { r: u(r, 255) * 255, g: u(e, 255) * 255, b: u(t, 255) * 255 };
}
function v(r, e, t) {
  r = u(r, 255), e = u(e, 255), t = u(t, 255);
  const n = Math.max(r, e, t), s = Math.min(r, e, t);
  let a = 0, i = 0;
  const h = (n + s) / 2;
  if (n === s)
    i = 0, a = 0;
  else {
    const o = n - s;
    switch (i = h > 0.5 ? o / (2 - n - s) : o / (n + s), n) {
      case r:
        a = (e - t) / o + (e < t ? 6 : 0);
        break;
      case e:
        a = (t - r) / o + 2;
        break;
      case t:
        a = (r - e) / o + 4;
        break;
    }
    a /= 6;
  }
  return { h: a, s: i, l: h };
}
function w(r, e, t) {
  return t < 0 && (t += 1), t > 1 && (t -= 1), t < 1 / 6 ? r + (e - r) * (6 * t) : t < 1 / 2 ? e : t < 2 / 3 ? r + (e - r) * (2 / 3 - t) * 6 : r;
}
function q(r, e, t) {
  let n, s, a;
  if (r = u(r, 360), e = u(e, 100), t = u(t, 100), e === 0)
    s = t, a = t, n = t;
  else {
    const i = t < 0.5 ? t * (1 + e) : t + e - t * e, h = 2 * t - i;
    n = w(h, i, r + 1 / 3), s = w(h, i, r), a = w(h, i, r - 1 / 3);
  }
  return { r: n * 255, g: s * 255, b: a * 255 };
}
function A(r, e, t) {
  r = u(r, 255), e = u(e, 255), t = u(t, 255);
  const n = Math.max(r, e, t), s = Math.min(r, e, t);
  let a = 0;
  const i = n, h = n - s, o = n === 0 ? 0 : h / n;
  if (n === s)
    a = 0;
  else {
    switch (n) {
      case r:
        a = (e - t) / h + (e < t ? 6 : 0);
        break;
      case e:
        a = (t - r) / h + 2;
        break;
      case t:
        a = (r - e) / h + 4;
        break;
    }
    a /= 6;
  }
  return { h: a, s: o, v: i };
}
function P(r, e, t) {
  r = u(r, 360) * 6, e = u(e, 100), t = u(t, 100);
  const n = Math.floor(r), s = r - n, a = t * (1 - e), i = t * (1 - s * e), h = t * (1 - (1 - s) * e), o = n % 6, x = [t, i, a, a, h, t][o], M = [h, t, t, i, a, a][o], N = [a, a, h, t, t, i][o];
  return { r: x * 255, g: M * 255, b: N * 255 };
}
function H(r, e, t, n) {
  const s = [l(Math.round(r).toString(16)), l(Math.round(e).toString(16)), l(Math.round(t).toString(16))];
  return n && s[0].startsWith(s[0].charAt(1)) && s[1].startsWith(s[1].charAt(1)) && s[2].startsWith(s[2].charAt(1)) ? s[0].charAt(0) + s[1].charAt(0) + s[2].charAt(0) : s.join("");
}
function j(r, e, t, n, s) {
  const a = [l(Math.round(r).toString(16)), l(Math.round(e).toString(16)), l(Math.round(t).toString(16)), l(W(n))];
  return s && a[0].startsWith(a[0].charAt(1)) && a[1].startsWith(a[1].charAt(1)) && a[2].startsWith(a[2].charAt(1)) && a[3].startsWith(a[3].charAt(1)) ? a[0].charAt(0) + a[1].charAt(0) + a[2].charAt(0) + a[3].charAt(0) : a.join("");
}
function O(r, e, t, n) {
  const s = r / 100, a = e / 100, i = t / 100, h = n / 100, o = 255 * (1 - s) * (1 - h), x = 255 * (1 - a) * (1 - h), M = 255 * (1 - i) * (1 - h);
  return { r: o, g: x, b: M };
}
function R(r, e, t) {
  let n = 1 - r / 255, s = 1 - e / 255, a = 1 - t / 255, i = Math.min(n, s, a);
  return i === 1 ? (n = 0, s = 0, a = 0) : (n = (n - i) / (1 - i) * 100, s = (s - i) / (1 - i) * 100, a = (a - i) / (1 - i) * 100), i *= 100, { c: Math.round(n), m: Math.round(s), y: Math.round(a), k: Math.round(i) };
}
function W(r) {
  return Math.round(parseFloat(r) * 255).toString(16);
}
function $(r) {
  return c(r) / 255;
}
function c(r) {
  return parseInt(r, 16);
}
function G(r) {
  return { r: r >> 16, g: (r & 65280) >> 8, b: r & 255 };
}
const y = { aliceblue: "#f0f8ff", antiquewhite: "#faebd7", aqua: "#00ffff", aquamarine: "#7fffd4", azure: "#f0ffff", beige: "#f5f5dc", bisque: "#ffe4c4", black: "#000000", blanchedalmond: "#ffebcd", blue: "#0000ff", blueviolet: "#8a2be2", brown: "#a52a2a", burlywood: "#deb887", cadetblue: "#5f9ea0", chartreuse: "#7fff00", chocolate: "#d2691e", coral: "#ff7f50", cornflowerblue: "#6495ed", cornsilk: "#fff8dc", crimson: "#dc143c", cyan: "#00ffff", darkblue: "#00008b", darkcyan: "#008b8b", darkgoldenrod: "#b8860b", darkgray: "#a9a9a9", darkgreen: "#006400", darkgrey: "#a9a9a9", darkkhaki: "#bdb76b", darkmagenta: "#8b008b", darkolivegreen: "#556b2f", darkorange: "#ff8c00", darkorchid: "#9932cc", darkred: "#8b0000", darksalmon: "#e9967a", darkseagreen: "#8fbc8f", darkslateblue: "#483d8b", darkslategray: "#2f4f4f", darkslategrey: "#2f4f4f", darkturquoise: "#00ced1", darkviolet: "#9400d3", deeppink: "#ff1493", deepskyblue: "#00bfff", dimgray: "#696969", dimgrey: "#696969", dodgerblue: "#1e90ff", firebrick: "#b22222", floralwhite: "#fffaf0", forestgreen: "#228b22", fuchsia: "#ff00ff", gainsboro: "#dcdcdc", ghostwhite: "#f8f8ff", goldenrod: "#daa520", gold: "#ffd700", gray: "#808080", green: "#008000", greenyellow: "#adff2f", grey: "#808080", honeydew: "#f0fff0", hotpink: "#ff69b4", indianred: "#cd5c5c", indigo: "#4b0082", ivory: "#fffff0", khaki: "#f0e68c", lavenderblush: "#fff0f5", lavender: "#e6e6fa", lawngreen: "#7cfc00", lemonchiffon: "#fffacd", lightblue: "#add8e6", lightcoral: "#f08080", lightcyan: "#e0ffff", lightgoldenrodyellow: "#fafad2", lightgray: "#d3d3d3", lightgreen: "#90ee90", lightgrey: "#d3d3d3", lightpink: "#ffb6c1", lightsalmon: "#ffa07a", lightseagreen: "#20b2aa", lightskyblue: "#87cefa", lightslategray: "#778899", lightslategrey: "#778899", lightsteelblue: "#b0c4de", lightyellow: "#ffffe0", lime: "#00ff00", limegreen: "#32cd32", linen: "#faf0e6", magenta: "#ff00ff", maroon: "#800000", mediumaquamarine: "#66cdaa", mediumblue: "#0000cd", mediumorchid: "#ba55d3", mediumpurple: "#9370db", mediumseagreen: "#3cb371", mediumslateblue: "#7b68ee", mediumspringgreen: "#00fa9a", mediumturquoise: "#48d1cc", mediumvioletred: "#c71585", midnightblue: "#191970", mintcream: "#f5fffa", mistyrose: "#ffe4e1", moccasin: "#ffe4b5", navajowhite: "#ffdead", navy: "#000080", oldlace: "#fdf5e6", olive: "#808000", olivedrab: "#6b8e23", orange: "#ffa500", orangered: "#ff4500", orchid: "#da70d6", palegoldenrod: "#eee8aa", palegreen: "#98fb98", paleturquoise: "#afeeee", palevioletred: "#db7093", papayawhip: "#ffefd5", peachpuff: "#ffdab9", peru: "#cd853f", pink: "#ffc0cb", plum: "#dda0dd", powderblue: "#b0e0e6", purple: "#800080", rebeccapurple: "#663399", red: "#ff0000", rosybrown: "#bc8f8f", royalblue: "#4169e1", saddlebrown: "#8b4513", salmon: "#fa8072", sandybrown: "#f4a460", seagreen: "#2e8b57", seashell: "#fff5ee", sienna: "#a0522d", silver: "#c0c0c0", skyblue: "#87ceeb", slateblue: "#6a5acd", slategray: "#708090", slategrey: "#708090", snow: "#fffafa", springgreen: "#00ff7f", steelblue: "#4682b4", tan: "#d2b48c", teal: "#008080", thistle: "#d8bfd8", tomato: "#ff6347", turquoise: "#40e0d0", violet: "#ee82ee", wheat: "#f5deb3", white: "#ffffff", whitesmoke: "#f5f5f5", yellow: "#ffff00", yellowgreen: "#9acd32" };
function T(r) {
  let e = { r: 0, g: 0, b: 0 }, t = 1, n = null, s = null, a = null, i = false, h = false;
  return typeof r == "string" && (r = V(r)), typeof r == "object" && (g(r.r) && g(r.g) && g(r.b) ? (e = B(r.r, r.g, r.b), i = true, h = String(r.r).substr(-1) === "%" ? "prgb" : "rgb") : g(r.h) && g(r.s) && g(r.v) ? (n = p(r.s), s = p(r.v), e = P(r.h, n, s), i = true, h = "hsv") : g(r.h) && g(r.s) && g(r.l) ? (n = p(r.s), a = p(r.l), e = q(r.h, n, a), i = true, h = "hsl") : g(r.c) && g(r.m) && g(r.y) && g(r.k) && (e = O(r.c, r.m, r.y, r.k), i = true, h = "cmyk"), Object.prototype.hasOwnProperty.call(r, "a") && (t = r.a)), t = F(t), { ok: i, format: r.format || h, r: Math.min(255, Math.max(e.r, 0)), g: Math.min(255, Math.max(e.g, 0)), b: Math.min(255, Math.max(e.b, 0)), a: t };
}
const U = "[-\\+]?\\d+%?", D = "[-\\+]?\\d*\\.\\d+%?", b = "(?:" + D + ")|(?:" + U + ")", S = "[\\s|\\(]+(" + b + ")[,|\\s]+(" + b + ")[,|\\s]+(" + b + ")\\s*\\)?", k = "[\\s|\\(]+(" + b + ")[,|\\s]+(" + b + ")[,|\\s]+(" + b + ")[,|\\s]+(" + b + ")\\s*\\)?", d = { CSS_UNIT: new RegExp(b), rgb: new RegExp("rgb" + S), rgba: new RegExp("rgba" + k), hsl: new RegExp("hsl" + S), hsla: new RegExp("hsla" + k), hsv: new RegExp("hsv" + S), hsva: new RegExp("hsva" + k), cmyk: new RegExp("cmyk" + k), hex3: /^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/, hex6: /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/, hex4: /^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/, hex8: /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/ };
function V(r) {
  if (r = r.trim().toLowerCase(), r.length === 0)
    return false;
  let e = false;
  if (y[r])
    r = y[r], e = true;
  else if (r === "transparent")
    return { r: 0, g: 0, b: 0, a: 0, format: "name" };
  let t = d.rgb.exec(r);
  return t ? { r: t[1], g: t[2], b: t[3] } : (t = d.rgba.exec(r), t ? { r: t[1], g: t[2], b: t[3], a: t[4] } : (t = d.hsl.exec(r), t ? { h: t[1], s: t[2], l: t[3] } : (t = d.hsla.exec(r), t ? { h: t[1], s: t[2], l: t[3], a: t[4] } : (t = d.hsv.exec(r), t ? { h: t[1], s: t[2], v: t[3] } : (t = d.hsva.exec(r), t ? { h: t[1], s: t[2], v: t[3], a: t[4] } : (t = d.cmyk.exec(r), t ? { c: t[1], m: t[2], y: t[3], k: t[4] } : (t = d.hex8.exec(r), t ? { r: c(t[1]), g: c(t[2]), b: c(t[3]), a: $(t[4]), format: e ? "name" : "hex8" } : (t = d.hex6.exec(r), t ? { r: c(t[1]), g: c(t[2]), b: c(t[3]), format: e ? "name" : "hex" } : (t = d.hex4.exec(r), t ? { r: c(t[1] + t[1]), g: c(t[2] + t[2]), b: c(t[3] + t[3]), a: $(t[4] + t[4]), format: e ? "name" : "hex8" } : (t = d.hex3.exec(r), t ? { r: c(t[1] + t[1]), g: c(t[2] + t[2]), b: c(t[3] + t[3]), format: e ? "name" : "hex" } : false))))))))));
}
function g(r) {
  return typeof r == "number" ? !Number.isNaN(r) : d.CSS_UNIT.test(r);
}
class f {
  constructor(e = "", t = {}) {
    var _a;
    if (e instanceof f)
      return e;
    typeof e == "number" && (e = G(e)), this.originalInput = e;
    const n = T(e);
    this.originalInput = e, this.r = n.r, this.g = n.g, this.b = n.b, this.a = n.a, this.roundA = Math.round(100 * this.a) / 100, this.format = (_a = t.format) != null ? _a : n.format, this.gradientType = t.gradientType, this.r < 1 && (this.r = Math.round(this.r)), this.g < 1 && (this.g = Math.round(this.g)), this.b < 1 && (this.b = Math.round(this.b)), this.isValid = n.ok;
  }
  isDark() {
    return this.getBrightness() < 128;
  }
  isLight() {
    return !this.isDark();
  }
  getBrightness() {
    const e = this.toRgb();
    return (e.r * 299 + e.g * 587 + e.b * 114) / 1e3;
  }
  getLuminance() {
    const e = this.toRgb();
    let t, n, s;
    const a = e.r / 255, i = e.g / 255, h = e.b / 255;
    return a <= 0.03928 ? t = a / 12.92 : t = Math.pow((a + 0.055) / 1.055, 2.4), i <= 0.03928 ? n = i / 12.92 : n = Math.pow((i + 0.055) / 1.055, 2.4), h <= 0.03928 ? s = h / 12.92 : s = Math.pow((h + 0.055) / 1.055, 2.4), 0.2126 * t + 0.7152 * n + 0.0722 * s;
  }
  getAlpha() {
    return this.a;
  }
  setAlpha(e) {
    return this.a = F(e), this.roundA = Math.round(100 * this.a) / 100, this;
  }
  isMonochrome() {
    const { s: e } = this.toHsl();
    return e === 0;
  }
  toHsv() {
    const e = A(this.r, this.g, this.b);
    return { h: e.h * 360, s: e.s, v: e.v, a: this.a };
  }
  toHsvString() {
    const e = A(this.r, this.g, this.b), t = Math.round(e.h * 360), n = Math.round(e.s * 100), s = Math.round(e.v * 100);
    return this.a === 1 ? "hsv(".concat(t, ", ").concat(n, "%, ").concat(s, "%)") : "hsva(".concat(t, ", ").concat(n, "%, ").concat(s, "%, ").concat(this.roundA, ")");
  }
  toHsl() {
    const e = v(this.r, this.g, this.b);
    return { h: e.h * 360, s: e.s, l: e.l, a: this.a };
  }
  toHslString() {
    const e = v(this.r, this.g, this.b), t = Math.round(e.h * 360), n = Math.round(e.s * 100), s = Math.round(e.l * 100);
    return this.a === 1 ? "hsl(".concat(t, ", ").concat(n, "%, ").concat(s, "%)") : "hsla(".concat(t, ", ").concat(n, "%, ").concat(s, "%, ").concat(this.roundA, ")");
  }
  toHex(e = false) {
    return H(this.r, this.g, this.b, e);
  }
  toHexString(e = false) {
    return "#" + this.toHex(e);
  }
  toHex8(e = false) {
    return j(this.r, this.g, this.b, this.a, e);
  }
  toHex8String(e = false) {
    return "#" + this.toHex8(e);
  }
  toHexShortString(e = false) {
    return this.a === 1 ? this.toHexString(e) : this.toHex8String(e);
  }
  toRgb() {
    return { r: Math.round(this.r), g: Math.round(this.g), b: Math.round(this.b), a: this.a };
  }
  toRgbString() {
    const e = Math.round(this.r), t = Math.round(this.g), n = Math.round(this.b);
    return this.a === 1 ? "rgb(".concat(e, ", ").concat(t, ", ").concat(n, ")") : "rgba(".concat(e, ", ").concat(t, ", ").concat(n, ", ").concat(this.roundA, ")");
  }
  toPercentageRgb() {
    const e = (t) => "".concat(Math.round(u(t, 255) * 100), "%");
    return { r: e(this.r), g: e(this.g), b: e(this.b), a: this.a };
  }
  toPercentageRgbString() {
    const e = (t) => Math.round(u(t, 255) * 100);
    return this.a === 1 ? "rgb(".concat(e(this.r), "%, ").concat(e(this.g), "%, ").concat(e(this.b), "%)") : "rgba(".concat(e(this.r), "%, ").concat(e(this.g), "%, ").concat(e(this.b), "%, ").concat(this.roundA, ")");
  }
  toCmyk() {
    return { ...R(this.r, this.g, this.b) };
  }
  toCmykString() {
    const { c: e, m: t, y: n, k: s } = R(this.r, this.g, this.b);
    return "cmyk(".concat(e, ", ").concat(t, ", ").concat(n, ", ").concat(s, ")");
  }
  toName() {
    if (this.a === 0)
      return "transparent";
    if (this.a < 1)
      return false;
    const e = "#" + H(this.r, this.g, this.b, false);
    for (const [t, n] of Object.entries(y))
      if (e === n)
        return t;
    return false;
  }
  toString(e) {
    const t = !!e;
    e = e != null ? e : this.format;
    let n = false;
    const s = this.a < 1 && this.a >= 0;
    return !t && s && (e.startsWith("hex") || e === "name") ? e === "name" && this.a === 0 ? this.toName() : this.toRgbString() : (e === "rgb" && (n = this.toRgbString()), e === "prgb" && (n = this.toPercentageRgbString()), (e === "hex" || e === "hex6") && (n = this.toHexString()), e === "hex3" && (n = this.toHexString(true)), e === "hex4" && (n = this.toHex8String(true)), e === "hex8" && (n = this.toHex8String()), e === "name" && (n = this.toName()), e === "hsl" && (n = this.toHslString()), e === "hsv" && (n = this.toHsvString()), e === "cmyk" && (n = this.toCmykString()), n || this.toHexString());
  }
  toNumber() {
    return (Math.round(this.r) << 16) + (Math.round(this.g) << 8) + Math.round(this.b);
  }
  clone() {
    return new f(this.toString());
  }
  lighten(e = 10) {
    const t = this.toHsl();
    return t.l += e / 100, t.l = m(t.l), new f(t);
  }
  brighten(e = 10) {
    const t = this.toRgb();
    return t.r = Math.max(0, Math.min(255, t.r - Math.round(255 * -(e / 100)))), t.g = Math.max(0, Math.min(255, t.g - Math.round(255 * -(e / 100)))), t.b = Math.max(0, Math.min(255, t.b - Math.round(255 * -(e / 100)))), new f(t);
  }
  darken(e = 10) {
    const t = this.toHsl();
    return t.l -= e / 100, t.l = m(t.l), new f(t);
  }
  tint(e = 10) {
    return this.mix("white", e);
  }
  shade(e = 10) {
    return this.mix("black", e);
  }
  desaturate(e = 10) {
    const t = this.toHsl();
    return t.s -= e / 100, t.s = m(t.s), new f(t);
  }
  saturate(e = 10) {
    const t = this.toHsl();
    return t.s += e / 100, t.s = m(t.s), new f(t);
  }
  greyscale() {
    return this.desaturate(100);
  }
  spin(e) {
    const t = this.toHsl(), n = (t.h + e) % 360;
    return t.h = n < 0 ? 360 + n : n, new f(t);
  }
  mix(e, t = 50) {
    const n = this.toRgb(), s = new f(e).toRgb(), a = t / 100, i = { r: (s.r - n.r) * a + n.r, g: (s.g - n.g) * a + n.g, b: (s.b - n.b) * a + n.b, a: (s.a - n.a) * a + n.a };
    return new f(i);
  }
  analogous(e = 6, t = 30) {
    const n = this.toHsl(), s = 360 / t, a = [this];
    for (n.h = (n.h - (s * e >> 1) + 720) % 360; --e; )
      n.h = (n.h + s) % 360, a.push(new f(n));
    return a;
  }
  complement() {
    const e = this.toHsl();
    return e.h = (e.h + 180) % 360, new f(e);
  }
  monochromatic(e = 6) {
    const t = this.toHsv(), { h: n } = t, { s } = t;
    let { v: a } = t;
    const i = [], h = 1 / e;
    for (; e--; )
      i.push(new f({ h: n, s, v: a })), a = (a + h) % 1;
    return i;
  }
  splitcomplement() {
    const e = this.toHsl(), { h: t } = e;
    return [this, new f({ h: (t + 72) % 360, s: e.s, l: e.l }), new f({ h: (t + 216) % 360, s: e.s, l: e.l })];
  }
  onBackground(e) {
    const t = this.toRgb(), n = new f(e).toRgb(), s = t.a + n.a * (1 - t.a);
    return new f({ r: (t.r * t.a + n.r * n.a * (1 - t.a)) / s, g: (t.g * t.a + n.g * n.a * (1 - t.a)) / s, b: (t.b * t.a + n.b * n.a * (1 - t.a)) / s, a: s });
  }
  triad() {
    return this.polyad(3);
  }
  tetrad() {
    return this.polyad(4);
  }
  polyad(e) {
    const t = this.toHsl(), { h: n } = t, s = [this], a = 360 / e;
    for (let i = 1; i < e; i++)
      s.push(new f({ h: (n + i * a) % 360, s: t.s, l: t.l }));
    return s;
  }
  equals(e) {
    const t = new f(e);
    return this.format === "cmyk" || t.format === "cmyk" ? this.toCmykString() === t.toCmykString() : this.toRgbString() === t.toRgbString();
  }
}
export {
  f as T
};
