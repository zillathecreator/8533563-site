import { a as S, i as q, c as C, b as E, d as D, e as L, r as je, f as Wa, g as Aa, h as se, s as wa, j as xa, m as B, D as we, k as y, l as F, n as Q, o as Y, u as ee, p as oe, N as Ha, q as Va, t as $a, v as Ua, w as Ga, x as ja, y as fa, z as ce, A as ie, B as Ya, C as Ye, E as Be, F as Ba, G as ga, H as ue, I as Xa, J as Ja, K as Ka, L as za, M as Xe, O as Je, P as Ke, Q as ze, R as qe, S as Qe, T as Ze, U as qa, V as Qa, W as ea } from "./@intlify.928cb664.js";
import { d as xe, h as ba, al as Za, w as Ce, R as va, i as et, e as at, b as tt, r as z, H as lt, j as nt, k as ae, y as da, l as A, U as rt, S as st } from "./@vue.b00de3e9.js";
/*!
* vue-i18n v9.14.5
* (c) 2025 kazuya kawaguchi
* Released under the MIT License.
*/
const ct = "9.14.5";
function ut() {
  typeof __INTLIFY_JIT_COMPILATION__ != "boolean" && (se().__INTLIFY_JIT_COMPILATION__ = false), typeof __INTLIFY_DROP_MESSAGE_COMPILER__ != "boolean" && (se().__INTLIFY_DROP_MESSAGE_COMPILER__ = false), typeof __INTLIFY_PROD_DEVTOOLS__ != "boolean" && (se().__INTLIFY_PROD_DEVTOOLS__ = false);
}
const Ea = Qa.__EXTEND_POINT__, $ = ga(Ea);
$(), $(), $(), $(), $(), $(), $(), $(), $();
const Ta = Ba.__EXTEND_POINT__, M = ga(Ta), R = { UNEXPECTED_RETURN_TYPE: Ta, INVALID_ARGUMENT: M(), MUST_BE_CALL_SETUP_TOP: M(), NOT_INSTALLED: M(), NOT_AVAILABLE_IN_LEGACY_MODE: M(), REQUIRED_VALUE: M(), INVALID_VALUE: M(), CANNOT_SETUP_VUE_DEVTOOLS_PLUGIN: M(), NOT_INSTALLED_WITH_PROVIDE: M(), UNEXPECTED_ERROR: M(), NOT_COMPATIBLE_LEGACY_VUE_I18N: M(), BRIDGE_SUPPORT_VUE_2_ONLY: M(), MUST_DEFINE_I18N_OPTION_IN_ALLOW_COMPOSITION: M(), NOT_AVAILABLE_COMPOSITION_IN_LEGACY: M(), __EXTEND_POINT__: M() };
function h(e, ...s) {
  return xa(e, null, void 0);
}
const pe = B("__translateVNode"), De = B("__datetimeParts"), Se = B("__numberParts"), Ia = B("__setPluralRules"), La = B("__injectWithOption"), We = B("__dispose");
function te(e) {
  if (!D(e) || ue(e))
    return e;
  for (const s in e)
    if (ie(e, s))
      if (!s.includes("."))
        D(e[s]) && te(e[s]);
      else {
        const t = s.split("."), n = t.length - 1;
        let c = e, a = false;
        for (let l = 0; l < n; l++) {
          if (t[l] === "__proto__")
            throw new Error("unsafe key: ".concat(t[l]));
          if (t[l] in c || (c[t[l]] = C()), !D(c[t[l]])) {
            a = true;
            break;
          }
          c = c[t[l]];
        }
        if (a || (ue(c) ? Xa.includes(t[n]) || delete e[s] : (c[t[n]] = e[s], delete e[s])), !ue(c)) {
          const l = c[t[n]];
          D(l) && te(l);
        }
      }
  return e;
}
function me(e, s) {
  const { messages: t, __i18n: n, messageResolver: c, flatJson: a } = s, l = F(t) ? t : y(n) ? C() : { [e]: C() };
  if (y(n) && n.forEach((i) => {
    if ("locale" in i && "resource" in i) {
      const { locale: m, resource: _ } = i;
      m ? (l[m] = l[m] || C(), ce(_, l[m])) : ce(_, l);
    } else
      E(i) && ce(JSON.parse(i), l);
  }), c == null && a)
    for (const i in l)
      ie(l, i) && te(l[i]);
  return l;
}
function Oa(e) {
  return e.type;
}
function Fa(e, s, t) {
  let n = D(s.messages) ? s.messages : C();
  "__i18nGlobal" in t && (n = me(e.locale.value, { messages: n, __i18n: t.__i18nGlobal }));
  const c = Object.keys(n);
  c.length && c.forEach((a) => {
    e.mergeLocaleMessage(a, n[a]);
  });
  {
    if (D(s.datetimeFormats)) {
      const a = Object.keys(s.datetimeFormats);
      a.length && a.forEach((l) => {
        e.mergeDateTimeFormat(l, s.datetimeFormats[l]);
      });
    }
    if (D(s.numberFormats)) {
      const a = Object.keys(s.numberFormats);
      a.length && a.forEach((l) => {
        e.mergeNumberFormat(l, s.numberFormats[l]);
      });
    }
  }
}
function aa(e) {
  return rt(st, null, e, 0);
}
const ta = "__INTLIFY_META__", la = () => [], ot = () => false;
let na = 0;
function ra(e) {
  return (s, t, n, c) => e(t, n, ae() || void 0, c);
}
const it = () => {
  const e = ae();
  let s = null;
  return e && (s = Oa(e)[ta]) ? { [ta]: s } : null;
};
function He(e = {}, s) {
  const { __root: t, __injectWithOption: n } = e, c = t === void 0, a = e.flatJson, l = oe ? z : da, i = !!e.translateExistCompatible;
  let m = L(e.inheritLocale) ? e.inheritLocale : true;
  const _ = l(t && m ? t.locale.value : E(e.locale) ? e.locale : we), b = l(t && m ? t.fallbackLocale.value : E(e.fallbackLocale) || y(e.fallbackLocale) || F(e.fallbackLocale) || e.fallbackLocale === false ? e.fallbackLocale : _.value), v = l(me(_.value, e)), g = l(F(e.datetimeFormats) ? e.datetimeFormats : { [_.value]: {} }), d = l(F(e.numberFormats) ? e.numberFormats : { [_.value]: {} });
  let k = t ? t.missingWarn : L(e.missingWarn) || Q(e.missingWarn) ? e.missingWarn : true, P = t ? t.fallbackWarn : L(e.fallbackWarn) || Q(e.fallbackWarn) ? e.fallbackWarn : true, w = t ? t.fallbackRoot : L(e.fallbackRoot) ? e.fallbackRoot : true, p = !!e.fallbackFormat, X = Y(e.missing) ? e.missing : null, x = Y(e.missing) ? ra(e.missing) : null, H = Y(e.postTranslation) ? e.postTranslation : null, J = t ? t.warnHtmlMessage : L(e.warnHtmlMessage) ? e.warnHtmlMessage : true, U = !!e.escapeParameter;
  const Z = t ? t.modifiers : F(e.modifiers) ? e.modifiers : {};
  let W = e.pluralRules || t && t.pluralRules, f;
  f = (() => {
    c && ea(null);
    const r = { version: ct, locale: _.value, fallbackLocale: b.value, messages: v.value, modifiers: Z, pluralRules: W, missing: x === null ? void 0 : x, missingWarn: k, fallbackWarn: P, fallbackFormat: p, unresolving: true, postTranslation: H === null ? void 0 : H, warnHtmlMessage: J, escapeParameter: U, messageResolver: e.messageResolver, messageCompiler: e.messageCompiler, __meta: { framework: "vue" } };
    r.datetimeFormats = g.value, r.numberFormats = d.value, r.__datetimeFormatters = F(f) ? f.__datetimeFormatters : void 0, r.__numberFormatters = F(f) ? f.__numberFormatters : void 0;
    const u = Ya(r);
    return c && ea(u), u;
  })(), ee(f, _.value, b.value);
  function _e() {
    return [_.value, b.value, v.value, g.value, d.value];
  }
  const fe = A({ get: () => _.value, set: (r) => {
    _.value = r, f.locale = _.value;
  } }), ge = A({ get: () => b.value, set: (r) => {
    b.value = r, f.fallbackLocale = b.value, ee(f, _.value, r);
  } }), be = A(() => v.value), ve = A(() => g.value), G = A(() => d.value);
  function de() {
    return Y(H) ? H : null;
  }
  function Ee(r) {
    H = r, f.postTranslation = r;
  }
  function Te() {
    return X;
  }
  function Ie(r) {
    r !== null && (x = ra(r)), X = r, f.missing = x;
  }
  const V = (r, u, I, O, j, re) => {
    _e();
    let K;
    try {
      __INTLIFY_PROD_DEVTOOLS__ && Ja(it()), c || (f.fallbackContext = t ? Ka() : void 0), K = r(f);
    } finally {
      __INTLIFY_PROD_DEVTOOLS__, c || (f.fallbackContext = void 0);
    }
    if (I !== "translate exists" && q(K) && K === za || I === "translate exists" && !K) {
      const [Sa, pt] = u();
      return t && w ? O(t) : j(Sa);
    } else {
      if (re(K))
        return K;
      throw h(R.UNEXPECTED_RETURN_TYPE);
    }
  };
  function ne(...r) {
    return V((u) => Reflect.apply(Je, null, [u, ...r]), () => Xe(...r), "translate", (u) => Reflect.apply(u.t, u, [...r]), (u) => u, (u) => E(u));
  }
  function Le(...r) {
    const [u, I, O] = r;
    if (O && !D(O))
      throw h(R.INVALID_ARGUMENT);
    return ne(u, I, S({ resolvedMessage: true }, O || {}));
  }
  function Oe(...r) {
    return V((u) => Reflect.apply(qe, null, [u, ...r]), () => ze(...r), "datetime format", (u) => Reflect.apply(u.d, u, [...r]), () => Ke, (u) => E(u));
  }
  function Fe(...r) {
    return V((u) => Reflect.apply(Ze, null, [u, ...r]), () => Qe(...r), "number format", (u) => Reflect.apply(u.n, u, [...r]), () => Ke, (u) => E(u));
  }
  function Re(r) {
    return r.map((u) => E(u) || q(u) || L(u) ? aa(String(u)) : u);
  }
  const ke = { normalize: Re, interpolate: (r) => r, type: "vnode" };
  function Ne(...r) {
    return V((u) => {
      let I;
      const O = u;
      try {
        O.processor = ke, I = Reflect.apply(Je, null, [O, ...r]);
      } finally {
        O.processor = null;
      }
      return I;
    }, () => Xe(...r), "translate", (u) => u[pe](...r), (u) => [aa(u)], (u) => y(u));
  }
  function he(...r) {
    return V((u) => Reflect.apply(Ze, null, [u, ...r]), () => Qe(...r), "number format", (u) => u[Se](...r), la, (u) => E(u) || y(u));
  }
  function Pe(...r) {
    return V((u) => Reflect.apply(qe, null, [u, ...r]), () => ze(...r), "datetime format", (u) => u[De](...r), la, (u) => E(u) || y(u));
  }
  function Me(r) {
    W = r, f.pluralRules = W;
  }
  function ye(r, u) {
    return V(() => {
      if (!r)
        return false;
      const I = E(u) ? u : _.value, O = Ge(I), j = f.messageResolver(O, r);
      return i ? j != null : ue(j) || qa(j) || E(j);
    }, () => [r], "translate exists", (I) => Reflect.apply(I.te, I, [r, u]), ot, (I) => L(I));
  }
  function o(r) {
    let u = null;
    const I = fa(f, b.value, _.value);
    for (let O = 0; O < I.length; O++) {
      const j = v.value[I[O]] || {}, re = f.messageResolver(j, r);
      if (re != null) {
        u = re;
        break;
      }
    }
    return u;
  }
  function T(r) {
    const u = o(r);
    return u != null ? u : t ? t.tm(r) || {} : {};
  }
  function Ge(r) {
    return v.value[r] || {};
  }
  function Na(r, u) {
    if (a) {
      const I = { [r]: u };
      for (const O in I)
        ie(I, O) && te(I[O]);
      u = I[r];
    }
    v.value[r] = u, f.messages = v.value;
  }
  function ha(r, u) {
    v.value[r] = v.value[r] || {};
    const I = { [r]: u };
    if (a)
      for (const O in I)
        ie(I, O) && te(I[O]);
    u = I[r], ce(u, v.value[r]), f.messages = v.value;
  }
  function Pa(r) {
    return g.value[r] || {};
  }
  function Ma(r, u) {
    g.value[r] = u, f.datetimeFormats = g.value, Ye(f, r, u);
  }
  function ya(r, u) {
    g.value[r] = S(g.value[r] || {}, u), f.datetimeFormats = g.value, Ye(f, r, u);
  }
  function Ca(r) {
    return d.value[r] || {};
  }
  function pa(r, u) {
    d.value[r] = u, f.numberFormats = d.value, Be(f, r, u);
  }
  function Da(r, u) {
    d.value[r] = S(d.value[r] || {}, u), f.numberFormats = d.value, Be(f, r, u);
  }
  na++, t && oe && (Ce(t.locale, (r) => {
    m && (_.value = r, f.locale = r, ee(f, _.value, b.value));
  }), Ce(t.fallbackLocale, (r) => {
    m && (b.value = r, f.fallbackLocale = r, ee(f, _.value, b.value));
  }));
  const N = { id: na, locale: fe, fallbackLocale: ge, get inheritLocale() {
    return m;
  }, set inheritLocale(r) {
    m = r, r && t && (_.value = t.locale.value, b.value = t.fallbackLocale.value, ee(f, _.value, b.value));
  }, get availableLocales() {
    return Object.keys(v.value).sort();
  }, messages: be, get modifiers() {
    return Z;
  }, get pluralRules() {
    return W || {};
  }, get isGlobal() {
    return c;
  }, get missingWarn() {
    return k;
  }, set missingWarn(r) {
    k = r, f.missingWarn = k;
  }, get fallbackWarn() {
    return P;
  }, set fallbackWarn(r) {
    P = r, f.fallbackWarn = P;
  }, get fallbackRoot() {
    return w;
  }, set fallbackRoot(r) {
    w = r;
  }, get fallbackFormat() {
    return p;
  }, set fallbackFormat(r) {
    p = r, f.fallbackFormat = p;
  }, get warnHtmlMessage() {
    return J;
  }, set warnHtmlMessage(r) {
    J = r, f.warnHtmlMessage = r;
  }, get escapeParameter() {
    return U;
  }, set escapeParameter(r) {
    U = r, f.escapeParameter = r;
  }, t: ne, getLocaleMessage: Ge, setLocaleMessage: Na, mergeLocaleMessage: ha, getPostTranslationHandler: de, setPostTranslationHandler: Ee, getMissingHandler: Te, setMissingHandler: Ie, [Ia]: Me };
  return N.datetimeFormats = ve, N.numberFormats = G, N.rt = Le, N.te = ye, N.tm = T, N.d = Oe, N.n = Fe, N.getDateTimeFormat = Pa, N.setDateTimeFormat = Ma, N.mergeDateTimeFormat = ya, N.getNumberFormat = Ca, N.setNumberFormat = pa, N.mergeNumberFormat = Da, N[La] = n, N[pe] = Ne, N[De] = Pe, N[Se] = he, N;
}
function mt(e) {
  const s = E(e.locale) ? e.locale : we, t = E(e.fallbackLocale) || y(e.fallbackLocale) || F(e.fallbackLocale) || e.fallbackLocale === false ? e.fallbackLocale : s, n = Y(e.missing) ? e.missing : void 0, c = L(e.silentTranslationWarn) || Q(e.silentTranslationWarn) ? !e.silentTranslationWarn : true, a = L(e.silentFallbackWarn) || Q(e.silentFallbackWarn) ? !e.silentFallbackWarn : true, l = L(e.fallbackRoot) ? e.fallbackRoot : true, i = !!e.formatFallbackMessages, m = F(e.modifiers) ? e.modifiers : {}, _ = e.pluralizationRules, b = Y(e.postTranslation) ? e.postTranslation : void 0, v = E(e.warnHtmlInMessage) ? e.warnHtmlInMessage !== "off" : true, g = !!e.escapeParameterHtml, d = L(e.sync) ? e.sync : true;
  let k = e.messages;
  if (F(e.sharedMessages)) {
    const U = e.sharedMessages;
    k = Object.keys(U).reduce((W, f) => {
      const le = W[f] || (W[f] = {});
      return S(le, U[f]), W;
    }, k || {});
  }
  const { __i18n: P, __root: w, __injectWithOption: p } = e, X = e.datetimeFormats, x = e.numberFormats, H = e.flatJson, J = e.translateExistCompatible;
  return { locale: s, fallbackLocale: t, messages: k, flatJson: H, datetimeFormats: X, numberFormats: x, missing: n, missingWarn: c, fallbackWarn: a, fallbackRoot: l, fallbackFormat: i, modifiers: m, pluralRules: _, postTranslation: b, warnHtmlMessage: v, escapeParameter: g, messageResolver: e.messageResolver, inheritLocale: d, translateExistCompatible: J, __i18n: P, __root: w, __injectWithOption: p };
}
function Ae(e = {}, s) {
  {
    const t = He(mt(e)), { __extender: n } = e, c = { id: t.id, get locale() {
      return t.locale.value;
    }, set locale(a) {
      t.locale.value = a;
    }, get fallbackLocale() {
      return t.fallbackLocale.value;
    }, set fallbackLocale(a) {
      t.fallbackLocale.value = a;
    }, get messages() {
      return t.messages.value;
    }, get datetimeFormats() {
      return t.datetimeFormats.value;
    }, get numberFormats() {
      return t.numberFormats.value;
    }, get availableLocales() {
      return t.availableLocales;
    }, get formatter() {
      return { interpolate() {
        return [];
      } };
    }, set formatter(a) {
    }, get missing() {
      return t.getMissingHandler();
    }, set missing(a) {
      t.setMissingHandler(a);
    }, get silentTranslationWarn() {
      return L(t.missingWarn) ? !t.missingWarn : t.missingWarn;
    }, set silentTranslationWarn(a) {
      t.missingWarn = L(a) ? !a : a;
    }, get silentFallbackWarn() {
      return L(t.fallbackWarn) ? !t.fallbackWarn : t.fallbackWarn;
    }, set silentFallbackWarn(a) {
      t.fallbackWarn = L(a) ? !a : a;
    }, get modifiers() {
      return t.modifiers;
    }, get formatFallbackMessages() {
      return t.fallbackFormat;
    }, set formatFallbackMessages(a) {
      t.fallbackFormat = a;
    }, get postTranslation() {
      return t.getPostTranslationHandler();
    }, set postTranslation(a) {
      t.setPostTranslationHandler(a);
    }, get sync() {
      return t.inheritLocale;
    }, set sync(a) {
      t.inheritLocale = a;
    }, get warnHtmlInMessage() {
      return t.warnHtmlMessage ? "warn" : "off";
    }, set warnHtmlInMessage(a) {
      t.warnHtmlMessage = a !== "off";
    }, get escapeParameterHtml() {
      return t.escapeParameter;
    }, set escapeParameterHtml(a) {
      t.escapeParameter = a;
    }, get preserveDirectiveContent() {
      return true;
    }, set preserveDirectiveContent(a) {
    }, get pluralizationRules() {
      return t.pluralRules || {};
    }, __composer: t, t(...a) {
      const [l, i, m] = a, _ = {};
      let b = null, v = null;
      if (!E(l))
        throw h(R.INVALID_ARGUMENT);
      const g = l;
      return E(i) ? _.locale = i : y(i) ? b = i : F(i) && (v = i), y(m) ? b = m : F(m) && (v = m), Reflect.apply(t.t, t, [g, b || v || {}, _]);
    }, rt(...a) {
      return Reflect.apply(t.rt, t, [...a]);
    }, tc(...a) {
      const [l, i, m] = a, _ = { plural: 1 };
      let b = null, v = null;
      if (!E(l))
        throw h(R.INVALID_ARGUMENT);
      const g = l;
      return E(i) ? _.locale = i : q(i) ? _.plural = i : y(i) ? b = i : F(i) && (v = i), E(m) ? _.locale = m : y(m) ? b = m : F(m) && (v = m), Reflect.apply(t.t, t, [g, b || v || {}, _]);
    }, te(a, l) {
      return t.te(a, l);
    }, tm(a) {
      return t.tm(a);
    }, getLocaleMessage(a) {
      return t.getLocaleMessage(a);
    }, setLocaleMessage(a, l) {
      t.setLocaleMessage(a, l);
    }, mergeLocaleMessage(a, l) {
      t.mergeLocaleMessage(a, l);
    }, d(...a) {
      return Reflect.apply(t.d, t, [...a]);
    }, getDateTimeFormat(a) {
      return t.getDateTimeFormat(a);
    }, setDateTimeFormat(a, l) {
      t.setDateTimeFormat(a, l);
    }, mergeDateTimeFormat(a, l) {
      t.mergeDateTimeFormat(a, l);
    }, n(...a) {
      return Reflect.apply(t.n, t, [...a]);
    }, getNumberFormat(a) {
      return t.getNumberFormat(a);
    }, setNumberFormat(a, l) {
      t.setNumberFormat(a, l);
    }, mergeNumberFormat(a, l) {
      t.mergeNumberFormat(a, l);
    }, getChoiceIndex(a, l) {
      return -1;
    } };
    return c.__extender = n, c;
  }
}
const Ve = { tag: { type: [String, Object] }, locale: { type: String }, scope: { type: String, validator: (e) => e === "parent" || e === "global", default: "parent" }, i18n: { type: Object } };
function _t({ slots: e }, s) {
  return s.length === 1 && s[0] === "default" ? (e.default ? e.default() : []).reduce((n, c) => [...n, ...c.type === va ? c.children : [c]], []) : s.reduce((t, n) => {
    const c = e[n];
    return c && (t[n] = c()), t;
  }, C());
}
function Ra(e) {
  return va;
}
const ft = xe({ name: "i18n-t", props: S({ keypath: { type: String, required: true }, plural: { type: [Number, String], validator: (e) => q(e) || !isNaN(e) } }, Ve), setup(e, s) {
  const { slots: t, attrs: n } = s, c = e.i18n || $e({ useScope: e.scope, __useComponent: true });
  return () => {
    const a = Object.keys(t).filter((v) => v !== "_"), l = C();
    e.locale && (l.locale = e.locale), e.plural !== void 0 && (l.plural = E(e.plural) ? +e.plural : e.plural);
    const i = _t(s, a), m = c[pe](e.keypath, i, l), _ = S(C(), n), b = E(e.tag) || D(e.tag) ? e.tag : Ra();
    return ba(b, _, m);
  };
} }), sa = ft;
function gt(e) {
  return y(e) && !E(e[0]);
}
function ka(e, s, t, n) {
  const { slots: c, attrs: a } = s;
  return () => {
    const l = { part: true };
    let i = C();
    e.locale && (l.locale = e.locale), E(e.format) ? l.key = e.format : D(e.format) && (E(e.format.key) && (l.key = e.format.key), i = Object.keys(e.format).reduce((g, d) => t.includes(d) ? S(C(), g, { [d]: e.format[d] }) : g, C()));
    const m = n(e.value, l, i);
    let _ = [l.key];
    y(m) ? _ = m.map((g, d) => {
      const k = c[g.type], P = k ? k({ [g.type]: g.value, index: d, parts: m }) : [g.value];
      return gt(P) && (P[0].key = "".concat(g.type, "-").concat(d)), P;
    }) : E(m) && (_ = [m]);
    const b = S(C(), a), v = E(e.tag) || D(e.tag) ? e.tag : Ra();
    return ba(v, b, _);
  };
}
const bt = xe({ name: "i18n-n", props: S({ value: { type: Number, required: true }, format: { type: [String, Object] } }, Ve), setup(e, s) {
  const t = e.i18n || $e({ useScope: e.scope, __useComponent: true });
  return ka(e, s, Ha, (...n) => t[Se](...n));
} }), ca = bt, vt = xe({ name: "i18n-d", props: S({ value: { type: [Number, Date], required: true }, format: { type: [String, Object] } }, Ve), setup(e, s) {
  const t = e.i18n || $e({ useScope: e.scope, __useComponent: true });
  return ka(e, s, Va, (...n) => t[De](...n));
} }), ua = vt;
function dt(e, s) {
  const t = e;
  if (e.mode === "composition")
    return t.__getInstance(s) || e.global;
  {
    const n = t.__getInstance(s);
    return n != null ? n.__composer : e.global.__composer;
  }
}
function Et(e) {
  const s = (l) => {
    const { instance: i, modifiers: m, value: _ } = l;
    if (!i || !i.$)
      throw h(R.UNEXPECTED_ERROR);
    const b = dt(e, i.$), v = oa(_);
    return [Reflect.apply(b.t, b, [...ia(v)]), b];
  };
  return { created: (l, i) => {
    const [m, _] = s(i);
    oe && e.global === _ && (l.__i18nWatcher = Ce(_.locale, () => {
      i.instance && i.instance.$forceUpdate();
    })), l.__composer = _, l.textContent = m;
  }, unmounted: (l) => {
    oe && l.__i18nWatcher && (l.__i18nWatcher(), l.__i18nWatcher = void 0, delete l.__i18nWatcher), l.__composer && (l.__composer = void 0, delete l.__composer);
  }, beforeUpdate: (l, { value: i }) => {
    if (l.__composer) {
      const m = l.__composer, _ = oa(i);
      l.textContent = Reflect.apply(m.t, m, [...ia(_)]);
    }
  }, getSSRProps: (l) => {
    const [i] = s(l);
    return { textContent: i };
  } };
}
function oa(e) {
  if (E(e))
    return { path: e };
  if (F(e)) {
    if (!("path" in e))
      throw h(R.REQUIRED_VALUE, "path");
    return e;
  } else
    throw h(R.INVALID_VALUE);
}
function ia(e) {
  const { path: s, locale: t, args: n, choice: c, plural: a } = e, l = {}, i = n || {};
  return E(t) && (l.locale = t), q(c) && (l.plural = c), q(a) && (l.plural = a), [s, i, l];
}
function Tt(e, s, ...t) {
  const n = F(t[0]) ? t[0] : {}, c = !!n.useI18nComponentName;
  (L(n.globalInstall) ? n.globalInstall : true) && ([c ? "i18n" : sa.name, "I18nT"].forEach((l) => e.component(l, sa)), [ca.name, "I18nN"].forEach((l) => e.component(l, ca)), [ua.name, "I18nD"].forEach((l) => e.component(l, ua))), e.directive("t", Et(s));
}
function It(e, s, t) {
  return { beforeCreate() {
    const n = ae();
    if (!n)
      throw h(R.UNEXPECTED_ERROR);
    const c = this.$options;
    if (c.i18n) {
      const a = c.i18n;
      if (c.__i18n && (a.__i18n = c.__i18n), a.__root = s, this === this.$root)
        this.$i18n = ma(e, a);
      else {
        a.__injectWithOption = true, a.__extender = t.__vueI18nExtend, this.$i18n = Ae(a);
        const l = this.$i18n;
        l.__extender && (l.__disposer = l.__extender(this.$i18n));
      }
    } else if (c.__i18n)
      if (this === this.$root)
        this.$i18n = ma(e, c);
      else {
        this.$i18n = Ae({ __i18n: c.__i18n, __injectWithOption: true, __extender: t.__vueI18nExtend, __root: s });
        const a = this.$i18n;
        a.__extender && (a.__disposer = a.__extender(this.$i18n));
      }
    else
      this.$i18n = e;
    c.__i18nGlobal && Fa(s, c, c), this.$t = (...a) => this.$i18n.t(...a), this.$rt = (...a) => this.$i18n.rt(...a), this.$tc = (...a) => this.$i18n.tc(...a), this.$te = (a, l) => this.$i18n.te(a, l), this.$d = (...a) => this.$i18n.d(...a), this.$n = (...a) => this.$i18n.n(...a), this.$tm = (a) => this.$i18n.tm(a), t.__setInstance(n, this.$i18n);
  }, mounted() {
  }, unmounted() {
    const n = ae();
    if (!n)
      throw h(R.UNEXPECTED_ERROR);
    const c = this.$i18n;
    delete this.$t, delete this.$rt, delete this.$tc, delete this.$te, delete this.$d, delete this.$n, delete this.$tm, c.__disposer && (c.__disposer(), delete c.__disposer, delete c.__extender), t.__deleteInstance(n), delete this.$i18n;
  } };
}
function ma(e, s) {
  e.locale = s.locale || e.locale, e.fallbackLocale = s.fallbackLocale || e.fallbackLocale, e.missing = s.missing || e.missing, e.silentTranslationWarn = s.silentTranslationWarn || e.silentFallbackWarn, e.silentFallbackWarn = s.silentFallbackWarn || e.silentFallbackWarn, e.formatFallbackMessages = s.formatFallbackMessages || e.formatFallbackMessages, e.postTranslation = s.postTranslation || e.postTranslation, e.warnHtmlInMessage = s.warnHtmlInMessage || e.warnHtmlInMessage, e.escapeParameterHtml = s.escapeParameterHtml || e.escapeParameterHtml, e.sync = s.sync || e.sync, e.__composer[Ia](s.pluralizationRules || e.pluralizationRules);
  const t = me(e.locale, { messages: s.messages, __i18n: s.__i18n });
  return Object.keys(t).forEach((n) => e.mergeLocaleMessage(n, t[n])), s.datetimeFormats && Object.keys(s.datetimeFormats).forEach((n) => e.mergeDateTimeFormat(n, s.datetimeFormats[n])), s.numberFormats && Object.keys(s.numberFormats).forEach((n) => e.mergeNumberFormat(n, s.numberFormats[n])), e;
}
const Lt = B("global-vue-i18n");
function Wt(e = {}, s) {
  const t = L(e.legacy) ? e.legacy : true, n = L(e.globalInjection) ? e.globalInjection : true, c = t ? !!e.allowComposition : true, a = /* @__PURE__ */ new Map(), [l, i] = Ot(e, t), m = B("");
  function _(g) {
    return a.get(g) || null;
  }
  function b(g, d) {
    a.set(g, d);
  }
  function v(g) {
    a.delete(g);
  }
  {
    const g = { get mode() {
      return t ? "legacy" : "composition";
    }, get allowComposition() {
      return c;
    }, async install(d, ...k) {
      if (d.__VUE_I18N_SYMBOL__ = m, d.provide(d.__VUE_I18N_SYMBOL__, g), F(k[0])) {
        const p = k[0];
        g.__composerExtend = p.__composerExtend, g.__vueI18nExtend = p.__vueI18nExtend;
      }
      let P = null;
      !t && n && (P = Ct(d, g.global)), Tt(d, g, ...k), t && d.mixin(It(i, i.__composer, g));
      const w = d.unmount;
      d.unmount = () => {
        P && P(), g.dispose(), w();
      };
    }, get global() {
      return i;
    }, dispose() {
      l.stop();
    }, __instances: a, __getInstance: _, __setInstance: b, __deleteInstance: v };
    return g;
  }
}
function $e(e = {}) {
  const s = ae();
  if (s == null)
    throw h(R.MUST_BE_CALL_SETUP_TOP);
  if (!s.isCE && s.appContext.app != null && !s.appContext.app.__VUE_I18N_SYMBOL__)
    throw h(R.NOT_INSTALLED);
  const t = Ft(s), n = kt(t), c = Oa(s), a = Rt(e, c);
  if (t.mode === "legacy" && !e.__useComponent) {
    if (!t.allowComposition)
      throw h(R.NOT_AVAILABLE_IN_LEGACY_MODE);
    return Mt(s, a, n, e);
  }
  if (a === "global")
    return Fa(n, e, c), n;
  if (a === "parent") {
    let m = Nt(t, s, e.__useComponent);
    return m == null && (m = n), m;
  }
  const l = t;
  let i = l.__getInstance(s);
  if (i == null) {
    const m = S({}, e);
    "__i18n" in c && (m.__i18n = c.__i18n), n && (m.__root = n), i = He(m), l.__composerExtend && (i[We] = l.__composerExtend(i)), Pt(l, s, i), l.__setInstance(s, i);
  }
  return i;
}
function Ot(e, s, t) {
  const n = Za();
  {
    const c = s ? n.run(() => Ae(e)) : n.run(() => He(e));
    if (c == null)
      throw h(R.UNEXPECTED_ERROR);
    return [n, c];
  }
}
function Ft(e) {
  {
    const s = et(e.isCE ? Lt : e.appContext.app.__VUE_I18N_SYMBOL__);
    if (!s)
      throw h(e.isCE ? R.NOT_INSTALLED_WITH_PROVIDE : R.UNEXPECTED_ERROR);
    return s;
  }
}
function Rt(e, s) {
  return $a(e) ? "__i18n" in s ? "local" : "global" : e.useScope ? e.useScope : "local";
}
function kt(e) {
  return e.mode === "composition" ? e.global : e.global.__composer;
}
function Nt(e, s, t = false) {
  let n = null;
  const c = s.root;
  let a = ht(s, t);
  for (; a != null; ) {
    const l = e;
    if (e.mode === "composition")
      n = l.__getInstance(a);
    else {
      const i = l.__getInstance(a);
      i != null && (n = i.__composer, t && n && !n[La] && (n = null));
    }
    if (n != null || c === a)
      break;
    a = a.parent;
  }
  return n;
}
function ht(e, s = false) {
  return e == null ? null : s && e.vnode.ctx || e.parent;
}
function Pt(e, s, t) {
  at(() => {
  }, s), tt(() => {
    const n = t;
    e.__deleteInstance(s);
    const c = n[We];
    c && (c(), delete n[We]);
  }, s);
}
function Mt(e, s, t, n = {}) {
  const c = s === "local", a = da(null);
  if (c && e.proxy && !(e.proxy.$options.i18n || e.proxy.$options.__i18n))
    throw h(R.MUST_DEFINE_I18N_OPTION_IN_ALLOW_COMPOSITION);
  const l = L(n.inheritLocale) ? n.inheritLocale : !E(n.locale), i = z(!c || l ? t.locale.value : E(n.locale) ? n.locale : we), m = z(!c || l ? t.fallbackLocale.value : E(n.fallbackLocale) || y(n.fallbackLocale) || F(n.fallbackLocale) || n.fallbackLocale === false ? n.fallbackLocale : i.value), _ = z(me(i.value, n)), b = z(F(n.datetimeFormats) ? n.datetimeFormats : { [i.value]: {} }), v = z(F(n.numberFormats) ? n.numberFormats : { [i.value]: {} }), g = c ? t.missingWarn : L(n.missingWarn) || Q(n.missingWarn) ? n.missingWarn : true, d = c ? t.fallbackWarn : L(n.fallbackWarn) || Q(n.fallbackWarn) ? n.fallbackWarn : true, k = c ? t.fallbackRoot : L(n.fallbackRoot) ? n.fallbackRoot : true, P = !!n.fallbackFormat, w = Y(n.missing) ? n.missing : null, p = Y(n.postTranslation) ? n.postTranslation : null, X = c ? t.warnHtmlMessage : L(n.warnHtmlMessage) ? n.warnHtmlMessage : true, x = !!n.escapeParameter, H = c ? t.modifiers : F(n.modifiers) ? n.modifiers : {}, J = n.pluralRules || c && t.pluralRules;
  function U() {
    return [i.value, m.value, _.value, b.value, v.value];
  }
  const Z = A({ get: () => a.value ? a.value.locale.value : i.value, set: (o) => {
    a.value && (a.value.locale.value = o), i.value = o;
  } }), W = A({ get: () => a.value ? a.value.fallbackLocale.value : m.value, set: (o) => {
    a.value && (a.value.fallbackLocale.value = o), m.value = o;
  } }), f = A(() => a.value ? a.value.messages.value : _.value), le = A(() => b.value), _e = A(() => v.value);
  function fe() {
    return a.value ? a.value.getPostTranslationHandler() : p;
  }
  function ge(o) {
    a.value && a.value.setPostTranslationHandler(o);
  }
  function be() {
    return a.value ? a.value.getMissingHandler() : w;
  }
  function ve(o) {
    a.value && a.value.setMissingHandler(o);
  }
  function G(o) {
    return U(), o();
  }
  function de(...o) {
    return a.value ? G(() => Reflect.apply(a.value.t, null, [...o])) : G(() => "");
  }
  function Ee(...o) {
    return a.value ? Reflect.apply(a.value.rt, null, [...o]) : "";
  }
  function Te(...o) {
    return a.value ? G(() => Reflect.apply(a.value.d, null, [...o])) : G(() => "");
  }
  function Ie(...o) {
    return a.value ? G(() => Reflect.apply(a.value.n, null, [...o])) : G(() => "");
  }
  function V(o) {
    return a.value ? a.value.tm(o) : {};
  }
  function ne(o, T) {
    return a.value ? a.value.te(o, T) : false;
  }
  function Le(o) {
    return a.value ? a.value.getLocaleMessage(o) : {};
  }
  function Oe(o, T) {
    a.value && (a.value.setLocaleMessage(o, T), _.value[o] = T);
  }
  function Fe(o, T) {
    a.value && a.value.mergeLocaleMessage(o, T);
  }
  function Re(o) {
    return a.value ? a.value.getDateTimeFormat(o) : {};
  }
  function Ue(o, T) {
    a.value && (a.value.setDateTimeFormat(o, T), b.value[o] = T);
  }
  function ke(o, T) {
    a.value && a.value.mergeDateTimeFormat(o, T);
  }
  function Ne(o) {
    return a.value ? a.value.getNumberFormat(o) : {};
  }
  function he(o, T) {
    a.value && (a.value.setNumberFormat(o, T), v.value[o] = T);
  }
  function Pe(o, T) {
    a.value && a.value.mergeNumberFormat(o, T);
  }
  const Me = { get id() {
    return a.value ? a.value.id : -1;
  }, locale: Z, fallbackLocale: W, messages: f, datetimeFormats: le, numberFormats: _e, get inheritLocale() {
    return a.value ? a.value.inheritLocale : l;
  }, set inheritLocale(o) {
    a.value && (a.value.inheritLocale = o);
  }, get availableLocales() {
    return a.value ? a.value.availableLocales : Object.keys(_.value);
  }, get modifiers() {
    return a.value ? a.value.modifiers : H;
  }, get pluralRules() {
    return a.value ? a.value.pluralRules : J;
  }, get isGlobal() {
    return a.value ? a.value.isGlobal : false;
  }, get missingWarn() {
    return a.value ? a.value.missingWarn : g;
  }, set missingWarn(o) {
    a.value && (a.value.missingWarn = o);
  }, get fallbackWarn() {
    return a.value ? a.value.fallbackWarn : d;
  }, set fallbackWarn(o) {
    a.value && (a.value.missingWarn = o);
  }, get fallbackRoot() {
    return a.value ? a.value.fallbackRoot : k;
  }, set fallbackRoot(o) {
    a.value && (a.value.fallbackRoot = o);
  }, get fallbackFormat() {
    return a.value ? a.value.fallbackFormat : P;
  }, set fallbackFormat(o) {
    a.value && (a.value.fallbackFormat = o);
  }, get warnHtmlMessage() {
    return a.value ? a.value.warnHtmlMessage : X;
  }, set warnHtmlMessage(o) {
    a.value && (a.value.warnHtmlMessage = o);
  }, get escapeParameter() {
    return a.value ? a.value.escapeParameter : x;
  }, set escapeParameter(o) {
    a.value && (a.value.escapeParameter = o);
  }, t: de, getPostTranslationHandler: fe, setPostTranslationHandler: ge, getMissingHandler: be, setMissingHandler: ve, rt: Ee, d: Te, n: Ie, tm: V, te: ne, getLocaleMessage: Le, setLocaleMessage: Oe, mergeLocaleMessage: Fe, getDateTimeFormat: Re, setDateTimeFormat: Ue, mergeDateTimeFormat: ke, getNumberFormat: Ne, setNumberFormat: he, mergeNumberFormat: Pe };
  function ye(o) {
    o.locale.value = i.value, o.fallbackLocale.value = m.value, Object.keys(_.value).forEach((T) => {
      o.mergeLocaleMessage(T, _.value[T]);
    }), Object.keys(b.value).forEach((T) => {
      o.mergeDateTimeFormat(T, b.value[T]);
    }), Object.keys(v.value).forEach((T) => {
      o.mergeNumberFormat(T, v.value[T]);
    }), o.escapeParameter = x, o.fallbackFormat = P, o.fallbackRoot = k, o.fallbackWarn = d, o.missingWarn = g, o.warnHtmlMessage = X;
  }
  return lt(() => {
    if (e.proxy == null || e.proxy.$i18n == null)
      throw h(R.NOT_AVAILABLE_COMPOSITION_IN_LEGACY);
    const o = a.value = e.proxy.$i18n.__composer;
    s === "global" ? (i.value = o.locale.value, m.value = o.fallbackLocale.value, _.value = o.messages.value, b.value = o.datetimeFormats.value, v.value = o.numberFormats.value) : c && ye(o);
  }), Me;
}
const yt = ["locale", "fallbackLocale", "availableLocales"], _a = ["t", "rt", "d", "n", "tm", "te"];
function Ct(e, s) {
  const t = /* @__PURE__ */ Object.create(null);
  return yt.forEach((c) => {
    const a = Object.getOwnPropertyDescriptor(s, c);
    if (!a)
      throw h(R.UNEXPECTED_ERROR);
    const l = nt(a.value) ? { get() {
      return a.value.value;
    }, set(i) {
      a.value.value = i;
    } } : { get() {
      return a.get && a.get();
    } };
    Object.defineProperty(t, c, l);
  }), e.config.globalProperties.$i18n = t, _a.forEach((c) => {
    const a = Object.getOwnPropertyDescriptor(s, c);
    if (!a || !a.value)
      throw h(R.UNEXPECTED_ERROR);
    Object.defineProperty(e.config.globalProperties, "$".concat(c), a);
  }), () => {
    delete e.config.globalProperties.$i18n, _a.forEach((c) => {
      delete e.config.globalProperties["$".concat(c)];
    });
  };
}
ut();
__INTLIFY_JIT_COMPILATION__ ? je(Ua) : je(Ga);
Wa(ja);
Aa(fa);
if (__INTLIFY_PROD_DEVTOOLS__) {
  const e = se();
  e.__INTLIFY__ = true, wa(e.__INTLIFY_DEVTOOLS_GLOBAL_HOOK__);
}
export {
  Wt as c,
  $e as u
};
