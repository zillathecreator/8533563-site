import { o as e, c as i, a as r } from "./@vue.b00de3e9.js";
const n = { xmlns: "http://www.w3.org/2000/svg", fill: "currentColor", viewBox: "0 0 52 40" };
function o(t, a) {
  return e(), i("svg", n, [...a[0] || (a[0] = [r("g", { id: "wg_side_pink_vip__ded88c12d68b97f1730c213f896786f1-icon_sy_zc_vip", fill: "currentColor", transform: "translate(5082.123 19238)" }, [r("g", { id: "wg_side_pink_vip__ded88c12d68b97f1730c213f896786f1-icon_btm_vip1", fill: "currentColor", transform: "translate(-5069.123 -19230)" }, [r("g", { id: "wg_side_pink_vip__ded88c12d68b97f1730c213f896786f1-Group_2452", fill: "currentColor", "data-name": "Group 2452" }, [r("path", { id: "wg_side_pink_vip__ded88c12d68b97f1730c213f896786f1-Union_41", fill: "currentColor", d: "M-6226.9 6004.631h-10.65a2.44 2.44 0 0 1-2.455-2.421v-17.2c.013-1.52.845-1.746 1.339-1.746a2.3 2.3 0 0 1 .951.229l3.359 2.283a1.6 1.6 0 0 0 .68.133 1.7 1.7 0 0 0 .516-.07l5.707-4.6.073-.046a.87.87 0 0 1 .491-.194h.022a.94.94 0 0 1 .524.241l5.706 4.6a1.8 1.8 0 0 0 .55.07 1.2 1.2 0 0 0 .649-.133l3.335-2.283a2 2 0 0 1 .982-.293 1.17 1.17 0 0 1 .942.443 2.16 2.16 0 0 1 .388 1.367v17.2a2.44 2.44 0 0 1-2.458 2.421Zm-6.65-10.082a6.86 6.86 0 0 0 6.855 6.856 6.863 6.863 0 0 0 6.855-6.856 6.863 6.863 0 0 0-6.855-6.854 6.86 6.86 0 0 0-6.857 6.854Zm5.966 4.214-3.725-6.264a.95.95 0 0 1 .33-1.3.95.95 0 0 1 1.305.332l2.905 4.89 2.911-4.89a.95.95 0 0 1 1.3-.332.95.95 0 0 1 .333 1.3l-3.727 6.264a.95.95 0 0 1-.82.466.95.95 0 0 1-.817-.466Z", "data-name": "Union 41", transform: "translate(6240.001 -5981)" })])])], -1)])]);
}
const d = { render: o };
export {
  d as default,
  o as render
};
