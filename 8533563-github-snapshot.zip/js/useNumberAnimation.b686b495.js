import { ai as w, am as b, __tla as __tla_0 } from "./index.bb04cb73.js";
import { w as M, e as S, f as g, r as c } from "./@vue.b00de3e9.js";
let N;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e) {
    }
  })()
]).then(async () => {
  N = function(i, p = {}) {
    const { interval: m = 20, autoStart: d = true } = p, e = c(0), l = c(0), u = c(null), f = () => typeof i == "function" ? i() : i.value, o = () => {
      u.value && (clearInterval(u.value), u.value = null);
    }, r = () => {
      o();
      const a = f();
      a != null && (l.value = a, e.value > a && (e.value = 0), u.value = setInterval(() => {
        const t = w(l.value, e.value);
        if (!t) {
          o();
          return;
        }
        let n;
        const s = parseInt(t).toString().length;
        if (t > 0) {
          const h = Math.pow(10, s - 1), v = Number(h.toString().replace("1", "5").replace("0", "3"));
          t > v ? n = v : s >= 2 ? n = t.toString()[0] !== "1" ? Math.pow(10, s - 1) : Math.pow(10, s - 2) : n = t > 0.21 ? 0.11 : 0.01;
        } else
          n = t / 2;
        e.value = b(e.value, n), e.value === l.value && o();
      }, m));
    };
    return M(f, (a) => {
      a !== l.value && r();
    }), d && (S(r), g(r)), {
      animatedValue: e,
      start: r,
      stop: o
    };
  };
});
export {
  __tla,
  N as u
};
