import { t as J, ad as Q, _ as q, $ as u, b as A, __tla as __tla_0 } from "./index.bb04cb73.js";
import { u as Y } from "./vue-i18n.07fcbeea.js";
import { u as W } from "./vuex.33ea5d58.js";
import { u as tt, __tla as __tla_1 } from "./index.5f74bd60.js";
import { w as $, e as et, a9 as st, o as _, J as at, V as N, c as y, a5 as ot, _ as c, a as s, W as g, u as p, M as z, U as nt, d as ct, ao as lt, l as v, r as l } from "./@vue.b00de3e9.js";
import "./vue-router.c227d4ba.js";
import "./axios.853f16bf.js";
import "./element-plus.53baa8a9.js";
import "./@element-plus.e21ea623.js";
import "./@ctrl.11979b50.js";
import "./dayjs.9abdbee1.js";
import "./clipboard.aaae98d3.js";
import "./@vueuse.eccd744a.js";
import "./lodash-es.e1022fb5.js";
import "./@popperjs.da591b4f.js";
import "./vant.f7b4805b.js";
import "./@vant.f52f09a9.js";
import "./xe-utils.a532b55a.js";
import "./crypto-js.c184c643.js";
import "./decimal.js.2def1975.js";
import "./nprogress.9fc41f77.js";
import "./vconsole.0cfb1d33.js";
import "./perfect-scrollbar.19f80865.js";
import "./@intlify.928cb664.js";
let ee;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e) {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch (e) {
    }
  })()
]).then(async () => {
  const it = "/png/step-1-en.189edc86.png", rt = "/png/step-1-pt.94ca4e06.png", ut = "/png/step-1-zh.41287b55.png", pt = "/png/step-2-en.8b5865e1.png", mt = "/png/step-2-pt.c5e60100.png", dt = "/png/step-2-zh.624bf701.png";
  let ht, _t, gt, vt, ft, kt, wt, yt, It, Tt, St, bt, Dt, xt, Ct, Et;
  ht = {
    class: "task-content"
  };
  _t = {
    class: "task-head"
  };
  gt = [
    "src"
  ];
  vt = {
    class: "task-right"
  };
  ft = {
    class: "task-name"
  };
  kt = {
    class: "task-money"
  };
  wt = {
    class: "task-money-number"
  };
  yt = {
    class: "schedule"
  };
  It = {
    class: "task-img-list"
  };
  Tt = {
    class: "banner-img"
  };
  St = [
    "src"
  ];
  bt = [
    "src"
  ];
  Dt = {
    class: "task-list-content"
  };
  xt = [
    "src"
  ];
  Ct = {
    key: 0,
    class: "time-out-close"
  };
  Et = ct({
    name: "true"
  });
  ee = Object.assign(Et, {
    setup(Lt) {
      const U = lt(() => q(() => import("./task_list.e7c3983d.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/task_list.e7c3983d.js","js/like.c2f99b19.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/task_list.791098c9.css"])), I = 5.25, V = 0.1, F = 4.65, m = Object.freeze({
        stepOne: {
          en: it,
          pt: rt,
          zh: ut
        },
        stepTwo: {
          en: pt,
          pt: mt,
          zh: dt
        }
      }), i = W(), { t: T, locale: B } = Y(), { balanceAmount: S } = tt(), b = v(() => i.state.showFloatPromotionDialog), n = l({}), d = l({}), a = l(null), D = l(null), f = l(""), r = l(null), x = (t) => {
        i.state.showFloatPromotionDialog = t;
      }, C = (t) => {
        const e = Number(String(t != null ? t : 0).replace(/,/g, ""));
        return Number.isFinite(e) ? e : 0;
      }, k = v(() => {
        const t = C(n.value.target), e = t ? Math.min(Math.max(C(S.value) / t, 0), 1) : 0, o = e > 0.85 ? -0.6 : 0.1, w = Math.min(Math.max(I * e + o, V), F);
        return {
          text: "".concat((e * 100).toFixed(2).replace(/\.00$/, ""), "%"),
          width: "".concat((I * e).toFixed(4), "rem"),
          textLeft: "".concat(w, "rem")
        };
      }), K = v(() => {
        const t = String(B.value || "").toLowerCase();
        return t.startsWith("zh") ? "zh" : t.startsWith("pt") ? "pt" : "en";
      }), E = v(() => {
        const t = K.value;
        return {
          stepOne: m.stepOne[t] || m.stepOne.en,
          stepTwo: m.stepTwo[t] || m.stepTwo.en
        };
      }), L = async () => {
        const t = await u.get("/user/work/schedule");
        t.status === "OK" && (n.value = t.data);
      }, R = async () => {
        try {
          const t = await u.get("/user/work/guidePopup");
          if (t.status === "OK") {
            const { taskSettleSys: e = 0, closeTimeout: o = 0, taskSettleImage: w = "", closeDelay: P = 0 } = (t == null ? void 0 : t.data) || {};
            if (e === 1 && (f.value = w), r.value = e || 0, o === 0) {
              a.value = 0;
              return;
            }
            a.value = P, D.value = setInterval(() => {
              a.value = a.value - 1, a.value <= 0 && clearInterval(D.value);
            }, 1e3);
          } else
            a.value = 0, r.value = 0;
        } catch (e) {
          a.value = 0, r.value = 0;
        }
      };
      $(() => {
        var _a;
        return (_a = i.state.accountInfo) == null ? void 0 : _a.id;
      }, (t) => {
        t && L();
      }), $(() => b.value, (t) => {
        t && (a.value = null, R());
      }, {
        immediate: true
      });
      const M = (t) => u.post("/user/tracking/tracking", {
        step: t
      }).catch(() => {
      }), G = () => {
        const t = n.value.taskDomain.split("?"), [e, o] = t;
        return "".concat(n.value.taskDomain.includes("http") ? "" : "https://").concat(e.replace(/\/$/, ""), "/task-center?") + new URLSearchParams({
          hallConfigType: 1,
          reword: d.value.activeAmount,
          source: "game",
          taskId: n.value.taskLogId
        }).toString() + (o ? "&".concat(o) : "");
      }, h = (t) => {
        t && !t.closed && t.close();
      }, X = (t) => {
        const e = G();
        if (t && !t.closed) {
          t.location.href = e;
          return;
        }
        if (A()) {
          window.location.href = e;
          return;
        }
        window.open(e, "_blank");
      }, j = async (t) => {
        try {
          const e = {
            channel: 1,
            accountId: 0,
            amount: d.value.activeAmount
          };
          if (d.value.activeAmount && (await u.post("/trade/account/cashApply", e)).status !== "OK") {
            h(t);
            return;
          }
          i.dispatch("refreshBalance", true), i.dispatch("getNewerUnfinished"), X(t), setTimeout(() => {
            globalVBus.$emit("getSchedule"), x(false);
          }, 3e3);
        } catch (e) {
          h(t);
        }
      }, H = async (t) => {
        try {
          const e = await u.get("/trade/account/list", {
            forCash: 1
          });
          if (e.status === "OK") {
            d.value = e.ext || {}, await j(t);
            return;
          }
          h(t);
        } catch (e) {
          h(t);
        }
      }, Z = () => {
        M(503);
        const t = A() ? window.open("", "_blank") : null;
        H(t);
      }, O = () => {
        x(false), M(502);
      };
      return et(() => {
        J() && L();
      }), (t, e) => {
        const o = st("Dialog");
        return b.value ? (_(), at(o, {
          key: 0,
          zIndexBase: 1e4,
          class: "pinch-hitter-guide",
          width: "6.88rem",
          onInput: O,
          showClose: a.value === 0,
          title: " ",
          modalClose: false,
          onCancel: O
        }, {
          footer: N(() => [
            a.value ? (_(), y("div", Ct, [
              ot(c(a.value) + "s ", 1),
              s("span", null, c(t.$t("taskCenter.closeText")), 1)
            ])) : g("", true)
          ]),
          default: N(() => {
            var _a;
            return [
              s("div", ht, [
                s("div", _t, [
                  s("img", {
                    src: (_a = n.value) == null ? void 0 : _a.levelIcon,
                    class: "task-img"
                  }, null, 8, gt),
                  s("div", vt, [
                    s("div", ft, c(p(T)("pinch_hitter_guide.task_progress")), 1),
                    s("div", kt, [
                      s("span", null, c(p(T)("pinch_hitter_guide.withdrawal_amount")), 1),
                      s("span", wt, c(p(Q)(p(S) || 0)), 1),
                      s("span", null, "/" + c(n.value.target), 1)
                    ]),
                    s("div", yt, [
                      s("div", {
                        class: "schedule-percentage",
                        style: z({
                          width: k.value.width
                        })
                      }, null, 4),
                      s("div", {
                        class: "schedule-text",
                        style: z({
                          left: k.value.textLeft
                        })
                      }, c(k.value.text), 5)
                    ])
                  ])
                ]),
                s("div", It, [
                  s("div", Tt, [
                    f.value && r.value === 1 ? (_(), y("img", {
                      key: 0,
                      src: f.value,
                      class: "img"
                    }, null, 8, St)) : g("", true),
                    r.value === 0 ? (_(), y("img", {
                      key: 1,
                      src: E.value.stepOne,
                      class: "img"
                    }, null, 8, bt)) : g("", true)
                  ]),
                  s("div", Dt, [
                    nt(p(U), {
                      taskList: n.value.taskList,
                      style: {
                        width: "6.55rem"
                      }
                    }, null, 8, [
                      "taskList"
                    ])
                  ])
                ]),
                s("img", {
                  src: E.value.stepTwo,
                  class: "button",
                  onClick: Z
                }, null, 8, xt)
              ])
            ];
          }),
          _: 1
        }, 8, [
          "showClose"
        ])) : g("", true);
      };
    }
  });
});
export {
  __tla,
  ee as default
};
