import { u as r } from "./vuex.33ea5d58.js";
import { k as l, __tla as __tla_0 } from "./index.bb04cb73.js";
import { o as t, c as s, u as d, a as i, W as n } from "./@vue.b00de3e9.js";
import "./vue-router.c227d4ba.js";
import "./axios.853f16bf.js";
import "./element-plus.53baa8a9.js";
import "./@element-plus.e21ea623.js";
import "./@ctrl.11979b50.js";
import "./dayjs.9abdbee1.js";
import "./clipboard.aaae98d3.js";
import "./@vueuse.eccd744a.js";
import "./lodash-es.e1022fb5.js";
import "./@popperjs.da591b4f.js";
import "./vant.f7b4805b.js";
import "./@vant.f52f09a9.js";
import "./vue-i18n.07fcbeea.js";
import "./@intlify.928cb664.js";
import "./xe-utils.a532b55a.js";
import "./crypto-js.c184c643.js";
import "./decimal.js.2def1975.js";
import "./nprogress.9fc41f77.js";
import "./vconsole.0cfb1d33.js";
import "./perfect-scrollbar.19f80865.js";
let L;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e) {
    }
  })()
]).then(async () => {
  let p, m, v, g, _, c, u;
  p = {
    key: 0,
    class: "global-loading"
  };
  m = {
    key: 0,
    class: "loading-overlay"
  };
  v = {
    key: 1,
    class: "spinning-loading-1"
  };
  g = {
    key: 2,
    class: "spinning-loading-2"
  };
  _ = {
    key: 3,
    class: "spinning-loading-3"
  };
  c = {
    key: 4,
    class: "spinning-loading-4"
  };
  u = {
    __name: "index",
    props: {
      loading: {
        type: Boolean,
        default: false
      }
    },
    setup(e) {
      const a = r();
      return (y, o) => e.loading ? (t(), s("div", p, [
        d(a).state.loadAnimation === 0 ? (t(), s("div", m, [
          ...o[0] || (o[0] = [
            i("div", {
              class: "loading-overlay-box"
            }, [
              i("span")
            ], -1)
          ])
        ])) : n("", true),
        d(a).state.loadAnimation === 1 ? (t(), s("div", v, [
          ...o[1] || (o[1] = [
            i("div", {
              class: "loading-inner"
            }, [
              i("div"),
              i("div"),
              i("div"),
              i("div"),
              i("div"),
              i("div"),
              i("div"),
              i("div"),
              i("div")
            ], -1)
          ])
        ])) : n("", true),
        d(a).state.loadAnimation === 2 ? (t(), s("div", g, [
          ...o[2] || (o[2] = [
            i("div", {
              class: "loading-inner"
            }, [
              i("div", {
                class: "base-loading"
              })
            ], -1)
          ])
        ])) : n("", true),
        d(a).state.loadAnimation === 3 ? (t(), s("div", _, [
          ...o[3] || (o[3] = [
            i("div", {
              class: "spinning"
            }, [
              i("div", {
                class: "loading-box"
              }, [
                i("div", {
                  class: "base-loading"
                })
              ])
            ], -1)
          ])
        ])) : n("", true),
        d(a).state.loadAnimation === 4 ? (t(), s("div", c, [
          ...o[4] || (o[4] = [
            i("div", {
              class: "loading-inner"
            }, [
              i("div"),
              i("div")
            ], -1)
          ])
        ])) : n("", true)
      ])) : n("", true);
    }
  };
  L = l(u, [
    [
      "__scopeId",
      "data-v-abe78d17"
    ]
  ]);
});
export {
  __tla,
  L as default
};
