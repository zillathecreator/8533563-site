import { s as a, h as f, j as v, __tla as __tla_0 } from "./index.bb04cb73.js";
import "./@vue.b00de3e9.js";
import "./vue-router.c227d4ba.js";
import "./axios.853f16bf.js";
import "./element-plus.53baa8a9.js";
import "./@element-plus.e21ea623.js";
import "./@ctrl.11979b50.js";
import "./dayjs.9abdbee1.js";
import "./clipboard.aaae98d3.js";
import "./@vueuse.eccd744a.js";
import "./lodash-es.e1022fb5.js";
import "./@popperjs.da591b4f.js";
import "./vant.f7b4805b.js";
import "./@vant.f52f09a9.js";
import "./vue-i18n.07fcbeea.js";
import "./@intlify.928cb664.js";
import "./vuex.33ea5d58.js";
import "./xe-utils.a532b55a.js";
import "./crypto-js.c184c643.js";
import "./decimal.js.2def1975.js";
import "./nprogress.9fc41f77.js";
import "./vconsole.0cfb1d33.js";
import "./perfect-scrollbar.19f80865.js";
Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e) {
    }
  })()
]).then(async () => {
  const c = document, x = window;
  var t = c.documentElement, r = navigator.userAgent.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), n = r ? Math.min(x.devicePixelRatio, 3) : 1, n = window.top === window.self ? n : 1, n = 1, p = 1 / n, w = "orientationchange" in window ? "orientationchange" : "resize";
  t.dataset.dpr = n;
  t.dataset.device = "mobile";
  const h = c.createElement("meta");
  h.name = "viewport";
  h.content = "initial-scale=" + p + ",maximum-scale=" + p + ", minimum-scale=" + p;
  t.firstElementChild.appendChild(h);
  const y = function() {
    let i = t.clientWidth;
    if (r = navigator.userAgent.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), i > 450 ? (t.dataset.deviceNodesktop = 1, a.state.isDesktop = true) : (t.dataset.deviceNodesktop = 0, a.state.isDesktop = false), f.includes(a.state.layoutMode)) {
      t.dataset.skinThemeColor = "panda";
      const e = 486, m = 390, l = 16;
      t.style.setProperty("--lobby__max-width", "486px");
      let s = t.clientWidth;
      s > e && (s = e);
      const o = s / m * l;
      t.style.fontSize = o + "px", t.classList.add(...v().trim().split(/\s+/));
    } else {
      let e;
      if (r && i < 450)
        t.dataset.deviceOs = "ios", a.state.deviceOs = "ios", t.style.setProperty("--lobby__max-width", "467.7661169415292px"), e = 467.7661169415292;
      else if (navigator.userAgent.indexOf("Android") > -1 && i < 450)
        t.dataset.deviceOs = "android", a.state.deviceOs = "android", t.style.setProperty("--lobby__max-width", "467.7661169415292px"), e = 467.7661169415292;
      else if (i === 980 && (r || navigator.userAgent.indexOf("Android") > -1))
        t.style.setProperty("--lobby__max-width", "980px"), e = 980;
      else {
        t.dataset.deviceOs = "windows";
        let o = t.clientHeight;
        const d = 0.56221917;
        t.style.setProperty("--lobby__max-width", o * d > 980 ? "980px" : o * d + "px"), e = o * d > 980 ? 980 : o * d;
      }
      t.style.setProperty("--lobby__vh", t.clientHeight / 100 + "px");
      const m = 750, l = 100;
      i > e && (i = e);
      const s = i * l / m;
      t.style.fontSize = s + "px";
    }
  };
  y();
  c.addEventListener && x.addEventListener(w, y, false);
});
