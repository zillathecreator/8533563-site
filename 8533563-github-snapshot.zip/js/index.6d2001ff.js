import { t as P, $ as R, p, _ as a, __tla as __tla_0 } from "./index.bb04cb73.js";
import { u as J } from "./vuex.33ea5d58.js";
import "./xe-utils.a532b55a.js";
import { u as Y } from "./vue-router.c227d4ba.js";
import { f as Q, g as X, e as Z, F as ee, u as e, o as s, c as te, J as n, W as r, U as oe, L as ae, d as se, r as m, m as re, ao as i, l as u } from "./@vue.b00de3e9.js";
import "./axios.853f16bf.js";
import "./element-plus.53baa8a9.js";
import "./@element-plus.e21ea623.js";
import "./@ctrl.11979b50.js";
import "./dayjs.9abdbee1.js";
import "./clipboard.aaae98d3.js";
import "./@vueuse.eccd744a.js";
import "./lodash-es.e1022fb5.js";
import "./@popperjs.da591b4f.js";
import "./vant.f7b4805b.js";
import "./@vant.f52f09a9.js";
import "./vue-i18n.07fcbeea.js";
import "./@intlify.928cb664.js";
import "./crypto-js.c184c643.js";
import "./decimal.js.2def1975.js";
import "./nprogress.9fc41f77.js";
import "./vconsole.0cfb1d33.js";
import "./perfect-scrollbar.19f80865.js";
let Ie;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e2) {
    }
  })()
]).then(async () => {
  let ie;
  ie = se({
    beforeRouteEnter(L, o, c) {
      c();
    }
  });
  Ie = Object.assign(ie, {
    __name: "index",
    setup(L) {
      const o = J(), c = i(() => a(() => import("./dark.5c3ff18a.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/dark.5c3ff18a.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/img_game_tj_1.e2fa3187.js","js/collect_on.28ab0f00.js","js/collect_off.17e416b3.js","js/maintenance.1b212141.js","js/hammerjs.1014e407.js","js/bookmark_star_2.03c96bfe.js","css/dark.4476658b.css"])), h = i(() => a(() => import("./new_player_task.660b64b2.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/new_player_task.660b64b2.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/img_rw_xr.ab8de304.js","css/new_player_task.0ddf93a9.css"])), T = i(() => a(() => import("./rankings_dialog.57aff102.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/rankings_dialog.57aff102.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/rankings_dialog.637043c0.css"])), V = i(() => a(() => import("./drag_customer_service.60f1a75b.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/drag_customer_service.60f1a75b.js","js/customer_service.4571aa27.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/drag_customer_service.4ab104b3.css"])), A = i(() => a(() => import("./first_recharge_dialog.e65d41a7.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/first_recharge_dialog.e65d41a7.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/img_xf_hand.d472df28.js","js/tx_icon_ljcz.a51b0bf7.js","css/first_recharge_dialog.2f259937.css"])), O = i(() => a(() => import("./unclaimed_dialog.1413c6bb.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/unclaimed_dialog.1413c6bb.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/unclaimed_dialog.271943b4.css"])), I = i(() => a(() => import("./message_dialog.c921f7c5.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/message_dialog.c921f7c5.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/message_dialog.b538711b.css"])), w = i(() => a(() => import("./sign_dialog.fbac668e.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/sign_dialog.fbac668e.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/signatureDialog.65adc82f.css"])), x = i(() => a(() => import("./complex_2.708ef59b.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/complex_2.708ef59b.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/img_vip_v.bac31204.js","js/maintenance.1b212141.js","js/img_game_tj_1.e2fa3187.js","js/hammerjs.1014e407.js","js/index.5f74bd60.js","js/btn_sc_off_2.0912d166.js","css/complex_2.a4fbd66a.css"])), C = i(() => a(() => import("./custom_template_1.b4068d6d.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/custom_template_1.b4068d6d.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/img_game_tj_1.e2fa3187.js","js/collect_on.28ab0f00.js","js/collect_off.17e416b3.js","js/maintenance.1b212141.js","js/hammerjs.1014e407.js","js/bookmark_star_2.03c96bfe.js","css/custom_template_1.79863e72.css"])), M = i(() => a(() => import("./custom_template_2.ac1a28b2.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/custom_template_2.ac1a28b2.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/icon_dtfl_rm_1.f9056bb5.js","js/img_vip_v.bac31204.js","js/wg_dz_16.1debd719.js","js/collect_on.28ab0f00.js","js/collect_off.17e416b3.js","js/maintenance.1b212141.js","js/hammerjs.1014e407.js","js/swiper.e7c9d9a6.js","css/swiper.aa45c171.css","js/index.5f74bd60.js","js/bookmark_star_2.03c96bfe.js","css/custom_template_2.6f0330e0.css"])), S = i(() => a(() => import("./complex_4.d86be1ef.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/complex_4.d86be1ef.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/img_game_tj_1.e2fa3187.js","js/collect_on.28ab0f00.js","js/collect_off.17e416b3.js","js/maintenance.1b212141.js","js/hammerjs.1014e407.js","js/bookmark_star_2.03c96bfe.js","css/complex_4.90ae9ef0.css"])), B = i(() => a(() => import("./complex_5.1a78cf8a.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/complex_5.1a78cf8a.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/img_game_tj_1.e2fa3187.js","js/collect_on.28ab0f00.js","js/collect_off.17e416b3.js","js/maintenance_5.aa237f02.js","js/hammerjs.1014e407.js","js/bookmark_star_2.03c96bfe.js","css/complex_5.3cf34fbe.css"])), U = i(() => a(() => import("./complex_6.ee06785d.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/complex_6.ee06785d.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/img_game_tj_1.e2fa3187.js","js/collect_on.28ab0f00.js","js/collect_off.17e416b3.js","js/maintenance.1b212141.js","js/hammerjs.1014e407.js","js/bookmark_star_2.03c96bfe.js","css/complex_6.126ddfad.css"])), b = i(() => a(() => import("./complex_7.3b6c41bd.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/complex_7.3b6c41bd.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/img_game_tj_1.e2fa3187.js","js/collect_on_7.72d4a742.js","js/collect_on.28ab0f00.js","js/collect_off_7.67443dd1.js","js/collect_off.17e416b3.js","js/maintenance_7.a9c17d1f.js","js/hammerjs.1014e407.js","js/bookmark_star_2.03c96bfe.js","js/collect_on_7.5565173d.js","css/complex_7.809227e1.css"])), N = i(() => a(() => import("./complex_8.32084a95.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/complex_8.32084a95.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/img_game_tj_1.e2fa3187.js","js/collect_on.28ab0f00.js","js/collect_off.17e416b3.js","js/maintenance.1b212141.js","js/hammerjs.1014e407.js","js/bookmark_star_2.03c96bfe.js","css/complex_8.1b609842.css"])), q = i(() => a(() => import("./digital_version1.048b0cff.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/digital_version1.048b0cff.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/tab-scroll-img.92c90ae3.js","js/img_game_tj_1.e2fa3187.js","js/collect_on.28ab0f00.js","js/collect_off.17e416b3.js","js/maintenance.1b212141.js","js/hammerjs.1014e407.js","js/bookmark_star_2.03c96bfe.js","css/digital_version1.64bf710d.css"])), F = i(() => a(() => import("./pinch_hitter_guide_right.b8b89259.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/pinch_hitter_guide_right.b8b89259.js","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/@vue.b00de3e9.js","js/index.bb04cb73.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/index.5f74bd60.js","css/pinch_hitter_guide_right.1c4108dc.css"])), l = Y(), d = m(false), f = re([]), y = m(null), v = m(0), E = m(true), k = (t) => {
        requestAnimationFrame(() => {
          setTimeout(t, 0);
        });
      };
      let $ = u(() => {
        let t = false;
        return o.state.popStep === 3 && (l.name !== "index" ? t = false : o.state.messageInfo ? t = true : (t = false, o.state.popStep = 4)), t && p("message"), t;
      }), G = u(() => {
        let t = false;
        return o.state.popStep === 6 ? t = true : t = false, t && p("sign"), t;
      }), H = u(() => {
        let t = false;
        return o.state.popStep === 7 ? t = true : t = false, t && p("firstRecharge"), t;
      }), j = u(() => {
        if (!P())
          return false;
      }), z = u(() => {
        let t = false;
        return o.state.popStep === 8 ? t = true : t = false, o.state.showNewPlayerTaskPop && (t = true), t && p("newPlayer"), t;
      }), K = u(() => {
        let t = false;
        return o.state.popStep === 9 ? t = true : t = false, t && p("unclaimed"), t;
      });
      const g = () => {
        P() && (f.length = 0, R.get("/user/promotion/rankPop").then((t) => {
          t && t.status === "OK" && t.data && (d.value = true, f.push(...t.data));
        }));
      }, W = () => {
        R.get("/game/game/jackpotLogs").then((t) => {
          t.status === "OK" && (o.state.winnerData = t);
        });
      };
      return Q(() => {
        let t = document.querySelector("#app .home-page-scroll");
        t && (t.scrollTop = v.value), k(g);
      }), X(() => {
        let t = document.querySelector("#app .home-page-scroll");
        t && (v.value = t.scrollTop);
      }), Z(() => {
        o.dispatch("getBannerList"), k(W), globalVBus.$on("getRankPop", g);
      }), ee(() => {
        globalVBus.$off("getRankPop", g);
      }), (t, _) => e(o).state.loadedCss ? (s(), te("div", {
        key: 0,
        class: ae([
          "home-page-box",
          [
            {
              squire: e(o).state.homeGameLayout.imageType === 1
            },
            {
              row4: e(o).state.homeGameLayout.rowSize === 4
            }
          ]
        ]),
        ref_key: "homePageRef",
        ref: y
      }, [
        e(o).state.layoutMode === 7 ? (s(), n(e(x), {
          key: 0
        })) : r("", true),
        [
          3,
          8
        ].includes(e(o).state.layoutMode) ? (s(), n(e(c), {
          key: 1
        })) : r("", true),
        e(o).state.layoutMode === 9 ? (s(), n(e(C), {
          key: 2
        })) : r("", true),
        e(o).state.layoutMode === 16 ? (s(), n(e(M), {
          key: 3
        })) : r("", true),
        e(o).state.layoutMode === 10 ? (s(), n(e(S), {
          key: 4
        })) : r("", true),
        e(o).state.layoutMode === 11 ? (s(), n(e(B), {
          key: 5
        })) : r("", true),
        e(o).state.layoutMode === 12 ? (s(), n(e(U), {
          key: 6
        })) : r("", true),
        e(o).state.layoutMode === 13 ? (s(), n(e(b), {
          key: 7
        })) : r("", true),
        e(o).state.layoutMode === 14 ? (s(), n(e(N), {
          key: 8
        })) : r("", true),
        e(o).state.layoutMode === 15 ? (s(), n(e(q), {
          key: 9
        })) : r("", true),
        e(z) && e(l).name === "index" && e(o).state.popDialogList[0] === "newPlayer" ? (s(), n(e(h), {
          key: 10
        })) : r("", true),
        e(j) ? (s(), n(e(T), {
          key: 11,
          value: d.value,
          "onUpdate:value": _[0] || (_[0] = (D) => d.value = D),
          info: f
        }, null, 8, [
          "value",
          "info"
        ])) : r("", true),
        e(o).state.customerConfig.ocs ? (s(), n(e(V), {
          key: 12,
          parentDom: y.value
        }, null, 8, [
          "parentDom"
        ])) : r("", true),
        e(H) && e(l).name === "index" && e(o).state.popDialogList[0] == "firstRecharge" ? (s(), n(e(A), {
          key: 13
        })) : r("", true),
        e(K) && e(l).name === "index" && e(o).state.popDialogList[0] == "unclaimed" ? (s(), n(e(O), {
          key: 14
        })) : r("", true),
        e($) && e(l).name == "index" && e(o).state.popDialogList[0] === "message" ? (s(), n(e(I), {
          key: 15,
          value: E.value,
          "onUpdate:value": _[1] || (_[1] = (D) => E.value = D)
        }, null, 8, [
          "value"
        ])) : r("", true),
        e(G) && e(l).name === "index" && e(o).state.popDialogList[0] == "sign" ? (s(), n(e(w), {
          key: 16
        })) : r("", true),
        oe(e(F))
      ], 2)) : r("", true);
    }
  });
});
export {
  __tla,
  Ie as default
};
