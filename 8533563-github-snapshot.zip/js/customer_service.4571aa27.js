const e = "/png/customer_service.884a62e6.png";
export {
  e as _
};
