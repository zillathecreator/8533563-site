const i = { addEventListeners(n, e, r) {
  for (let t = 0, a = e.length; t < a; t++)
    n.addEventListener(e[t], r, { passive: false });
}, removeEventListeners(n, e, r) {
  for (let t = 0, a = e.length; t < a; t++)
    n.removeEventListener(e[t], r, { passive: false });
}, emitEvent: function(n, e, r) {
  if (n.componentInstance)
    n.componentInstance.$emit(e, r);
  else {
    let t = new window.CustomEvent(e, { detail: r });
    n.el.dispatchEvent(t);
  }
} }, h = ["mousedown", "touchstart"], g = ["mousemove", "touchmove"], y = ["mouseup", "touchend"], b = function(n, e, r) {
  let t = n, a = true, m = window;
  typeof e.value == "boolean" ? a = e.value : typeof e.value == "object" ? (typeof e.value.target == "string" ? (t = n.querySelector(e.value.target), t || console.error("There is no element with the current target value.")) : typeof e.value.target < "u" && console.error("The parameter \"target\" should be either 'undefined' or 'string'."), typeof e.value.container == "string" ? (m = document.querySelector(e.value.container), m || console.error("There is no element with the current container value.")) : typeof e.value.container < "u" && console.error("The parameter \"container\" should be be either 'undefined' or 'string'."), typeof e.value.active == "boolean" ? a = e.value.active : typeof e.value.active < "u" && console.error("The parameter \"active\" value should be either 'undefined', 'true' or 'false'.")) : typeof e.value < "u" && console.error("The passed value should be either 'undefined', 'true' or 'false' or 'object'.");
  const E = function(u, f) {
    m === window ? window.scrollBy(u, f) : (m.scrollLeft += u, m.scrollTop += f);
  }, L = function() {
    let u, f, w, v = false;
    t.md = function(o) {
      const c = o instanceof window.MouseEvent, l = c ? o.pageX : o.touches[0].pageX, s = c ? o.pageY : o.touches[0].pageY, d = document.elementFromPoint(l - window.pageXOffset, s - window.pageYOffset), p = e.arg === "nochilddrag", X = e.modifiers.noleft, Y = e.modifiers.noright, S = e.modifiers.nomiddle, x = e.modifiers.noback, O = e.modifiers.noforward, D = e.arg === "firstchilddrag", V = d === t, C = d === t.firstChild, I = p ? typeof (d == null ? void 0 : d.dataset.dragscroll) < "u" : typeof (d == null ? void 0 : d.dataset.noDragscroll) > "u";
      if (!(!V && (!I || D && !C)) && !(o.button === 0 && X)) {
        if (o.button === 1 && S || o.button === 2 && Y || o.button === 3 && x || o.button === 4 && O)
          return;
        w = 1, u = c ? o.clientX : o.touches[0].clientX, f = c ? o.clientY : o.touches[0].clientY;
      }
    }, t.mu = function(o) {
      w = 0, v && i.emitEvent(r, "dragscrollend"), v = false;
    }, t.mm = function(o) {
      const c = o instanceof window.MouseEvent;
      let l, s;
      if (w) {
        o.preventDefault(), v || i.emitEvent(r, "dragscrollstart"), v = true;
        const d = t.scrollLeft + t.clientWidth >= t.scrollWidth || t.scrollLeft === 0, p = t.scrollTop + t.clientHeight >= t.scrollHeight || t.scrollTop === 0;
        l = -u + (u = c ? o.clientX : o.touches[0].clientX), s = -f + (f = c ? o.clientY : o.touches[0].clientY), e.modifiers.pass ? (t.scrollLeft -= e.modifiers.y ? -0 : l, t.scrollTop -= e.modifiers.x ? -0 : s, t === document.body && (t.scrollLeft -= e.modifiers.y ? -0 : l, t.scrollTop -= e.modifiers.x ? -0 : s), (d || e.modifiers.y) && E(-l, 0), (p || e.modifiers.x) && E(0, -s)) : (e.modifiers.x && (s = -0), e.modifiers.y && (l = -0), t.scrollLeft -= l, t.scrollTop -= s, t === document.body && (t.scrollLeft -= l, t.scrollTop -= s)), i.emitEvent(r, "dragscrollmove", { deltaX: -l, deltaY: -s });
      }
    }, i.addEventListeners(t, h, t.md), i.addEventListeners(window, y, t.mu), i.addEventListeners(window, g, t.mm);
  };
  a ? document.readyState === "complete" ? L() : window.addEventListener("load", L) : (i.removeEventListeners(t, h, t.md), i.removeEventListeners(window, y, t.mu), i.removeEventListeners(window, g, t.mm));
}, M = (n) => {
  const e = n;
  i.removeEventListeners(e, h, e.md), i.removeEventListeners(window, y, e.mu), i.removeEventListeners(window, g, e.mm);
}, T = { mounted: (n, e, r) => b(n, e, r), updated: (n, e, r) => {
  JSON.stringify(e.value) !== JSON.stringify(e.oldValue) && b(n, e, r);
}, unmounted: (n) => M(n) }, N = { install(n) {
  n.directive("dragscroll", T);
} };
typeof window < "u" && window.Vue && (window.VueDragscroll = T);
export {
  N as default,
  T as dragscroll
};
