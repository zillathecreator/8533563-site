import { _ as P, $ as j, av as X, d as q, __tla as __tla_0 } from "./index.bb04cb73.js";
import { C as z } from "./vant.f7b4805b.js";
import { u as F } from "./vuex.33ea5d58.js";
import { b as K } from "./vue-router.c227d4ba.js";
import { u as G } from "./vue-i18n.07fcbeea.js";
import { X as Q } from "./xe-utils.a532b55a.js";
import { e as Y, a9 as Z, o as i, J as _, V as f, a as l, L as p, c, R as b, ab as x, W as g, U as w, a5 as ee, _ as te, u as se, ao as oe, r as v, m as ae, l as L } from "./@vue.b00de3e9.js";
import "./axios.853f16bf.js";
import "./element-plus.53baa8a9.js";
import "./@element-plus.e21ea623.js";
import "./@ctrl.11979b50.js";
import "./dayjs.9abdbee1.js";
import "./clipboard.aaae98d3.js";
import "./@vueuse.eccd744a.js";
import "./lodash-es.e1022fb5.js";
import "./@popperjs.da591b4f.js";
import "./crypto-js.c184c643.js";
import "./decimal.js.2def1975.js";
import "./nprogress.9fc41f77.js";
import "./vconsole.0cfb1d33.js";
import "./perfect-scrollbar.19f80865.js";
import "./@vant.f52f09a9.js";
import "./@intlify.928cb664.js";
let Oe;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e) {
    }
  })()
]).then(async () => {
  let ne, le, ie, re, de, ce, ue, me, pe, ge, ve;
  ne = {
    class: "wg-message-box"
  };
  le = {
    key: 0,
    class: "tabs-wrap"
  };
  ie = [
    "onClick"
  ];
  re = {
    class: "tabsLabel"
  };
  de = [
    "innerHTML"
  ];
  ce = {
    class: "tabs-content"
  };
  ue = {
    class: "content"
  };
  me = [
    "innerHTML"
  ];
  pe = [
    "src",
    "onClick"
  ];
  ge = {
    key: 0,
    class: "agreedBox"
  };
  ve = {
    class: "agreedWrap"
  };
  Oe = {
    __name: "message_dialog",
    props: [
      "value",
      "detail",
      "ext"
    ],
    emits: [
      "update:value"
    ],
    setup(N, { emit: D }) {
      const B = oe(() => P(() => import("./index.bb04cb73.js").then(async (m) => {
        await m.__tla;
        return m;
      }).then((t) => t.cg), ["js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css"])), d = F(), R = D, V = N;
      K(), G();
      const W = v(null), u = v(0), C = v(null), I = v(null), n = v(), r = ae([]), y = v(false), k = L({
        get() {
          return V.value;
        },
        set(t) {
          R("update:value", t);
        }
      }), A = L(() => d.state.messageExt === 2 ? "tb" : d.state.messageExt === 3 ? "bt" : d.state.messageExt === 1 ? "lr" : "rl"), J = (t) => {
        var _a;
        t ? (n.value.notShowToday = true, n.value.todayEndTime = new Date(Q.getWhatDay(/* @__PURE__ */ new Date(), 0, "last")).getTime()) : (n.value.notShowToday = false, n.value.todayEndTime = 0);
        let o = (_a = JSON.parse(localStorage.getItem("messageList"))) == null ? void 0 : _a.list;
        o.forEach((a) => {
          a.msgId === n.value.msgId && (a.notShowToday = n.value.notShowToday, a.todayEndTime = n.value.todayEndTime);
        }), localStorage.setItem("messageList", JSON.stringify({
          list: o,
          time: (/* @__PURE__ */ new Date()).getTime()
        }));
      }, E = (t) => {
        j.get("/user/msg/view", {
          msgId: t.msgId,
          id: t.id
        }).then((o) => {
          o.status === "OK" && (t.status = 1, d.dispatch("getAllBadges"));
        });
      }, h = (t) => {
        u.value = t, n.value = r[t], n.value.status = 1, E(n.value), y.value = n.value.notShowToday;
        const o = C.value, a = I.value, s = o.clientWidth;
        if (o.scrollWidth <= s)
          return;
        const m = a[t], H = m.offsetLeft + m.offsetWidth / 2 - s / 2;
        o.scrollTo({
          left: H,
          behavior: "smooth"
        });
      }, M = () => {
        u.value--, h(u.value);
      }, O = () => {
        u.value++, h(u.value);
      }, U = (t) => {
        t.jump && (k.value = false, d.state.popStep = 4, X(t));
      }, T = () => {
        q("message"), d.state.popStep === 3 && (d.state.popStep = 4);
      };
      Y(() => {
        $();
      });
      const $ = () => {
        var _a;
        let t = d.state.messageInfo, o = (_a = JSON.parse(localStorage.getItem("messageList"))) == null ? void 0 : _a.list, a = (/* @__PURE__ */ new Date()).getTime();
        t.forEach((s) => {
          if (s.notShowToday = false, d.state.accountInfo.id && (s.userId = d.state.accountInfo.id), s.popStartTime > a || s.popEndTime < a)
            return;
          if (s.popUp === 5 && (s.sysTodayEndTime = a + 24 * 60 * 60 * 1e3), !o)
            return r.push(s);
          let e = o.find((m) => m.msgId == s.msgId);
          if (e) {
            if (e.todayEndTime && (s.todayEndTime = e.todayEndTime, e.todayEndTime > a))
              return s.notShowToday = true;
            if (e.popUp === 5) {
              if (d.state.accountInfo.id) {
                if (d.state.accountInfo.id == e.userId && (s.sysTodayEndTime = e.sysTodayEndTime, e.sysTodayEndTime > a))
                  return;
              } else if (!e.userId && (s.sysTodayEndTime = e.sysTodayEndTime, e.sysTodayEndTime > a))
                return;
            }
            if (e.popUp === 1)
              return;
            r.push(s);
          } else
            r.push(s);
        }), localStorage.setItem("messageList", JSON.stringify({
          list: t,
          time: (/* @__PURE__ */ new Date()).getTime()
        })), r.length ? (n.value = r[0], E(n.value)) : T();
      };
      return (t, o) => {
        const a = Z("svg-icon"), s = z;
        return k.value && r.length ? (i(), _(se(B), {
          key: 0,
          class: p([
            "wg-message-dialog",
            {
              newBtm: n.value && n.value.allowNotRemind
            }
          ]),
          ref_key: "dialogRef",
          ref: W,
          onInput: T,
          title: "''",
          onCancel: T
        }, {
          title: f(() => [
            ...o[1] || (o[1] = [])
          ]),
          footer: f(() => [
            ...o[2] || (o[2] = [])
          ]),
          default: f(() => [
            l("div", ne, [
              l("div", {
                class: p([
                  "tabs",
                  A.value
                ])
              }, [
                r.length > 1 ? (i(), c("div", le, [
                  l("div", {
                    class: "scrollBox",
                    ref_key: "tabScroll",
                    ref: C
                  }, [
                    (i(true), c(b, null, x(r, (e, m) => (i(), c("div", {
                      class: p([
                        "tab",
                        {
                          active: u.value == m
                        }
                      ]),
                      ref_for: true,
                      ref_key: "tabItems",
                      ref: I
                    }, [
                      l("div", {
                        class: "tabsItem",
                        onClick: (S) => h(m)
                      }, [
                        l("div", {
                          class: p([
                            "icon",
                            {
                              unRead: e.status == 0
                            }
                          ])
                        }, [
                          l("i", null, [
                            e.type === 1 ? (i(), _(a, {
                              key: 0,
                              iconClass: "wg_pop_msg_1"
                            })) : e.type === 2 ? (i(), _(a, {
                              key: 1,
                              iconClass: "wg_pop_msg_2"
                            })) : e.type === 4 ? (i(), _(a, {
                              key: 2,
                              iconClass: "wg_pop_msg_3"
                            })) : g("", true)
                          ])
                        ], 2),
                        l("div", re, [
                          l("div", {
                            class: "titleContent",
                            innerHTML: e.title
                          }, null, 8, de)
                        ])
                      ], 8, ie)
                    ], 2))), 256))
                  ], 512)
                ])) : g("", true),
                l("div", ce, [
                  (i(true), c(b, null, x(r, (e, m) => (i(), c("div", {
                    class: p([
                      "ui-tab__pane",
                      {
                        active: u.value == m
                      }
                    ])
                  }, [
                    l("div", {
                      class: p([
                        "item",
                        {
                          miniItem: r.length !== 1
                        }
                      ])
                    }, [
                      l("div", ue, [
                        l("div", {
                          class: p([
                            "textBox",
                            {
                              hasImg: e.type !== 1 && e.type !== 2
                            }
                          ])
                        }, [
                          e.type === 1 || e.type === 2 ? (i(), c("div", {
                            key: 0,
                            class: "text",
                            innerHTML: e.content
                          }, null, 8, me)) : (i(), c("img", {
                            key: 1,
                            src: e.image,
                            alt: "",
                            onClick: (S) => U(e)
                          }, null, 8, pe))
                        ], 2)
                      ])
                    ], 2)
                  ], 2))), 256)),
                  u.value != 0 ? (i(), c("div", {
                    key: 0,
                    class: "leftArrow arrow",
                    onClick: M
                  }, [
                    l("i", null, [
                      w(a, {
                        iconClass: "wg_pop_msg_arrow"
                      })
                    ])
                  ])) : g("", true),
                  r.length > 1 && u.value !== r.length - 1 ? (i(), c("div", {
                    key: 1,
                    class: "rightArrow arrow",
                    onClick: O
                  }, [
                    l("i", null, [
                      w(a, {
                        iconClass: "wg_pop_msg_arrow"
                      })
                    ])
                  ])) : g("", true)
                ])
              ], 2)
            ]),
            n.value && n.value.allowNotRemind ? (i(), c("div", ge, [
              l("div", ve, [
                w(s, {
                  modelValue: y.value,
                  "onUpdate:modelValue": o[0] || (o[0] = (e) => y.value = e),
                  onChange: J,
                  shape: "square"
                }, {
                  default: f(() => [
                    ee(te(t.$t("common.no_remind")), 1)
                  ]),
                  _: 1
                }, 8, [
                  "modelValue"
                ])
              ])
            ])) : g("", true)
          ]),
          _: 1
        }, 8, [
          "class"
        ])) : g("", true);
      };
    }
  };
});
export {
  __tla,
  Oe as default
};
