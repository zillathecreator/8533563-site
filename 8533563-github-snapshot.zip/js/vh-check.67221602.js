import { a as _, c as k } from "./clipboard.aaae98d3.js";
function z(u, d) {
  for (var r = 0; r < d.length; r++) {
    const o = d[r];
    if (typeof o != "string" && !Array.isArray(o)) {
      for (const i in o)
        if (i !== "default" && !(i in u)) {
          const c = Object.getOwnPropertyDescriptor(o, i);
          c && Object.defineProperty(u, i, c.get ? c : { enumerable: true, get: () => o[i] });
        }
    }
  }
  return Object.freeze(Object.defineProperty(u, Symbol.toStringTag, { value: "Module" }));
}
var E = { exports: {} };
(function(u, d) {
  (function(r, o) {
    u.exports = o();
  })(k, function() {
    /*! *****************************************************************************
    	    Copyright (c) Microsoft Corporation. All rights reserved.
    	    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    	    this file except in compliance with the License. You may obtain a copy of the
    	    License at http://www.apache.org/licenses/LICENSE-2.0
    
    	    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    	    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    	    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    	    MERCHANTABLITY OR NON-INFRINGEMENT.
    
    	    See the Apache Version 2.0 License for specific language governing permissions
    	    and limitations under the License.
    	    ***************************************************************************** */
    var r = function() {
      return r = Object.assign || function(t) {
        for (var n, a = 1, s = arguments.length; a < s; a++) {
          n = arguments[a];
          for (var p in n)
            Object.prototype.hasOwnProperty.call(n, p) && (t[p] = n[p]);
        }
        return t;
      }, r.apply(this, arguments);
    };
    function o() {
      var e = document.createElement("div");
      return e.style.cssText = "position: fixed; top: 0; height: 100vh; pointer-events: none;", document.documentElement.insertBefore(e, document.documentElement.firstChild), e;
    }
    function i(e) {
      document.documentElement.removeChild(e);
    }
    function c() {
      var e = o(), t = window.innerHeight, n = e.offsetHeight, a = n - t;
      return i(e), { vh: n, windowHeight: t, offset: a, isNeeded: a !== 0, value: 0 };
    }
    function v() {
    }
    function g() {
      var e = c();
      return e.value = e.offset, e;
    }
    function j() {
      var e = c();
      return e.value = e.windowHeight * 0.01, e;
    }
    var N = Object.freeze({ noop: v, computeDifference: g, redefineVhUnit: j });
    function b(e) {
      return typeof e == "string" && e.length > 0;
    }
    function C(e) {
      return typeof e == "function";
    }
    var m = Object.freeze({ cssVarName: "vh-offset", redefineVh: false, method: g, force: false, bind: true, updateOnTouch: false, onUpdate: v });
    function x(e) {
      if (b(e))
        return r({}, m, { cssVarName: e });
      if (typeof e != "object")
        return m;
      var t = { force: e.force === true, bind: e.bind !== false, updateOnTouch: e.updateOnTouch === true, onUpdate: C(e.onUpdate) ? e.onUpdate : v }, n = e.redefineVh === true;
      return t.method = N[n ? "redefineVhUnit" : "computeDifference"], t.cssVarName = b(e.cssVarName) ? e.cssVarName : n ? "vh" : m.cssVarName, t;
    }
    var h = false, l = [];
    try {
      var f = Object.defineProperty({}, "passive", { get: function() {
        h = true;
      } });
      window.addEventListener("test", f, f), window.removeEventListener("test", f, f);
    } catch (e) {
      h = false;
    }
    function w(e, t) {
      l.push({ eventName: e, callback: t }), window.addEventListener(e, t, h ? { passive: true } : false);
    }
    function T() {
      l.forEach(function(e) {
        window.removeEventListener(e.eventName, e.callback);
      }), l = [];
    }
    function O(e, t) {
      document.documentElement.style.setProperty("--" + e, t.value + "px");
    }
    function y(e, t) {
      return r({}, e, { unbind: T, recompute: t.method });
    }
    function U(e) {
      var t = Object.freeze(x(e)), n = y(t.method(), t);
      if (!n.isNeeded && !t.force || (O(t.cssVarName, n), t.onUpdate(n), !t.bind))
        return n;
      function a() {
        window.requestAnimationFrame(function() {
          var s = t.method();
          O(t.cssVarName, s), t.onUpdate(y(s, t));
        });
      }
      return n.unbind(), w("orientationchange", a), t.updateOnTouch && w("touchmove", a), n;
    }
    return U;
  });
})(E);
var V = E.exports;
const L = _(V), D = z({ __proto__: null, default: L }, [V]);
export {
  D as v
};
