const a = "/png/bookmark_star_2.0caade9f.png?index=";
export {
  a as b
};
