import { u as S, P as $, U as M, t as w, $ as y, g as x, a as Ze, _ as i, B as F, p as L, i as Xe, b as j, c as H, __tla as __tla_0 } from "./index.bb04cb73.js";
import { w as E, e as et, H as tt, a9 as ot, o as r, J as l, V as O, u as t, c as at, L as st, a as D, M as J, U as c, Y as it, ap as nt, a2 as rt, W as u, O as lt, Z as ut, ao as n, r as m, m as dt, l as _ } from "./@vue.b00de3e9.js";
import { u as pt } from "./vuex.33ea5d58.js";
import { u as gt, b as ct } from "./vue-router.c227d4ba.js";
import { a as mt, p as _t, e as K, i as vt, b as ft } from "./element-plus.53baa8a9.js";
import "./dayjs.9abdbee1.js";
import { L as P, s as wt, a as q, b as ht, c as Et } from "./vant.f7b4805b.js";
import "./xe-utils.a532b55a.js";
import { u as Dt } from "./vue-i18n.07fcbeea.js";
import { c as Pt, h as It, __tla as __tla_1 } from "./app_common.14116141.js";
import "./axios.853f16bf.js";
import "./crypto-js.c184c643.js";
import "./clipboard.aaae98d3.js";
import "./decimal.js.2def1975.js";
import "./nprogress.9fc41f77.js";
import "./vconsole.0cfb1d33.js";
import "./perfect-scrollbar.19f80865.js";
import "./@element-plus.e21ea623.js";
import "./@ctrl.11979b50.js";
import "./@vueuse.eccd744a.js";
import "./lodash-es.e1022fb5.js";
import "./@popperjs.da591b4f.js";
import "./@vant.f52f09a9.js";
import "./@intlify.928cb664.js";
let Zt;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e) {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch (e) {
    }
  })()
]).then(async () => {
  let yt, At;
  yt = {
    class: "main-content"
  };
  At = {
    class: "scroll-wrapper"
  };
  Zt = {
    __name: "App_wg",
    setup(Rt) {
      const p = gt(), v = ct(), { locale: z, t: Tt } = Dt(), Q = n(() => i(() => import("./index.2e440740.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index.2e440740.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/comm_logo_bg.ac9483e5.js","js/circular_close.952b11ce.js","js/login_tab.7a7f3d23.js","js/encrypt_password.992066bd.js","js/vue3-puzzle-vcode.400183d9.js","css/vue3-puzzle-vcode.bf187446.css","js/index.e72a0941.js","js/app_common.14116141.js","js/mix_input.f1c89a38.js","js/comm_icon_tip1.8f759eaa.js","css/mix_input.0794ce03.css","js/code_input.82e09e36.js","css/code_input.75fa1312.css","js/pwd_input.440ec920.js","css/pwd_input.5a3601cb.css","js/phone_input.845d79fd.js","css/phone_input.bb0355d5.css","css/login_tab.f949f825.css","css/index.2c0539cb.css"])), Y = n(() => i(() => import("./index.b8899cf0.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index.b8899cf0.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css"])), Z = n(() => i(() => import("./register_pwd.0ef0e718.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/register_pwd.0ef0e718.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/circular_close.952b11ce.js","js/encrypt_password.992066bd.js","js/vue3-puzzle-vcode.400183d9.js","css/vue3-puzzle-vcode.bf187446.css","js/index.e72a0941.js","js/app_common.14116141.js","css/register_pwd.427e4523.css"])), X = n(() => i(() => import("./index.bc7832f3.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index.bc7832f3.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/index.4c252ee2.css"])), ee = n(() => i(() => import("./reset_pwd.25a61442.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/reset_pwd.25a61442.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/comm_icon_tip1.8f759eaa.js","js/encrypt_password.992066bd.js","js/vue3-puzzle-vcode.400183d9.js","css/vue3-puzzle-vcode.bf187446.css","js/index.e72a0941.js","css/reset_pwd.619750aa.css"])), te = n(() => i(() => import("./confirm.62b5e314.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/confirm.62b5e314.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/confirm.42027ad5.css"])), oe = n(() => i(() => import("./index.d3f90ed3.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index.d3f90ed3.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/circular_close.952b11ce.js","css/index.4e044013.css"])), ae = n(() => i(() => import("./index.5f92dda7.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index.5f92dda7.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/index.53686d5a.css"])), se = n(() => i(() => import("./index.ca7747f9.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index.ca7747f9.js","js/@vue.b00de3e9.js","js/hand.6c197bb5.js","js/index.bb04cb73.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/index.26bc09ef.css"])), ie = n(() => i(() => import("./index.eb7908ac.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index.eb7908ac.js","js/@vue.b00de3e9.js","js/index.bb04cb73.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/index.0db484c7.css"])), ne = n(() => i(() => import("./index.89d10a9c.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index.89d10a9c.js","js/@vue.b00de3e9.js","js/index.bb04cb73.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/index.efaabe70.css"])), re = n(() => i(() => import("./index.2a1a42fc.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index.2a1a42fc.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css"])), le = n(() => i(() => import("./join_dialog.ac120fd2.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }).then((o) => o.j), ["js/join_dialog.ac120fd2.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/xkyd_shou.60700d40.js","js/avatar_temp.407804fb.js","js/circular_close.952b11ce.js","js/lottie-web.691429cd.js","css/join_dialog.758f9635.css"])), ue = n(() => i(() => import("./register_success_dialog.454d5e76.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/register_success_dialog.454d5e76.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/icon_zccgtc_cz.afbd43ed.js","css/register_success_dialog.09d17c11.css"])), de = n(() => i(() => import("./index.418b5537.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index.418b5537.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/index.58e9f836.css"])), pe = n(() => i(() => import("./index_popup.a8083de8.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index_popup.a8083de8.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/index_popup.068d7308.css"])), ge = n(() => i(() => import("./pay_success_dialog.2a8f6078.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/pay_success_dialog.2a8f6078.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/success.65a38cdf.js","js/usdt.c352bfdb.js","js/USDC.a2ba449c.js","css/pay_success_dialog.22b9c6dd.css"])), ce = n(() => i(() => import("./index.9ecb6f05.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index.9ecb6f05.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/comm_icon_zdwm_title.cda19b67.js","js/app_icon.48558148.js","js/circular_close.952b11ce.js","js/file-saver.cfd1b088.js","js/html-to-image.90ce8487.js","css/index.ee50a55f.css"])), me = n(() => i(() => import("./index.6127333f.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index.6127333f.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/index.0cb897a9.css"])), _e = n(() => i(() => import("./index.0659ea05.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index.0659ea05.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/comm_icon_tip1.8f759eaa.js","js/encrypt_password.992066bd.js","css/index.f8e8961e.css"])), ve = n(() => i(() => import("./index.082c5487.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index.082c5487.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/dark_pix.d25c516e.js","js/dark_usdt.2168c616.js","js/record_transfer.d1509971.js","css/index.26c20e63.css"])), fe = n(() => i(() => import("./index.533bbec4.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index.533bbec4.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/index.7bfe6299.css"])), we = n(() => i(() => import("./index.e8502447.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index.e8502447.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/index.8ed2907b.css"])), he = n(() => i(() => import("./index.54fb1c81.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index.54fb1c81.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/zalo.9281e435.js","js/comm_icon_tip1.57d2198c.js","css/index.b001e3c9.css"])), Ee = n(() => i(() => import("./index.4afb10b3.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index.4afb10b3.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/icon_wd_ggyz_b.846426f7.js","js/comm_icon_tip1.8f759eaa.js","js/qrcode.24b1e9bf.js","js/dijkstrajs.f906a09e.js","css/index.f63304a5.css"])), De = n(() => i(() => import("./index.6d0c387f.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index.6d0c387f.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/index.42b9889c.css"])), Pe = n(() => i(() => import("./index.6005db2f.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index.6005db2f.js","js/vant.f7b4805b.js","js/@vue.b00de3e9.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/float_box2.c6e3f09a.js","js/comm_btn_top.bd498d23.js","js/index.bb04cb73.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/index.c7facdff.css"])), Ie = n(() => i(() => import("./winningToastContainer.0fd8c688.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/winningToastContainer.0fd8c688.js","js/useWinningToast.fa7f6a2b.js","js/@vue.b00de3e9.js","js/cry.d9cd19a0.js","js/xyzp_icon_gglq.56b3b0c7.js","js/index.bb04cb73.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/winningToastContainer.ebfdd6b4.css"])), ye = n(() => i(() => import("./index.f5743f84.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index.f5743f84.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/index.5b75fd5c.css"])), Ae = n(() => i(() => import("./index.ab8df807.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index.ab8df807.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/index.3831b08a.css"])), Re = n(() => i(() => import("./index.c1284b08.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index.c1284b08.js","js/vuex.33ea5d58.js","js/@vue.b00de3e9.js","js/index.bb04cb73.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/index.b76f7142.css"])), Te = n(() => i(() => import("./signatureDialog.fe779221.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/signatureDialog.fe779221.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/betAndRecharge.fe68b42c.js","css/signatureDialog.65adc82f.css"])), ke = n(() => i(() => import("./newcomer_bonus_dialog.6478a9b6.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/newcomer_bonus_dialog.6478a9b6.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/newcomer_bonus_dialog.3c575cdd.css"])), Se = n(() => i(() => import("./newcomer_bonus_tips.099fd033.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/newcomer_bonus_tips.099fd033.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/newcomer_bonus_tips.306d419b.css"])), Le = n(() => i(() => import("./pinch_hitter_guide.8e3f92b9.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/pinch_hitter_guide.8e3f92b9.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/index.5f74bd60.js","css/pinch_hitter_guide.098575f0.css"])), Oe = n(() => i(() => import("./index.1f5ff7e8.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index.1f5ff7e8.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/index.888c1b0c.css"])), Be = n(() => i(() => import("./registr_activity_index.9bbb76d9.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/registr_activity_index.9bbb76d9.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/useWinningToast.fa7f6a2b.js","css/registr_activity_index.893a7c89.css"])), e = pt(), I = m(null), B = m(false), C = dt([]), A = m(false), h = m(null), f = m(false), R = m(null), Ce = m(""), Ve = m(""), V = m(), T = m(false), Ue = _(() => ({
        paddingBottom: p.meta.bottomMenu ? F : "0"
      })), be = _(() => ({
        paddingBottom: "4rem"
      })), U = _(() => e.state.unfoldStatus);
      let Ne = _(() => {
        let o;
        return e.state.popStep === 5 && p.name == "index" && (L("goldWheel"), o = true), e.state.showGoldWheelActivity && (o = true), o;
      }), Ge = _(() => {
        let o = e.state.popStep, a = false;
        return e.state.showRegisterPwdDialog || e.state.showRegisterDialog ? a = false : !w() && o === 1 && p.name == "index" && (a = true), p.name == "login" || p.name == "register" ? true : (e.state.showLoginDialog && (a = true), a);
      }), We = _(() => {
        var _a, _b, _c, _d, _e2, _f, _g, _h, _i, _j, _k, _l;
        if (f.value || e.state.isApp || Xe())
          return;
        let o = false;
        return e.state.popStep === 2 && ($e.value ? p.name !== "index" ? o = false : j() ? ((_a = e.state.downloadBar) == null ? void 0 : _a.systemGuideConfig.IOS.installType.includes("1")) || ((_c = (_b = e.state.downloadInfo) == null ? void 0 : _b.iOS) == null ? void 0 : _c.downloadUrl) && ((_d = e.state.downloadBar) == null ? void 0 : _d.systemGuideConfig.IOS.installType.includes("0")) ? o = true : (e.state.popStep = 3, o = false) : H() ? ((_e2 = e.state.downloadBar) == null ? void 0 : _e2.systemGuideConfig.Android.installType.includes("1")) || ((_g = (_f = e.state.downloadInfo) == null ? void 0 : _f.Android) == null ? void 0 : _g.downloadUrl) && ((_h = e.state.downloadBar) == null ? void 0 : _h.systemGuideConfig.Android.installType.includes("0")) ? o = true : (e.state.popStep = 3, o = false) : ((_i = e.state.downloadBar) == null ? void 0 : _i.systemGuideConfig.PC.installType.includes("1")) || ((_k = (_j = e.state.downloadInfo) == null ? void 0 : _j.Android) == null ? void 0 : _k.downloadUrl) && ((_l = e.state.downloadBar) == null ? void 0 : _l.systemGuideConfig.Android.installType.includes("0")) ? o = true : (e.state.popStep = 3, o = false) : (e.state.popStep = 3, o = false)), e.state.showAppDownloadPop && (o = true), o && L("download"), o;
      });
      const $e = _(() => {
        var _a, _b, _c;
        return H() ? !e.state.isApp && !!((_a = e.state.downloadBar) == null ? void 0 : _a.systemGuideConfig.Android.guideStatus) : j() ? !e.state.isApp && !!((_b = e.state.downloadBar) == null ? void 0 : _b.systemGuideConfig.IOS.guideStatus) : !!((_c = e.state.downloadBar) == null ? void 0 : _c.systemGuideConfig.PC.guideStatus);
      });
      let Me = _(() => {
        let o = false;
        return e.state.popStep === 4 && p.name == "index" ? (o = true, L("findUs")) : o = false, e.state.showFindUs && (S("findUs"), o = true), o;
      });
      E(() => Ge.value, (o, a) => {
        o && !a ? e.state.loginConfig.popUp === 0 || e.state.loginConfig.popUp === 1 ? (S("login"), T.value = true) : [
          2,
          3
        ].includes(e.state.loginConfig.popUp) && (e.state.loginType === "register" ? v.push("/home/register") : v.push("/home/login")) : !o && a && (e.state.loginConfig.popUp === 0 || e.state.loginConfig.popUp === 1 ? T.value = false : [
          2,
          3
        ].includes(e.state.loginConfig.popUp) && (e.state.showLoginDialog = false));
      }), E(() => e.state.accountInfo, (o) => {
        o.id ? e.state.currentModuleList = e.state.loginModuleList : e.state.currentModuleList = e.state.moduleList;
      }, {
        immediate: true
      }), E(p, (o) => {
        sessionStorage.getItem($) === "1" && sessionStorage.getItem(M) === "1" && p.name != "game" && w() && (sessionStorage.removeItem($), sessionStorage.removeItem(M), e.state.showFloatPromotionDialog = true), setTimeout(() => {
          if (o.meta.bottomMenu) {
            const a = () => {
              if (I.value) {
                let d = F;
                I.value.style.paddingBottom = d;
              } else
                setTimeout(a, 200);
            };
            a();
          } else {
            const a = () => {
              I.value ? I.value.style.paddingBottom = 0 : setTimeout(a, 200);
            };
            a();
          }
        }, 200);
      }, {
        deep: true,
        immediate: true
      }), E(() => e.state.popStep, (o) => {
        console.log("popStep:", o);
      }), E(() => e.state.jackpotInfo, (o) => {
        if (o) {
          const { jackPotCfgList: a = [] } = o, d = a.find((s) => s.participated);
          if (d) {
            const g = d.periodEnd - Date.now() + 30 * 1e3;
            g > 0 && (e.state.jackpotTimer && clearTimeout(e.state.jackpotTimer), e.state.jackpotTimer = setTimeout(() => {
              e.dispatch("getJackpotDetail");
            }, g));
          }
        }
      }, {
        immediate: true,
        deep: true
      });
      let xe = _(() => (document.documentElement.setAttribute("lang", e.state.language), e.state.language === "pt" ? (P.use("pt-BR", wt), _t) : e.state.language === "en" ? (P.use("en-US", q), K) : e.state.language === "id" ? (P.use("id-ID", ht), vt) : e.state.language === "es_mx" ? (P.use("es-ES", Et), ft) : (P.use("en-US", q), K)));
      const Fe = (o) => {
        requestAnimationFrame(() => {
          setTimeout(o, 0);
        });
      }, je = (o) => {
        if ("requestIdleCallback" in window) {
          window.requestIdleCallback(o, {
            timeout: 1200
          });
          return;
        }
        setTimeout(o, 400);
      }, b = () => {
        let o = (/* @__PURE__ */ new Date()).getTime(), a = {};
        const d = x();
        e.state.inGamePage && (a.s = 1), p.name === "game" && (p.params.id && (a.id = p.params.id), d.vendorId && (a.vendor = d.vendorId)), y.get("/game/game/link", a).then((s) => {
          if (s && s.status === "OK") {
            let g = (/* @__PURE__ */ new Date()).getTime();
            e.state.network = g - o;
          }
        });
      }, He = () => {
        R.value && clearInterval(R.value), b(), R.value = setInterval(b, 6e4);
      }, Je = () => {
        const o = document.documentElement, d = getComputedStyle(o).getPropertyValue("--skin__home_bg").trim(), s = document.createElement("meta");
        s.name = "theme-color", s.content = d, document.querySelector("head").appendChild(s);
      }, Ke = () => {
        "serviceWorker" in navigator && fetch("/sw-path.json?time=".concat((/* @__PURE__ */ new Date()).getTime())).then((o) => o.json()).then((o) => {
          const a = o.swPath;
          navigator.serviceWorker.register(a).then((d) => {
            console.log("Service Worker registered:", d);
          }).catch((d) => {
            console.error("Service Worker registration failed:", d);
          });
        }).catch((o) => {
          console.error("Failed to fetch sw-path.json:", o);
        });
      }, qe = () => {
        He(), Ye(), Promise.allSettled([
          e.dispatch("getNoticeList"),
          e.dispatch("getNewerUnfinished"),
          e.dispatch("getAllBadges"),
          e.dispatch("checkRedEnvelopes_wg"),
          e.dispatch("getJackpotDetail")
        ]), w() && Promise.allSettled([
          e.dispatch("getUserInfo", 1),
          e.dispatch("refreshBalance"),
          e.dispatch("getReliefCheck"),
          e.dispatch("getBadge")
        ]), je(() => {
          Promise.allSettled([
            e.dispatch("getVipList"),
            e.dispatch("getFeedbackConfig")
          ]), Ke();
        });
      };
      et(async () => {
        if (Pt(), e.state.maintainContent)
          return v.push("/maintain");
        await e.dispatch("checkToken"), localStorage.getItem("haveAccount") && (e.state.haveAccount = true), !e.state.region && v.currentRoute.value.name !== "maintain" ? (e.state.showPreviewRegisterPage = false, v.push("/limit")) : v.currentRoute.value.name === "limit" && v.push("/"), document.addEventListener("touchstart", () => {
        }, {
          passive: true
        });
        const o = localStorage.getItem("language") || "en", a = localStorage.getItem("userInfo");
        a && (e.state.accountInfo = JSON.parse(a)), z.value = o, e.state.language = o, globalVBus.$on("globalLoading", (d) => {
          B.value = d;
        }), globalVBus.$on("reopenRedEnvelopes", () => {
          e.state.haveRedEnvelop = true;
        }), e.state.country && !e.state.showPreviewRegisterPage && (e.state.popStep = 1), globalVBus.$on("finishRegister", () => {
          f.value = true, e.state.popStep = 1, S("finishRegister");
        }), Fe(qe), Je(), globalVBus.$on("addDesktop", Qe), globalVBus.$on("signInActivityEvent", (d) => {
          V.value = d.id, e.state.showSign = true;
        }), globalVBus.$on("checkRechargeOrderStatus", N), localStorage.getItem("rechargeOrderNo") && N();
      });
      const N = () => {
        h.value && clearInterval(h.value), w() && (h.value = setInterval(() => {
          let o = localStorage.getItem("rechargeOrderNo");
          if (!o || !w())
            return clearInterval(h.value);
          y.get("/trade/order/result", {
            ids: o
          }).then((a) => {
            if (a.status === "OK") {
              const { data: d } = a;
              let s = o.split(",");
              x(), d && d.length && d.forEach((g) => {
                if (g.result)
                  globalVBus.$emit("orderRechargeSuccess", g.id), e.state.rechargeSuccessDialog = true, e.state.payInfo = g, It(g, s), e.dispatch("refreshBalance", true), e.dispatch("getBadge");
                else if (g.status === -1) {
                  let G = s.findIndex((k) => k === g.orderNo);
                  G !== -1 && s.splice(G, 1);
                  let W = s.findIndex((k) => k == g.id);
                  W !== -1 && s.splice(W, 1);
                }
              }), s.length ? localStorage.setItem("rechargeOrderNo", s.join(",")) : (clearInterval(h.value), localStorage.removeItem("rechargeOrderNo"));
            }
          });
        }, 15e3));
      }, ze = () => {
        let o = "";
        switch (e.state.layoutMode) {
          case 3:
            o = "wg_copy_3";
            break;
          case 7:
            o = "wg_copy_7";
            break;
          case 8:
            o = "wg_copy_8";
            break;
          case 9:
            o = "wg_copy_3";
            break;
          case 12:
            o = "wg_copy_7";
            break;
          case 14:
            o = "wg_copy_14";
            break;
          default:
            o = "wg_copy_3";
            break;
        }
        e.state.copyClassName = o;
      };
      tt(() => {
        v.getRoutes().forEach((o) => {
          o.meta.keepAlive && C.push(o.name);
        }), ze(), e.state.noDataImg = new URL("/img/colors/" + Ze() + "/blank_img_none_sj.png", import.meta.url).href;
      });
      const Qe = () => {
        y.post("/user/task/shortcut").then((o) => {
          A.value = true, globalVBus.$emit("refreshTask");
        });
      }, Ye = () => {
        y.get("/user/app/download").then((o) => {
          o.status === "OK" && o.data && (o.data.Android || o.data.iOS) && (e.state.appDownloadInfo = o.data);
        });
      };
      return (o, a) => {
        const d = ot("router-view");
        return r(), l(t(mt), {
          locale: t(xe)
        }, {
          default: O(() => [
            !t(e).state.showPreviewRegisterPage || t(w)() ? (r(), at("div", {
              key: 0,
              class: st([
                "main-body",
                [
                  {
                    isMobile: t(e).state.isMobile
                  }
                ]
              ])
            }, [
              D("div", yt, [
                D("div", At, [
                  D("div", {
                    class: "wrapper",
                    style: J(U.value ? be.value : Ue.value)
                  }, [
                    D("div", {
                      class: "animation",
                      style: J(U.value ? "overflow-y:auto" : "overflow-y:hidden")
                    }, [
                      D("div", null, [
                        c(d, null, {
                          default: O(({ Component: s }) => [
                            c(it, {
                              name: t(e).state.transitionName,
                              appear: false
                            }, {
                              default: O(() => [
                                (r(), l(nt, {
                                  include: C
                                }, [
                                  (r(), l(rt(s), {
                                    key: t(p).meta.transitionKey ? o.$route.fullPath : void 0
                                  }))
                                ], 1032, [
                                  "include"
                                ]))
                              ]),
                              _: 2
                            }, 1032, [
                              "name"
                            ])
                          ]),
                          _: 1
                        })
                      ])
                    ], 4)
                  ], 4)
                ])
              ]),
              t(e).state.maintainContent ? u("", true) : (r(), l(t(re), {
                key: 0
              })),
              lt(c(t(Y), null, null, 512), [
                [
                  ut,
                  t(p).meta.bottomMenu
                ]
              ]),
              T.value && t(p).name !== "limit" ? (r(), l(t(Q), {
                key: 1
              })) : u("", true),
              t(e).state.showRegisterPwdDialog && t(p).name !== "limit" ? (r(), l(t(Z), {
                key: 2
              })) : u("", true),
              t(e).state.showRegisterDialog ? (r(), l(t(ee), {
                key: 3,
                value: t(e).state.showRegisterDialog,
                "onUpdate:value": a[0] || (a[0] = (s) => t(e).state.showRegisterDialog = s)
              }, null, 8, [
                "value"
              ])) : u("", true),
              c(t(te)),
              c(t(oe)),
              c(t(ae))
            ], 2)) : u("", true),
            c(t(Re), {
              loading: B.value
            }, null, 8, [
              "loading"
            ]),
            !t(e).state.showPreviewRegisterPage || t(w)() ? (r(), l(t(Pe), {
              key: 1
            })) : u("", true),
            A.value && t(p).name !== "limit" ? (r(), l(t(se), {
              key: 2,
              onClose: a[1] || (a[1] = (s) => A.value = false)
            })) : u("", true),
            f.value && t(e).state.popDialogList[0] == "finishRegister" ? (r(), l(t(ue), {
              key: 3,
              value: f.value,
              "onUpdate:value": a[2] || (a[2] = (s) => f.value = s)
            }, null, 8, [
              "value"
            ])) : u("", true),
            t(e).state.showNewbieBonusDialog ? (r(), l(t(ie), {
              key: 4,
              onClose: a[3] || (a[3] = (s) => t(e).state.showNewbieBonusDialog = false)
            })) : u("", true),
            c(t(ne), {
              value: t(e).state.appDownloadDialog,
              "onUpdate:value": a[4] || (a[4] = (s) => t(e).state.appDownloadDialog = s)
            }, null, 8, [
              "value"
            ]),
            t(Ne) && !f.value && t(p).name !== "game" && t(p).name !== "limit" && t(e).state.popDialogList[0] === "goldWheel" ? (r(), l(t(le), {
              key: 5,
              inviteUserName: Ce.value,
              inviteUserAvatar: Ve.value
            }, null, 8, [
              "inviteUserName",
              "inviteUserAvatar"
            ])) : u("", true),
            t(e).state.haveRedEnvelop && !f.value && t(p).name !== "game" && t(e).state.popDialogList[0] === "RedEnvelopes" ? (r(), l(t(X), {
              key: 6,
              value: t(e).state.haveRedEnvelop,
              "onUpdate:value": a[5] || (a[5] = (s) => t(e).state.haveRedEnvelop = s)
            }, null, 8, [
              "value"
            ])) : u("", true),
            c(t(de)),
            c(t(pe)),
            t(p).name !== "game" ? (r(), l(t(ge), {
              key: 7
            })) : u("", true),
            t(Me) && t(e).state.popDialogList[0] === "findUs" ? (r(), l(t(ce), {
              key: 8,
              onClose: a[6] || (a[6] = (s) => t(e).state.showFindUs = false)
            })) : u("", true),
            t(e).state.showRiskConfirmTips ? (r(), l(t(Ae), {
              key: 9
            })) : u("", true),
            t(e).state.showBindPhone ? (r(), l(t(me), {
              key: 10
            })) : u("", true),
            t(e).state.showSetWithdrawPwd ? (r(), l(t(_e), {
              key: 11
            })) : u("", true),
            t(e).state.showBindWithdrawAccount ? (r(), l(t(ve), {
              key: 12
            })) : u("", true),
            t(e).state.showSetAvatar ? (r(), l(t(fe), {
              key: 13
            })) : u("", true),
            t(e).state.showSetBirthday ? (r(), l(t(we), {
              key: 14
            })) : u("", true),
            t(e).state.showSetSocialAccount ? (r(), l(t(he), {
              key: 15
            })) : u("", true),
            t(e).state.showBindGoogle ? (r(), l(t(Ee), {
              key: 16
            })) : u("", true),
            t(We) && !f.value && t(e).state.popDialogList[0] === "download" ? (r(), l(t(De), {
              key: 17
            })) : u("", true),
            c(t(Ie)),
            t(e).state.showLanguageDialog ? (r(), l(t(ye), {
              key: 18
            })) : u("", true),
            t(e).state.showSign ? (r(), l(t(Te), {
              key: 19,
              currentId: V.value,
              value: t(e).state.showSign,
              "onUpdate:value": a[7] || (a[7] = (s) => t(e).state.showSign = s)
            }, null, 8, [
              "currentId",
              "value"
            ])) : u("", true),
            t(e).state.showNewcomerBonus ? (r(), l(t(ke), {
              key: 20,
              value: t(e).state.showNewcomerBonus,
              "onUpdate:value": a[8] || (a[8] = (s) => t(e).state.showNewcomerBonus = s)
            }, null, 8, [
              "value"
            ])) : u("", true),
            t(e).state.showNewcomerBonusTips ? (r(), l(t(Se), {
              key: 21,
              value: t(e).state.showNewcomerBonusTips,
              "onUpdate:value": a[9] || (a[9] = (s) => t(e).state.showNewcomerBonusTips = s)
            }, null, 8, [
              "value"
            ])) : u("", true),
            c(t(Le), {
              value: t(e).state.showFloatPromotionDialog,
              "onUpdate:value": a[10] || (a[10] = (s) => t(e).state.showFloatPromotionDialog = s)
            }, null, 8, [
              "value"
            ]),
            t(e).state.showPreviewRegisterPage && !t(w)() ? (r(), l(t(Oe), {
              key: 22
            })) : u("", true),
            c(t(Be))
          ]),
          _: 1
        }, 8, [
          "locale"
        ]);
      };
    }
  };
});
export {
  __tla,
  Zt as default
};
