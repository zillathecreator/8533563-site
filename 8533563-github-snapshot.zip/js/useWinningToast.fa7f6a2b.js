import { r } from "./@vue.b00de3e9.js";
const n = r([]);
function i() {
  function u(o, t) {
    n.value.push({ id: Date.now(), message: o, icon: t });
  }
  function e() {
    n.value = [];
  }
  return { queue: n, show: u, clear: e };
}
export {
  i as u
};
