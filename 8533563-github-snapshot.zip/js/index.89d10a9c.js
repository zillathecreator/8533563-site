import { w as N, a9 as z, o as e, J as n, V as A, c as a, L as T, a as s, u as _, U as u, Y as C, R as I, _ as r, W as v, a5 as x, l as g, r as V, n as J } from "./@vue.b00de3e9.js";
import { b as l, c as f, __tla as __tla_0 } from "./index.bb04cb73.js";
import { u as L } from "./vuex.33ea5d58.js";
import { u as M } from "./vue-i18n.07fcbeea.js";
import "./vue-router.c227d4ba.js";
import "./axios.853f16bf.js";
import "./element-plus.53baa8a9.js";
import "./@element-plus.e21ea623.js";
import "./@ctrl.11979b50.js";
import "./dayjs.9abdbee1.js";
import "./clipboard.aaae98d3.js";
import "./@vueuse.eccd744a.js";
import "./lodash-es.e1022fb5.js";
import "./@popperjs.da591b4f.js";
import "./vant.f7b4805b.js";
import "./@vant.f52f09a9.js";
import "./xe-utils.a532b55a.js";
import "./crypto-js.c184c643.js";
import "./decimal.js.2def1975.js";
import "./nprogress.9fc41f77.js";
import "./vconsole.0cfb1d33.js";
import "./perfect-scrollbar.19f80865.js";
import "./@intlify.928cb664.js";
let Js;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e2) {
    }
  })()
]).then(async () => {
  const S = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFgAAABYCAMAAABGS8AGAAAAilBMVEUAAAD////e5Orv8vXe5Or////e5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Or////////h5+z8/f7z9ffm6/Dp7fHt8PT5+vv2+PrCEzcDAAAAJXRSTlMAYJYggoAJR6DVzbyRfHYuimpXKBlePTURrlDbxOm27OJwZaif1OMsUAAABGNJREFUWMPdmdtiojAQhlNAOSOoeK6tugRy4P1fb0lCO26DDRiv9r8Twsfkz0wSA/ovtVh6tzj8fP/4eP+M4iBdrpC93GtwJJQ1La+leNswisOgXNtQd9czpg2vNPGG4v1y/iR2lWDaVo9Ud2xv/YyxDmnqnsG77hOCOxFhC/+6znDuTsSuHdx89ZrgU5CW/nbluqutX6ZBJP1RYeN8kiEZZv2DJMr9nfbaZRL2/alZdJ3ignyIU5xvHzXaOJipVsQZaXWBG4UNi99zJuvR7LQcw00Il63xxdw2VTG02DO3dahqmuxG1Y8jw6iJY2g4V1wWH9BIFZEMmjoGLlPv302oI4eayYqLczRJKomoY/CX4wxNVI4F+bHPDpHcAk2Wp8gPcuOChQ/AnURWzx4GByEUiYNT9JQS0ds2HjSiEb1JnoDC+LABmzMCN55SIALDpVb4wn4eWSw4G0k4aR4x8b4rslAq+ky9HyOHlRFWujUiM34ELK9JI2zM0EJewyUbJVrIHuuufNpvQsT40QKB5IVsoOVsNnMRGnEDQuYh/F5S0QV9uX2rhN7QmBuQAwTWyX33osbRw6qU3nSukh5z3Hak/J/iIBut1awC8hC3mmmPlLQfLHDiiAbBQNa51R99CcL1nReOcCIZBgNZ50LEoHPHYl9pIOZLekCDHgNZ54LHoIx1QZ7758VQalUHECBrl3RtCSTYgYh5DSET2cgFkxcQfYDMZANX6dR2vi6/x455aAR5BBcFMHpiIGmJRpDNXDXt9MUW8c4VHxnII7mooN9pEXJZdwaymQvV1qoF6hPG0UQ2c5EPOfbRgfEKmcnANYHDEWAgA9cMBivswboVRzF4W3srYPD4SUs3+8G7iqw4qwJpoUDs0y2VEwQUYfqSAgEavONVJR3L/oPd0asmIVib5Jpd491rps3F3USPjjWkhe1EX1C5sQe/m/w1S9PtfnIvhcmh9WIKFm9grwnzm93yf5AWaxsj6w0LbNagDOt3yy0W9H3z75pNC+tNob7PduS+1mYbCwGy7D6tZRcuA/vrP7C/Nt/IGVTHXfrxI7LTSgacD/zhSezADvz1+nnRt+EWIjj2M7iF6EZztuC6IRd2zjXjqTx+sTCCQQJoRVOR9GkuqWTR6fJxLWwun+OmwmAeDuamR8S96PDUwMlDIVz8ckjSxk+Qr5hrxzOa/+1pshsXzH8feddpBBlfph67cdNpx0KSOZ5SgnOH1JI7R0ZyTZ3FWK6/Z5Xk7kzntrJdg7OxNvSHsfORPavpmOwoI1rD8bFJHm7l2TTZG+akZUz4pO4dYlbLB0hUrB96loVEBlDTYDN6oBPlXMUp3hergTG+xJjxSoXrTTrpupH2+8tPeEuXW3c37964c7eltz8SJu7KTpnzRzewqZTkFyHcS34TqnqsNgwjM5So7irVUvCbMwzmTtTCw6LTuuqWkShzkYV874T774TwpZDgON0ia7mHNDgdu++anT7ej3GQ+Wv0H+ov9UMLyPmx8boAAAAASUVORK5CYII=";
  let U, P, G, E, Q, Z, W, Y, X, F, j, q, K, $, ss, es, os, ts, as, is, ns, ls, ds, rs, cs, _s, us, ps;
  U = {
    key: 0,
    class: "download-dialog-box4"
  };
  P = {
    class: "saveShortcut"
  };
  G = {
    class: "bottom"
  };
  E = [
    "innerHTML"
  ];
  Q = {
    key: 0,
    class: "download-dialog-box"
  };
  Z = {
    class: "topBox"
  };
  W = {
    class: "topBox-logo"
  };
  Y = [
    "src"
  ];
  X = {
    class: "topBox-text"
  };
  F = [
    "innerHTML"
  ];
  j = [
    "innerHTML"
  ];
  q = {
    class: "btns"
  };
  K = {
    key: 1,
    class: "download-dialog-box2"
  };
  $ = {
    class: "saveShortcut"
  };
  ss = {
    class: "content"
  };
  es = {
    class: "logo"
  };
  os = [
    "src"
  ];
  ts = {
    class: "text"
  };
  as = {
    class: "wrapperIconClose"
  };
  is = {
    class: "tips"
  };
  ns = [
    "innerHTML"
  ];
  ls = {
    class: "saveShortcut"
  };
  ds = {
    class: "content"
  };
  rs = {
    key: 1,
    class: "arrow"
  };
  cs = {
    class: "text"
  };
  _s = {
    class: "tips"
  };
  us = {
    class: "tips"
  };
  ps = {
    key: 2,
    class: "arrow"
  };
  Js = {
    __name: "index",
    props: [
      "value"
    ],
    emits: [
      "update:value"
    ],
    setup(B, { emit: D }) {
      const H = D, { t: k } = M(), R = B, d = L(), p = g({
        get() {
          return R.value;
        },
        set(i) {
          H("update:value", i);
        }
      }), w = V(false);
      N(p, () => {
        p.value && setTimeout(() => {
          w.value = true;
        });
      });
      const c = g(() => {
        var _a, _b, _c;
        return l() ? (_a = d.state.downloadBar) == null ? void 0 : _a.systemGuideConfig.IOS.desktopStyle : f() ? (_b = d.state.downloadBar) == null ? void 0 : _b.systemGuideConfig.Android.desktopStyle : (_c = d.state.downloadBar) == null ? void 0 : _c.systemGuideConfig.PC.desktopStyle;
      }), b = g(() => l() ? k("add_tips_dialog_wg.text1_ios") : k("add_tips_dialog_wg.text1")), m = () => {
        w.value = false, J(() => {
          p.value = false, d.state.popStep === 2 && (d.state.popStep = 3);
        });
      }, y = g(() => {
        var _a;
        return ((_a = d.state.downloadBar) == null ? void 0 : _a.systemGuideConfig[l() ? "IOS" : f() ? "Android" : "PC"].guideText) || "";
      }), h = g(() => {
        var _a;
        return (_a = d.state.downloadBar) == null ? void 0 : _a.desktopIcon;
      }), O = () => {
        p.value = false, globalVBus.$emit("addDesktop");
      };
      return (i, o) => {
        const t = z("svg-icon");
        return e(), n(C, {
          name: "down-opacity"
        }, {
          default: A(() => [
            p.value ? (e(), a("div", {
              key: 0,
              class: T([
                "app-download-dialog",
                [
                  {
                    noOverlay: c.value === 1
                  }
                ]
              ])
            }, [
              c.value === 3 ? (e(), a("div", U, [
                s("div", P, [
                  s("div", G, [
                    s("div", {
                      class: "wrapperAddToHomeScreen",
                      onClick: O
                    }, [
                      s("i", null, [
                        _(l)() ? (e(), n(t, {
                          key: 0,
                          iconClass: "wg_add_main_add"
                        })) : (e(), n(t, {
                          key: 1,
                          iconClass: "wg_add_main_screen"
                        }))
                      ]),
                      s("div", {
                        class: "btnText",
                        innerHTML: b.value
                      }, null, 8, E)
                    ]),
                    s("i", {
                      onClick: m
                    }, [
                      u(t, {
                        iconClass: "wg_header_close"
                      })
                    ])
                  ])
                ])
              ])) : [
                2,
                1
              ].includes(c.value) ? (e(), n(C, {
                key: 1,
                name: "down-translate"
              }, {
                default: A(() => [
                  w.value ? (e(), a(I, {
                    key: 0
                  }, [
                    c.value === 2 ? (e(), a("div", Q, [
                      s("div", Z, [
                        s("div", W, [
                          s("img", {
                            src: h.value
                          }, null, 8, Y)
                        ]),
                        s("div", X, [
                          y.value ? (e(), a("span", {
                            key: 0,
                            innerHTML: y.value
                          }, null, 8, F)) : (e(), a("span", {
                            key: 1,
                            innerHTML: i.$t("add_tips_dialog_wg.text1")
                          }, null, 8, j))
                        ])
                      ]),
                      s("div", q, [
                        s("div", {
                          class: "btn",
                          onClick: m
                        }, [
                          s("span", null, r(i.$t("add_tips_dialog_wg.btn1_text")), 1)
                        ]),
                        s("div", {
                          class: "btn",
                          onClick: O
                        }, [
                          u(t, {
                            iconClass: "wg_add_main_screen"
                          }),
                          s("span", null, r(i.$t("add_tips_dialog.title2")), 1)
                        ])
                      ])
                    ])) : c.value === 1 ? (e(), a("div", K, [
                      s("div", $, [
                        s("div", ss, [
                          s("div", es, [
                            s("img", {
                              src: h.value,
                              alt: ""
                            }, null, 8, os)
                          ]),
                          s("div", ts, [
                            s("div", as, [
                              s("div", is, r(i.$t("common_wg.tips_title")), 1),
                              s("div", {
                                onClick: m
                              }, [
                                s("i", null, [
                                  u(t, {
                                    iconClass: "wg_header_close"
                                  })
                                ])
                              ])
                            ]),
                            s("div", {
                              class: "bottom",
                              onClick: O
                            }, [
                              s("i", null, [
                                u(t, {
                                  iconClass: "wg_add_main_screen"
                                })
                              ]),
                              s("div", {
                                class: "btnTxt",
                                innerHTML: i.$t("add_tips_dialog_wg.text1")
                              }, null, 8, ns)
                            ])
                          ])
                        ])
                      ])
                    ])) : v("", true)
                  ], 64)) : v("", true)
                ]),
                _: 1
              })) : c.value === 4 ? (e(), n(C, {
                key: 2,
                name: "down-scale"
              }, {
                default: A(() => [
                  w.value ? (e(), a("div", {
                    key: 0,
                    class: T([
                      "download-dialog-box3",
                      _(l)() ? "ios" : ""
                    ])
                  }, [
                    s("div", ls, [
                      s("div", ds, [
                        _(l)() ? (e(), a("div", {
                          key: 0,
                          class: "closeBtn",
                          onClick: m
                        }, [
                          ...o[0] || (o[0] = [
                            s("img", {
                              src: S,
                              alt: ""
                            }, null, -1)
                          ])
                        ])) : (e(), a("div", rs, [
                          s("i", null, [
                            u(t, {
                              iconClass: "wg_add_main_arrow"
                            })
                          ])
                        ])),
                        s("div", cs, [
                          s("div", _s, [
                            o[1] || (o[1] = s("div", {
                              class: "index"
                            }, "1", -1)),
                            s("span", null, r(i.$t("add_tips_dialog_wg.click")) + '"', 1),
                            s("span", null, [
                              s("i", null, [
                                _(l)() ? (e(), n(t, {
                                  key: 0,
                                  iconClass: "wg_add_main_pop"
                                })) : (e(), n(t, {
                                  key: 1,
                                  iconClass: "wg_download_tips_icon"
                                }))
                              ])
                            ]),
                            o[2] || (o[2] = s("span", null, '"', -1)),
                            s("span", null, r(i.$t("add_tips_dialog_wg.open_menu")) + '"', 1)
                          ]),
                          s("div", us, [
                            o[3] || (o[3] = s("div", {
                              class: "index"
                            }, "2", -1)),
                            s("span", null, r(i.$t("add_tips_dialog_wg.choose")) + '"', 1),
                            o[4] || (o[4] = x(' "', -1)),
                            s("i", null, [
                              _(l)() ? (e(), n(t, {
                                key: 0,
                                iconClass: "wg_add_main_add"
                              })) : (e(), n(t, {
                                key: 1,
                                iconClass: "wg_add_main_screen"
                              }))
                            ]),
                            o[5] || (o[5] = x('" ', -1)),
                            s("span", null, r(i.$t("add_tips_dialog.title2")), 1)
                          ])
                        ]),
                        _(l)() ? (e(), a("div", ps, [
                          s("i", null, [
                            u(t, {
                              iconClass: "wg_add_main_arrow"
                            })
                          ])
                        ])) : (e(), a("div", {
                          key: 3,
                          class: "closeBtn",
                          onClick: m
                        }, [
                          ...o[6] || (o[6] = [
                            s("img", {
                              src: S,
                              alt: ""
                            }, null, -1)
                          ])
                        ]))
                      ])
                    ])
                  ], 2)) : v("", true)
                ]),
                _: 1
              })) : v("", true)
            ], 2)) : v("", true)
          ]),
          _: 1
        });
      };
    }
  };
});
export {
  __tla,
  Js as default
};
