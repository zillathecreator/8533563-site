var P = "top", k = "bottom", V = "right", B = "left", Et = "auto", ft = [P, k, V, B], _ = "start", at = "end", ve = "clippingParents", Kt = "viewport", rt = "popper", ge = "reference", St = ft.reduce(function(t, e) {
  return t.concat([e + "-" + _, e + "-" + at]);
}, []), _t = [].concat(ft, [Et]).reduce(function(t, e) {
  return t.concat([e, e + "-" + _, e + "-" + at]);
}, []), ye = "beforeRead", be = "read", xe = "afterRead", we = "beforeMain", Oe = "main", je = "afterMain", Ee = "beforeWrite", De = "write", Ae = "afterWrite", Le = [ye, be, xe, we, Oe, je, Ee, De, Ae];
function N(t) {
  return t ? (t.nodeName || "").toLowerCase() : null;
}
function R(t) {
  if (t == null)
    return window;
  if (t.toString() !== "[object Window]") {
    var e = t.ownerDocument;
    return e && e.defaultView || window;
  }
  return t;
}
function Z(t) {
  var e = R(t).Element;
  return t instanceof e || t instanceof Element;
}
function T(t) {
  var e = R(t).HTMLElement;
  return t instanceof e || t instanceof HTMLElement;
}
function Dt(t) {
  if (typeof ShadowRoot > "u")
    return false;
  var e = R(t).ShadowRoot;
  return t instanceof e || t instanceof ShadowRoot;
}
function We(t) {
  var e = t.state;
  Object.keys(e.elements).forEach(function(n) {
    var r = e.styles[n] || {}, o = e.attributes[n] || {}, a = e.elements[n];
    !T(a) || !N(a) || (Object.assign(a.style, r), Object.keys(o).forEach(function(c) {
      var s = o[c];
      s === false ? a.removeAttribute(c) : a.setAttribute(c, s === true ? "" : s);
    }));
  });
}
function Pe(t) {
  var e = t.state, n = { popper: { position: e.options.strategy, left: "0", top: "0", margin: "0" }, arrow: { position: "absolute" }, reference: {} };
  return Object.assign(e.elements.popper.style, n.popper), e.styles = n, e.elements.arrow && Object.assign(e.elements.arrow.style, n.arrow), function() {
    Object.keys(e.elements).forEach(function(r) {
      var o = e.elements[r], a = e.attributes[r] || {}, c = Object.keys(e.styles.hasOwnProperty(r) ? e.styles[r] : n[r]), s = c.reduce(function(i, f) {
        return i[f] = "", i;
      }, {});
      !T(o) || !N(o) || (Object.assign(o.style, s), Object.keys(a).forEach(function(i) {
        o.removeAttribute(i);
      }));
    });
  };
}
var $t = { name: "applyStyles", enabled: true, phase: "write", fn: We, effect: Pe, requires: ["computeStyles"] };
function q(t) {
  return t.split("-")[0];
}
var U = Math.max, gt = Math.min, $ = Math.round;
function Ot() {
  var t = navigator.userAgentData;
  return t != null && t.brands && Array.isArray(t.brands) ? t.brands.map(function(e) {
    return e.brand + "/" + e.version;
  }).join(" ") : navigator.userAgent;
}
function Xt() {
  return !/^((?!chrome|android).)*safari/i.test(Ot());
}
function X(t, e, n) {
  e === void 0 && (e = false), n === void 0 && (n = false);
  var r = t.getBoundingClientRect(), o = 1, a = 1;
  e && T(t) && (o = t.offsetWidth > 0 && $(r.width) / t.offsetWidth || 1, a = t.offsetHeight > 0 && $(r.height) / t.offsetHeight || 1);
  var c = Z(t) ? R(t) : window, s = c.visualViewport, i = !Xt() && n, f = (r.left + (i && s ? s.offsetLeft : 0)) / o, u = (r.top + (i && s ? s.offsetTop : 0)) / a, h = r.width / o, m = r.height / a;
  return { width: h, height: m, top: u, right: f + h, bottom: u + m, left: f, x: f, y: u };
}
function At(t) {
  var e = X(t), n = t.offsetWidth, r = t.offsetHeight;
  return Math.abs(e.width - n) <= 1 && (n = e.width), Math.abs(e.height - r) <= 1 && (r = e.height), { x: t.offsetLeft, y: t.offsetTop, width: n, height: r };
}
function te(t, e) {
  var n = e.getRootNode && e.getRootNode();
  if (t.contains(e))
    return true;
  if (n && Dt(n)) {
    var r = e;
    do {
      if (r && t.isSameNode(r))
        return true;
      r = r.parentNode || r.host;
    } while (r);
  }
  return false;
}
function S(t) {
  return R(t).getComputedStyle(t);
}
function Be(t) {
  return ["table", "td", "th"].indexOf(N(t)) >= 0;
}
function Y(t) {
  return ((Z(t) ? t.ownerDocument : t.document) || window.document).documentElement;
}
function yt(t) {
  return N(t) === "html" ? t : t.assignedSlot || t.parentNode || (Dt(t) ? t.host : null) || Y(t);
}
function Yt(t) {
  return !T(t) || S(t).position === "fixed" ? null : t.offsetParent;
}
function He(t) {
  var e = /firefox/i.test(Ot()), n = /Trident/i.test(Ot());
  if (n && T(t)) {
    var r = S(t);
    if (r.position === "fixed")
      return null;
  }
  var o = yt(t);
  for (Dt(o) && (o = o.host); T(o) && ["html", "body"].indexOf(N(o)) < 0; ) {
    var a = S(o);
    if (a.transform !== "none" || a.perspective !== "none" || a.contain === "paint" || ["transform", "perspective"].indexOf(a.willChange) !== -1 || e && a.willChange === "filter" || e && a.filter && a.filter !== "none")
      return o;
    o = o.parentNode;
  }
  return null;
}
function ct(t) {
  for (var e = R(t), n = Yt(t); n && Be(n) && S(n).position === "static"; )
    n = Yt(n);
  return n && (N(n) === "html" || N(n) === "body" && S(n).position === "static") ? e : n || He(t) || e;
}
function Lt(t) {
  return ["top", "bottom"].indexOf(t) >= 0 ? "x" : "y";
}
function ot(t, e, n) {
  return U(t, gt(e, n));
}
function Re(t, e, n) {
  var r = ot(t, e, n);
  return r > n ? n : r;
}
function ee() {
  return { top: 0, right: 0, bottom: 0, left: 0 };
}
function ne(t) {
  return Object.assign({}, ee(), t);
}
function re(t, e) {
  return e.reduce(function(n, r) {
    return n[r] = t, n;
  }, {});
}
var Te = function(t, e) {
  return t = typeof t == "function" ? t(Object.assign({}, e.rects, { placement: e.placement })) : t, ne(typeof t != "number" ? t : re(t, ft));
};
function ke(t) {
  var e, n = t.state, r = t.name, o = t.options, a = n.elements.arrow, c = n.modifiersData.popperOffsets, s = q(n.placement), i = Lt(s), f = [B, V].indexOf(s) >= 0, u = f ? "height" : "width";
  if (!(!a || !c)) {
    var h = Te(o.padding, n), m = At(a), l = i === "y" ? P : B, y = i === "y" ? k : V, p = n.rects.reference[u] + n.rects.reference[i] - c[i] - n.rects.popper[u], g = c[i] - n.rects.reference[i], b = ct(a), w = b ? i === "y" ? b.clientHeight || 0 : b.clientWidth || 0 : 0, O = p / 2 - g / 2, d = h[l], v = w - m[u] - h[y], x = w / 2 - m[u] / 2 + O, j = ot(d, x, v), E = i;
    n.modifiersData[r] = (e = {}, e[E] = j, e.centerOffset = j - x, e);
  }
}
function Ve(t) {
  var e = t.state, n = t.options, r = n.element, o = r === void 0 ? "[data-popper-arrow]" : r;
  o != null && (typeof o == "string" && (o = e.elements.popper.querySelector(o), !o) || te(e.elements.popper, o) && (e.elements.arrow = o));
}
var Ce = { name: "arrow", enabled: true, phase: "main", fn: ke, effect: Ve, requires: ["popperOffsets"], requiresIfExists: ["preventOverflow"] };
function tt(t) {
  return t.split("-")[1];
}
var Me = { top: "auto", right: "auto", bottom: "auto", left: "auto" };
function qe(t, e) {
  var n = t.x, r = t.y, o = e.devicePixelRatio || 1;
  return { x: $(n * o) / o || 0, y: $(r * o) / o || 0 };
}
function zt(t) {
  var e, n = t.popper, r = t.popperRect, o = t.placement, a = t.variation, c = t.offsets, s = t.position, i = t.gpuAcceleration, f = t.adaptive, u = t.roundOffsets, h = t.isFixed, m = c.x, l = m === void 0 ? 0 : m, y = c.y, p = y === void 0 ? 0 : y, g = typeof u == "function" ? u({ x: l, y: p }) : { x: l, y: p };
  l = g.x, p = g.y;
  var b = c.hasOwnProperty("x"), w = c.hasOwnProperty("y"), O = B, d = P, v = window;
  if (f) {
    var x = ct(n), j = "clientHeight", E = "clientWidth";
    if (x === R(n) && (x = Y(n), S(x).position !== "static" && s === "absolute" && (j = "scrollHeight", E = "scrollWidth")), x = x, o === P || (o === B || o === V) && a === at) {
      d = k;
      var D = h && x === v && v.visualViewport ? v.visualViewport.height : x[j];
      p -= D - r.height, p *= i ? 1 : -1;
    }
    if (o === B || (o === P || o === k) && a === at) {
      O = V;
      var A = h && x === v && v.visualViewport ? v.visualViewport.width : x[E];
      l -= A - r.width, l *= i ? 1 : -1;
    }
  }
  var L = Object.assign({ position: s }, f && Me), C = u === true ? qe({ x: l, y: p }, R(n)) : { x: l, y: p };
  if (l = C.x, p = C.y, i) {
    var W;
    return Object.assign({}, L, (W = {}, W[d] = w ? "0" : "", W[O] = b ? "0" : "", W.transform = (v.devicePixelRatio || 1) <= 1 ? "translate(" + l + "px, " + p + "px)" : "translate3d(" + l + "px, " + p + "px, 0)", W));
  }
  return Object.assign({}, L, (e = {}, e[d] = w ? p + "px" : "", e[O] = b ? l + "px" : "", e.transform = "", e));
}
function Ne(t) {
  var e = t.state, n = t.options, r = n.gpuAcceleration, o = r === void 0 ? true : r, a = n.adaptive, c = a === void 0 ? true : a, s = n.roundOffsets, i = s === void 0 ? true : s, f = { placement: q(e.placement), variation: tt(e.placement), popper: e.elements.popper, popperRect: e.rects.popper, gpuAcceleration: o, isFixed: e.options.strategy === "fixed" };
  e.modifiersData.popperOffsets != null && (e.styles.popper = Object.assign({}, e.styles.popper, zt(Object.assign({}, f, { offsets: e.modifiersData.popperOffsets, position: e.options.strategy, adaptive: c, roundOffsets: i })))), e.modifiersData.arrow != null && (e.styles.arrow = Object.assign({}, e.styles.arrow, zt(Object.assign({}, f, { offsets: e.modifiersData.arrow, position: "absolute", adaptive: false, roundOffsets: i })))), e.attributes.popper = Object.assign({}, e.attributes.popper, { "data-popper-placement": e.placement });
}
var oe = { name: "computeStyles", enabled: true, phase: "beforeWrite", fn: Ne, data: {} }, ht = { passive: true };
function Ie(t) {
  var e = t.state, n = t.instance, r = t.options, o = r.scroll, a = o === void 0 ? true : o, c = r.resize, s = c === void 0 ? true : c, i = R(e.elements.popper), f = [].concat(e.scrollParents.reference, e.scrollParents.popper);
  return a && f.forEach(function(u) {
    u.addEventListener("scroll", n.update, ht);
  }), s && i.addEventListener("resize", n.update, ht), function() {
    a && f.forEach(function(u) {
      u.removeEventListener("scroll", n.update, ht);
    }), s && i.removeEventListener("resize", n.update, ht);
  };
}
var ie = { name: "eventListeners", enabled: true, phase: "write", fn: function() {
}, effect: Ie, data: {} }, Se = { left: "right", right: "left", bottom: "top", top: "bottom" };
function vt(t) {
  return t.replace(/left|right|bottom|top/g, function(e) {
    return Se[e];
  });
}
var Ye = { start: "end", end: "start" };
function Ft(t) {
  return t.replace(/start|end/g, function(e) {
    return Ye[e];
  });
}
function Wt(t) {
  var e = R(t), n = e.pageXOffset, r = e.pageYOffset;
  return { scrollLeft: n, scrollTop: r };
}
function Pt(t) {
  return X(Y(t)).left + Wt(t).scrollLeft;
}
function ze(t, e) {
  var n = R(t), r = Y(t), o = n.visualViewport, a = r.clientWidth, c = r.clientHeight, s = 0, i = 0;
  if (o) {
    a = o.width, c = o.height;
    var f = Xt();
    (f || !f && e === "fixed") && (s = o.offsetLeft, i = o.offsetTop);
  }
  return { width: a, height: c, x: s + Pt(t), y: i };
}
function Fe(t) {
  var e, n = Y(t), r = Wt(t), o = (e = t.ownerDocument) == null ? void 0 : e.body, a = U(n.scrollWidth, n.clientWidth, o ? o.scrollWidth : 0, o ? o.clientWidth : 0), c = U(n.scrollHeight, n.clientHeight, o ? o.scrollHeight : 0, o ? o.clientHeight : 0), s = -r.scrollLeft + Pt(t), i = -r.scrollTop;
  return S(o || n).direction === "rtl" && (s += U(n.clientWidth, o ? o.clientWidth : 0) - a), { width: a, height: c, x: s, y: i };
}
function Bt(t) {
  var e = S(t), n = e.overflow, r = e.overflowX, o = e.overflowY;
  return /auto|scroll|overlay|hidden/.test(n + o + r);
}
function ae(t) {
  return ["html", "body", "#document"].indexOf(N(t)) >= 0 ? t.ownerDocument.body : T(t) && Bt(t) ? t : ae(yt(t));
}
function it(t, e) {
  var n;
  e === void 0 && (e = []);
  var r = ae(t), o = r === ((n = t.ownerDocument) == null ? void 0 : n.body), a = R(r), c = o ? [a].concat(a.visualViewport || [], Bt(r) ? r : []) : r, s = e.concat(c);
  return o ? s : s.concat(it(yt(c)));
}
function jt(t) {
  return Object.assign({}, t, { left: t.x, top: t.y, right: t.x + t.width, bottom: t.y + t.height });
}
function Ge(t, e) {
  var n = X(t, false, e === "fixed");
  return n.top = n.top + t.clientTop, n.left = n.left + t.clientLeft, n.bottom = n.top + t.clientHeight, n.right = n.left + t.clientWidth, n.width = t.clientWidth, n.height = t.clientHeight, n.x = n.left, n.y = n.top, n;
}
function Gt(t, e, n) {
  return e === Kt ? jt(ze(t, n)) : Z(e) ? Ge(e, n) : jt(Fe(Y(t)));
}
function Je(t) {
  var e = it(yt(t)), n = ["absolute", "fixed"].indexOf(S(t).position) >= 0, r = n && T(t) ? ct(t) : t;
  return Z(r) ? e.filter(function(o) {
    return Z(o) && te(o, r) && N(o) !== "body";
  }) : [];
}
function Qe(t, e, n, r) {
  var o = e === "clippingParents" ? Je(t) : [].concat(e), a = [].concat(o, [n]), c = a[0], s = a.reduce(function(i, f) {
    var u = Gt(t, f, r);
    return i.top = U(u.top, i.top), i.right = gt(u.right, i.right), i.bottom = gt(u.bottom, i.bottom), i.left = U(u.left, i.left), i;
  }, Gt(t, c, r));
  return s.width = s.right - s.left, s.height = s.bottom - s.top, s.x = s.left, s.y = s.top, s;
}
function se(t) {
  var e = t.reference, n = t.element, r = t.placement, o = r ? q(r) : null, a = r ? tt(r) : null, c = e.x + e.width / 2 - n.width / 2, s = e.y + e.height / 2 - n.height / 2, i;
  switch (o) {
    case P:
      i = { x: c, y: e.y - n.height };
      break;
    case k:
      i = { x: c, y: e.y + e.height };
      break;
    case V:
      i = { x: e.x + e.width, y: s };
      break;
    case B:
      i = { x: e.x - n.width, y: s };
      break;
    default:
      i = { x: e.x, y: e.y };
  }
  var f = o ? Lt(o) : null;
  if (f != null) {
    var u = f === "y" ? "height" : "width";
    switch (a) {
      case _:
        i[f] = i[f] - (e[u] / 2 - n[u] / 2);
        break;
      case at:
        i[f] = i[f] + (e[u] / 2 - n[u] / 2);
        break;
    }
  }
  return i;
}
function st(t, e) {
  e === void 0 && (e = {});
  var n = e, r = n.placement, o = r === void 0 ? t.placement : r, a = n.strategy, c = a === void 0 ? t.strategy : a, s = n.boundary, i = s === void 0 ? ve : s, f = n.rootBoundary, u = f === void 0 ? Kt : f, h = n.elementContext, m = h === void 0 ? rt : h, l = n.altBoundary, y = l === void 0 ? false : l, p = n.padding, g = p === void 0 ? 0 : p, b = ne(typeof g != "number" ? g : re(g, ft)), w = m === rt ? ge : rt, O = t.rects.popper, d = t.elements[y ? w : m], v = Qe(Z(d) ? d : d.contextElement || Y(t.elements.popper), i, u, c), x = X(t.elements.reference), j = se({ reference: x, element: O, placement: o }), E = jt(Object.assign({}, O, j)), D = m === rt ? E : x, A = { top: v.top - D.top + b.top, bottom: D.bottom - v.bottom + b.bottom, left: v.left - D.left + b.left, right: D.right - v.right + b.right }, L = t.modifiersData.offset;
  if (m === rt && L) {
    var C = L[o];
    Object.keys(A).forEach(function(W) {
      var z = [V, k].indexOf(W) >= 0 ? 1 : -1, F = [P, k].indexOf(W) >= 0 ? "y" : "x";
      A[W] += C[F] * z;
    });
  }
  return A;
}
function Ue(t, e) {
  e === void 0 && (e = {});
  var n = e, r = n.placement, o = n.boundary, a = n.rootBoundary, c = n.padding, s = n.flipVariations, i = n.allowedAutoPlacements, f = i === void 0 ? _t : i, u = tt(r), h = u ? s ? St : St.filter(function(y) {
    return tt(y) === u;
  }) : ft, m = h.filter(function(y) {
    return f.indexOf(y) >= 0;
  });
  m.length === 0 && (m = h);
  var l = m.reduce(function(y, p) {
    return y[p] = st(t, { placement: p, boundary: o, rootBoundary: a, padding: c })[q(p)], y;
  }, {});
  return Object.keys(l).sort(function(y, p) {
    return l[y] - l[p];
  });
}
function Ze(t) {
  if (q(t) === Et)
    return [];
  var e = vt(t);
  return [Ft(t), e, Ft(e)];
}
function Ke(t) {
  var e = t.state, n = t.options, r = t.name;
  if (!e.modifiersData[r]._skip) {
    for (var o = n.mainAxis, a = o === void 0 ? true : o, c = n.altAxis, s = c === void 0 ? true : c, i = n.fallbackPlacements, f = n.padding, u = n.boundary, h = n.rootBoundary, m = n.altBoundary, l = n.flipVariations, y = l === void 0 ? true : l, p = n.allowedAutoPlacements, g = e.options.placement, b = q(g), w = b === g, O = i || (w || !y ? [vt(g)] : Ze(g)), d = [g].concat(O).reduce(function(J, I) {
      return J.concat(q(I) === Et ? Ue(e, { placement: I, boundary: u, rootBoundary: h, padding: f, flipVariations: y, allowedAutoPlacements: p }) : I);
    }, []), v = e.rects.reference, x = e.rects.popper, j = /* @__PURE__ */ new Map(), E = true, D = d[0], A = 0; A < d.length; A++) {
      var L = d[A], C = q(L), W = tt(L) === _, z = [P, k].indexOf(C) >= 0, F = z ? "width" : "height", H = st(e, { placement: L, boundary: u, rootBoundary: h, altBoundary: m, padding: f }), M = z ? W ? V : B : W ? k : P;
      v[F] > x[F] && (M = vt(M));
      var ut = vt(M), G = [];
      if (a && G.push(H[C] <= 0), s && G.push(H[M] <= 0, H[ut] <= 0), G.every(function(J) {
        return J;
      })) {
        D = L, E = false;
        break;
      }
      j.set(L, G);
    }
    if (E)
      for (var pt = y ? 3 : 1, bt = function(J) {
        var I = d.find(function(dt) {
          var nt = j.get(dt);
          if (nt)
            return nt.slice(0, J).every(function(K) {
              return K;
            });
        });
        if (I)
          return D = I, "break";
      }, et = pt; et > 0; et--) {
        var lt = bt(et);
        if (lt === "break")
          break;
      }
    e.placement !== D && (e.modifiersData[r]._skip = true, e.placement = D, e.reset = true);
  }
}
var _e = { name: "flip", enabled: true, phase: "main", fn: Ke, requiresIfExists: ["offset"], data: { _skip: false } };
function Jt(t, e, n) {
  return n === void 0 && (n = { x: 0, y: 0 }), { top: t.top - e.height - n.y, right: t.right - e.width + n.x, bottom: t.bottom - e.height + n.y, left: t.left - e.width - n.x };
}
function Qt(t) {
  return [P, V, k, B].some(function(e) {
    return t[e] >= 0;
  });
}
function $e(t) {
  var e = t.state, n = t.name, r = e.rects.reference, o = e.rects.popper, a = e.modifiersData.preventOverflow, c = st(e, { elementContext: "reference" }), s = st(e, { altBoundary: true }), i = Jt(c, r), f = Jt(s, o, a), u = Qt(i), h = Qt(f);
  e.modifiersData[n] = { referenceClippingOffsets: i, popperEscapeOffsets: f, isReferenceHidden: u, hasPopperEscaped: h }, e.attributes.popper = Object.assign({}, e.attributes.popper, { "data-popper-reference-hidden": u, "data-popper-escaped": h });
}
var Xe = { name: "hide", enabled: true, phase: "main", requiresIfExists: ["preventOverflow"], fn: $e };
function tn(t, e, n) {
  var r = q(t), o = [B, P].indexOf(r) >= 0 ? -1 : 1, a = typeof n == "function" ? n(Object.assign({}, e, { placement: t })) : n, c = a[0], s = a[1];
  return c = c || 0, s = (s || 0) * o, [B, V].indexOf(r) >= 0 ? { x: s, y: c } : { x: c, y: s };
}
function en(t) {
  var e = t.state, n = t.options, r = t.name, o = n.offset, a = o === void 0 ? [0, 0] : o, c = _t.reduce(function(u, h) {
    return u[h] = tn(h, e.rects, a), u;
  }, {}), s = c[e.placement], i = s.x, f = s.y;
  e.modifiersData.popperOffsets != null && (e.modifiersData.popperOffsets.x += i, e.modifiersData.popperOffsets.y += f), e.modifiersData[r] = c;
}
var nn = { name: "offset", enabled: true, phase: "main", requires: ["popperOffsets"], fn: en };
function rn(t) {
  var e = t.state, n = t.name;
  e.modifiersData[n] = se({ reference: e.rects.reference, element: e.rects.popper, placement: e.placement });
}
var fe = { name: "popperOffsets", enabled: true, phase: "read", fn: rn, data: {} };
function on(t) {
  return t === "x" ? "y" : "x";
}
function an(t) {
  var e = t.state, n = t.options, r = t.name, o = n.mainAxis, a = o === void 0 ? true : o, c = n.altAxis, s = c === void 0 ? false : c, i = n.boundary, f = n.rootBoundary, u = n.altBoundary, h = n.padding, m = n.tether, l = m === void 0 ? true : m, y = n.tetherOffset, p = y === void 0 ? 0 : y, g = st(e, { boundary: i, rootBoundary: f, padding: h, altBoundary: u }), b = q(e.placement), w = tt(e.placement), O = !w, d = Lt(b), v = on(d), x = e.modifiersData.popperOffsets, j = e.rects.reference, E = e.rects.popper, D = typeof p == "function" ? p(Object.assign({}, e.rects, { placement: e.placement })) : p, A = typeof D == "number" ? { mainAxis: D, altAxis: D } : Object.assign({ mainAxis: 0, altAxis: 0 }, D), L = e.modifiersData.offset ? e.modifiersData.offset[e.placement] : null, C = { x: 0, y: 0 };
  if (x) {
    if (a) {
      var W, z = d === "y" ? P : B, F = d === "y" ? k : V, H = d === "y" ? "height" : "width", M = x[d], ut = M + g[z], G = M - g[F], pt = l ? -E[H] / 2 : 0, bt = w === _ ? j[H] : E[H], et = w === _ ? -E[H] : -j[H], lt = e.elements.arrow, J = l && lt ? At(lt) : { width: 0, height: 0 }, I = e.modifiersData["arrow#persistent"] ? e.modifiersData["arrow#persistent"].padding : ee(), dt = I[z], nt = I[F], K = ot(0, j[H], J[H]), ce = O ? j[H] / 2 - pt - K - dt - A.mainAxis : bt - K - dt - A.mainAxis, ue = O ? -j[H] / 2 + pt + K + nt + A.mainAxis : et + K + nt + A.mainAxis, xt = e.elements.arrow && ct(e.elements.arrow), pe = xt ? d === "y" ? xt.clientTop || 0 : xt.clientLeft || 0 : 0, Rt = (W = L == null ? void 0 : L[d]) != null ? W : 0, le = M + ce - Rt - pe, de = M + ue - Rt, Tt = ot(l ? gt(ut, le) : ut, M, l ? U(G, de) : G);
      x[d] = Tt, C[d] = Tt - M;
    }
    if (s) {
      var kt, me = d === "x" ? P : B, he = d === "x" ? k : V, Q = x[v], mt = v === "y" ? "height" : "width", Vt = Q + g[me], Ct = Q - g[he], wt = [P, B].indexOf(b) !== -1, Mt = (kt = L == null ? void 0 : L[v]) != null ? kt : 0, qt = wt ? Vt : Q - j[mt] - E[mt] - Mt + A.altAxis, Nt = wt ? Q + j[mt] + E[mt] - Mt - A.altAxis : Ct, It = l && wt ? Re(qt, Q, Nt) : ot(l ? qt : Vt, Q, l ? Nt : Ct);
      x[v] = It, C[v] = It - Q;
    }
    e.modifiersData[r] = C;
  }
}
var sn = { name: "preventOverflow", enabled: true, phase: "main", fn: an, requiresIfExists: ["offset"] };
function fn(t) {
  return { scrollLeft: t.scrollLeft, scrollTop: t.scrollTop };
}
function cn(t) {
  return t === R(t) || !T(t) ? Wt(t) : fn(t);
}
function un(t) {
  var e = t.getBoundingClientRect(), n = $(e.width) / t.offsetWidth || 1, r = $(e.height) / t.offsetHeight || 1;
  return n !== 1 || r !== 1;
}
function pn(t, e, n) {
  n === void 0 && (n = false);
  var r = T(e), o = T(e) && un(e), a = Y(e), c = X(t, o, n), s = { scrollLeft: 0, scrollTop: 0 }, i = { x: 0, y: 0 };
  return (r || !r && !n) && ((N(e) !== "body" || Bt(a)) && (s = cn(e)), T(e) ? (i = X(e, true), i.x += e.clientLeft, i.y += e.clientTop) : a && (i.x = Pt(a))), { x: c.left + s.scrollLeft - i.x, y: c.top + s.scrollTop - i.y, width: c.width, height: c.height };
}
function ln(t) {
  var e = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Set(), r = [];
  t.forEach(function(a) {
    e.set(a.name, a);
  });
  function o(a) {
    n.add(a.name);
    var c = [].concat(a.requires || [], a.requiresIfExists || []);
    c.forEach(function(s) {
      if (!n.has(s)) {
        var i = e.get(s);
        i && o(i);
      }
    }), r.push(a);
  }
  return t.forEach(function(a) {
    n.has(a.name) || o(a);
  }), r;
}
function dn(t) {
  var e = ln(t);
  return Le.reduce(function(n, r) {
    return n.concat(e.filter(function(o) {
      return o.phase === r;
    }));
  }, []);
}
function mn(t) {
  var e;
  return function() {
    return e || (e = new Promise(function(n) {
      Promise.resolve().then(function() {
        e = void 0, n(t());
      });
    })), e;
  };
}
function hn(t) {
  var e = t.reduce(function(n, r) {
    var o = n[r.name];
    return n[r.name] = o ? Object.assign({}, o, r, { options: Object.assign({}, o.options, r.options), data: Object.assign({}, o.data, r.data) }) : r, n;
  }, {});
  return Object.keys(e).map(function(n) {
    return e[n];
  });
}
var Ut = { placement: "bottom", modifiers: [], strategy: "absolute" };
function Zt() {
  for (var t = arguments.length, e = new Array(t), n = 0; n < t; n++)
    e[n] = arguments[n];
  return !e.some(function(r) {
    return !(r && typeof r.getBoundingClientRect == "function");
  });
}
function Ht(t) {
  t === void 0 && (t = {});
  var e = t, n = e.defaultModifiers, r = n === void 0 ? [] : n, o = e.defaultOptions, a = o === void 0 ? Ut : o;
  return function(c, s, i) {
    i === void 0 && (i = a);
    var f = { placement: "bottom", orderedModifiers: [], options: Object.assign({}, Ut, a), modifiersData: {}, elements: { reference: c, popper: s }, attributes: {}, styles: {} }, u = [], h = false, m = { state: f, setOptions: function(p) {
      var g = typeof p == "function" ? p(f.options) : p;
      y(), f.options = Object.assign({}, a, f.options, g), f.scrollParents = { reference: Z(c) ? it(c) : c.contextElement ? it(c.contextElement) : [], popper: it(s) };
      var b = dn(hn([].concat(r, f.options.modifiers)));
      return f.orderedModifiers = b.filter(function(w) {
        return w.enabled;
      }), l(), m.update();
    }, forceUpdate: function() {
      if (!h) {
        var p = f.elements, g = p.reference, b = p.popper;
        if (Zt(g, b)) {
          f.rects = { reference: pn(g, ct(b), f.options.strategy === "fixed"), popper: At(b) }, f.reset = false, f.placement = f.options.placement, f.orderedModifiers.forEach(function(E) {
            return f.modifiersData[E.name] = Object.assign({}, E.data);
          });
          for (var w = 0; w < f.orderedModifiers.length; w++) {
            if (f.reset === true) {
              f.reset = false, w = -1;
              continue;
            }
            var O = f.orderedModifiers[w], d = O.fn, v = O.options, x = v === void 0 ? {} : v, j = O.name;
            typeof d == "function" && (f = d({ state: f, options: x, name: j, instance: m }) || f);
          }
        }
      }
    }, update: mn(function() {
      return new Promise(function(p) {
        m.forceUpdate(), p(f);
      });
    }), destroy: function() {
      y(), h = true;
    } };
    if (!Zt(c, s))
      return m;
    m.setOptions(i).then(function(p) {
      !h && i.onFirstUpdate && i.onFirstUpdate(p);
    });
    function l() {
      f.orderedModifiers.forEach(function(p) {
        var g = p.name, b = p.options, w = b === void 0 ? {} : b, O = p.effect;
        if (typeof O == "function") {
          var d = O({ state: f, name: g, instance: m, options: w }), v = function() {
          };
          u.push(d || v);
        }
      });
    }
    function y() {
      u.forEach(function(p) {
        return p();
      }), u = [];
    }
    return m;
  };
}
Ht();
var vn = [ie, fe, oe, $t];
Ht({ defaultModifiers: vn });
var gn = [ie, fe, oe, $t, nn, _e, sn, Ce, Xe], yn = Ht({ defaultModifiers: gn });
export {
  _t as E,
  yn as w
};
