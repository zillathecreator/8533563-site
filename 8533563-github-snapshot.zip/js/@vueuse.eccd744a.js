import { s as I, t as W, v as j, x, u as F, y as L, r as _, w as P, l as S, e as z, k as D } from "./@vue.b00de3e9.js";
function Q(e, n) {
  var r;
  const t = L();
  return I(() => {
    t.value = e();
  }, { ...n, flush: (r = n == null ? void 0 : n.flush) != null ? r : "sync" }), W(t);
}
function g(e) {
  return j() ? (x(e), true) : false;
}
function w(e) {
  return typeof e == "function" ? e() : F(e);
}
const T = typeof window < "u" && typeof document < "u";
typeof WorkerGlobalScope < "u" && globalThis instanceof WorkerGlobalScope;
const $ = (e) => e != null, B = Object.prototype.toString, G = (e) => B.call(e) === "[object Object]", b = () => {
}, N = q();
function q() {
  var e, n;
  return T && ((e = window == null ? void 0 : window.navigator) == null ? void 0 : e.userAgent) && (/iP(?:ad|hone|od)/.test(window.navigator.userAgent) || ((n = window == null ? void 0 : window.navigator) == null ? void 0 : n.maxTouchPoints) > 2 && /iPad|Macintosh/.test(window == null ? void 0 : window.navigator.userAgent));
}
function V(e, n) {
  function r(...t) {
    return new Promise((i, o) => {
      Promise.resolve(e(() => n.apply(this, t), { fn: n, thisArg: this, args: t })).then(i).catch(o);
    });
  }
  return r;
}
function H(e, n = {}) {
  let r, t, i = b;
  const o = (u) => {
    clearTimeout(u), i(), i = b;
  };
  return (u) => {
    const m = w(e), d = w(n.maxWait);
    return r && o(r), m <= 0 || d !== void 0 && d <= 0 ? (t && (o(t), t = null), Promise.resolve(u())) : new Promise((f, l) => {
      i = n.rejectOnCancel ? l : f, d && !t && (t = setTimeout(() => {
        r && o(r), t = null, f(u());
      }, d)), r = setTimeout(() => {
        t && o(t), t = null, f(u());
      }, m);
    });
  };
}
function U(e, n = 200, r = {}) {
  return V(H(n, r), e);
}
function X(e, n, r = {}) {
  const { immediate: t = true } = r, i = _(false);
  let o = null;
  function p() {
    o && (clearTimeout(o), o = null);
  }
  function u() {
    i.value = false, p();
  }
  function m(...d) {
    p(), i.value = true, o = setTimeout(() => {
      i.value = false, o = null, e(...d);
    }, w(n));
  }
  return t && (i.value = true, T && m()), g(u), { isPending: W(i), start: m, stop: u };
}
const A = T ? window : void 0;
function y(e) {
  var n;
  const r = w(e);
  return (n = r == null ? void 0 : r.$el) != null ? n : r;
}
function O(...e) {
  let n, r, t, i;
  if (typeof e[0] == "string" || Array.isArray(e[0]) ? ([r, t, i] = e, n = A) : [n, r, t, i] = e, !n)
    return b;
  Array.isArray(r) || (r = [r]), Array.isArray(t) || (t = [t]);
  const o = [], p = () => {
    o.forEach((f) => f()), o.length = 0;
  }, u = (f, l, c, h) => (f.addEventListener(l, c, h), () => f.removeEventListener(l, c, h)), m = P(() => [y(n), w(i)], ([f, l]) => {
    if (p(), !f)
      return;
    const c = G(l) ? { ...l } : l;
    o.push(...r.flatMap((h) => t.map((M) => u(f, h, M, c))));
  }, { immediate: true, flush: "post" }), d = () => {
    m(), p();
  };
  return g(d), d;
}
let R = false;
function Y(e, n, r = {}) {
  const { window: t = A, ignore: i = [], capture: o = true, detectIframe: p = false } = r;
  if (!t)
    return b;
  N && !R && (R = true, Array.from(t.document.body.children).forEach((s) => s.addEventListener("click", b)), t.document.documentElement.addEventListener("click", b));
  let u = true;
  const m = (s) => w(i).some((a) => {
    if (typeof a == "string")
      return Array.from(t.document.querySelectorAll(a)).some((v) => v === s.target || s.composedPath().includes(v));
    {
      const v = y(a);
      return v && (s.target === v || s.composedPath().includes(v));
    }
  });
  function d(s) {
    const a = w(s);
    return a && a.$.subTree.shapeFlag === 16;
  }
  function f(s, a) {
    const v = w(s), E = v.$.subTree && v.$.subTree.children;
    return E == null || !Array.isArray(E) ? false : E.some((k) => k.el === a.target || a.composedPath().includes(k.el));
  }
  const l = (s) => {
    const a = y(e);
    if (s.target != null && !(!(a instanceof Element) && d(e) && f(e, s)) && !(!a || a === s.target || s.composedPath().includes(a))) {
      if (s.detail === 0 && (u = !m(s)), !u) {
        u = true;
        return;
      }
      n(s);
    }
  };
  let c = false;
  const h = [O(t, "click", (s) => {
    c || (c = true, setTimeout(() => {
      c = false;
    }, 0), l(s));
  }, { passive: true, capture: o }), O(t, "pointerdown", (s) => {
    const a = y(e);
    u = !m(s) && !!(a && !s.composedPath().includes(a));
  }, { passive: true }), p && O(t, "blur", (s) => {
    setTimeout(() => {
      var a;
      const v = y(e);
      ((a = t.document.activeElement) == null ? void 0 : a.tagName) === "IFRAME" && !(v == null ? void 0 : v.contains(t.document.activeElement)) && n(s);
    }, 0);
  })].filter(Boolean);
  return () => h.forEach((s) => s());
}
function J() {
  const e = _(false), n = D();
  return n && z(() => {
    e.value = true;
  }, n), e;
}
function C(e) {
  const n = J();
  return S(() => (n.value, !!e()));
}
function Z(e, n, r = {}) {
  const { window: t = A, ...i } = r;
  let o;
  const p = C(() => t && "MutationObserver" in t), u = () => {
    o && (o.disconnect(), o = void 0);
  }, m = S(() => {
    const c = w(e), h = (Array.isArray(c) ? c : [c]).map(y).filter($);
    return new Set(h);
  }), d = P(() => m.value, (c) => {
    u(), p.value && c.size && (o = new MutationObserver(n), c.forEach((h) => o.observe(h, i)));
  }, { immediate: true, flush: "post" }), f = () => o == null ? void 0 : o.takeRecords(), l = () => {
    d(), u();
  };
  return g(l), { isSupported: p, stop: l, takeRecords: f };
}
function ee(e, n, r = {}) {
  const { window: t = A, ...i } = r;
  let o;
  const p = C(() => t && "ResizeObserver" in t), u = () => {
    o && (o.disconnect(), o = void 0);
  }, m = S(() => {
    const l = w(e);
    return Array.isArray(l) ? l.map((c) => y(c)) : [y(l)];
  }), d = P(m, (l) => {
    if (u(), p.value && t) {
      o = new ResizeObserver(n);
      for (const c of l)
        c && o.observe(c, i);
    }
  }, { immediate: true, flush: "post" }), f = () => {
    u(), d();
  };
  return g(f), { isSupported: p, stop: f };
}
export {
  O as a,
  y as b,
  Q as c,
  Z as d,
  N as e,
  U as f,
  X as g,
  T as i,
  Y as o,
  g as t,
  ee as u
};
