function Ze(e, t) {
  return function() {
    return e.apply(t, arguments);
  };
}
const { toString: Et } = Object.prototype, { getPrototypeOf: ie } = Object, { iterator: ae, toStringTag: Ye } = Symbol, ce = ((e) => (t) => {
  const n = Et.call(t);
  return e[n] || (e[n] = n.slice(8, -1).toLowerCase());
})(/* @__PURE__ */ Object.create(null)), D = (e) => (e = e.toLowerCase(), (t) => ce(t) === e), le = (e) => (t) => typeof t === e, { isArray: $ } = Array, M = le("undefined");
function W(e) {
  return e !== null && !M(e) && e.constructor !== null && !M(e.constructor) && _(e.constructor.isBuffer) && e.constructor.isBuffer(e);
}
const et = D("ArrayBuffer");
function Rt(e) {
  let t;
  return typeof ArrayBuffer < "u" && ArrayBuffer.isView ? t = ArrayBuffer.isView(e) : t = e && e.buffer && et(e.buffer), t;
}
const gt = le("string"), _ = le("function"), tt = le("number"), K = (e) => e !== null && typeof e == "object", Ot = (e) => e === true || e === false, ee = (e) => {
  if (ce(e) !== "object")
    return false;
  const t = ie(e);
  return (t === null || t === Object.prototype || Object.getPrototypeOf(t) === null) && !(Ye in e) && !(ae in e);
}, St = (e) => {
  if (!K(e) || W(e))
    return false;
  try {
    return Object.keys(e).length === 0 && Object.getPrototypeOf(e) === Object.prototype;
  } catch (e2) {
    return false;
  }
}, Tt = D("Date"), At = D("File"), xt = (e) => !!(e && typeof e.uri < "u"), _t = (e) => e && typeof e.getParts < "u", Ct = D("Blob"), Pt = D("FileList"), Nt = (e) => K(e) && _(e.pipe);
function Ft() {
  return typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : typeof global < "u" ? global : {};
}
const Be = Ft(), ke = typeof Be.FormData < "u" ? Be.FormData : void 0, Dt = (e) => {
  if (!e)
    return false;
  if (ke && e instanceof ke)
    return true;
  const t = ie(e);
  if (!t || t === Object.prototype || !_(e.append))
    return false;
  const n = ce(e);
  return n === "formdata" || n === "object" && _(e.toString) && e.toString() === "[object FormData]";
}, Ut = D("URLSearchParams"), [Lt, Bt, kt, jt] = ["ReadableStream", "Request", "Response", "Headers"].map(D), It = (e) => e.trim ? e.trim() : e.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "");
function v(e, t, { allOwnKeys: n = false } = {}) {
  if (e === null || typeof e > "u")
    return;
  let r, s;
  if (typeof e != "object" && (e = [e]), $(e))
    for (r = 0, s = e.length; r < s; r++)
      t.call(null, e[r], r, e);
  else {
    if (W(e))
      return;
    const o = n ? Object.getOwnPropertyNames(e) : Object.keys(e), i = o.length;
    let c;
    for (r = 0; r < i; r++)
      c = o[r], t.call(null, e[c], c, e);
  }
}
function nt(e, t) {
  if (W(e))
    return null;
  t = t.toLowerCase();
  const n = Object.keys(e);
  let r = n.length, s;
  for (; r-- > 0; )
    if (s = n[r], t === s.toLowerCase())
      return s;
  return null;
}
const j = (() => typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : global)(), rt = (e) => !M(e) && e !== j;
function we() {
  const { caseless: e, skipUndefined: t } = rt(this) && this || {}, n = {}, r = (s, o) => {
    if (o === "__proto__" || o === "constructor" || o === "prototype")
      return;
    const i = e && nt(n, o) || o;
    ee(n[i]) && ee(s) ? n[i] = we(n[i], s) : ee(s) ? n[i] = we({}, s) : $(s) ? n[i] = s.slice() : (!t || !M(s)) && (n[i] = s);
  };
  for (let s = 0, o = arguments.length; s < o; s++)
    arguments[s] && v(arguments[s], r);
  return n;
}
const qt = (e, t, n, { allOwnKeys: r } = {}) => (v(t, (s, o) => {
  n && _(s) ? Object.defineProperty(e, o, { value: Ze(s, n), writable: true, enumerable: true, configurable: true }) : Object.defineProperty(e, o, { value: s, writable: true, enumerable: true, configurable: true });
}, { allOwnKeys: r }), e), Ht = (e) => (e.charCodeAt(0) === 65279 && (e = e.slice(1)), e), Mt = (e, t, n, r) => {
  e.prototype = Object.create(t.prototype, r), Object.defineProperty(e.prototype, "constructor", { value: e, writable: true, enumerable: false, configurable: true }), Object.defineProperty(e, "super", { value: t.prototype }), n && Object.assign(e.prototype, n);
}, $t = (e, t, n, r) => {
  let s, o, i;
  const c = {};
  if (t = t || {}, e == null)
    return t;
  do {
    for (s = Object.getOwnPropertyNames(e), o = s.length; o-- > 0; )
      i = s[o], (!r || r(i, e, t)) && !c[i] && (t[i] = e[i], c[i] = true);
    e = n !== false && ie(e);
  } while (e && (!n || n(e, t)) && e !== Object.prototype);
  return t;
}, zt = (e, t, n) => {
  e = String(e), (n === void 0 || n > e.length) && (n = e.length), n -= t.length;
  const r = e.indexOf(t, n);
  return r !== -1 && r === n;
}, Jt = (e) => {
  if (!e)
    return null;
  if ($(e))
    return e;
  let t = e.length;
  if (!tt(t))
    return null;
  const n = new Array(t);
  for (; t-- > 0; )
    n[t] = e[t];
  return n;
}, Vt = ((e) => (t) => e && t instanceof e)(typeof Uint8Array < "u" && ie(Uint8Array)), Wt = (e, t) => {
  const r = (e && e[ae]).call(e);
  let s;
  for (; (s = r.next()) && !s.done; ) {
    const o = s.value;
    t.call(e, o[0], o[1]);
  }
}, Kt = (e, t) => {
  let n;
  const r = [];
  for (; (n = e.exec(t)) !== null; )
    r.push(n);
  return r;
}, vt = D("HTMLFormElement"), Xt = (e) => e.toLowerCase().replace(/[-_\s]([a-z\d])(\w*)/g, function(n, r, s) {
  return r.toUpperCase() + s;
}), je = (({ hasOwnProperty: e }) => (t, n) => e.call(t, n))(Object.prototype), Gt = D("RegExp"), st = (e, t) => {
  const n = Object.getOwnPropertyDescriptors(e), r = {};
  v(n, (s, o) => {
    let i;
    (i = t(s, o, e)) !== false && (r[o] = i || s);
  }), Object.defineProperties(e, r);
}, Qt = (e) => {
  st(e, (t, n) => {
    if (_(e) && ["arguments", "caller", "callee"].indexOf(n) !== -1)
      return false;
    const r = e[n];
    if (_(r)) {
      if (t.enumerable = false, "writable" in t) {
        t.writable = false;
        return;
      }
      t.set || (t.set = () => {
        throw Error("Can not rewrite read-only method '" + n + "'");
      });
    }
  });
}, Zt = (e, t) => {
  const n = {}, r = (s) => {
    s.forEach((o) => {
      n[o] = true;
    });
  };
  return $(e) ? r(e) : r(String(e).split(t)), n;
}, Yt = () => {
}, en = (e, t) => e != null && Number.isFinite(e = +e) ? e : t;
function tn(e) {
  return !!(e && _(e.append) && e[Ye] === "FormData" && e[ae]);
}
const nn = (e) => {
  const t = new Array(10), n = (r, s) => {
    if (K(r)) {
      if (t.indexOf(r) >= 0)
        return;
      if (W(r))
        return r;
      if (!("toJSON" in r)) {
        t[s] = r;
        const o = $(r) ? [] : {};
        return v(r, (i, c) => {
          const d = n(i, s + 1);
          !M(d) && (o[c] = d);
        }), t[s] = void 0, o;
      }
    }
    return r;
  };
  return n(e, 0);
}, rn = D("AsyncFunction"), sn = (e) => e && (K(e) || _(e)) && _(e.then) && _(e.catch), ot = ((e, t) => e ? setImmediate : t ? ((n, r) => (j.addEventListener("message", ({ source: s, data: o }) => {
  s === j && o === n && r.length && r.shift()();
}, false), (s) => {
  r.push(s), j.postMessage(n, "*");
}))("axios@".concat(Math.random()), []) : (n) => setTimeout(n))(typeof setImmediate == "function", _(j.postMessage)), on = typeof queueMicrotask < "u" ? queueMicrotask.bind(j) : typeof process < "u" && process.nextTick || ot, an = (e) => e != null && _(e[ae]), a = { isArray: $, isArrayBuffer: et, isBuffer: W, isFormData: Dt, isArrayBufferView: Rt, isString: gt, isNumber: tt, isBoolean: Ot, isObject: K, isPlainObject: ee, isEmptyObject: St, isReadableStream: Lt, isRequest: Bt, isResponse: kt, isHeaders: jt, isUndefined: M, isDate: Tt, isFile: At, isReactNativeBlob: xt, isReactNative: _t, isBlob: Ct, isRegExp: Gt, isFunction: _, isStream: Nt, isURLSearchParams: Ut, isTypedArray: Vt, isFileList: Pt, forEach: v, merge: we, extend: qt, trim: It, stripBOM: Ht, inherits: Mt, toFlatObject: $t, kindOf: ce, kindOfTest: D, endsWith: zt, toArray: Jt, forEachEntry: Wt, matchAll: Kt, isHTMLForm: vt, hasOwnProperty: je, hasOwnProp: je, reduceDescriptors: st, freezeMethods: Qt, toObjectSet: Zt, toCamelCase: Xt, noop: Yt, toFiniteNumber: en, findKey: nt, global: j, isContextDefined: rt, isSpecCompliantForm: tn, toJSONObject: nn, isAsyncFn: rn, isThenable: sn, setImmediate: ot, asap: on, isIterable: an };
class T extends Error {
  static from(t, n, r, s, o, i) {
    const c = new T(t.message, n || t.code, r, s, o);
    return c.cause = t, c.name = t.name, t.status != null && c.status == null && (c.status = t.status), i && Object.assign(c, i), c;
  }
  constructor(t, n, r, s, o) {
    super(t), Object.defineProperty(this, "message", { value: t, enumerable: true, writable: true, configurable: true }), this.name = "AxiosError", this.isAxiosError = true, n && (this.code = n), r && (this.config = r), s && (this.request = s), o && (this.response = o, this.status = o.status);
  }
  toJSON() {
    return { message: this.message, name: this.name, description: this.description, number: this.number, fileName: this.fileName, lineNumber: this.lineNumber, columnNumber: this.columnNumber, stack: this.stack, config: a.toJSONObject(this.config), code: this.code, status: this.status };
  }
}
T.ERR_BAD_OPTION_VALUE = "ERR_BAD_OPTION_VALUE";
T.ERR_BAD_OPTION = "ERR_BAD_OPTION";
T.ECONNABORTED = "ECONNABORTED";
T.ETIMEDOUT = "ETIMEDOUT";
T.ERR_NETWORK = "ERR_NETWORK";
T.ERR_FR_TOO_MANY_REDIRECTS = "ERR_FR_TOO_MANY_REDIRECTS";
T.ERR_DEPRECATED = "ERR_DEPRECATED";
T.ERR_BAD_RESPONSE = "ERR_BAD_RESPONSE";
T.ERR_BAD_REQUEST = "ERR_BAD_REQUEST";
T.ERR_CANCELED = "ERR_CANCELED";
T.ERR_NOT_SUPPORT = "ERR_NOT_SUPPORT";
T.ERR_INVALID_URL = "ERR_INVALID_URL";
T.ERR_FORM_DATA_DEPTH_EXCEEDED = "ERR_FORM_DATA_DEPTH_EXCEEDED";
const y = T, cn = null;
function Ee(e) {
  return a.isPlainObject(e) || a.isArray(e);
}
function it(e) {
  return a.endsWith(e, "[]") ? e.slice(0, -2) : e;
}
function he(e, t, n) {
  return e ? e.concat(t).map(function(s, o) {
    return s = it(s), !n && o ? "[" + s + "]" : s;
  }).join(n ? "." : "") : t;
}
function ln(e) {
  return a.isArray(e) && !e.some(Ee);
}
const un = a.toFlatObject(a, {}, null, function(t) {
  return /^is[A-Z]/.test(t);
});
function ue(e, t, n) {
  if (!a.isObject(e))
    throw new TypeError("target must be an object");
  t = t || new FormData(), n = a.toFlatObject(n, { metaTokens: true, dots: false, indexes: false }, false, function(f, w) {
    return !a.isUndefined(w[f]);
  });
  const r = n.metaTokens, s = n.visitor || m, o = n.dots, i = n.indexes, c = n.Blob || typeof Blob < "u" && Blob, d = n.maxDepth === void 0 ? 100 : n.maxDepth, u = c && a.isSpecCompliantForm(t);
  if (!a.isFunction(s))
    throw new TypeError("visitor must be a function");
  function l(p) {
    if (p === null)
      return "";
    if (a.isDate(p))
      return p.toISOString();
    if (a.isBoolean(p))
      return p.toString();
    if (!u && a.isBlob(p))
      throw new y("Blob is not supported. Use a Buffer instead.");
    return a.isArrayBuffer(p) || a.isTypedArray(p) ? u && typeof Blob == "function" ? new Blob([p]) : Buffer.from(p) : p;
  }
  function m(p, f, w) {
    let U = p;
    if (a.isReactNative(t) && a.isReactNativeBlob(p))
      return t.append(he(w, f, o), l(p)), false;
    if (p && !w && typeof p == "object") {
      if (a.endsWith(f, "{}"))
        f = r ? f : f.slice(0, -2), p = JSON.stringify(p);
      else if (a.isArray(p) && ln(p) || (a.isFileList(p) || a.endsWith(f, "[]")) && (U = a.toArray(p)))
        return f = it(f), U.forEach(function(R, A) {
          !(a.isUndefined(R) || R === null) && t.append(i === true ? he([f], A, o) : i === null ? f : f + "[]", l(R));
        }), false;
    }
    return Ee(p) ? true : (t.append(he(w, f, o), l(p)), false);
  }
  const b = [], E = Object.assign(un, { defaultVisitor: m, convertValue: l, isVisitable: Ee });
  function h(p, f, w = 0) {
    if (!a.isUndefined(p)) {
      if (w > d)
        throw new y("Object is too deeply nested (" + w + " levels). Max depth: " + d, y.ERR_FORM_DATA_DEPTH_EXCEEDED);
      if (b.indexOf(p) !== -1)
        throw Error("Circular reference detected in " + f.join("."));
      b.push(p), a.forEach(p, function(O, R) {
        (!(a.isUndefined(O) || O === null) && s.call(t, O, a.isString(R) ? R.trim() : R, f, E)) === true && h(O, f ? f.concat(R) : [R], w + 1);
      }), b.pop();
    }
  }
  if (!a.isObject(e))
    throw new TypeError("data must be an object");
  return h(e), t;
}
function Ie(e) {
  const t = { "!": "%21", "'": "%27", "(": "%28", ")": "%29", "~": "%7E", "%20": "+" };
  return encodeURIComponent(e).replace(/[!'()~]|%20/g, function(r) {
    return t[r];
  });
}
function Oe(e, t) {
  this._pairs = [], e && ue(e, this, t);
}
const at = Oe.prototype;
at.append = function(t, n) {
  this._pairs.push([t, n]);
};
at.toString = function(t) {
  const n = t ? function(r) {
    return t.call(this, r, Ie);
  } : Ie;
  return this._pairs.map(function(s) {
    return n(s[0]) + "=" + n(s[1]);
  }, "").join("&");
};
function fn(e) {
  return encodeURIComponent(e).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+");
}
function ct(e, t, n) {
  if (!t)
    return e;
  const r = n && n.encode || fn, s = a.isFunction(n) ? { serialize: n } : n, o = s && s.serialize;
  let i;
  if (o ? i = o(t, s) : i = a.isURLSearchParams(t) ? t.toString() : new Oe(t, s).toString(r), i) {
    const c = e.indexOf("#");
    c !== -1 && (e = e.slice(0, c)), e += (e.indexOf("?") === -1 ? "?" : "&") + i;
  }
  return e;
}
class dn {
  constructor() {
    this.handlers = [];
  }
  use(t, n, r) {
    return this.handlers.push({ fulfilled: t, rejected: n, synchronous: r ? r.synchronous : false, runWhen: r ? r.runWhen : null }), this.handlers.length - 1;
  }
  eject(t) {
    this.handlers[t] && (this.handlers[t] = null);
  }
  clear() {
    this.handlers && (this.handlers = []);
  }
  forEach(t) {
    a.forEach(this.handlers, function(r) {
      r !== null && t(r);
    });
  }
}
const qe = dn, Se = { silentJSONParsing: true, forcedJSONParsing: true, clarifyTimeoutError: false, legacyInterceptorReqResOrdering: true }, pn = typeof URLSearchParams < "u" ? URLSearchParams : Oe, hn = typeof FormData < "u" ? FormData : null, mn = typeof Blob < "u" ? Blob : null, yn = { isBrowser: true, classes: { URLSearchParams: pn, FormData: hn, Blob: mn }, protocols: ["http", "https", "file", "blob", "url", "data"] }, Te = typeof window < "u" && typeof document < "u", Re = typeof navigator == "object" && navigator || void 0, bn = Te && (!Re || ["ReactNative", "NativeScript", "NS"].indexOf(Re.product) < 0), wn = (() => typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope && typeof self.importScripts == "function")(), En = Te && window.location.href || "http://localhost", Rn = Object.freeze(Object.defineProperty({ __proto__: null, hasBrowserEnv: Te, hasStandardBrowserEnv: bn, hasStandardBrowserWebWorkerEnv: wn, navigator: Re, origin: En }, Symbol.toStringTag, { value: "Module" })), S = { ...Rn, ...yn };
function gn(e, t) {
  return ue(e, new S.classes.URLSearchParams(), { visitor: function(n, r, s, o) {
    return S.isNode && a.isBuffer(n) ? (this.append(r, n.toString("base64")), false) : o.defaultVisitor.apply(this, arguments);
  }, ...t });
}
function On(e) {
  return a.matchAll(/\w+|\[(\w*)]/g, e).map((t) => t[0] === "[]" ? "" : t[1] || t[0]);
}
function Sn(e) {
  const t = {}, n = Object.keys(e);
  let r;
  const s = n.length;
  let o;
  for (r = 0; r < s; r++)
    o = n[r], t[o] = e[o];
  return t;
}
function lt(e) {
  function t(n, r, s, o) {
    let i = n[o++];
    if (i === "__proto__")
      return true;
    const c = Number.isFinite(+i), d = o >= n.length;
    return i = !i && a.isArray(s) ? s.length : i, d ? (a.hasOwnProp(s, i) ? s[i] = a.isArray(s[i]) ? s[i].concat(r) : [s[i], r] : s[i] = r, !c) : ((!s[i] || !a.isObject(s[i])) && (s[i] = []), t(n, r, s[i], o) && a.isArray(s[i]) && (s[i] = Sn(s[i])), !c);
  }
  if (a.isFormData(e) && a.isFunction(e.entries)) {
    const n = {};
    return a.forEachEntry(e, (r, s) => {
      t(On(r), s, n, 0);
    }), n;
  }
  return null;
}
const H = (e, t) => e != null && a.hasOwnProp(e, t) ? e[t] : void 0;
function Tn(e, t, n) {
  if (a.isString(e))
    try {
      return (t || JSON.parse)(e), a.trim(e);
    } catch (r) {
      if (r.name !== "SyntaxError")
        throw r;
    }
  return (n || JSON.stringify)(e);
}
const Ae = { transitional: Se, adapter: ["xhr", "http", "fetch"], transformRequest: [function(t, n) {
  const r = n.getContentType() || "", s = r.indexOf("application/json") > -1, o = a.isObject(t);
  if (o && a.isHTMLForm(t) && (t = new FormData(t)), a.isFormData(t))
    return s ? JSON.stringify(lt(t)) : t;
  if (a.isArrayBuffer(t) || a.isBuffer(t) || a.isStream(t) || a.isFile(t) || a.isBlob(t) || a.isReadableStream(t))
    return t;
  if (a.isArrayBufferView(t))
    return t.buffer;
  if (a.isURLSearchParams(t))
    return n.setContentType("application/x-www-form-urlencoded;charset=utf-8", false), t.toString();
  let c;
  if (o) {
    const d = H(this, "formSerializer");
    if (r.indexOf("application/x-www-form-urlencoded") > -1)
      return gn(t, d).toString();
    if ((c = a.isFileList(t)) || r.indexOf("multipart/form-data") > -1) {
      const u = H(this, "env"), l = u && u.FormData;
      return ue(c ? { "files[]": t } : t, l && new l(), d);
    }
  }
  return o || s ? (n.setContentType("application/json", false), Tn(t)) : t;
}], transformResponse: [function(t) {
  const n = H(this, "transitional") || Ae.transitional, r = n && n.forcedJSONParsing, s = H(this, "responseType"), o = s === "json";
  if (a.isResponse(t) || a.isReadableStream(t))
    return t;
  if (t && a.isString(t) && (r && !s || o)) {
    const c = !(n && n.silentJSONParsing) && o;
    try {
      return JSON.parse(t, H(this, "parseReviver"));
    } catch (d) {
      if (c)
        throw d.name === "SyntaxError" ? y.from(d, y.ERR_BAD_RESPONSE, this, null, H(this, "response")) : d;
    }
  }
  return t;
}], timeout: 0, xsrfCookieName: "XSRF-TOKEN", xsrfHeaderName: "X-XSRF-TOKEN", maxContentLength: -1, maxBodyLength: -1, env: { FormData: S.classes.FormData, Blob: S.classes.Blob }, validateStatus: function(t) {
  return t >= 200 && t < 300;
}, headers: { common: { Accept: "application/json, text/plain, */*", "Content-Type": void 0 } } };
a.forEach(["delete", "get", "head", "post", "put", "patch"], (e) => {
  Ae.headers[e] = {};
});
const xe = Ae, An = a.toObjectSet(["age", "authorization", "content-length", "content-type", "etag", "expires", "from", "host", "if-modified-since", "if-unmodified-since", "last-modified", "location", "max-forwards", "proxy-authorization", "referer", "retry-after", "user-agent"]), xn = (e) => {
  const t = {};
  let n, r, s;
  return e && e.split("\n").forEach(function(i) {
    s = i.indexOf(":"), n = i.substring(0, s).trim().toLowerCase(), r = i.substring(s + 1).trim(), !(!n || t[n] && An[n]) && (n === "set-cookie" ? t[n] ? t[n].push(r) : t[n] = [r] : t[n] = t[n] ? t[n] + ", " + r : r);
  }), t;
}, He = Symbol("internals"), _n = /[^\x09\x20-\x7E\x80-\xFF]/g;
function Cn(e) {
  let t = 0, n = e.length;
  for (; t < n; ) {
    const r = e.charCodeAt(t);
    if (r !== 9 && r !== 32)
      break;
    t += 1;
  }
  for (; n > t; ) {
    const r = e.charCodeAt(n - 1);
    if (r !== 9 && r !== 32)
      break;
    n -= 1;
  }
  return t === 0 && n === e.length ? e : e.slice(t, n);
}
function V(e) {
  return e && String(e).trim().toLowerCase();
}
function Pn(e) {
  return Cn(e.replace(_n, ""));
}
function te(e) {
  return e === false || e == null ? e : a.isArray(e) ? e.map(te) : Pn(String(e));
}
function Nn(e) {
  const t = /* @__PURE__ */ Object.create(null), n = /([^\s,;=]+)\s*(?:=\s*([^,;]+))?/g;
  let r;
  for (; r = n.exec(e); )
    t[r[1]] = r[2];
  return t;
}
const Fn = (e) => /^[-_a-zA-Z0-9^`|~,!#$%&'*+.]+$/.test(e.trim());
function me(e, t, n, r, s) {
  if (a.isFunction(r))
    return r.call(this, t, n);
  if (s && (t = n), !!a.isString(t)) {
    if (a.isString(r))
      return t.indexOf(r) !== -1;
    if (a.isRegExp(r))
      return r.test(t);
  }
}
function Dn(e) {
  return e.trim().toLowerCase().replace(/([a-z\d])(\w*)/g, (t, n, r) => n.toUpperCase() + r);
}
function Un(e, t) {
  const n = a.toCamelCase(" " + t);
  ["get", "set", "has"].forEach((r) => {
    Object.defineProperty(e, r + n, { value: function(s, o, i) {
      return this[r].call(this, t, s, o, i);
    }, configurable: true });
  });
}
class fe {
  constructor(t) {
    t && this.set(t);
  }
  set(t, n, r) {
    const s = this;
    function o(c, d, u) {
      const l = V(d);
      if (!l)
        throw new Error("header name must be a non-empty string");
      const m = a.findKey(s, l);
      (!m || s[m] === void 0 || u === true || u === void 0 && s[m] !== false) && (s[m || d] = te(c));
    }
    const i = (c, d) => a.forEach(c, (u, l) => o(u, l, d));
    if (a.isPlainObject(t) || t instanceof this.constructor)
      i(t, n);
    else if (a.isString(t) && (t = t.trim()) && !Fn(t))
      i(xn(t), n);
    else if (a.isObject(t) && a.isIterable(t)) {
      let c = {}, d, u;
      for (const l of t) {
        if (!a.isArray(l))
          throw TypeError("Object iterator must return a key-value pair");
        c[u = l[0]] = (d = c[u]) ? a.isArray(d) ? [...d, l[1]] : [d, l[1]] : l[1];
      }
      i(c, n);
    } else
      t != null && o(n, t, r);
    return this;
  }
  get(t, n) {
    if (t = V(t), t) {
      const r = a.findKey(this, t);
      if (r) {
        const s = this[r];
        if (!n)
          return s;
        if (n === true)
          return Nn(s);
        if (a.isFunction(n))
          return n.call(this, s, r);
        if (a.isRegExp(n))
          return n.exec(s);
        throw new TypeError("parser must be boolean|regexp|function");
      }
    }
  }
  has(t, n) {
    if (t = V(t), t) {
      const r = a.findKey(this, t);
      return !!(r && this[r] !== void 0 && (!n || me(this, this[r], r, n)));
    }
    return false;
  }
  delete(t, n) {
    const r = this;
    let s = false;
    function o(i) {
      if (i = V(i), i) {
        const c = a.findKey(r, i);
        c && (!n || me(r, r[c], c, n)) && (delete r[c], s = true);
      }
    }
    return a.isArray(t) ? t.forEach(o) : o(t), s;
  }
  clear(t) {
    const n = Object.keys(this);
    let r = n.length, s = false;
    for (; r--; ) {
      const o = n[r];
      (!t || me(this, this[o], o, t, true)) && (delete this[o], s = true);
    }
    return s;
  }
  normalize(t) {
    const n = this, r = {};
    return a.forEach(this, (s, o) => {
      const i = a.findKey(r, o);
      if (i) {
        n[i] = te(s), delete n[o];
        return;
      }
      const c = t ? Dn(o) : String(o).trim();
      c !== o && delete n[o], n[c] = te(s), r[c] = true;
    }), this;
  }
  concat(...t) {
    return this.constructor.concat(this, ...t);
  }
  toJSON(t) {
    const n = /* @__PURE__ */ Object.create(null);
    return a.forEach(this, (r, s) => {
      r != null && r !== false && (n[s] = t && a.isArray(r) ? r.join(", ") : r);
    }), n;
  }
  [Symbol.iterator]() {
    return Object.entries(this.toJSON())[Symbol.iterator]();
  }
  toString() {
    return Object.entries(this.toJSON()).map(([t, n]) => t + ": " + n).join("\n");
  }
  getSetCookie() {
    return this.get("set-cookie") || [];
  }
  get [Symbol.toStringTag]() {
    return "AxiosHeaders";
  }
  static from(t) {
    return t instanceof this ? t : new this(t);
  }
  static concat(t, ...n) {
    const r = new this(t);
    return n.forEach((s) => r.set(s)), r;
  }
  static accessor(t) {
    const r = (this[He] = this[He] = { accessors: {} }).accessors, s = this.prototype;
    function o(i) {
      const c = V(i);
      r[c] || (Un(s, i), r[c] = true);
    }
    return a.isArray(t) ? t.forEach(o) : o(t), this;
  }
}
fe.accessor(["Content-Type", "Content-Length", "Accept", "Accept-Encoding", "User-Agent", "Authorization"]);
a.reduceDescriptors(fe.prototype, ({ value: e }, t) => {
  let n = t[0].toUpperCase() + t.slice(1);
  return { get: () => e, set(r) {
    this[n] = r;
  } };
});
a.freezeMethods(fe);
const F = fe;
function ye(e, t) {
  const n = this || xe, r = t || n, s = F.from(r.headers);
  let o = r.data;
  return a.forEach(e, function(c) {
    o = c.call(n, o, s.normalize(), t ? t.status : void 0);
  }), s.normalize(), o;
}
function ut(e) {
  return !!(e && e.__CANCEL__);
}
class Ln extends y {
  constructor(t, n, r) {
    super(t != null ? t : "canceled", y.ERR_CANCELED, n, r), this.name = "CanceledError", this.__CANCEL__ = true;
  }
}
const X = Ln;
function ft(e, t, n) {
  const r = n.config.validateStatus;
  !n.status || !r || r(n.status) ? e(n) : t(new y("Request failed with status code " + n.status, [y.ERR_BAD_REQUEST, y.ERR_BAD_RESPONSE][Math.floor(n.status / 100) - 4], n.config, n.request, n));
}
function Bn(e) {
  const t = /^([-+\w]{1,25})(:?\/\/|:)/.exec(e);
  return t && t[1] || "";
}
function kn(e, t) {
  e = e || 10;
  const n = new Array(e), r = new Array(e);
  let s = 0, o = 0, i;
  return t = t !== void 0 ? t : 1e3, function(d) {
    const u = Date.now(), l = r[o];
    i || (i = u), n[s] = d, r[s] = u;
    let m = o, b = 0;
    for (; m !== s; )
      b += n[m++], m = m % e;
    if (s = (s + 1) % e, s === o && (o = (o + 1) % e), u - i < t)
      return;
    const E = l && u - l;
    return E ? Math.round(b * 1e3 / E) : void 0;
  };
}
function jn(e, t) {
  let n = 0, r = 1e3 / t, s, o;
  const i = (u, l = Date.now()) => {
    n = l, s = null, o && (clearTimeout(o), o = null), e(...u);
  };
  return [(...u) => {
    const l = Date.now(), m = l - n;
    m >= r ? i(u, l) : (s = u, o || (o = setTimeout(() => {
      o = null, i(s);
    }, r - m)));
  }, () => s && i(s)];
}
const se = (e, t, n = 3) => {
  let r = 0;
  const s = kn(50, 250);
  return jn((o) => {
    const i = o.loaded, c = o.lengthComputable ? o.total : void 0, d = c != null ? Math.min(i, c) : i, u = Math.max(0, d - r), l = s(u);
    r = Math.max(r, d);
    const m = { loaded: d, total: c, progress: c ? d / c : void 0, bytes: u, rate: l || void 0, estimated: l && c ? (c - d) / l : void 0, event: o, lengthComputable: c != null, [t ? "download" : "upload"]: true };
    e(m);
  }, n);
}, Me = (e, t) => {
  const n = e != null;
  return [(r) => t[0]({ lengthComputable: n, total: e, loaded: r }), t[1]];
}, $e = (e) => (...t) => a.asap(() => e(...t)), In = S.hasStandardBrowserEnv ? ((e, t) => (n) => (n = new URL(n, S.origin), e.protocol === n.protocol && e.host === n.host && (t || e.port === n.port)))(new URL(S.origin), S.navigator && /(msie|trident)/i.test(S.navigator.userAgent)) : () => true, qn = S.hasStandardBrowserEnv ? { write(e, t, n, r, s, o, i) {
  if (typeof document > "u")
    return;
  const c = ["".concat(e, "=").concat(encodeURIComponent(t))];
  a.isNumber(n) && c.push("expires=".concat(new Date(n).toUTCString())), a.isString(r) && c.push("path=".concat(r)), a.isString(s) && c.push("domain=".concat(s)), o === true && c.push("secure"), a.isString(i) && c.push("SameSite=".concat(i)), document.cookie = c.join("; ");
}, read(e) {
  if (typeof document > "u")
    return null;
  const t = document.cookie.match(new RegExp("(?:^|; )" + e + "=([^;]*)"));
  return t ? decodeURIComponent(t[1]) : null;
}, remove(e) {
  this.write(e, "", Date.now() - 864e5, "/");
} } : { write() {
}, read() {
  return null;
}, remove() {
} };
function Hn(e) {
  return typeof e != "string" ? false : /^([a-z][a-z\d+\-.]*:)?\/\//i.test(e);
}
function Mn(e, t) {
  return t ? e.replace(/\/?\/$/, "") + "/" + t.replace(/^\/+/, "") : e;
}
function dt(e, t, n) {
  let r = !Hn(t);
  return e && (r || n === false) ? Mn(e, t) : t;
}
const ze = (e) => e instanceof F ? { ...e } : e;
function I(e, t) {
  t = t || {};
  const n = /* @__PURE__ */ Object.create(null);
  Object.defineProperty(n, "hasOwnProperty", { value: Object.prototype.hasOwnProperty, enumerable: false, writable: true, configurable: true });
  function r(u, l, m, b) {
    return a.isPlainObject(u) && a.isPlainObject(l) ? a.merge.call({ caseless: b }, u, l) : a.isPlainObject(l) ? a.merge({}, l) : a.isArray(l) ? l.slice() : l;
  }
  function s(u, l, m, b) {
    if (a.isUndefined(l)) {
      if (!a.isUndefined(u))
        return r(void 0, u, m, b);
    } else
      return r(u, l, m, b);
  }
  function o(u, l) {
    if (!a.isUndefined(l))
      return r(void 0, l);
  }
  function i(u, l) {
    if (a.isUndefined(l)) {
      if (!a.isUndefined(u))
        return r(void 0, u);
    } else
      return r(void 0, l);
  }
  function c(u, l, m) {
    if (a.hasOwnProp(t, m))
      return r(u, l);
    if (a.hasOwnProp(e, m))
      return r(void 0, u);
  }
  const d = { url: o, method: o, data: o, baseURL: i, transformRequest: i, transformResponse: i, paramsSerializer: i, timeout: i, timeoutMessage: i, withCredentials: i, withXSRFToken: i, adapter: i, responseType: i, xsrfCookieName: i, xsrfHeaderName: i, onUploadProgress: i, onDownloadProgress: i, decompress: i, maxContentLength: i, maxBodyLength: i, beforeRedirect: i, transport: i, httpAgent: i, httpsAgent: i, cancelToken: i, socketPath: i, allowedSocketPaths: i, responseEncoding: i, validateStatus: c, headers: (u, l, m) => s(ze(u), ze(l), m, true) };
  return a.forEach(Object.keys({ ...e, ...t }), function(l) {
    if (l === "__proto__" || l === "constructor" || l === "prototype")
      return;
    const m = a.hasOwnProp(d, l) ? d[l] : s, b = a.hasOwnProp(e, l) ? e[l] : void 0, E = a.hasOwnProp(t, l) ? t[l] : void 0, h = m(b, E, l);
    a.isUndefined(h) && m !== c || (n[l] = h);
  }), n;
}
const pt = (e) => {
  const t = I({}, e), n = (b) => a.hasOwnProp(t, b) ? t[b] : void 0, r = n("data");
  let s = n("withXSRFToken");
  const o = n("xsrfHeaderName"), i = n("xsrfCookieName");
  let c = n("headers");
  const d = n("auth"), u = n("baseURL"), l = n("allowAbsoluteUrls"), m = n("url");
  if (t.headers = c = F.from(c), t.url = ct(dt(u, m, l), e.params, e.paramsSerializer), d && c.set("Authorization", "Basic " + btoa((d.username || "") + ":" + (d.password ? unescape(encodeURIComponent(d.password)) : ""))), a.isFormData(r)) {
    if (S.hasStandardBrowserEnv || S.hasStandardBrowserWebWorkerEnv)
      c.setContentType(void 0);
    else if (a.isFunction(r.getHeaders)) {
      const b = r.getHeaders(), E = ["content-type", "content-length"];
      Object.entries(b).forEach(([h, p]) => {
        E.includes(h.toLowerCase()) && c.set(h, p);
      });
    }
  }
  if (S.hasStandardBrowserEnv && (a.isFunction(s) && (s = s(t)), s === true || s == null && In(t.url))) {
    const E = o && i && qn.read(i);
    E && c.set(o, E);
  }
  return t;
}, $n = typeof XMLHttpRequest < "u", zn = $n && function(e) {
  return new Promise(function(n, r) {
    const s = pt(e);
    let o = s.data;
    const i = F.from(s.headers).normalize();
    let { responseType: c, onUploadProgress: d, onDownloadProgress: u } = s, l, m, b, E, h;
    function p() {
      E && E(), h && h(), s.cancelToken && s.cancelToken.unsubscribe(l), s.signal && s.signal.removeEventListener("abort", l);
    }
    let f = new XMLHttpRequest();
    f.open(s.method.toUpperCase(), s.url, true), f.timeout = s.timeout;
    function w() {
      if (!f)
        return;
      const O = F.from("getAllResponseHeaders" in f && f.getAllResponseHeaders()), A = { data: !c || c === "text" || c === "json" ? f.responseText : f.response, status: f.status, statusText: f.statusText, headers: O, config: e, request: f };
      ft(function(C) {
        n(C), p();
      }, function(C) {
        r(C), p();
      }, A), f = null;
    }
    "onloadend" in f ? f.onloadend = w : f.onreadystatechange = function() {
      !f || f.readyState !== 4 || f.status === 0 && !(f.responseURL && f.responseURL.indexOf("file:") === 0) || setTimeout(w);
    }, f.onabort = function() {
      f && (r(new y("Request aborted", y.ECONNABORTED, e, f)), f = null);
    }, f.onerror = function(R) {
      const A = R && R.message ? R.message : "Network Error", B = new y(A, y.ERR_NETWORK, e, f);
      B.event = R || null, r(B), f = null;
    }, f.ontimeout = function() {
      let R = s.timeout ? "timeout of " + s.timeout + "ms exceeded" : "timeout exceeded";
      const A = s.transitional || Se;
      s.timeoutErrorMessage && (R = s.timeoutErrorMessage), r(new y(R, A.clarifyTimeoutError ? y.ETIMEDOUT : y.ECONNABORTED, e, f)), f = null;
    }, o === void 0 && i.setContentType(null), "setRequestHeader" in f && a.forEach(i.toJSON(), function(R, A) {
      f.setRequestHeader(A, R);
    }), a.isUndefined(s.withCredentials) || (f.withCredentials = !!s.withCredentials), c && c !== "json" && (f.responseType = s.responseType), u && ([b, h] = se(u, true), f.addEventListener("progress", b)), d && f.upload && ([m, E] = se(d), f.upload.addEventListener("progress", m), f.upload.addEventListener("loadend", E)), (s.cancelToken || s.signal) && (l = (O) => {
      f && (r(!O || O.type ? new X(null, e, f) : O), f.abort(), f = null);
    }, s.cancelToken && s.cancelToken.subscribe(l), s.signal && (s.signal.aborted ? l() : s.signal.addEventListener("abort", l)));
    const U = Bn(s.url);
    if (U && S.protocols.indexOf(U) === -1) {
      r(new y("Unsupported protocol " + U + ":", y.ERR_BAD_REQUEST, e));
      return;
    }
    f.send(o || null);
  });
}, Jn = (e, t) => {
  const { length: n } = e = e ? e.filter(Boolean) : [];
  if (t || n) {
    let r = new AbortController(), s;
    const o = function(u) {
      if (!s) {
        s = true, c();
        const l = u instanceof Error ? u : this.reason;
        r.abort(l instanceof y ? l : new X(l instanceof Error ? l.message : l));
      }
    };
    let i = t && setTimeout(() => {
      i = null, o(new y("timeout of ".concat(t, "ms exceeded"), y.ETIMEDOUT));
    }, t);
    const c = () => {
      e && (i && clearTimeout(i), i = null, e.forEach((u) => {
        u.unsubscribe ? u.unsubscribe(o) : u.removeEventListener("abort", o);
      }), e = null);
    };
    e.forEach((u) => u.addEventListener("abort", o));
    const { signal: d } = r;
    return d.unsubscribe = () => a.asap(c), d;
  }
}, Vn = Jn, Wn = function* (e, t) {
  let n = e.byteLength;
  if (!t || n < t) {
    yield e;
    return;
  }
  let r = 0, s;
  for (; r < n; )
    s = r + t, yield e.slice(r, s), r = s;
}, Kn = async function* (e, t) {
  for await (const n of vn(e))
    yield* Wn(n, t);
}, vn = async function* (e) {
  if (e[Symbol.asyncIterator]) {
    yield* e;
    return;
  }
  const t = e.getReader();
  try {
    for (; ; ) {
      const { done: n, value: r } = await t.read();
      if (n)
        break;
      yield r;
    }
  } finally {
    await t.cancel();
  }
}, Je = (e, t, n, r) => {
  const s = Kn(e, t);
  let o = 0, i, c = (d) => {
    i || (i = true, r && r(d));
  };
  return new ReadableStream({ async pull(d) {
    try {
      const { done: u, value: l } = await s.next();
      if (u) {
        c(), d.close();
        return;
      }
      let m = l.byteLength;
      if (n) {
        let b = o += m;
        n(b);
      }
      d.enqueue(new Uint8Array(l));
    } catch (u) {
      throw c(u), u;
    }
  }, cancel(d) {
    return c(d), s.return();
  } }, { highWaterMark: 2 });
}, Ve = 64 * 1024, { isFunction: Y } = a, Xn = (({ Request: e, Response: t }) => ({ Request: e, Response: t }))(a.global), { ReadableStream: We, TextEncoder: Ke } = a.global, ve = (e, ...t) => {
  try {
    return !!e(...t);
  } catch (e2) {
    return false;
  }
}, Gn = (e) => {
  e = a.merge.call({ skipUndefined: true }, Xn, e);
  const { fetch: t, Request: n, Response: r } = e, s = t ? Y(t) : typeof fetch == "function", o = Y(n), i = Y(r);
  if (!s)
    return false;
  const c = s && Y(We), d = s && (typeof Ke == "function" ? ((h) => (p) => h.encode(p))(new Ke()) : async (h) => new Uint8Array(await new n(h).arrayBuffer())), u = o && c && ve(() => {
    let h = false;
    const p = new n(S.origin, { body: new We(), method: "POST", get duplex() {
      return h = true, "half";
    } }), f = p.headers.has("Content-Type");
    return p.body != null && p.body.cancel(), h && !f;
  }), l = i && c && ve(() => a.isReadableStream(new r("").body)), m = { stream: l && ((h) => h.body) };
  s && ["text", "arrayBuffer", "blob", "formData", "stream"].forEach((h) => {
    !m[h] && (m[h] = (p, f) => {
      let w = p && p[h];
      if (w)
        return w.call(p);
      throw new y("Response type '".concat(h, "' is not supported"), y.ERR_NOT_SUPPORT, f);
    });
  });
  const b = async (h) => {
    if (h == null)
      return 0;
    if (a.isBlob(h))
      return h.size;
    if (a.isSpecCompliantForm(h))
      return (await new n(S.origin, { method: "POST", body: h }).arrayBuffer()).byteLength;
    if (a.isArrayBufferView(h) || a.isArrayBuffer(h))
      return h.byteLength;
    if (a.isURLSearchParams(h) && (h = h + ""), a.isString(h))
      return (await d(h)).byteLength;
  }, E = async (h, p) => {
    const f = a.toFiniteNumber(h.getContentLength());
    return f != null ? f : b(p);
  };
  return async (h) => {
    let { url: p, method: f, data: w, signal: U, cancelToken: O, timeout: R, onDownloadProgress: A, onUploadProgress: B, responseType: C, headers: z, withCredentials: G = "same-origin", fetchOptions: Pe } = pt(h), Ne = t || fetch;
    C = C ? (C + "").toLowerCase() : "text";
    let Q = Vn([U, O && O.toAbortSignal()], R), J = null;
    const k = Q && Q.unsubscribe && (() => {
      Q.unsubscribe();
    });
    let Fe;
    try {
      if (B && u && f !== "get" && f !== "head" && (Fe = await E(z, w)) !== 0) {
        let P = new n(p, { method: "POST", body: w, duplex: "half" }), q;
        if (a.isFormData(w) && (q = P.headers.get("content-type")) && z.setContentType(q), P.body) {
          const [pe, Z] = Me(Fe, se($e(B)));
          w = Je(P.body, Ve, pe, Z);
        }
      }
      a.isString(G) || (G = G ? "include" : "omit");
      const x = o && "credentials" in n.prototype;
      if (a.isFormData(w)) {
        const P = z.getContentType();
        P && /^multipart\/form-data/i.test(P) && !/boundary=/i.test(P) && z.delete("content-type");
      }
      const De = { ...Pe, signal: Q, method: f.toUpperCase(), headers: z.normalize().toJSON(), body: w, duplex: "half", credentials: x ? G : void 0 };
      J = o && new n(p, De);
      let L = await (o ? Ne(J, Pe) : Ne(p, De));
      const Ue = l && (C === "stream" || C === "response");
      if (l && (A || Ue && k)) {
        const P = {};
        ["status", "statusText", "headers"].forEach((Le) => {
          P[Le] = L[Le];
        });
        const q = a.toFiniteNumber(L.headers.get("content-length")), [pe, Z] = A && Me(q, se($e(A), true)) || [];
        L = new r(Je(L.body, Ve, pe, () => {
          Z && Z(), k && k();
        }), P);
      }
      C = C || "text";
      let wt = await m[a.findKey(m, C) || "text"](L, h);
      return !Ue && k && k(), await new Promise((P, q) => {
        ft(P, q, { data: wt, headers: F.from(L.headers), status: L.status, statusText: L.statusText, config: h, request: J });
      });
    } catch (x) {
      throw k && k(), x && x.name === "TypeError" && /Load failed|fetch/i.test(x.message) ? Object.assign(new y("Network Error", y.ERR_NETWORK, h, J, x && x.response), { cause: x.cause || x }) : y.from(x, x && x.code, h, J, x && x.response);
    }
  };
}, Qn = /* @__PURE__ */ new Map(), ht = (e) => {
  let t = e && e.env || {};
  const { fetch: n, Request: r, Response: s } = t, o = [r, s, n];
  let i = o.length, c = i, d, u, l = Qn;
  for (; c--; )
    d = o[c], u = l.get(d), u === void 0 && l.set(d, u = c ? /* @__PURE__ */ new Map() : Gn(t)), l = u;
  return u;
};
ht();
const _e = { http: cn, xhr: zn, fetch: { get: ht } };
a.forEach(_e, (e, t) => {
  if (e) {
    try {
      Object.defineProperty(e, "name", { value: t });
    } catch (e2) {
    }
    Object.defineProperty(e, "adapterName", { value: t });
  }
});
const Xe = (e) => "- ".concat(e), Zn = (e) => a.isFunction(e) || e === null || e === false;
function Yn(e, t) {
  e = a.isArray(e) ? e : [e];
  const { length: n } = e;
  let r, s;
  const o = {};
  for (let i = 0; i < n; i++) {
    r = e[i];
    let c;
    if (s = r, !Zn(r) && (s = _e[(c = String(r)).toLowerCase()], s === void 0))
      throw new y("Unknown adapter '".concat(c, "'"));
    if (s && (a.isFunction(s) || (s = s.get(t))))
      break;
    o[c || "#" + i] = s;
  }
  if (!s) {
    const i = Object.entries(o).map(([d, u]) => "adapter ".concat(d, " ") + (u === false ? "is not supported by the environment" : "is not available in the build"));
    let c = n ? i.length > 1 ? "since :\n" + i.map(Xe).join("\n") : " " + Xe(i[0]) : "as no adapter specified";
    throw new y("There is no suitable adapter to dispatch the request " + c, "ERR_NOT_SUPPORT");
  }
  return s;
}
const mt = { getAdapter: Yn, adapters: _e };
function be(e) {
  if (e.cancelToken && e.cancelToken.throwIfRequested(), e.signal && e.signal.aborted)
    throw new X(null, e);
}
function Ge(e) {
  return be(e), e.headers = F.from(e.headers), e.data = ye.call(e, e.transformRequest), ["post", "put", "patch"].indexOf(e.method) !== -1 && e.headers.setContentType("application/x-www-form-urlencoded", false), mt.getAdapter(e.adapter || xe.adapter, e)(e).then(function(r) {
    return be(e), r.data = ye.call(e, e.transformResponse, r), r.headers = F.from(r.headers), r;
  }, function(r) {
    return ut(r) || (be(e), r && r.response && (r.response.data = ye.call(e, e.transformResponse, r.response), r.response.headers = F.from(r.response.headers))), Promise.reject(r);
  });
}
const yt = "1.15.2", de = {};
["object", "boolean", "number", "function", "string", "symbol"].forEach((e, t) => {
  de[e] = function(r) {
    return typeof r === e || "a" + (t < 1 ? "n " : " ") + e;
  };
});
const Qe = {};
de.transitional = function(t, n, r) {
  function s(o, i) {
    return "[Axios v" + yt + "] Transitional option '" + o + "'" + i + (r ? ". " + r : "");
  }
  return (o, i, c) => {
    if (t === false)
      throw new y(s(i, " has been removed" + (n ? " in " + n : "")), y.ERR_DEPRECATED);
    return n && !Qe[i] && (Qe[i] = true, console.warn(s(i, " has been deprecated since v" + n + " and will be removed in the near future"))), t ? t(o, i, c) : true;
  };
};
de.spelling = function(t) {
  return (n, r) => (console.warn("".concat(r, " is likely a misspelling of ").concat(t)), true);
};
function er(e, t, n) {
  if (typeof e != "object")
    throw new y("options must be an object", y.ERR_BAD_OPTION_VALUE);
  const r = Object.keys(e);
  let s = r.length;
  for (; s-- > 0; ) {
    const o = r[s], i = Object.prototype.hasOwnProperty.call(t, o) ? t[o] : void 0;
    if (i) {
      const c = e[o], d = c === void 0 || i(c, o, e);
      if (d !== true)
        throw new y("option " + o + " must be " + d, y.ERR_BAD_OPTION_VALUE);
      continue;
    }
    if (n !== true)
      throw new y("Unknown option " + o, y.ERR_BAD_OPTION);
  }
}
const ne = { assertOptions: er, validators: de }, N = ne.validators;
class oe {
  constructor(t) {
    this.defaults = t || {}, this.interceptors = { request: new qe(), response: new qe() };
  }
  async request(t, n) {
    try {
      return await this._request(t, n);
    } catch (r) {
      if (r instanceof Error) {
        let s = {};
        Error.captureStackTrace ? Error.captureStackTrace(s) : s = new Error();
        const o = (() => {
          if (!s.stack)
            return "";
          const i = s.stack.indexOf("\n");
          return i === -1 ? "" : s.stack.slice(i + 1);
        })();
        try {
          if (!r.stack)
            r.stack = o;
          else if (o) {
            const i = o.indexOf("\n"), c = i === -1 ? -1 : o.indexOf("\n", i + 1), d = c === -1 ? "" : o.slice(c + 1);
            String(r.stack).endsWith(d) || (r.stack += "\n" + o);
          }
        } catch (e) {
        }
      }
      throw r;
    }
  }
  _request(t, n) {
    typeof t == "string" ? (n = n || {}, n.url = t) : n = t || {}, n = I(this.defaults, n);
    const { transitional: r, paramsSerializer: s, headers: o } = n;
    r !== void 0 && ne.assertOptions(r, { silentJSONParsing: N.transitional(N.boolean), forcedJSONParsing: N.transitional(N.boolean), clarifyTimeoutError: N.transitional(N.boolean), legacyInterceptorReqResOrdering: N.transitional(N.boolean) }, false), s != null && (a.isFunction(s) ? n.paramsSerializer = { serialize: s } : ne.assertOptions(s, { encode: N.function, serialize: N.function }, true)), n.allowAbsoluteUrls !== void 0 || (this.defaults.allowAbsoluteUrls !== void 0 ? n.allowAbsoluteUrls = this.defaults.allowAbsoluteUrls : n.allowAbsoluteUrls = true), ne.assertOptions(n, { baseUrl: N.spelling("baseURL"), withXsrfToken: N.spelling("withXSRFToken") }, true), n.method = (n.method || this.defaults.method || "get").toLowerCase();
    let i = o && a.merge(o.common, o[n.method]);
    o && a.forEach(["delete", "get", "head", "post", "put", "patch", "common"], (h) => {
      delete o[h];
    }), n.headers = F.concat(i, o);
    const c = [];
    let d = true;
    this.interceptors.request.forEach(function(p) {
      if (typeof p.runWhen == "function" && p.runWhen(n) === false)
        return;
      d = d && p.synchronous;
      const f = n.transitional || Se;
      f && f.legacyInterceptorReqResOrdering ? c.unshift(p.fulfilled, p.rejected) : c.push(p.fulfilled, p.rejected);
    });
    const u = [];
    this.interceptors.response.forEach(function(p) {
      u.push(p.fulfilled, p.rejected);
    });
    let l, m = 0, b;
    if (!d) {
      const h = [Ge.bind(this), void 0];
      for (h.unshift(...c), h.push(...u), b = h.length, l = Promise.resolve(n); m < b; )
        l = l.then(h[m++], h[m++]);
      return l;
    }
    b = c.length;
    let E = n;
    for (; m < b; ) {
      const h = c[m++], p = c[m++];
      try {
        E = h(E);
      } catch (f) {
        p.call(this, f);
        break;
      }
    }
    try {
      l = Ge.call(this, E);
    } catch (h) {
      return Promise.reject(h);
    }
    for (m = 0, b = u.length; m < b; )
      l = l.then(u[m++], u[m++]);
    return l;
  }
  getUri(t) {
    t = I(this.defaults, t);
    const n = dt(t.baseURL, t.url, t.allowAbsoluteUrls);
    return ct(n, t.params, t.paramsSerializer);
  }
}
a.forEach(["delete", "get", "head", "options"], function(t) {
  oe.prototype[t] = function(n, r) {
    return this.request(I(r || {}, { method: t, url: n, data: (r || {}).data }));
  };
});
a.forEach(["post", "put", "patch"], function(t) {
  function n(r) {
    return function(o, i, c) {
      return this.request(I(c || {}, { method: t, headers: r ? { "Content-Type": "multipart/form-data" } : {}, url: o, data: i }));
    };
  }
  oe.prototype[t] = n(), oe.prototype[t + "Form"] = n(true);
});
const re = oe;
class Ce {
  constructor(t) {
    if (typeof t != "function")
      throw new TypeError("executor must be a function.");
    let n;
    this.promise = new Promise(function(o) {
      n = o;
    });
    const r = this;
    this.promise.then((s) => {
      if (!r._listeners)
        return;
      let o = r._listeners.length;
      for (; o-- > 0; )
        r._listeners[o](s);
      r._listeners = null;
    }), this.promise.then = (s) => {
      let o;
      const i = new Promise((c) => {
        r.subscribe(c), o = c;
      }).then(s);
      return i.cancel = function() {
        r.unsubscribe(o);
      }, i;
    }, t(function(o, i, c) {
      r.reason || (r.reason = new X(o, i, c), n(r.reason));
    });
  }
  throwIfRequested() {
    if (this.reason)
      throw this.reason;
  }
  subscribe(t) {
    if (this.reason) {
      t(this.reason);
      return;
    }
    this._listeners ? this._listeners.push(t) : this._listeners = [t];
  }
  unsubscribe(t) {
    if (!this._listeners)
      return;
    const n = this._listeners.indexOf(t);
    n !== -1 && this._listeners.splice(n, 1);
  }
  toAbortSignal() {
    const t = new AbortController(), n = (r) => {
      t.abort(r);
    };
    return this.subscribe(n), t.signal.unsubscribe = () => this.unsubscribe(n), t.signal;
  }
  static source() {
    let t;
    return { token: new Ce(function(s) {
      t = s;
    }), cancel: t };
  }
}
const tr = Ce;
function nr(e) {
  return function(n) {
    return e.apply(null, n);
  };
}
function rr(e) {
  return a.isObject(e) && e.isAxiosError === true;
}
const ge = { Continue: 100, SwitchingProtocols: 101, Processing: 102, EarlyHints: 103, Ok: 200, Created: 201, Accepted: 202, NonAuthoritativeInformation: 203, NoContent: 204, ResetContent: 205, PartialContent: 206, MultiStatus: 207, AlreadyReported: 208, ImUsed: 226, MultipleChoices: 300, MovedPermanently: 301, Found: 302, SeeOther: 303, NotModified: 304, UseProxy: 305, Unused: 306, TemporaryRedirect: 307, PermanentRedirect: 308, BadRequest: 400, Unauthorized: 401, PaymentRequired: 402, Forbidden: 403, NotFound: 404, MethodNotAllowed: 405, NotAcceptable: 406, ProxyAuthenticationRequired: 407, RequestTimeout: 408, Conflict: 409, Gone: 410, LengthRequired: 411, PreconditionFailed: 412, PayloadTooLarge: 413, UriTooLong: 414, UnsupportedMediaType: 415, RangeNotSatisfiable: 416, ExpectationFailed: 417, ImATeapot: 418, MisdirectedRequest: 421, UnprocessableEntity: 422, Locked: 423, FailedDependency: 424, TooEarly: 425, UpgradeRequired: 426, PreconditionRequired: 428, TooManyRequests: 429, RequestHeaderFieldsTooLarge: 431, UnavailableForLegalReasons: 451, InternalServerError: 500, NotImplemented: 501, BadGateway: 502, ServiceUnavailable: 503, GatewayTimeout: 504, HttpVersionNotSupported: 505, VariantAlsoNegotiates: 506, InsufficientStorage: 507, LoopDetected: 508, NotExtended: 510, NetworkAuthenticationRequired: 511, WebServerIsDown: 521, ConnectionTimedOut: 522, OriginIsUnreachable: 523, TimeoutOccurred: 524, SslHandshakeFailed: 525, InvalidSslCertificate: 526 };
Object.entries(ge).forEach(([e, t]) => {
  ge[t] = e;
});
const sr = ge;
function bt(e) {
  const t = new re(e), n = Ze(re.prototype.request, t);
  return a.extend(n, re.prototype, t, { allOwnKeys: true }), a.extend(n, t, null, { allOwnKeys: true }), n.create = function(s) {
    return bt(I(e, s));
  }, n;
}
const g = bt(xe);
g.Axios = re;
g.CanceledError = X;
g.CancelToken = tr;
g.isCancel = ut;
g.VERSION = yt;
g.toFormData = ue;
g.AxiosError = y;
g.Cancel = g.CanceledError;
g.all = function(t) {
  return Promise.all(t);
};
g.spread = nr;
g.isAxiosError = rr;
g.mergeConfig = I;
g.AxiosHeaders = F;
g.formToJSON = (e) => lt(a.isHTMLForm(e) ? new FormData(e) : e);
g.getAdapter = mt.getAdapter;
g.HttpStatusCode = sr;
g.default = g;
const or = g;
export {
  or as a
};
