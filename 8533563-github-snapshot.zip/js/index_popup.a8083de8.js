import { _ as p, __tla as __tla_0 } from "./index.bb04cb73.js";
import { P as d } from "./vant.f7b4805b.js";
import { u as h } from "./vuex.33ea5d58.js";
import { u as f } from "./vue-router.c227d4ba.js";
import { w as v, o as a, c as g, U as s, V as w, J as x, u as i, W as P, ao as m, l as R } from "./@vue.b00de3e9.js";
import "./axios.853f16bf.js";
import "./element-plus.53baa8a9.js";
import "./@element-plus.e21ea623.js";
import "./@ctrl.11979b50.js";
import "./dayjs.9abdbee1.js";
import "./clipboard.aaae98d3.js";
import "./@vueuse.eccd744a.js";
import "./lodash-es.e1022fb5.js";
import "./@popperjs.da591b4f.js";
import "./vue-i18n.07fcbeea.js";
import "./@intlify.928cb664.js";
import "./xe-utils.a532b55a.js";
import "./crypto-js.c184c643.js";
import "./decimal.js.2def1975.js";
import "./nprogress.9fc41f77.js";
import "./vconsole.0cfb1d33.js";
import "./perfect-scrollbar.19f80865.js";
import "./@vant.f52f09a9.js";
let K;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e) {
    }
  })()
]).then(async () => {
  K = {
    __name: "index_popup",
    setup(y) {
      const c = m(() => p(() => import("./index.f03cfe1d.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/index.f03cfe1d.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","js/index.5f74bd60.js","css/index.7003e7ca.css"])), n = m(() => p(() => import("./recharge_record_popup.41822c69.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), ["js/recharge_record_popup.41822c69.js","js/index.bb04cb73.js","js/@vue.b00de3e9.js","js/vue-router.c227d4ba.js","js/axios.853f16bf.js","js/element-plus.53baa8a9.js","js/@element-plus.e21ea623.js","js/@ctrl.11979b50.js","js/dayjs.9abdbee1.js","js/clipboard.aaae98d3.js","js/@vueuse.eccd744a.js","js/lodash-es.e1022fb5.js","js/@popperjs.da591b4f.js","css/element-plus.97a7971e.css","js/vant.f7b4805b.js","js/@vant.f52f09a9.js","css/vant.29f79a2e.css","js/vue-i18n.07fcbeea.js","js/@intlify.928cb664.js","js/vuex.33ea5d58.js","js/xe-utils.a532b55a.js","js/crypto-js.c184c643.js","js/decimal.js.2def1975.js","js/nprogress.9fc41f77.js","js/vconsole.0cfb1d33.js","js/perfect-scrollbar.19f80865.js","css/perfect-scrollbar.fbe6c729.css","css/index.13b2c741.css","css/recharge_record_popup.c63fa3f0.css"])), e = h(), _ = f(), o = R(() => e.state.showRechargeDialog);
      return v(() => _.fullPath, (t) => {
        t !== "/recharge" && (e.state.showRechargeDialog = false);
      }), (t, r) => {
        const u = d;
        return a(), g("div", null, [
          s(u, {
            show: o.value,
            "onUpdate:show": r[0] || (r[0] = (l) => o.value = l),
            position: "bottom",
            closeable: false,
            class: "recharge",
            style: {
              height: "calc(100vh - var(--browser-address-bar, 0px) - .9rem)"
            }
          }, {
            default: w(() => [
              o.value ? (a(), x(i(c), {
                key: 0,
                class: "index-popup"
              })) : P("", true)
            ]),
            _: 1
          }, 8, [
            "show"
          ]),
          s(i(n))
        ]);
      };
    }
  };
});
export {
  __tla,
  K as default
};
