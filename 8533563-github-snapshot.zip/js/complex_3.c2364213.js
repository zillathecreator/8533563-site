import { t as D, Y as R, ad as A, _ as v, aR as M, __tla as __tla_0 } from "./index.bb04cb73.js";
import { a9 as E, o, c as a, a as t, U as m, W as i, u as s, _ as l, a3 as k, J as V, ao as y, r as c, l as N } from "./@vue.b00de3e9.js";
import { u as P } from "./vuex.33ea5d58.js";
import { u as O, b as j } from "./vue-router.c227d4ba.js";
import { u as z, __tla as __tla_1 } from "./index.5f74bd60.js";
import "./axios.853f16bf.js";
import "./element-plus.53baa8a9.js";
import "./@element-plus.e21ea623.js";
import "./@ctrl.11979b50.js";
import "./dayjs.9abdbee1.js";
import "./clipboard.aaae98d3.js";
import "./@vueuse.eccd744a.js";
import "./lodash-es.e1022fb5.js";
import "./@popperjs.da591b4f.js";
import "./vant.f7b4805b.js";
import "./@vant.f52f09a9.js";
import "./vue-i18n.07fcbeea.js";
import "./@intlify.928cb664.js";
import "./xe-utils.a532b55a.js";
import "./crypto-js.c184c643.js";
import "./decimal.js.2def1975.js";
import "./nprogress.9fc41f77.js";
import "./vconsole.0cfb1d33.js";
import "./perfect-scrollbar.19f80865.js";
let Le;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch (e) {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch (e) {
    }
  })()
]).then(async () => {
  let W, G, H, F, J, U, Y, Z, q, K, Q, X, ee, se, te, oe;
  W = {
    class: "dark-headerMenu-left"
  };
  G = {
    class: "navIcon"
  };
  H = {
    class: "logoBox"
  };
  F = [
    "src"
  ];
  J = {
    class: "dark-headerMenu-right"
  };
  U = {
    key: 0,
    class: "balanceBox"
  };
  Y = {
    class: "imgBox"
  };
  Z = [
    "src"
  ];
  q = {
    key: 1
  };
  K = {
    key: 1,
    class: "selectBox"
  };
  Q = {
    class: "text"
  };
  X = {
    key: 2,
    class: "btnBox"
  };
  ee = {
    key: 0,
    class: "normal-festival-header"
  };
  se = [
    "src"
  ];
  te = [
    "src"
  ];
  oe = [
    "src"
  ];
  Le = {
    __name: "complex_3",
    setup(ae, { expose: B }) {
      const x = y(() => v(() => import("./index.829d73d9.js"), ["js/index.829d73d9.js","js/@vue.b00de3e9.js","js/img_xzapp_jl.d99abebb.js","js/vuex.33ea5d58.js","css/index.1e446410.css"])), C = y(() => v(() => import("./wg_search.f2b75fe6.js"), ["js/wg_search.f2b75fe6.js","js/@vue.b00de3e9.js"])), { balanceAmount: w, animationBalance: re } = z(), e = P(), _ = c(null);
      O();
      const u = j(), d = c(0), g = c(null), $ = c(null), h = N(() => e.state.logos.find((r) => r.alias === "homeLogo")), I = (n) => {
        n ? _.value.style.top = M : _.value.style.top = 0;
      }, S = () => {
        globalVBus.$emit("openSideBar"), e.state.showSideBar = !e.state.showSideBar;
      }, b = () => {
        d.value += 720, g.value.style.transform = "rotateZ(".concat(d.value, "deg)"), e.dispatch("refreshBalance", true), e.state.refreshBalance = true, setTimeout(() => {
          e.state.refreshBalance = false;
        }, 500);
      }, T = () => {
        e.state.showLoginDialog = true, e.state.loginType = "login";
      }, L = () => {
        e.state.showLoginDialog = true, e.state.loginType = "register";
      };
      return B({
        setTop: I
      }), (n, r) => {
        var _a, _b, _c, _d, _e, _f, _g;
        const p = E("svg-icon");
        return o(), a("div", {
          class: "dark-headerMenu",
          ref_key: "headerMenu",
          ref: _
        }, [
          t("div", {
            class: "headerMenu-bgBox",
            ref_key: "headerBgBox",
            ref: $
          }, [
            t("div", W, [
              t("div", G, [
                m(p, {
                  iconClass: "wg_pink_header_menu",
                  class: "slideIcon",
                  onClick: S
                })
              ]),
              t("div", H, [
                h.value ? (o(), a("img", {
                  key: 0,
                  src: h.value.icon,
                  class: "logoIcon"
                }, null, 8, F)) : i("", true)
              ])
            ]),
            t("div", J, [
              s(D)() ? (o(), a("div", U, [
                t("div", Y, [
                  t("img", {
                    src: s(R)(),
                    class: "countryIcon"
                  }, null, 8, Z)
                ]),
                s(e).state.accountInfo.username ? (o(), a("span", {
                  key: 0,
                  class: "balanceAmount",
                  onClick: r[0] || (r[0] = (f) => s(u).push("/account?tabId=4"))
                }, l(s(e).state.refreshBalance ? "Loading" : s(A)(s(w) || 0)), 1)) : (o(), a("span", q, l(s(e).state.metaConfig.currency[0].label), 1)),
                s(e).state.accountInfo.username ? (o(), a("div", {
                  key: 2,
                  ref_key: "refreshRef",
                  ref: g,
                  class: "refreshIcon",
                  onClick: b
                }, [
                  m(p, {
                    iconClass: "wg_header_refresh"
                  })
                ], 512)) : i("", true)
              ])) : i("", true),
              s(e).state.accountInfo.username ? (o(), a("div", K, [
                t("div", {
                  class: "selectBox-btn",
                  onClick: r[1] || (r[1] = (f) => s(u).push("recharge"))
                }, [
                  t("div", Q, [
                    t("span", null, l(n.$t("recharge.recharge")), 1)
                  ])
                ])
              ])) : (o(), a("div", X, [
                t("div", {
                  class: "login",
                  onClick: k(T, [
                    "stop"
                  ])
                }, [
                  t("span", null, l(n.$t("login.login")), 1)
                ]),
                t("div", {
                  class: "register",
                  onClick: k(L, [
                    "stop"
                  ])
                }, [
                  t("span", null, l(n.$t("login.register4")), 1),
                  s(e).state.task_register_reward ? (o(), V(s(x), {
                    key: 0,
                    text: "+" + s(e).state.task_register_reward,
                    bgColor: "var(--skin__accent_1)",
                    auto: true,
                    top: "-.2rem",
                    left: "50%",
                    right: "auto"
                  }, null, 8, [
                    "text"
                  ])) : i("", true)
                ])
              ])),
              t("i", {
                class: "search-box",
                onClick: r[2] || (r[2] = (f) => s(u).push("/home/search"))
              }, [
                m(s(C), {
                  class: "svg-icon search"
                })
              ])
            ]),
            ((_a = s(e).state.festivalStyle) == null ? void 0 : _a.show) ? (o(), a("div", ee, [
              t("img", {
                src: "/img_wg/festivalTheme/skin".concat((_b = s(e).state.festivalStyle) == null ? void 0 : _b.skin, "/theme").concat((_c = s(e).state.festivalStyle) == null ? void 0 : _c.style, "/h5_zs_jr.png"),
                class: "left"
              }, null, 8, se),
              t("img", {
                src: "/img_wg/festivalTheme/skin".concat((_d = s(e).state.festivalStyle) == null ? void 0 : _d.skin, "/theme").concat((_e = s(e).state.festivalStyle) == null ? void 0 : _e.style, "/h5_zs_jr3.png"),
                class: "center"
              }, null, 8, te),
              t("img", {
                src: "/img_wg/festivalTheme/skin".concat((_f = s(e).state.festivalStyle) == null ? void 0 : _f.skin, "/theme").concat((_g = s(e).state.festivalStyle) == null ? void 0 : _g.style, "/h5_zs_jr2.png"),
                class: "right"
              }, null, 8, oe)
            ])) : i("", true)
          ], 512)
        ], 512);
      };
    }
  };
});
export {
  __tla,
  Le as default
};
